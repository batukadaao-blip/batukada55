import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
  try {
    const urlObj = new URL(url);
    url = urlObj.origin;
  } catch (e) {
    url = url.replace(/\/+$/, '');
  }
}

if (url && key) {
  const supabase = createClient(url, key);
  
  // Choose arbitrary query to check listing of tables
  // We can select table_name from information_schema.tables where table_schema='public'
  // But wait! Can we execute any query to list tables? Yes, we can try to query common tables or query definitions.
  // Wait, let's try to fetch a row from various possible table names to see if they exist or fail with relation does not exist!
  const possibleTables = [
    'profiles', 'beats', 'favorites', 'orders', 'order_items', 'purchased_beats', 'wallets', 'wallet', 'wallet_transactions', 'platform_wallet', 'transactions', 'accounts', 'user_wallets', 'producer_banking_info'
  ];
  
  for (const table of possibleTables) {
    const { data, error } = await supabase.from(table).select('*').limit(1);
    if (!error) {
      console.log(`Table '${table}' exists! Sample:`, data);
      if (data && data.length > 0) {
        console.log(`Columns for '${table}':`, Object.keys(data[0]));
        // Print the type of id or beat_id
        if ('id' in data[0]) {
          console.log(`- Type of 'id' in ${table}:`, typeof data[0].id);
        }
        if ('beat_id' in data[0]) {
          console.log(`- Type of 'beat_id' in ${table}:`, typeof data[0].beat_id);
        }
      }
    } else {
      if (error.message.includes('does not exist')) {
        // Table doesn't exist
      } else {
        console.log(`Table '${table}' exists but query failed:`, error.message);
      }
    }
  }
}
