import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let supabaseUrl = process.env.VITE_SUPABASE_URL || '';
let serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !serviceKey) {
  console.error("Missing config!");
} else {
  supabaseUrl = supabaseUrl.trim().replace(/^["'](.+)["']$/, '$1');
  if (supabaseUrl.startsWith('http')) {
    try {
      const urlObj = new URL(supabaseUrl);
      supabaseUrl = urlObj.origin;
    } catch (e) {
      supabaseUrl = supabaseUrl.replace(/\/+$/, '');
    }
  }

  const supabase = createClient(supabaseUrl, serviceKey);

  async function check() {
    console.log("Checking profiles table...");
    const { data, error } = await supabase.from('profiles').select('id, username, display_name, artistic_name, role');
    if (error) {
      console.log('Error querying profiles table:', error.code, error.message);
    } else {
      console.log('Registered profiles total:', data?.length);
      console.log(JSON.stringify(data, null, 2));
    }
  }
  check();
}
