import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url && key) {
  const supabase = createClient(url, key);
  const candidates = [
    'exec', 'execute', 'run', 'eval_sql', 'eval', 'postgres_query', 'pg_query', 'system_query', 'raw_query', 'sql', 'run_query'
  ];
  for (const name of candidates) {
    try {
      const { data, error } = await supabase.rpc(name, { query: 'SELECT 1;' });
      if (!error) {
        console.log(`RPC ${name} (query) worked! Result:`, data);
        continue;
      }
    } catch (e) {}
    try {
      const { data, error } = await supabase.rpc(name, { sql: 'SELECT 1;' });
      if (!error) {
        console.log(`RPC ${name} (sql) worked! Result:`, data);
        continue;
      }
    } catch (e) {}
  }
}
