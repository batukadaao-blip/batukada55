import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

async function run() {
  let cleanedUrl = url;
  if (cleanedUrl) {
    if (!cleanedUrl.startsWith('http')) {
      cleanedUrl = `https://${cleanedUrl}`;
    }
    try {
      const urlObj = new URL(cleanedUrl);
      cleanedUrl = urlObj.origin;
    } catch (e) {
      cleanedUrl = cleanedUrl.replace(/\/+$/, '');
    }
  }
  const supabase = createClient(cleanedUrl, key);
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .limit(10);
  if (error) {
    console.error('Error fetching profiles:', error);
  } else {
    console.log('Profiles rows count:', data ? data.length : 0);
    if (data && data.length > 0) {
      data.forEach((p, index) => {
        console.log(`[PROFILE #${index}]`, {
          id: p.id,
          username: p.username,
          artistic_name: p.artistic_name,
          display_name: p.display_name,
          avatar_url: p.avatar_url,
          role: p.role
        });
      });
    } else {
      console.log('No profiles found in table');
    }
  }
}
run();
