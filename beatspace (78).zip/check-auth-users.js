import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let supabaseUrl = process.env.VITE_SUPABASE_URL || '';
if (supabaseUrl.endsWith('/rest/v1/')) {
  supabaseUrl = supabaseUrl.replace('/rest/v1/', '');
} else if (supabaseUrl.endsWith('/rest/v1')) {
  supabaseUrl = supabaseUrl.replace('/rest/v1', '');
}

const supabase = createClient(supabaseUrl, process.env.SUPABASE_SERVICE_ROLE_KEY || '');

async function checkAuthUsers() {
  console.log('Querying auth.users via service role...');
  try {
    // Note: auth.users can be queried directly via admin API or RPC/SQL
    const { data: users, error } = await supabase.auth.admin.listUsers();
    if (error) {
      console.error('Error listing auth users:', error);
    } else {
      console.log(`Auth users count: ${users?.users?.length || 0}`);
      users?.users?.forEach(u => {
        console.log(` - User in auth: ID=${u.id}, email=${u.email}`);
      });
    }
  } catch (err) {
    console.error('Exception querying auth users:', err);
  }
}

checkAuthUsers();
