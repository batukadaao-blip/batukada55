import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
  try {
    const urlObj = new URL(url);
    url = urlObj.origin;
  } catch (e) {
    url = url.replace(/\/+$/, '');
  }
}

if (url && key) {
  const supabase = createClient(url, key);
  
  const testRPCs = ['exec_sql', 'run_sql', 'execute_sql', 'sql_query', 'query'];
  for (const rpcName of testRPCs) {
    console.log(`Testing RPC: ${rpcName}...`);
    try {
      const { data, error } = await supabase.rpc(rpcName, { sql: 'SELECT 1 as val;' });
      if (!error) {
        console.log(`  Success! RPC ${rpcName} returned:`, data);
        continue;
      } else {
        console.log(`  Failed ${rpcName} with code ${error.code}: ${error.message}`);
      }
    } catch (e) {
      console.log(`  Threw exception for ${rpcName}:`, e.message);
    }

    try {
      const { data, error } = await supabase.rpc(rpcName, { query: 'SELECT 1 as val;' });
      if (!error) {
        console.log(`  Success (query arg)! RPC ${rpcName} returned:`, data);
        continue;
      } else {
        console.log(`  Failed (query arg) ${rpcName} with code ${error.code}: ${error.message}`);
      }
    } catch (e) {
      console.log(`  Threw exception (query arg) for ${rpcName}:`, e.message);
    }
  }
}
