import { Beat, Producer } from './types';

export const beats: Beat[] = [
  {
    id: 'b1',
    title: 'Afro Soul Vibe',
    producer: 'Jay M Beats',
    genre: 'Afro-Trap',
    price: {
      basic: 15000,
      premium: 35000,
      exclusive: 150000
    },
    image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=400&auto=format&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    bpm: 105
  },
  {
    id: 'b2',
    title: 'Midnight in Luanda',
    producer: 'Jay M Beats',
    genre: 'Kizomba',
    price: {
      basic: 12000,
      premium: 28000,
      exclusive: 120000
    },
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=400&auto=format&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    bpm: 92
  }
];

export const producers: Producer[] = [
  {
    id: '1',
    name: 'Jay M Beats',
    tagline: 'O arquiteto do som de Luanda',
    bio: 'Produtor Multi-Platina baseado em Luanda, Angola. Especialista em Afro-Trap, Kizomba Moderno e R&B. Com mais de 10 anos de experiência, já trabalhou com os maiores nomes da música Angolana.',
    avatar: '',
    banner: '',
    followers: 12500,
    following: 342,
    totalBeats: 48,
    totalPlays: '4.2M',
    isVerified: true,
    location: 'Luanda, Angola',
    joinDate: 'Janeiro 2022',
    genres: ['Afro-Trap', 'Kizomba', 'Hip Hop'],
    socials: {
      instagram: 'https://instagram.com',
      youtube: 'https://youtube.com',
      spotify: 'https://spotify.com'
    },
    equipment: ['FL Studio 21', 'Apollo Twin X', 'Yamaha HS8', 'Kontakt 7']
  },
  {
    id: '2',
    name: 'Dany Beats',
    tagline: 'Waves from the South',
    bio: 'Focado em vibes melódicas e percussões rítmicas. Transformo ideias em hits globais.',
    avatar: '',
    banner: '',
    followers: 8200,
    following: 156,
    totalBeats: 32,
    totalPlays: '1.8M',
    isVerified: true,
    location: 'Benguela, Angola',
    joinDate: 'Março 2023',
    genres: ['Kuduro', 'Amapiano', 'Afro-House'],
    socials: {
      instagram: 'https://instagram.com',
      youtube: 'https://youtube.com'
    },
    equipment: ['Ableton Live 11', 'Logic Pro X', 'Komplete 14']
  }
];
