import { useEffect, useState, useRef } from 'react';
import { io, Socket } from 'socket.io-client';

export function useChat(userId: string | undefined) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [conversations, setConversations] = useState<any[]>([]);
  const [typingStatus, setTypingStatus] = useState<Record<string | number, boolean>>({});
  const [unreadCount, setUnreadCount] = useState(0);
  const [activeConversationId, setActiveConversationId] = useState<string | number | null>(null);
  
  const activeConvIdRef = useRef<string | number | null>(null);

  useEffect(() => {
    activeConvIdRef.current = activeConversationId;
  }, [activeConversationId]);

  useEffect(() => {
    if (!userId) return;

    const socketUrl = window.location.origin && window.location.origin !== 'null' ? window.location.origin : '';
    const newSocket = io(socketUrl, {
      query: { userId }
    });

    setSocket(newSocket);

    newSocket.on('new_message', (message) => {
      const activeId = activeConvIdRef.current;
      if (activeId && String(message.conversation_id) === String(activeId)) {
        setMessages((prev) => {
          if (prev.some(m => m.id === message.id)) return prev;
          return [...prev, message];
        });
      } else {
        setUnreadCount((prev) => prev + 1);
      }
      // Fetch updated conversations to show latest snippet
      fetchConversations();
    });

    newSocket.on('message_sent', (message) => {
      const activeId = activeConvIdRef.current;
      if (activeId && String(message.conversation_id) === String(activeId)) {
        setMessages((prev) => {
          if (prev.some(m => m.id === message.id)) return prev;
          return [...prev, message];
        });
      }
      fetchConversations();
    });

    newSocket.on('user_typing', ({ conversationId, isTyping }) => {
      setTypingStatus((prev) => ({ ...prev, [conversationId]: isTyping }));
    });

    fetchConversations();

    return () => {
      newSocket.disconnect();
    };
  }, [userId]);

  const fetchConversations = async () => {
    if (!userId) return;
    const url = `/api/conversations?userId=${userId}`;
    try {
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status} when fetching ${url}`);
      }
      const data = await res.json();
      
      if (!Array.isArray(data)) {
        console.error("Conversations data is not an array:", data);
        setConversations([]);
        setUnreadCount(0);
        return;
      }

      setConversations(data);
      
      // Calculate unread
      const totalUnread = data.reduce((acc: number, conv: any) => {
        const unreadInConv = conv.messages?.filter((m: any) => !m.is_read && m.sender_id !== userId).length || 0;
        return acc + unreadInConv;
      }, 0);
      setUnreadCount(totalUnread);
    } catch (err) {
      console.error("Failed to fetch conversations:", { url, error: err });
    }
  };

  const deleteConversation = async (conversationId: string | number) => {
    // 1. Immediately update UI state (remover da lista sem refresh)
    setConversations((prev) => prev.filter((c) => String(c.id) !== String(conversationId)));
    if (activeConversationId && String(activeConversationId) === String(conversationId)) {
      setActiveConversationId(null);
      setMessages([]);
    }

    // 2. Perform server API call to delete underlying database and message records
    try {
      const res = await fetch(`/api/conversations/${conversationId}`, {
        method: "DELETE"
      });
      if (!res.ok) {
        throw new Error(`Failed to delete conversation: status ${res.status}`);
      }
      console.log(`[useChat] Conversation ${conversationId} deleted successfully on server.`);
    } catch (err) {
      console.error("[useChat] Error deleting conversation from backend:", err);
      // Re-fetch list as safety fallback in case delete failed on server
      fetchConversations();
    }
  };

  const sendMessage = (toUserId: string, content: string, conversationId: string | number) => {
    if (socket) {
      socket.emit('private_message', { toUserId, content, conversationId, senderId: userId });
    }

    // Track message_sent event
    try {
      import('@/src/lib/analytics').then(m => {
        m.trackAnalyticsEvent('message_sent', {
          producerId: toUserId,
          userId: userId || undefined,
          metadata: { conversationId, contentLength: content.length }
        });
      });
    } catch (err) {
      console.error("[ANALYTICS] Message tracking error:", err);
    }
  };

  const sendTyping = (toUserId: string, conversationId: string | number, isTyping: boolean) => {
    if (socket) {
      socket.emit('typing', { toUserId, conversationId, isTyping });
    }
  };

  return { 
    socket, 
    messages, 
    setMessages,
    conversations, 
    setConversations,
    typingStatus, 
    unreadCount, 
    activeConversationId,
    setActiveConversationId,
    sendMessage, 
    sendTyping,
    deleteConversation,
    fetchConversations 
  };
}
