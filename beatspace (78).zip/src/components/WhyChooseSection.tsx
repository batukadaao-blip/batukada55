import React from 'react';
import { Shield, Zap, FileText, Store, Users, Search, Headphones, CheckCircle } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Proteção Total',
    description: 'Seu dinheiro fica seguro até o recebimento completo do beat.',
    items: ['Pagamento seguro', 'Garantia de entrega', 'Suporte dedicado'],
    className: 'bg-[#0c0c12]/60 md:col-span-1'
  },
  {
    icon: Zap,
    title: 'Download Instantâneo',
    description: 'Pague e baixe os arquivos na hora. Sem espera, sem complicação.',
    items: ['Arquivos WAV e MP3', 'Stems separados', 'Alta qualidade'],
    className: 'bg-[#0c0c12]/60 md:col-span-1'
  },
  {
    icon: FileText,
    title: 'Contratos Prontos',
    description: 'Termos de uso gerados automaticamente para cada transação.',
    items: ['Licenças claras', 'Sem burocracy', '100% legal'],
    className: 'bg-[#0c0c12]/60 md:col-span-1'
  }
];

const smallFeatures = [
  { icon: Store, title: 'Marketplace Completo', description: 'Milhares de beats de produtores angolanos e internacionais.' },
  { icon: Users, title: 'Comunidade Ativa', description: 'Conecte-se com artistas e produtores de Angola inteira.' },
  { icon: Search, title: 'Busca Inteligente', description: 'Filtros por gênero, BPM, tonalidade e muito mais.' },
  { icon: Headphones, title: 'Suporte Rápido', description: 'Equipe pronta para ajudar você em qualquer momento.' },
];

export default function WhyChooseSection() {
  return (
    <section className="mt-14 py-10 border-t border-white/[0.04]">
      <div className="text-center mb-8">
        <h3 className="text-gray-400 font-bold text-[10px] uppercase tracking-wider mb-1.5">Segurança e Praticidade</h3>
        <h2 className="text-2xl md:text-3xl font-black text-white tracking-tight">Por que escolher a Batukada</h2>
      </div>

      <div className="grid md:grid-cols-3 gap-5 mb-5">
        {features.map((feature, idx) => (
          <div key={idx} className={`p-5 rounded-xl border border-white/[0.04] bg-[#0c0c12]/80 hover:border-white/[0.08] transition-all duration-200`}>
            <feature.icon className="w-6 h-6 text-[#5865F2] mb-4" />
            <h4 className="text-base font-bold text-white mb-1.5">{feature.title}</h4>
            <p className="text-gray-400 text-xs mb-4 leading-relaxed">{feature.description}</p>
            <ul className="space-y-2">
              {feature.items.map((item, i) => (
                <li key={i} className="flex items-center text-gray-300 text-xs gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-[#5865F2]" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
        {smallFeatures.map((feature, idx) => (
          <div key={idx} className="bg-[#0c0c12]/40 border border-white/[0.04] p-4 rounded-xl hover:bg-[#12121c]/60 hover:border-white/[0.08] transition-all duration-200">
            <feature.icon className="w-5 h-5 text-[#5865F2] mb-3" />
            <h4 className="font-bold text-white text-xs mb-1">{feature.title}</h4>
            <p className="text-gray-500 text-[11px] leading-relaxed">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
