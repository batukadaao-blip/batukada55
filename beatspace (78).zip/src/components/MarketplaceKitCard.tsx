import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Beat } from '../types';
import { Package, Heart, User, ListMusic, ShieldCheck, Download, ShoppingCart, X } from 'lucide-react';
import VerifiedBadge from './VerifiedBadge';
import { motion, AnimatePresence } from 'motion/react';
import { getSupabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

interface MarketplaceKitCardProps {
  kit: Beat & { type?: 'beat' | 'kit'; category?: string };
  onAddToCart: (kit: Beat) => void;
  onSelectProducer?: (producerName: string) => void;
  onSelectBeat?: (beat: Beat) => void;
}

// Shared caches across all MarketplaceKitCard instances (avoids massive parallel duplicate database requests)
const producerVerificationCache = new Map<string, boolean>();
const activeVerificationPromises = new Map<string, Promise<boolean>>();

const userFavoriteCache = new Map<string, boolean>();
const activeFavoritePromises = new Map<string, Promise<boolean>>();

function MarketplaceKitCard({ kit, onAddToCart, onSelectProducer, onSelectBeat }: MarketplaceKitCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const supabase = getSupabase();
  const { user } = useAuth();
  const [isProducerVerified, setIsProducerVerified] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    const cacheKey = kit.producer_id || kit.producer_name || kit.producer;
    if (!cacheKey) return;

    if (producerVerificationCache.has(cacheKey)) {
      setIsProducerVerified(producerVerificationCache.get(cacheKey)!);
      return;
    }

    if (activeVerificationPromises.has(cacheKey)) {
      activeVerificationPromises.get(cacheKey)!.then(val => {
        setIsProducerVerified(val);
      });
      return;
    }

    const fetchVerification = async (): Promise<boolean> => {
      try {
        let query = supabase.from('profiles').select('is_verified');
        if (kit.producer_id) {
          query = query.eq('id', kit.producer_id);
        } else {
          query = query.eq('display_name', kit.producer_name || kit.producer);
        }
        const { data } = await query.maybeSingle();
        const verified = !!data?.is_verified;
        producerVerificationCache.set(cacheKey, verified);
        return verified;
      } catch (err) {
        console.warn('Silent skip verification fetch:', err);
        return false;
      }
    };

    const promise = fetchVerification();
    activeVerificationPromises.set(cacheKey, promise);
    promise.then(val => {
      setIsProducerVerified(val);
      activeVerificationPromises.delete(cacheKey);
    });
  }, [supabase, kit.producer_id, kit.producer, kit.producer_name]);

  useEffect(() => {
    if (!supabase) return;

    const kitIdStr = String(kit.id);
    let queryBeatId = kitIdStr;
    if (/^\d+$/.test(queryBeatId)) {
      const padded = queryBeatId.padStart(12, '0');
      queryBeatId = `00000000-0000-0000-0000-${padded}`;
    }

    if (userFavoriteCache.has(queryBeatId)) {
      setIsFavorited(userFavoriteCache.get(queryBeatId)!);
      return;
    }

    if (activeFavoritePromises.has(queryBeatId)) {
      activeFavoritePromises.get(queryBeatId)!.then(val => {
        setIsFavorited(val);
      });
      return;
    }

    const checkFavorite = async (): Promise<boolean> => {
      try {
        const { data: { user: currentUser } } = await supabase.auth.getUser();
        if (!currentUser) return false;

        const { data, error } = await supabase
          .from('favorites')
          .select('beat_id')
          .eq('user_id', currentUser.id)
          .eq('beat_id', queryBeatId);

        if (error) return false;
        const exists = !!(data && data.length > 0);
        userFavoriteCache.set(queryBeatId, exists);
        return exists;
      } catch (e) {
        return false;
      }
    };

    const promise = checkFavorite();
    activeFavoritePromises.set(queryBeatId, promise);
    promise.then(val => {
      setIsFavorited(val);
      activeFavoritePromises.delete(queryBeatId);
    });

    const handleFavChange = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && String(customEvent.detail.beatId) === kitIdStr) {
        setIsFavorited(customEvent.detail.isFavorited);
        userFavoriteCache.set(queryBeatId, customEvent.detail.isFavorited);
      }
    };

    window.addEventListener('favoriteStatusChanged', handleFavChange);
    return () => {
      window.removeEventListener('favoriteStatusChanged', handleFavChange);
    };
  }, [supabase, kit.id]);

  const toggleFavorite = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!supabase) return;

    const { data: { user: currentUser }, error: userError } = await supabase.auth.getUser();
    if (userError || !currentUser) return;

    const userId = currentUser.id;
    let queryBeatId = String(kit.id);
    if (/^\d+$/.test(queryBeatId)) {
      const padded = queryBeatId.padStart(12, '0');
      queryBeatId = `00000000-0000-0000-0000-${padded}`;
    }

    try {
      if (isFavorited) {
        const { error } = await supabase
          .from('favorites')
          .delete()
          .eq('user_id', userId)
          .eq('beat_id', queryBeatId);

        if (!error) {
          setIsFavorited(false);
          userFavoriteCache.set(queryBeatId, false);
          window.dispatchEvent(new CustomEvent('favoriteStatusChanged', { detail: { beatId: kit.id, isFavorited: false } }));
        }
      } else {
        const numericId = Number(kit.id);
        const { data: beatRecord } = await supabase
          .from('beats')
          .select('id')
          .eq('id', numericId)
          .maybeSingle();

        if (beatRecord) {
          const { error } = await supabase
            .from('favorites')
            .insert({ user_id: userId, beat_id: queryBeatId });

          if (!error) {
            setIsFavorited(true);
            userFavoriteCache.set(queryBeatId, true);
            window.dispatchEvent(new CustomEvent('favoriteStatusChanged', { detail: { beatId: kit.id, isFavorited: true } }));
          }
        }
      }
    } catch (error) {
      console.error('[FAVORITE] Error toggling favorite:', error);
    }
  };

  const isFree = kit.is_free_download || kit.price?.basic === 0 || kit.price?.basic === null || kit.price?.basic === undefined;

  return (
    <motion.div 
      whileHover={{ y: -4 }}
      onClick={() => onSelectBeat ? onSelectBeat(kit) : setShowDetails(true)}
      className="group relative bg-[#0c0c12]/65 border border-white/[0.04] rounded-2xl p-3.5 transition-all hover:bg-[#12121c]/90 hover:border-white/[0.08] hover:shadow-xl cursor-pointer"
    >
      {/* Artwork Section */}
      <div className="relative aspect-square overflow-hidden rounded-xl mb-3.5 bg-[#07070a] group-hover:shadow-[0_8px_24px_rgba(0,0,0,0.6)] transition-all">
        <img 
          src={kit.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400'} 
          alt={kit.title} 
          loading="lazy"
          className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105" 
          onError={(e) => {
            e.currentTarget.onerror = null;
            e.currentTarget.src = 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400';
          }}
        />
        
        {isFree && (
          <div className="absolute top-3 left-3 px-2 py-0.5 bg-[#5865F2] text-white text-[9px] font-bold tracking-tight rounded shadow-md z-10">
            Gratuito
          </div>
        )}
        
        {/* Overlay Action */}
        <div className="absolute inset-0 bg-black/55 md:opacity-0 md:group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 backdrop-blur-xs">
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (onSelectBeat) {
                onSelectBeat(kit);
              } else {
                setShowDetails(true);
              }
            }}
            className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-lg"
          >
            <Package className="w-5 h-5" />
          </motion.button>

          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (onSelectBeat) {
                onSelectBeat(kit);
              } else {
                setShowDetails(true);
              }
            }}
            className="px-2.5 py-1 bg-black/70 hover:bg-[#5865F2] hover:text-white transition-all rounded text-white font-medium text-[10px]"
          >
            Ver Detalhes
          </button>
        </div>

        {/* Kit Category Badge */}
        <div className="absolute top-3 right-3 bg-black/65 backdrop-blur-md px-2 py-0.5 rounded border border-white/5 flex items-center gap-1">
          <Package size={9} className="text-blue-400" />
          <span className="text-[10px] font-medium text-gray-300 tracking-tight">{kit.category || 'Kit'}</span>
        </div>
      </div>

      {/* Info Section */}
      <div className="space-y-2 px-0.5">
        <div className="flex justify-between items-start gap-2">
          <div className="overflow-hidden flex-1">
            <h3 
              onClick={(e) => {
                if (onSelectBeat) {
                  e.stopPropagation();
                  onSelectBeat(kit);
                }
              }}
              className="text-sm font-bold text-white tracking-tight truncate leading-tight hover:text-[#5865F2] transition-colors"
            >
              {kit.title}
            </h3>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onSelectProducer?.(kit.producer_username || kit.producer_name || kit.producer || 'Unknown Producer');
              }} 
              className="group/prod flex items-center gap-1 text-gray-400 text-[10px] font-medium hover:text-white transition-colors py-0.5"
            >
              <User size={9} className="text-gray-500" />
              <span className="truncate">@{kit.producer_username || kit.producer_name || kit.producer || 'Unknown Producer'}</span>
              {isProducerVerified && (
                <VerifiedBadge size="sm" />
              )}
            </button>
          </div>
          <div className="flex items-center shrink-0">
            <button
              onClick={(e) => {
                e.stopPropagation();
                window.dispatchEvent(new CustomEvent('showAddToPlaylist', { detail: { beat: kit } }));
              }}
              className="text-gray-500 hover:text-[#5865F2] transition-colors p-1"
              title="Adicionar à Playlist"
            >
              <ListMusic size={16} />
            </button>
            <button 
              onClick={toggleFavorite}
              className={`${isFavorited ? 'text-rose-500' : 'text-gray-500 hover:text-rose-500'} transition-colors p-1`}
            >
              <Heart className="w-[16px] h-[16px]" fill={isFavorited ? 'currentColor' : 'none'} />
            </button>
          </div>
        </div>

        {/* Tags */}
        <div className="flex gap-1 flex-wrap">
          <span className="text-[9px] font-medium text-gray-400 bg-white/5 px-2 py-0.5 rounded">{kit.genre}</span>
          <span className="text-[9px] font-medium text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded">Sound Kit</span>
        </div>
        
        {/* Price & Action */}
        <div className="flex items-center justify-between pt-2 border-t border-white/[0.04]">
          <div className="flex flex-col text-left">
            {isFree ? (
              <span className="text-xs font-black text-[#5865F2]">Gratuito</span>
            ) : (
              <>
                <span className="text-[9px] text-gray-500 leading-none mb-0.5">Preço do Kit</span>
                <span className="text-sm font-bold text-white tracking-tight">
                  {typeof kit.price === 'object' && kit.price !== null
                    ? (kit.price.basic !== undefined && kit.price.basic !== null ? Number(kit.price.basic).toLocaleString('pt-AO') : '0')
                    : Number(kit.price || 0).toLocaleString('pt-AO')}{' '}
                  <span className="text-[10px] text-[#5865F2] font-semibold">Kz</span>
                </span>
              </>
            )}
          </div>

          {user?.id === kit.producer_id ? (
            <div className="text-[9px] font-medium text-gray-500 text-center truncate max-w-[100px] px-2">
              Artigo Próprio
            </div>
          ) : isFree ? (
            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={(e) => {
                e.stopPropagation();
                const downloadUrl = kit.demo_url || kit.master_url || kit.audioUrl;
                if (downloadUrl) {
                  const a = document.createElement('a');
                  a.href = downloadUrl;
                  a.download = `${kit.title || 'SoundKit'}.zip`;
                  a.target = '_blank';
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                } else {
                  if (onSelectBeat) {
                    onSelectBeat(kit);
                  } else {
                    setShowDetails(true);
                  }
                }
              }}
              className="px-2.5 h-8 rounded-lg bg-[#5865F2]/20 border border-[#5865F2]/20 flex items-center justify-center gap-1 text-[#5865F2] hover:bg-[#5865F2] hover:text-white transition-all mr-1.5"
            >
              <Download size={11} />
              <span className="font-bold text-[10px]">Baixar</span>
            </motion.button>
          ) : (
            <div className="flex items-center gap-1">
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={(e) => {
                  e.stopPropagation();
                  if (onSelectBeat) {
                    onSelectBeat(kit);
                  } else {
                    window.dispatchEvent(new CustomEvent('showCheckout', { detail: kit }));
                  }
                }}
                className="px-3 h-8 rounded-lg bg-[#5865F2] text-white text-[10px] font-bold hover:bg-[#4752C4] transition-all"
              >
                Comprar
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToCart(kit);
                }}
                className="w-8 h-8 rounded-lg bg-white/5 border border-white/5 flex items-center justify-center text-gray-400 hover:bg-[#5865F2]/10 hover:text-[#5865F2] transition-all"
              >
                <ShoppingCart className="w-4 h-4" />
              </motion.button>
            </div>
          )}
        </div>
      </div>

      {createPortal(
        <AnimatePresence>
          {showDetails && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
              onClick={() => setShowDetails(false)}
            >
              <motion.div 
                initial={{ scale: 0.95, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 20 }}
                className="relative w-full max-w-xl bg-[#0F0F15] border border-white/10 rounded-[2.5rem] p-6 md:p-8 overflow-hidden shadow-2xl text-left"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button 
                  onClick={() => setShowDetails(false)}
                  className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <X size={20} />
                </button>

                <div className="grid md:grid-cols-2 gap-8 items-start mt-4">
                  {/* Artwork */}
                  <div className="space-y-4">
                    <div className="aspect-square rounded-[2rem] overflow-hidden border border-white/5 bg-[#0a0a0f]">
                      <img src={kit.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400'} alt={kit.title} className="w-full h-full object-cover" />
                    </div>
                  </div>

                  {/* Details */}
                  <div className="space-y-6">
                    <div>
                      <span className="text-blue-500 text-[10px] font-black uppercase tracking-widest italic">{kit.genre} • SOUND KIT</span>
                      <h2 className="text-xl md:text-2xl font-black text-white uppercase italic tracking-tighter leading-none mt-1">{kit.title}</h2>
                      <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest mt-2 flex items-center gap-1.5 flex-wrap">
                        <span>Produtor:</span>
                        <button 
                          onClick={() => {
                            onSelectProducer?.(kit.producer_username || kit.producer_name || kit.producer || 'Unknown Producer');
                            setShowDetails(false);
                          }}
                          className="text-amber-500 hover:text-amber-400 hover:underline transition font-black tracking-widest uppercase cursor-pointer flex items-center gap-1"
                        >
                          <span>@{kit.producer_username || kit.producer_name || kit.producer || 'Unknown Producer'}</span>
                          {isProducerVerified && (
                            <VerifiedBadge size="sm" />
                          )}
                        </button>
                      </p>
                    </div>

                    <div className="bg-white/5 border border-white/5 p-3 rounded-xl flex justify-between items-center">
                      <div>
                        <span className="text-gray-500 text-[8px] font-black uppercase tracking-widest block">Categoria</span>
                        <span className="text-white text-sm font-black italic uppercase tracking-wider">{kit.category || 'Sound Kit'}</span>
                      </div>
                      <span className="px-3 py-1 bg-blue-500/10 border border-blue-500/20 text-blue-400 font-bold uppercase text-[9px] rounded-lg tracking-wider">LOOP / DRUM KIT</span>
                    </div>

                    <div className="space-y-3 pt-3 border-t border-white/5">
                      <h4 className="text-white text-[10px] font-black uppercase tracking-widest italic">Acesso Comercial</h4>
                      <div className="flex items-center justify-between p-3 bg-white/[0.02] border border-white/5 rounded-xl">
                        <div>
                          <span className="text-white text-xs font-black uppercase tracking-wider">Licença de Kit</span>
                          <span className="text-gray-500 text-[9px] block">Royalty-Free completo para produções</span>
                        </div>
                        <span className="text-white font-black text-sm">
                          {isFree ? 'GRÁTIS' : `${Number(kit.price?.basic || 0).toLocaleString()} Kz`}
                        </span>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="pt-2">
                      {isFree ? (
                        <button
                          onClick={() => {
                            const downloadUrl = kit.demo_url || kit.master_url || kit.audioUrl;
                            if (downloadUrl) {
                              window.open(downloadUrl, '_blank');
                            }
                          }}
                          className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition"
                        >
                          Baixar Kit Agora
                        </button>
                      ) : (
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              onAddToCart(kit);
                              setShowDetails(false);
                            }}
                            className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 text-black font-black text-[10px] uppercase tracking-widest rounded-xl transition flex items-center justify-center gap-2"
                          >
                            <ShoppingCart size={14} /> Adicionar ao Carrinho
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </motion.div>
  );
}

export default React.memo(MarketplaceKitCard);

