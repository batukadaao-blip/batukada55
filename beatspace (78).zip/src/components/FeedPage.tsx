import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, Sparkles, LogIn, Compass, Play, Pause, 
  Music, Package, MessageSquare, Heart, Clock, ChevronRight, RefreshCw, UserPlus, Award, Globe
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getSupabase, getPublicUrl } from '../lib/supabase';
import VerifiedBadge from './VerifiedBadge';

interface FeedPageProps {
  onExplore: () => void;
  onProducers: () => void;
  onOpenAuth?: (mode: 'login' | 'signup') => void;
  beats?: any[];
  handlePlay?: (beat: any) => void;
  currentBeat?: any;
  isPlaying?: boolean;
  onSelectProducer?: (producerName: string) => void;
  onSelectBeat?: (beat: any) => void;
}

const getRelativePortugueseTime = (dateStr: string) => {
  try {
    const past = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - past.getTime();
    if (isNaN(diffMs)) return 'Recentemente';
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHrs = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHrs / 24);

    if (diffSecs < 10) return 'Agora mesmo';
    if (diffSecs < 60) return `há ${diffSecs}s`;
    if (diffMins < 60) return `há ${diffMins}m`;
    if (diffHrs < 24) return `há ${diffHrs}h`;
    return `há ${diffDays}d`;
  } catch (_) {
    return 'Há instantes';
  }
};

const formatSeconds = (secs: number) => {
  if (isNaN(secs)) return '0:00';
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
};

const getActivityIcon = (type: string) => {
  switch (type) {
    case 'beat_upload':
      return <Music className="w-3.5 h-3.5 text-emerald-400" />;
    case 'kit_upload':
      return <Package className="w-3.5 h-3.5 text-cyan-400" />;
    case 'follow':
      return <UserPlus className="w-3.5 h-3.5 text-purple-400" />;
    case 'like':
      return <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500/20" />;
    case 'comment':
      return <MessageSquare className="w-3.5 h-3.5 text-amber-400" />;
    case 'featured':
      return <Award className="w-3.5 h-3.5 text-yellow-500" />;
    default:
      return <Globe className="w-3.5 h-3.5 text-blue-400" />;
  }
};

const FeedPlaceholder = ({ title }: { title?: string }) => {
  const safeTitle = title || 'BATUKADA';
  const hash = safeTitle.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const gradients = [
    { from: 'from-[#0A0B13]', via: 'via-[#0D0F21]', to: 'to-[#05060A]' },
    { from: 'from-[#090A0E]', via: 'via-[#181424]', to: 'to-[#07060A]' },
    { from: 'from-[#0F0E0D]', via: 'via-[#21160D]', to: 'to-[#0B0907]' },
    { from: 'from-[#0A1010]', via: 'via-[#091E1A]', to: 'to-[#050B09]' },
  ];
  const styleIdx = hash % gradients.length;
  const activePattern = gradients[styleIdx];

  const formattedTitle = React.useMemo(() => {
    if (!safeTitle || safeTitle.toLowerCase() === 'undefined' || safeTitle.toLowerCase() === 'null') {
      return 'BATUKADA';
    }
    const clean = safeTitle.replace(/[\[\]\(\)\-\_]/g, ' ').trim();
    const words = clean.split(/\s+/).filter(Boolean);
    if (words.length === 0) return 'BATUKADA';
    if (words.length <= 2) return words.join(' ').toUpperCase();
    return `${words[0]} ${words[1]}`.toUpperCase().substring(0, 15);
  }, [safeTitle]);

  return (
    <div className={`w-full h-full bg-gradient-to-br ${activePattern.from} ${activePattern.via} ${activePattern.to} flex flex-col justify-between p-2 relative overflow-hidden select-none`}>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.03),transparent_70%)] pointer-events-none" />
      
      <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
        <svg viewBox="0 0 100 100" className="w-[120%] h-[120%] stroke-current text-white/50 animate-[spin_50s_linear_infinite]">
          <circle cx="50" cy="50" r="45" fill="none" strokeWidth="0.5" strokeDasharray="2 2" />
          <circle cx="50" cy="50" r="38" fill="none" strokeWidth="0.5" />
          <circle cx="50" cy="50" r="30" fill="none" strokeWidth="0.5" strokeDasharray="6 2" />
          <circle cx="50" cy="50" r="22" fill="none" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="flex justify-between items-center z-10">
        <span className="text-[6px] font-black tracking-[0.25em] font-mono text-white/45 uppercase leading-none">
          Coletivo
        </span>
        <Music size={8} className="text-white/35" />
      </div>

      <div className="my-auto z-10 flex flex-col justify-center text-left py-0.5">
        <span className="text-[9px] font-black text-white/95 leading-tight uppercase tracking-tight line-clamp-2 italic font-sans break-all">
          {formattedTitle}
        </span>
      </div>

      <div className="flex justify-between items-end border-t border-white/[0.05] pt-1 z-10 leading-none">
        <span className="text-[5px] font-semibold text-white/30 font-mono tracking-wider uppercase">
          BATUKADA SYSTEM
        </span>
        <span className="text-[5px] font-bold text-blue-500/60 font-mono uppercase">
          AO
        </span>
      </div>
    </div>
  );
};

const FeedImage = ({ src, alt, className = "w-full h-full object-cover" }: { src?: string; alt: string; className?: string }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState<string>('');

  const resolvedUrl = React.useMemo(() => {
    if (!src) return '';
    const s = String(src).trim();
    if (s === '' || s === 'null' || s === 'undefined' || s === '[object Object]' || s.includes('undefined') || s.includes('null')) {
      return '';
    }
    if (s.includes('your-project') || s.includes('REPLACE_ME')) {
      return '';
    }
    if (s.startsWith('http://') || s.startsWith('https://') || s.startsWith('data:') || s.startsWith('/') || s.startsWith('blob:')) {
      return s;
    }
    const derived = getPublicUrl('beats', s);
    if (!derived || derived.includes('your-project') || derived.includes('REPLACE_ME') || derived.includes('/null') || derived.includes('/undefined')) {
      return '';
    }
    return derived;
  }, [src]);

  // Synchronously reset/harmonize state when URL changes, preventing race conditions
  if (resolvedUrl !== currentSrc) {
    setCurrentSrc(resolvedUrl);
    setLoading(resolvedUrl ? true : false);
    setError(resolvedUrl ? false : true);
  }

  if (error || !resolvedUrl) {
    return <FeedPlaceholder title={alt} />;
  }

  return (
    <div className="relative w-full h-full bg-neutral-950 overflow-hidden">
      {loading && (
        <div className="absolute inset-0 bg-[#09090C] flex items-center justify-center">
          <div className="w-4 h-4 rounded-full border-2 border-blue-500/20 border-t-blue-500 animate-spin" />
        </div>
      )}
      <img
        key={resolvedUrl} // Forces React to unmount/mount image to always trigger onLoad properly
        src={resolvedUrl}
        alt={alt || "Capa Batukada"}
        className={`${className} ${loading ? 'opacity-0 scale-95' : 'opacity-100 scale-100'} transition-all duration-300 ease-out`}
        onError={(e) => {
          console.error("[FeedImage] Error loading image path:", resolvedUrl, e);
          setError(true);
          setLoading(false);
        }}
        onLoad={() => {
          setLoading(false);
        }}
        referrerPolicy="no-referrer"
        loading="eager"
      />
    </div>
  );
};

const FeedAvatar = ({ src, alt, username, size = "w-10 h-10", className = "rounded-xl border border-white/10" }: { src?: string; alt: string; username?: string; size?: string; className?: string }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState<string>('');

  const resolvedUrl = React.useMemo(() => {
    if (!src) return '';
    const s = String(src).trim();
    if (s === '' || s === 'null' || s === 'undefined' || s === '[object Object]' || s.includes('undefined') || s.includes('null')) {
      return '';
    }
    if (s.includes('your-project') || s.includes('REPLACE_ME')) {
      return '';
    }
    if (s.startsWith('http://') || s.startsWith('https://') || s.startsWith('data:') || s.startsWith('/') || s.startsWith('blob:')) {
      return s;
    }
    const derived = getPublicUrl('avatars', s);
    if (!derived || derived.includes('your-project') || derived.includes('REPLACE_ME') || derived.includes('/null') || derived.includes('/undefined')) {
      return '';
    }
    return derived;
  }, [src]);

  // Synchronously reset/harmonize state when URL changes, preventing race conditions
  if (resolvedUrl !== currentSrc) {
    setCurrentSrc(resolvedUrl);
    setLoading(resolvedUrl ? true : false);
    setError(resolvedUrl ? false : true);
  }

  if (error || !resolvedUrl) {
    const initials = (username || alt || 'M').substring(0, 2).toUpperCase();
    return (
      <div className={`${size} bg-gradient-to-br from-blue-600/10 to-purple-600/15 flex items-center justify-center font-black text-blue-400 uppercase text-[10px] tracking-wider ${className}`}>
        {initials}
      </div>
    );
  }

  return (
    <div className={`relative ${size} overflow-hidden bg-neutral-900 ${className}`}>
      {loading && (
        <div className="absolute inset-0 bg-[#060609] flex items-center justify-center">
          <div className="w-2.5 h-2.5 rounded-full border-2 border-blue-500/20 border-t-blue-500 animate-spin" />
        </div>
      )}
      <img
        key={resolvedUrl} // Forces React to unmount/mount image to always trigger onLoad properly
        src={resolvedUrl}
        alt={alt}
        className={`w-full h-full object-cover transition-all duration-300 ${loading ? 'opacity-0' : 'opacity-100'}`}
        onError={(e) => {
          console.error("[FeedAvatar] Error loading image path:", resolvedUrl, e);
          setError(true);
          setLoading(false);
        }}
        onLoad={() => {
          setLoading(false);
        }}
        referrerPolicy="no-referrer"
        loading="eager"
      />
    </div>
  );
};

export default function FeedPage({ 
  onExplore, 
  onProducers, 
  onOpenAuth, 
  beats, 
  handlePlay, 
  currentBeat, 
  isPlaying, 
  onSelectProducer 
}: FeedPageProps) {
  const { user } = useAuth();
  const [followingCount, setFollowingCount] = useState<number | null>(null);
  const [checkingFollows, setCheckingFollows] = useState<boolean>(true);
  const [feedItems, setFeedItems] = useState<any[]>([]);
  const [loadingFeed, setLoadingFeed] = useState<boolean>(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'beats' | 'social'>('all');
  const [limit, setLimit] = useState<number>(20);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // 1. Fetch Follow counts and check if following anyone
  const checkFollowsCount = useCallback(async () => {
    if (!user) {
      setCheckingFollows(false);
      return;
    }

    const supabase = getSupabase();
    if (!supabase) {
      setFollowingCount(0);
      setCheckingFollows(false);
      return;
    }

    try {
      const { count, error } = await supabase
        .from('followers')
        .select('id', { count: 'exact', head: true })
        .eq('follower_id', user.id);

      if (!error && count !== null) {
        setFollowingCount(count);
      } else {
        setFollowingCount(0);
      }
    } catch (err) {
      console.warn('Error checking followed producers:', err);
      setFollowingCount(0);
    } finally {
      setCheckingFollows(false);
    }
  }, [user]);

  // 2. Fetch Hybrid Feed of Beats, Kits, Activity Posts
  const fetchFeedData = useCallback(async (isSilent = false) => {
    if (!user) return;
    if (!isSilent) setLoadingFeed(true);
    
    try {
      // Debounce protection and URL assembly
      const res = await fetch(`/api/feed/following/${user.id}?limit=45`);
      if (res.ok) {
        const data = await res.json();
        
        // TECHNICAL DIAGNOSTIC LOG FOR DEDICATED DEBUGGING as requested
        console.log(`[FEED DEBUG] Loaded feed data successfully. Count: ${data.length || 0}`);
        if (data && Array.isArray(data)) {
          data.forEach((item: any, idx: number) => {
            const beatCover = item.target_cover || item.metadata?.target_cover;
            const userAvatar = item.avatar_url || item.actor_avatar || item.metadata?.actor_avatar;
            console.log(`[FEED ITEM #${idx}] type: ${item.type} | title: "${item.target_title || 'N/A'}"`);
            console.log(`  - cover path: "${beatCover}" (typeof: ${typeof beatCover})`);
            console.log(`  - avatar path: "${userAvatar}" (typeof: ${typeof userAvatar})`);
            console.log(`  - full raw object:`, item);
          });
        }
        
        setFeedItems(data);
      }
    } catch (err) {
      console.warn('Error downloading followed feed items:', err);
    } finally {
      setLoadingFeed(false);
      setIsRefreshing(false);
    }
  }, [user]);

  // Handle manual/auto refreshes
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await checkFollowsCount();
    await fetchFeedData(true);
  };

  useEffect(() => {
    checkFollowsCount();
  }, [checkFollowsCount]);

  useEffect(() => {
    if (user) {
      fetchFeedData();
    }
  }, [user, followingCount, fetchFeedData]);

  // Real-time custom event support: when follow change is dispatched somewhere, update instantly
  useEffect(() => {
    const handleFollowStateChange = () => {
      console.log("[FEED] Follow change event occurred. Harmonizing statistics and reloading feed... ");
      checkFollowsCount();
      fetchFeedData(true);
    };

    window.addEventListener('followStateChanged', handleFollowStateChange);
    window.addEventListener('followStatusChanged', handleFollowStateChange);
    return () => {
      window.removeEventListener('followStateChanged', handleFollowStateChange);
      window.removeEventListener('followStatusChanged', handleFollowStateChange);
    };
  }, [checkFollowsCount, fetchFeedData]);

  // Trigger sound play directly
  const playBeatDirectly = (targetId: string) => {
    if (!targetId) return;
    if (beats && handlePlay) {
      const beatItem = beats.find(b => String(b.id) === String(targetId) || String(b.beat_id) === String(targetId));
      if (beatItem) {
        handlePlay(beatItem);
        return;
      }
    }
    // Fallback event
    window.dispatchEvent(new CustomEvent('selectBeatPlay', { detail: { beatId: targetId } }));
  };

  // Filter matching
  const filteredItems = React.useMemo(() => {
    return feedItems.filter(item => {
      if (activeFilter === 'all') return true;
      if (activeFilter === 'beats') {
        return item.type === 'beat_upload' || item.type === 'kit_upload' || item.type === 'featured';
      }
      if (activeFilter === 'social') {
        return item.type === 'follow' || item.type === 'like' || item.type === 'comment' || item.type === 'playlist_created';
      }
      return true;
    });
  }, [feedItems, activeFilter]);

  // Check if item is the currently playing beat
  const isItemPlaying = (targetId: string) => {
    if (!isPlaying || !currentBeat || !targetId) return false;
    return String(currentBeat.id) === String(targetId) || String(currentBeat.beat_id) === String(targetId);
  };

  // Render Loading spinner
  if (checkingFollows) {
    return (
      <div className="w-full min-h-[60vh] flex flex-col items-center justify-center">
        <span className="w-8 h-8 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin" />
        <p className="text-sm text-neutral-400 font-medium mt-4">A carregar o teu feed...</p>
      </div>
    );
  }

  // Not logged in empty state
  if (!user) {
    return (
      <div className="w-full max-w-2xl mx-auto py-16 px-4 flex flex-col items-center text-center">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-blue-500 shadow-2xl shadow-blue-500/15 mb-6"
        >
          <LogIn size={28} />
        </motion.div>
        <span className="bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full text-[10px] uppercase font-mono tracking-widest text-blue-400 font-bold mb-4">
          Rede Social Privada
        </span>
        <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter sm:text-4xl">
          Feed de Produtores
        </h2>
        <p className="text-neutral-400 text-sm font-medium mt-3 max-w-md leading-relaxed">
          Inicia sessão para teres acesso ao teu feed personalizado e veres as atividades e novidades dos produtores angolanos que segues na plataforma.
        </p>
        <button 
          onClick={() => {
            if (onOpenAuth) onOpenAuth('login');
            else {
              window.dispatchEvent(new CustomEvent('openAuthModal', { detail: { mode: 'login' } }));
            }
          }}
          className="mt-8 px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white text-xs font-black uppercase tracking-widest rounded-2xl transition-all shadow-xl shadow-blue-600/20 hover:shadow-blue-600/40 transform hover:-translate-y-0.5 active:translate-y-0 active:scale-95 flex items-center gap-2 cursor-pointer text-center justify-center italic"
        >
          <LogIn size={14} />
          Autenticar-me na BATUKADA
        </button>
      </div>
    );
  }

  // Active Feed Display
  return (
    <div className="w-full max-w-5xl mx-auto py-6 md:py-10 px-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-white/[0.04] pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-widest text-blue-400 font-mono">Teu Feed Personalizado</span>
          </div>
          <h1 className="text-3xl font-black text-white uppercase italic tracking-tighter mt-1 sm:text-4xl">
            🔥 FEED DE SEGUIDORES
          </h1>
          <p className="text-xs text-neutral-400 font-medium mt-1">Atividades e instrumentais exclusivos dos produtores que escolheste seguir</p>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="p-2.5 bg-white/5 hover:bg-white/10 text-neutral-300 rounded-xl transition-all active:scale-95 border border-white/5 cursor-pointer disabled:opacity-50"
            title="Recarregar Feed"
          >
            <RefreshCw size={14} className={isRefreshing ? 'animate-spin' : ''} />
          </button>

          <button 
            onClick={onProducers}
            className="px-4 py-2.5 bg-white/5 hover:bg-white/10 hover:text-white border border-white/5 text-neutral-300 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer italic"
          >
            <Users size={12} />
            Gerir Seguidos
          </button>
          
          <button 
            onClick={onExplore}
            className="px-4 py-2.5 bg-gradient-to-r from-blue-600/20 to-blue-500/20 hover:from-blue-600/30 hover:to-blue-500/30 border border-blue-500/20 hover:border-blue-500/30 text-blue-400 hover:text-blue-300 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer italic"
          >
            <Sparkles size={12} />
            Explorar Sons
          </button>
        </div>
      </div>

      {/* FILTER BUTTONS SELECTOR */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-6 border-b border-white/[0.04]">
        {[
          { id: 'all', label: 'Tudo' },
          { id: 'beats', label: 'Beats & Soundkits' },
          { id: 'social', label: 'Interações & Atividades' }
        ].map(filter => (
          <button
            key={filter.id}
            onClick={() => {
              setActiveFilter(filter.id as any);
              setLimit(20); // reset page view limit
            }}
            className={`px-4 py-2.5 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all border whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeFilter === filter.id 
                ? 'bg-blue-600/15 border-blue-500/35 text-blue-400 shadow-lg shadow-blue-500/5' 
                : 'bg-[#09090C]/40 border-white/[0.04] text-neutral-400 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            {filter.id === 'beats' && <Music size={12} />}
            {filter.id === 'social' && <MessageSquare size={12} />}
            {filter.label}
          </button>
        ))}
      </div>

      {/* TIMELINE LIST */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {followingCount === 0 && (
            <div className="p-5 rounded-2xl bg-[#09090D]/50 border border-blue-500/20 shadow-lg shadow-blue-500/5 text-left mb-2">
              <div className="flex items-center gap-1.5 mb-1.5">
                <Sparkles size={14} className="text-blue-400 animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-widest text-blue-400 font-mono">Modo de Descoberta Coletiva</span>
              </div>
              <h4 className="text-sm font-black text-white uppercase italic">Segue produtores para personalizar o teu feed</h4>
              <p className="text-xs text-neutral-400 leading-relaxed mt-1">
                Ainda não segues nenhum produtor de Angola na plataforma. Para começar, sintonizámos os últimos lançamentos de beats, soundkits, destaques e atividades do nosso coletivo!
              </p>
              <button 
                onClick={onProducers}
                className="mt-4 px-4 py-2 bg-blue-600/10 hover:bg-blue-600/20 border border-blue-500/20 hover:border-blue-500/30 text-blue-400 hover:text-blue-300 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all cursor-pointer font-bold italic"
              >
                Escolher Produtores para Seguir →
              </button>
            </div>
          )}

          {loadingFeed ? (
            <div className="space-y-4">
              {[1, 2, 3].map(n => (
                <div key={n} className="w-full h-28 bg-[#09090A]/80 border border-white/[0.04] rounded-2xl animate-pulse flex items-center p-4 gap-4">
                  <div className="w-20 h-20 bg-neutral-800 rounded-xl" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-neutral-800 rounded w-1/3" />
                    <div className="h-3 bg-neutral-800 rounded w-1/2" />
                    <div className="h-3 bg-neutral-800 rounded w-1/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="text-center py-16 border border-white/[0.03] bg-white/[0.01] rounded-2xl p-6">
              <Sparkles size={32} className="mx-auto text-neutral-600 animate-pulse mb-3" />
              <p className="text-sm font-bold text-white uppercase italic">Segue produtores para personalizar o teu feed</p>
              <p className="text-xs text-neutral-400 mt-1">Novos beats dos produtores que segues aparecerão aqui.</p>
              <button 
                onClick={onProducers}
                className="mt-4 px-5 py-3 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all cursor-pointer shadow-lg shadow-blue-500/10"
              >
                Procurar Produtores para Seguir
              </button>
            </div>
          ) : (
            <div className="space-y-4" id="feed-timeline-container">
              <AnimatePresence mode="popLayout">
                {filteredItems.slice(0, limit).map((item) => {
                  const isBeatOrKit = item.type === 'beat_upload' || item.type === 'kit_upload' || item.type === 'featured';
                  const isPlayingCurrent = isBeatOrKit && isItemPlaying(item.target_id);

                  if (isBeatOrKit) {
                    return (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="relative bg-[#09090D]/50 hover:bg-[#0E0E14]/80 border border-white/[0.04] hover:border-blue-500/10 p-4 rounded-2xl backdrop-blur-xl transition-all duration-300 flex flex-col sm:flex-row items-center gap-4 group shadow-xl"
                      >
                        {/* 1. Capa do Beat com overlay interactivo de Play */}
                        <div className="relative w-20 h-20 bg-neutral-900 rounded-xl overflow-hidden shrink-0 border border-white/5 shadow-inner">
                          <FeedImage
                            src={item.target_cover || item.metadata?.target_cover}
                            alt={item.target_title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          
                          <button
                            onClick={() => playBeatDirectly(item.target_id)}
                            className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center text-white cursor-pointer"
                          >
                            {isPlayingCurrent ? (
                              <Pause size={20} className="text-blue-400 animate-pulse" />
                            ) : (
                              <Play size={20} className="text-white hover:scale-110 transition-transform" />
                            )}
                          </button>

                          {isPlayingCurrent && (
                            <div className="absolute bottom-1 right-1 bg-blue-500 px-1 py-0.5 rounded text-[7px] font-sans font-black uppercase tracking-wider text-black flex items-center gap-0.5">
                              <span className="w-1 h-1 bg-white rounded-full animate-ping" />
                              AR
                            </div>
                          )}
                        </div>

                        {/* 2. Informações principais */}
                        <div className="flex-1 min-w-0 w-full text-center sm:text-left">
                          <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap mb-1">
                            <span className={`text-[9px] uppercase tracking-wider font-mono px-2 py-0.5 border rounded-md font-bold ${
                              item.type === 'kit_upload' 
                              ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400' 
                              : item.type === 'featured'
                              ? 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                              : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                            }`}>
                              {item.type === 'kit_upload' ? 'SOUNDKIT' : (item.metadata?.genre || 'Instrumental')}
                            </span>
                            {item.is_suggestion && (
                              <span className="bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[9px] uppercase tracking-wider font-mono px-1.5 py-0.5 rounded-md font-bold shrink-0">
                                Sugerido
                              </span>
                            )}
                            <span className="text-[9px] text-neutral-500 font-mono flex items-center gap-1">
                              <Clock size={10} />
                              {getRelativePortugueseTime(item.created_at)}
                            </span>
                          </div>

                          <h3 
                            className="text-base font-black text-white truncate hover:text-blue-400 transition-colors cursor-pointer"
                            onClick={() => playBeatDirectly(item.target_id)}
                          >
                            {item.target_title}
                          </h3>

                          {/* Produtor */}
                          <div className="flex items-center justify-center sm:justify-start gap-1.5 mt-0.5">
                            <FeedAvatar
                              src={item.avatar_url || item.actor_avatar}
                              alt={item.actor_name || 'Produtor'}
                              username={item.actor_username || item.username}
                              size="w-4 h-4"
                              className="rounded-full border border-white/10 shrink-0"
                            />
                            <span 
                              onClick={() => {
                                if (onSelectProducer) onSelectProducer(item.actor_username || item.username);
                              }}
                              className="text-xs font-bold text-neutral-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1"
                            >
                              Por <strong className="text-white hover:underline">{item.actor_name || 'Produtor'}</strong>
                              {(item.is_verified || item.isVerified) && <VerifiedBadge size="sm" />}
                              <span className="text-neutral-500 font-normal font-mono text-[10px]">@{item.actor_username || item.username}</span>
                            </span>
                          </div>

                          {/* BPM e Escala */}
                          {item.type !== 'kit_upload' && (item.metadata?.bpm || item.metadata?.key) && (
                            <div className="flex items-center justify-center sm:justify-start gap-1.5 mt-2 text-[10px] font-mono text-neutral-400">
                              {item.metadata?.bpm && (
                                <span className="bg-white/[0.02] border border-white/[0.04] px-1.5 py-0.5 rounded text-neutral-300 font-bold">
                                  {item.metadata.bpm} BPM
                                </span>
                              )}
                              {(item.metadata?.key || item.metadata?.scale) && (
                                <span className="bg-white/[0.02] border border-white/[0.04] px-1.5 py-0.5 rounded text-neutral-300 font-bold">
                                  Tom: {item.metadata.key} {item.metadata.scale || ''}
                                </span>
                              )}
                            </div>
                          )}
                        </div>

                        {/* 3. Ações */}
                        <div className="flex items-center gap-3 shrink-0 w-full sm:w-auto justify-center sm:justify-end border-t sm:border-t-0 border-white/[0.03] pt-3 sm:pt-0 mt-1 sm:mt-0">
                          <button
                            onClick={() => playBeatDirectly(item.target_id)}
                            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-90 cursor-pointer border ${
                              isPlayingCurrent 
                                ? 'bg-blue-600 border-blue-500 text-white font-bold shadow-lg shadow-blue-500/20' 
                                : 'bg-white/5 border-white/[0.04] hover:bg-white/10 text-white'
                            }`}
                          >
                            {isPlayingCurrent ? <Pause size={16} /> : <Play size={16} className="translate-x-[1px]" />}
                          </button>
                          
                          <button
                            onClick={() => {
                              if (onSelectProducer) onSelectProducer(item.actor_username || item.username);
                            }}
                            className="px-4 py-2 bg-[#101015]/80 hover:bg-[#161622]/90 border border-white/[0.06] hover:border-white/[0.12] text-neutral-300 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all active:scale-95 cursor-pointer flex items-center gap-1 italic"
                          >
                            Visitar Perfil
                            <ChevronRight size={10} />
                          </button>
                        </div>
                      </motion.div>
                    );
                  } else {
                    // Rendição de Publicações Sociais (follow, like, comment, playlist)
                    return (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="p-4 bg-[#07070B]/30 hover:bg-[#0C0C12]/40 border border-white/[0.03] hover:border-white/[0.05] rounded-2xl flex items-start gap-3 transition-colors text-xs"
                      >
                        <div className="relative shrink-0">
                          <FeedAvatar
                            src={item.actor_avatar || item.avatar_url}
                            alt={item.actor_name || 'Usuário'}
                            username={item.actor_username || item.username}
                            size="w-10 h-10"
                            className="rounded-xl border border-white/10"
                          />
                          <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-black border border-white/[0.06] flex items-center justify-center shadow-lg">
                            {getActivityIcon(item.type)}
                          </span>
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1.5 flex-wrap">
                            <span 
                              onClick={() => {
                                if (onSelectProducer) onSelectProducer(item.actor_username || item.username);
                              }}
                              className="font-bold text-white hover:text-blue-400 cursor-pointer flex items-center gap-1 align-middle"
                            >
                              @{item.actor_username || item.username}
                              {(item.is_verified || item.isVerified) && <VerifiedBadge size="sm" />}
                              {item.is_suggestion && (
                                <span className="bg-blue-500/10 border border-blue-500/15 text-blue-400 text-[8px] uppercase tracking-wider font-mono px-1 py-0.5 rounded leading-none shrink-0 font-bold">
                                  Sugerido
                                </span>
                              )}
                            </span>
                            <span className="text-[9px] font-mono text-neutral-500">
                              {getRelativePortugueseTime(item.created_at)}
                            </span>
                          </div>

                          <p className="text-neutral-400 leading-relaxed mt-1 font-medium">
                            {item.type === 'follow' && (
                              <span>começou a seguir <strong className="text-white">@{item.target_title || 'Produtor'}</strong></span>
                            )}
                            {item.type === 'like' && (
                              <span>gostou do instrumental <strong className="text-blue-400 hover:underline cursor-pointer" onClick={() => playBeatDirectly(item.target_id)}>"{item.target_title}"</strong></span>
                            )}
                            {item.type === 'comment' && (
                              <span>
                                {item.metadata?.timestamp_seconds !== undefined && item.metadata?.timestamp_seconds !== null ? (
                                  <span>
                                    comentou aos <span className="text-amber-400 font-mono font-black bg-amber-500/10 px-1.5 py-0.5 rounded text-[10px] mr-1">[{formatSeconds(Number(item.metadata.timestamp_seconds))}]</span> em <strong className="text-blue-400 hover:underline cursor-pointer" onClick={() => playBeatDirectly(item.target_id)}>"{item.target_title}"</strong>:
                                  </span>
                                ) : (
                                  <span>comentou em <strong className="text-blue-400 hover:underline cursor-pointer" onClick={() => playBeatDirectly(item.target_id)}>"{item.target_title}"</strong>:</span>
                                )}
                                <span className="block mt-1 bg-white/[0.01] border-l-2 border-white/15 pl-2 py-0.5 text-neutral-400 italic">" {item.metadata?.comment || '...'} "</span>
                              </span>
                            )}
                            {item.type === 'playlist_created' && (
                              <span>criou uma nova playlist pública <strong className="text-white">"{item.target_title}"</strong></span>
                            )}
                          </p>
                        </div>
                      </motion.div>
                    );
                  }
                })}
              </AnimatePresence>

              {filteredItems.length > limit && (
                <div className="pt-4 text-center">
                  <button
                    onClick={() => setLimit(prev => prev + 15)}
                    className="px-6 py-3 bg-white/5 hover:bg-white/10 text-neutral-300 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all cursor-pointer border border-white/[0.04]"
                  >
                    Carregar Mais Atividades
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Informative Side Panel */}
        <div className="lg:col-span-1 hidden lg:block">
          <div className="bg-[#09090D]/50 border border-white/[0.04] p-5 rounded-2xl backdrop-blur-xl sticky top-32 space-y-5">
            <div>
              <h3 className="text-xs font-black uppercase tracking-widest text-white mb-2">Como funciona?</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                A tua timeline junta automaticamente lançamentos de beats antigos, drumkits novos, destaques oficiais e atividades sociais de todos os produtores angolanos que escolheste seguir no diretório.
              </p>
            </div>

            <div className="border-t border-white/[0.04] pt-4">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-neutral-400 mb-3">CONTEÚDOS SUPORTADOS</h4>
              <ul className="space-y-3 text-[11px] text-neutral-400 font-semibold">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                  Instrumentais recentes e hits de catálogo
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 shrink-0" />
                  Drumkits e Soundkits originais
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                  Lançamentos em destaque (Featured)
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500 shrink-0" />
                  Interações, curtidas e comentários
                </li>
              </ul>
            </div>

            <div className="border-t border-white/[0.04] pt-4 text-center bg-blue-500/5 rounded-xl p-3 border border-blue-500/10">
              <span className="text-[9px] font-bold text-blue-400 uppercase tracking-widest block font-mono">BATUKADA SOCIAL</span>
              <p className="text-[10px] text-neutral-400 mt-1">Descobre e sintoniza o melhor conteúdo da rede privada musical angolana.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
