import React from 'react';
import { motion } from 'motion/react';

interface InstagramLoaderProps {
  label?: string;
  fullScreen?: boolean;
}

export default function InstagramLoader({ label = 'A Carregar...', fullScreen = false }: InstagramLoaderProps) {
  const content = (
    <div className="flex flex-col items-center justify-center gap-4">
      <div className="relative flex items-center justify-center">
        {/* Simple crisp geometric loading track ring */}
        <div className="w-16 h-16 rounded-full border-2 border-white/[0.04]" />
        
        {/* Quick crisp spinning arc */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{
            duration: 0.8,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute w-16 h-16 rounded-full border-2 border-transparent border-t-[#6366f1] border-r-[#6366f1]/30"
        />

        {/* Brand center */}
        <div className="absolute w-10 h-10 rounded-full flex items-center justify-center bg-[#050505] border border-white/[0.06]">
          <img 
            src="https://i.ibb.co/hF1MD85X/20260523-155411.png" 
            className="w-5 h-5 object-contain opacity-85" 
            referrerPolicy="no-referrer" 
            alt="Logo" 
          />
        </div>
      </div>
      
      {/* Sleek minimal label indicator */}
      {label && (
        <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 animate-pulse duration-[1200ms]">
          {label}
        </span>
      )}
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#000000] h-screen w-screen transition-all duration-300">
        {content}
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[350px] w-full bg-transparent">
      {content}
    </div>
  );
}
