import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Download, Library, Sparkles, ShieldCheck, Mail, Music, ArrowRight, Loader2, Lock } from 'lucide-react';
import { getSupabase, getPublicUrl, getBeatSignedUrl } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

interface PaymentSuccessPageProps {
  onGoToLibrary: () => void;
  onGoToDashboard: () => void;
}

export default function PaymentSuccessPage({ onGoToLibrary, onGoToDashboard }: PaymentSuccessPageProps) {
  const [orderId, setOrderId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [orderData, setOrderData] = useState<any>(null);
  const [beatData, setBeatData] = useState<any>(null);
  const [producerName, setProducerName] = useState('Produtor');
  const [downloadLoading, setDownloadLoading] = useState(false);

  const supabase = getSupabase();
  const { user } = useAuth();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlOrderId = params.get('orderId');
      setOrderId(urlOrderId);
    }
  }, []);

  const toValidIntId = (id: any): number => {
    if (!id) return 1;
    const strId = String(id).trim();
    const parsed = parseInt(strId, 10);
    if (!isNaN(parsed)) return parsed;
    const lastParts = strId.split('-');
    return parseInt(lastParts[lastParts.length - 1], 10) || 1;
  };

  useEffect(() => {
    if (!orderId || !supabase) {
      setLoading(false);
      return;
    }

    async function fetchOrderDetails() {
      setLoading(true);
      try {
        // Query the order
        const { data: order, error: orderErr } = await supabase
          .from('orders')
          .select('*')
          .eq('id', orderId)
          .single();

        if (orderErr) throw orderErr;
        setOrderData(order);

        if (order && order.beat_id) {
          // Query associated beat details
          const numBeatId = toValidIntId(order.beat_id);
          const { data: beat, error: beatErr } = await supabase
            .from('beats')
            .select('*')
            .eq('id', numBeatId)
            .single();

          if (!beatErr && beat) {
            setBeatData(beat);

            // Track purchase event
            const trackingKey = `tracked_purchase_${order.id}`;
            if (!sessionStorage.getItem(trackingKey)) {
              sessionStorage.setItem(trackingKey, 'true');
              try {
                import('@/src/lib/analytics').then(m => {
                  m.trackAnalyticsEvent('purchase', {
                    producerId: beat.producer_id || order.producer_id || '00000000-0000-0000-0000-000000000000',
                    beatId: order.beat_id,
                    userId: user?.id || undefined,
                    amount: Number(order.amount || 0)
                  });
                });
              } catch (err) {
                console.error("[ANALYTICS] Purchase tracking error:", err);
              }
            }

            // Fetch producer profile if available
            if (beat.producer_id) {
              const { data: profile } = await supabase
                .from('profiles')
                .select('artistic_name, display_name')
                .eq('id', beat.producer_id)
                .single();

              if (profile) {
                setProducerName(profile.artistic_name || profile.display_name || beat.producer_name || 'Produtor Oficial');
              } else {
                setProducerName(beat.producer_name || 'Produtor Oficial');
              }
            } else {
              setProducerName(beat.producer_name || 'Produtor Oficial');
            }
          }
        }
      } catch (err) {
        console.error('[SUCCESS PAGE DETAIL LOAD ERROR]', err);
      } finally {
        setLoading(false);
      }
    }

    fetchOrderDetails();
  }, [orderId, supabase]);

  const handleDownloadBeat = async () => {
    if (!supabase || !beatData) return;
    const s = String(orderData?.status || 'pending').toLowerCase();
    const canAccess = ['completed', 'paid', 'approved', 'confirmed'].includes(s);
    if (!canAccess) {
      alert("Acesso negado. Ficheiro de alta qualidade protegido até confirmação do pagamento pelo administrador.");
      return;
    }

    setDownloadLoading(true);
    try {
      const fileKey = (orderData?.license_type === 'premium' || orderData?.license_type === 'exclusive' || orderData?.license_type === 'stems') && beatData.stems_url 
        ? 'stems'
        : 'master';

      const signedUrl = await getBeatSignedUrl(beatData.id, fileKey);
      if (signedUrl) {
        window.open(signedUrl, '_blank');
      } else {
        alert("Não foi possível gerar um link seguro temporário. Confirme se o estado do seu pagamento já foi validado pelo produtor/admin.");
      }
    } catch (err) {
      console.error(err);
      alert("Falha no download seguro da faixa.");
    } finally {
      setDownloadLoading(false);
    }
  };

  const formattedAmount = orderData?.amount 
    ? `${orderData.amount.toLocaleString('pt-AO')} Kz` 
    : beatData?.price 
      ? `${(beatData.price[orderData?.license_type || 'basic'] || 25000).toLocaleString('pt-AO')} Kz`
      : 'USD Equivalente';

  const licenseNameUpper = orderData?.license_type 
    ? String(orderData.license_type).toUpperCase() 
    : 'BÁSICA';

  if (loading) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 space-y-4">
        <Loader2 className="w-10 h-10 text-emerald-500 animate-spin" />
        <p className="text-gray-400 font-mono text-xs uppercase tracking-widest animate-pulse">A carregar recibo oficial...</p>
      </div>
    );
  }

  const canAccess = ['completed', 'paid', 'approved', 'confirmed'].includes(String(orderData?.status || 'pending').toLowerCase());

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 md:py-16 space-y-12">
      {/* Premium Glass Card */}
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="relative bg-gradient-to-b from-emerald-500/[0.03] to-[#000000] border border-emerald-500/10 rounded-[2.5rem] p-8 md:p-12 shadow-2xl overflow-hidden backdrop-blur-3xl"
      >
        {/* Decorative dynamic glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-72 bg-emerald-500/10 rounded-full filter blur-[100px] pointer-events-none" />

        <div className="flex flex-col items-center text-center space-y-6">
          {/* Success Ring animation like Stripe/Spotify style */}
          <div className="relative flex items-center justify-center">
            <motion.div 
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: [1, 1.1, 1], opacity: 1 }}
              transition={{ duration: 0.8, times: [0, 0.5, 1], ease: 'easeInOut' }}
              className={`w-20 h-20 rounded-full ${canAccess ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400' : 'bg-amber-500/10 border border-amber-500/20 text-amber-500'} flex items-center justify-center`}
            >
              {canAccess ? <CheckCircle2 size={44} className="stroke-[1.5]" /> : <Lock size={40} className="stroke-[1.5]" />}
            </motion.div>
            {canAccess && <Sparkles className="absolute -top-1 -right-1 text-yellow-400 animate-pulse" size={20} />}
          </div>

          <div className="space-y-2">
            {canAccess ? (
              <span className="text-emerald-400 text-[10px] font-black tracking-widest uppercase font-mono bg-emerald-500/10 border border-emerald-500/15 py-1 px-3 rounded-full">
                Pedido Pago &amp; Confirmado ✓
              </span>
            ) : (
              <span className="text-amber-500 text-[10px] font-black tracking-widest uppercase font-mono bg-amber-500/10 border border-amber-500/15 py-1 px-3 rounded-full">
                Aguardando Confirmação de Pagamento ⏳
              </span>
            )}
            <h1 className="text-3xl md:text-4xl font-black text-white italic tracking-tighter uppercase">
              {canAccess ? 'OBRIGADO PELO TEU' : 'PEDIDO RECURSO'}<br className="hidden sm:inline" /> <span className="text-gradient bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">{canAccess ? 'INVESTIMENTO' : 'REGISTADO'}</span>
            </h1>
            {canAccess ? (
              <p className="text-gray-400 font-medium text-sm max-w-lg mx-auto">
                O teu pagamento foi validado com sucesso. A licença legal e os ficheiros de alta qualidade áudio foram libertados imediatamente para ti.
              </p>
            ) : (
              <p className="text-gray-400 font-medium text-sm max-w-lg mx-auto">
                O teu pedido foi registado com sucesso no sistema. Os ficheiros finais do instrumental e a licença PDF serão libertados imediatamente após a auditoria e confirmação da sua transferência.
              </p>
            )}
          </div>

          {/* Buying summary details panel styling */}
          <div className="w-full bg-[#000000]/60 border border-white/[0.04] rounded-3xl p-6 md:p-8 text-left space-y-6">
            <h3 className="text-xs font-black text-white tracking-widest uppercase border-b border-white/5 pb-3">
              Resumo da Compra
            </h3>

            <div className="flex flex-col sm:flex-row justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-900/20 border border-emerald-500/10 overflow-hidden flex items-center justify-center shrink-0">
                  {beatData?.cover_url ? (
                    <img 
                      src={getPublicUrl('beats', beatData.cover_url) || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=100'} 
                      alt="" 
                      className="w-full h-full object-cover" 
                    />
                  ) : (
                    <Music className="text-emerald-500" size={24} />
                  )}
                </div>
                <div>
                  <h4 className="text-lg font-black text-white uppercase italic tracking-tighter leading-tight">
                    {orderData?.beat_title || beatData?.title || 'Beat Instrumental'}
                  </h4>
                  <p className="text-[10px] text-emerald-400 font-black tracking-widest uppercase mt-0.5">
                    {producerName}
                  </p>
                </div>
              </div>

              <div className="flex sm:flex-col justify-between sm:justify-center items-baseline sm:items-end border-t sm:border-t-0 border-white/5 pt-4 sm:pt-0 shrink-0">
                <span className="text-xs sm:text-[9px] text-gray-400 font-black uppercase tracking-widest">Valor de Aquisição</span>
                <span className="text-xl font-black text-emerald-400 font-sans tracking-tight">{formattedAmount}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-white/5 text-xs text-gray-400">
              <div className="bg-white/[0.02] p-3.5 rounded-2xl border border-white/[0.03]">
                <span className="text-[8px] font-black uppercase tracking-widest text-gray-500 block mb-1">Licença Concedida</span>
                <span className="font-extrabold text-white uppercase tracking-wider text-[11px]">{licenseNameUpper}</span>
              </div>
              <div className="bg-white/[0.02] p-3.5 rounded-2xl border border-white/[0.03]">
                <span className="text-[8px] font-black uppercase tracking-widest text-gray-500 block mb-1">Pagamento Via</span>
                <span className="font-extrabold text-white text-[11px]">PayPal Premium 💳</span>
              </div>
              <div className="bg-white/[0.02] p-3.5 rounded-2xl border border-white/[0.03]">
                <span className="text-[8px] font-black uppercase tracking-widest text-gray-500 block mb-1">ID da Transação</span>
                <span className="font-mono text-[10px] text-gray-400 truncate block">
                  {orderId ? orderId.substring(0, 16) + "..." : 'BKD-ORDER-OK'}
                </span>
              </div>
            </div>
          </div>

          {/* Email Confirmation Premium Structure - Email ready status section */}
          <div className={`w-full py-4 px-6 ${canAccess ? 'bg-[#0c5c3e]/10 border border-emerald-500/20' : 'bg-amber-500/5 border border-amber-500/10'} rounded-2xl flex items-center gap-3.5 justify-center`}>
            {canAccess ? <Mail size={16} className="text-emerald-400 shrink-0" /> : <Lock size={16} className="text-amber-500 shrink-0" />}
            <span className="text-xs font-bold text-gray-300">
              {canAccess 
                ? <>Recibo e contrato oficial de licença já enviados para o teu email <span className="text-white font-black">{user?.email || 'de registo'}</span></>
                : <>Ficheiros da licença protegidos até à verificação e validação da transferência</>
              }
            </span>
          </div>

          {/* Action Call for download & navigation buttons */}
          <div className="flex flex-col sm:flex-row gap-4 w-full pt-4">
            {beatData && (
              <button
                onClick={handleDownloadBeat}
                disabled={downloadLoading}
                className={`flex-1 py-4 px-6 ${
                  canAccess 
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:opacity-90 shadow-lg shadow-emerald-500/10 text-white cursor-pointer' 
                    : 'bg-white/[0.03] border border-white/5 text-gray-400 hover:text-white cursor-pointer'
                } active:scale-95 disabled:opacity-50 font-black uppercase text-xs tracking-widest rounded-2xl transition-all duration-300 flex items-center justify-center gap-2.5`}
              >
                {downloadLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  canAccess ? <Download size={14} /> : <Lock size={14} className="text-amber-500" />
                )}
                <span>{canAccess ? 'Descarregar Beat' : 'Restrito - Pagamento Pendente'}</span>
              </button>
            )}

            <button
              onClick={onGoToLibrary}
              className="flex-1 py-4 px-6 bg-white/5 border border-white/5 hover:bg-white/10 active:scale-95 text-white font-black uppercase text-xs tracking-widest rounded-2xl transition-all duration-300 flex items-center justify-center gap-2.5 cursor-pointer"
            >
              <Library size={14} />
              <span>Ir para Biblioteca</span>
            </button>
          </div>

          <div className="text-[11px] text-gray-500 font-extrabold uppercase mt-6 tracking-widest flex items-center gap-1.5 justify-center">
            <ShieldCheck size={14} className="text-emerald-400" />
            Compra 100% Protegida & Autenticada pelo Ecossistema Batukada
          </div>
        </div>
      </motion.div>
    </div>
  );
}
