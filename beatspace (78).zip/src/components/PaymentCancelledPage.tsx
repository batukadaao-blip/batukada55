import React from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, Music, HelpCircle, ArrowRight, ShieldAlert } from 'lucide-react';

interface PaymentCancelledPageProps {
  onGoToExplore: () => void;
  onGoToDashboard: () => void;
}

export default function PaymentCancelledPage({ onGoToExplore, onGoToDashboard }: PaymentCancelledPageProps) {
  return (
    <div className="max-w-xl mx-auto px-4 py-8 md:py-16">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="relative bg-gradient-to-b from-red-500/[0.02] to-[#0A0A0C] border border-red-500/10 rounded-[2.5rem] p-8 md:p-12 shadow-2xl overflow-hidden backdrop-blur-3xl text-center"
      >
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-60 h-60 bg-red-400/5 rounded-full filter blur-[80px] pointer-events-none" />

        <div className="flex flex-col items-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400">
            <AlertTriangle size={32} className="stroke-[1.5]" />
          </div>

          <div className="space-y-2">
            <span className="text-red-400 text-[10px] font-black tracking-widest uppercase font-mono bg-red-500/10 border border-red-500/15 py-1 px-3 rounded-full">
              Processo Cancelado
            </span>
            <h1 className="text-3xl font-black text-white italic tracking-tighter uppercase leading-none">
              PAGAMENTO <br /> <span className="text-gradient bg-gradient-to-r from-red-400 to-rose-400 bg-clip-text text-transparent">NÃO CONCLUÍDO</span>
            </h1>
            <p className="text-gray-400 font-medium text-xs leading-relaxed max-w-sm mx-auto">
              O fluxo de pagamento com o PayPal foi abortado ou cancelado voluntariamente. Nenhum montante foi debitado da tua conta.
            </p>
          </div>

          <div className="flex flex-col gap-3 w-full pt-4">
            <button
              onClick={onGoToExplore}
              className="w-full py-4 px-6 bg-gradient-to-r from-red-500 to-rose-500 hover:opacity-90 active:scale-95 text-white font-black uppercase text-xs tracking-widest rounded-2xl transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-500/10"
            >
              <Music size={14} />
              <span>Explorar Outros Beats</span>
            </button>

            <button
              onClick={onGoToDashboard}
              className="w-full py-4 px-6 bg-white/5 border border-white/5 hover:bg-white/10 active:scale-95 text-white font-black uppercase text-xs tracking-widest rounded-2xl transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Ver Minha Dashboard</span>
            </button>
          </div>

          <a 
            href="https://wa.me/27697273223?text=Olá, preciso de suporte com um pagamento PayPal cancelado no portal Batukada."
            target="_blank"
            rel="noopener noreferrer"
            className="text-[10px] text-gray-500 hover:text-white transition-colors flex items-center gap-1.5 justify-center mt-4 font-bold uppercase tracking-wider block"
          >
            <HelpCircle size={13} />
            Precisas de ajuda técnica? Fala Conosco
          </a>
        </div>
      </motion.div>
    </div>
  );
}
