import React from 'react';
import { Producer } from '../types';
import { getPublicUrl } from '../lib/supabase';
import VerifiedBadge from './VerifiedBadge';

interface Props {
  producers: Producer[];
  onSelectProducer: (producer: Producer) => void;
}

export default function ProducersPage({ producers, onSelectProducer }: Props) {
  console.log("DEBUG: Producers count in ProducersPage:", producers.length, producers);
  return (
    <div className="py-12">
      <h2 className="text-4xl font-black text-white mb-12">Produtores</h2>
      {producers.length === 0 ? (
        <div className="text-center py-24 bg-white/[0.02] border border-white/5 rounded-[2.5rem] p-8 max-w-xl mx-auto space-y-6">
          <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 mx-auto">
            🎧
          </div>
          <div className="space-y-2">
            <h3 className="text-white font-extrabold text-lg">Nenhum produtor registado no momento</h3>
            <p className="text-gray-400 text-xs leading-relaxed max-w-md mx-auto">
              Se você é produtor e quer começar a monetizar o seu talento, registe-se agora ou aceda às definições de conta para ativar o seu perfil de vendedor.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
          {producers.map(producer => {
            const hasCustomAvatar = !!producer.avatar && producer.avatar.trim() !== '';
            const initials = producer.name
              ? producer.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
              : 'P';
            return (
              <div 
                key={producer.id} 
                onClick={() => onSelectProducer(producer)}
                className="bg-[#0c0c12]/80 border border-white/[0.04] p-5 text-center flex flex-col justify-between items-center w-full rounded-2xl hover:bg-[#12121a] hover:border-white/[0.08] transition-all duration-150 cursor-pointer group select-none relative min-h-[220px]"
              >
                {/* Avatar container */}
                <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden mb-3.5 border border-white/[0.06] group-hover:border-[#5865F2]/40 transition-all duration-150 bg-[#070709] shrink-0">
                  {hasCustomAvatar ? (
                    <img 
                      src={(producer.avatar.startsWith('http') ? producer.avatar : getPublicUrl('avatars', producer.avatar)) || undefined} 
                      alt={producer.name} 
                      className="w-full h-full object-cover transition-transform duration-300 ease-out group-hover:scale-[1.03]" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full bg-neutral-900 flex items-center justify-center text-gray-400 text-sm font-bold uppercase transition-colors">
                      {initials}
                    </div>
                  )}
                </div>

                {/* Info Container */}
                <div className="flex flex-col items-center w-full min-w-0 flex-1 justify-center">
                  <div className="flex items-center gap-1 justify-center w-full px-1">
                    <h3 className="text-xs sm:text-sm font-extrabold text-white truncate max-w-full text-center group-hover:text-[#5865F2] transition-colors leading-tight">
                      {producer.name}
                    </h3>
                    {(producer.isVerified || (producer as any).is_verified) && (
                      <VerifiedBadge size="sm" />
                    )}
                  </div>
                  {producer.username && (
                    <p className="text-[10px] text-gray-500 text-center font-medium lowercase tracking-tight mt-0.5 truncate w-full px-1">
                      @{producer.username}
                    </p>
                  )}
                  <div className="mt-3 bg-white/[0.02] border border-white/[0.04] px-2 py-0.5 rounded text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                    {producer.totalBeats || 0} Beats
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
