import React, { useState, useEffect } from 'react';
import { getSupabase, getPublicUrl } from '@/src/lib/supabase';
import { useAuth } from '@/src/context/AuthContext';
import { X, CheckCircle2, AlertTriangle, MessageCircle, ShieldCheck, Check, FileText, Sparkles, Info, HelpCircle, Copy } from 'lucide-react';
import { Beat } from '@/src/types';

const toValidUuid = (id: any): string => {
  if (!id) return '00000000-0000-0000-0000-000000000000';
  const strId = String(id).trim();
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (uuidRegex.test(strId)) {
    return strId;
  }
  
  if (/^\d+$/.test(strId)) {
    const padded = strId.padStart(12, '0');
    return `00000000-0000-0000-0000-${padded}`;
  }
  
  let hex = '';
  for (let i = 0; i < strId.length; i++) {
    const code = strId.charCodeAt(i);
    hex += (code % 16).toString(16);
  }
  
  const cleanHex = hex.toLowerCase().replace(/[^0-9a-f]/g, '0').padStart(32, '0').substring(0, 32);
  return `${cleanHex.substring(0, 8)}-${cleanHex.substring(8, 12)}-${cleanHex.substring(12, 16)}-${cleanHex.substring(16, 20)}-${cleanHex.substring(20, 32)}`;
};

export default function CheckoutModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [beat, setBeat] = useState<Beat | null>(null);
  const [step, setStep] = useState<'license' | 'details' | 'payment' | 'confirm'>('license');
  const [selectedLicense, setSelectedLicense] = useState<'basic' | 'premium' | 'exclusive'>('basic');
  const [order, setOrder] = useState<any>(null);
  const [paypalLoading, setPaypalLoading] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<'multicaixa' | 'bank' | 'paypal'>('multicaixa');
  const [copiedLabel, setCopiedLabel] = useState<string | null>(null);
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});
  const [activePollOrderId, setActivePollOrderId] = useState<string | null>(null);
  const [activeDbOrderId, setActiveDbOrderId] = useState<string | null>(null);
  const [paypalPollingStatus, setPaypalPollingStatus] = useState<string>('');
  const handleImgError = (key: string) => {
    setImgErrors(prev => ({ ...prev, [key]: true }));
  };
  const supabase = getSupabase();
  const { user } = useAuth();

  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLabel(label);
    setTimeout(() => {
      setCopiedLabel(null);
    }, 2000);
  };

  const getDisplayId = (uuid: string) => {
    if (!uuid) return '';
    let hash = 0;
    for (let i = 0; i < uuid.length; i++) {
      hash = uuid.charCodeAt(i) + ((hash << 5) - hash);
    }
    const code = Math.abs(hash % 9000) + 1000;
    return `BKD-${code}`;
  };

  const handlePayWithPayPal = async () => {
    if (!order) return;
    setPaypalLoading(true);

    const payload = {
      orderId: order.id,
      amount: order.amount || order.total_amount,
      currency: 'AOA', // The platform base currency is Kz (AOA) which is converted in the backend to USD
      beatId: order.beat_id,
      buyerId: order.customer_id || order.buyer_id
    };

    console.log('PAYPAL PAYLOAD:', payload);

    try {
      let response;
      let isSuccess = false;
      let result: any = null;

      // 1. Try setup-session
      try {
        console.log('[PAYPAL REQUEST START] Fetching from /api/billing/setup-session for order:', order.id);
        response = await fetch('/api/billing/setup-session', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
        
        console.log('[PAYPAL RESPONSE RECEIVED] /api/billing/setup-session:', response);
        const contentType = response.headers.get('content-type');
        console.log('RESPONSE CONTENT TYPE:', contentType);

        if (response.ok && contentType && contentType.includes('application/json')) {
          result = await response.json();
          console.log('PAYPAL RESPONSE JSON:', result);
          if (result && result.success && result.approvalUrl) {
            isSuccess = true;
          }
        } else {
          const rawText = await response.text();
          console.warn('[PAYPAL RESPONSE NOT OK/JSON] /api/billing/setup-session:', response.status, rawText.substring(0, 500));
          if (rawText.startsWith('<!DOCTYPE') || rawText.startsWith('<html')) {
            console.error('Servidor PayPal ou rota retornou HTML em vez de JSON. Código:', response.status);
          }
        }
      } catch (e) {
        console.warn('Blocked or failed on /api/billing/setup-session, retrying fallback /api/pp-gateway/create-order...', e);
      }

      // 2. Fallback to /api/pp-gateway/create-order
      if (!isSuccess) {
        try {
          console.log('[PAYPAL FALLBACK START] Fetching from /api/pp-gateway/create-order');
          response = await fetch('/api/pp-gateway/create-order', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
          });
          
          const contentType = response.headers.get('content-type');
          if (response.ok && contentType && contentType.includes('application/json')) {
            result = await response.json();
            console.log('PAYPAL FALLBACK RESPONSE JSON:', result);
            if (result && result.approvalUrl) {
              isSuccess = true;
            }
          } else {
            const rawText = await response.text();
            console.warn('[PAYPAL RESPONSE NOT OK/JSON] /api/pp-gateway/create-order:', response.status, rawText.substring(0, 500));
          }
        } catch (err2) {
          console.warn('Blocked or failed on /api/pp-gateway/create-order, retrying final fallback /api/paypal/create-order...', err2);
        }
      }

      // 3. Final Fallback to /api/paypal/create-order
      if (!isSuccess) {
        try {
          console.log('[PAYPAL FINAL FALLBACK START] Fetching from /api/paypal/create-order');
          response = await fetch('/api/paypal/create-order', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
          });
          
          const contentType = response.headers.get('content-type');
          if (response.ok && contentType && contentType.includes('application/json')) {
            result = await response.json();
            console.log('PAYPAL FINAL FALLBACK RESPONSE JSON:', result);
            if (result && result.approvalUrl) {
              isSuccess = true;
            }
          } else {
            const rawText = await response.text();
            console.warn('[PAYPAL RESPONSE NOT OK/JSON] /api/paypal/create-order:', response.status, rawText.substring(0, 500));
          }
        } catch (err3) {
          console.error('Final fallback /api/paypal/create-order failed too:', err3);
        }
      }
      
      if (!isSuccess || !result || !result.approvalUrl) {
        alert(result?.error || 'Não foi possível ligar ao PayPal. Se as credenciais do servidor não estão configuradas ou se o modo Sandbox estiver indisponível no momento, use Transferência ou Multicaixa para testar o Checkout.');
        setPaypalLoading(false);
        return;
      }
      
      // Sandbox-safe top redirection fix: Open approval in a new window/tab
      console.log('[PAYPAL REDIRECTING WINDOW] Opening approval window:', result.approvalUrl);
      const payWindow = window.open(result.approvalUrl, '_blank', 'noopener,noreferrer');
      if (!payWindow) {
        console.warn("[PAYPAL REDIRECT] Popup was likely blocked by the browser. Prompting manual click.");
      }

      // Automatically show visual status and start backend order polling
      setPaypalPollingStatus('Aguardando confirmação do pagamento PayPal...');
      setActivePollOrderId(result.paypalOrderId);
      setActiveDbOrderId(order.id);
      setPaypalLoading(false);
    } catch (err: any) {
      console.error('PayPal redirect error:', err);
      alert('Falha ao conectar ao PayPal. Por favor, desative extensões de bloqueio de anúncios (adblockers) ou verifique as suas restrições de rede.');
      setPaypalLoading(false);
    }
  };

  useEffect(() => {
    if (!activePollOrderId || !activeDbOrderId) return;

    let isMounted = true;
    console.log(`[PAYPAL POLL] Initializing automatic background polling for order ${activeDbOrderId} / Paypal Order ${activePollOrderId}`);
    
    const intervalId = setInterval(async () => {
      try {
        const response = await fetch(`/api/paypal/check-order/${activePollOrderId}?orderId=${activeDbOrderId}`);
        if (!response.ok) {
          console.warn("[PAYPAL POLL] API check endpoint returned unexpected response error:", response.status);
          return;
        }
        
        const data = await response.json();
        if (!isMounted) return;

        console.log(`[PAYPAL POLL STATUS] Received status: ${data.status}`);

        if (data.success && data.status === 'COMPLETED') {
          clearInterval(intervalId);
          const currentDbId = activeDbOrderId;
          setActivePollOrderId(null);
          setActiveDbOrderId(null);
          setIsOpen(false);
          // Redirect dynamically to premium success page
          window.location.href = `/payment/success?orderId=${currentDbId}`;
        } else if (data.status === 'APPROVED') {
          setPaypalPollingStatus('Pagamento autorizado! Processando libertação imediata...');
        } else {
          setPaypalPollingStatus('Aguardando confirmação do pagamento PayPal...');
        }
      } catch (err) {
        console.error("[PAYPAL POLL ERROR] Failed trying to fetch transaction status:", err);
      }
    }, 3000);

    return () => {
      isMounted = false;
      clearInterval(intervalId);
    };
  }, [activePollOrderId, activeDbOrderId]);

  useEffect(() => {
    const handleShowCheckout = (e: any) => {
      const selectedBeat = e.detail;
      setBeat(selectedBeat);
      setIsOpen(true);
      setStep('license');

      // Track professional analytics checkout_start event
      if (selectedBeat) {
        try {
          import('@/src/lib/analytics').then(m => {
            m.trackAnalyticsEvent('checkout_start', {
              producerId: selectedBeat.producer_id,
              beatId: selectedBeat.id,
              userId: user?.id || undefined,
              amount: Number(selectedBeat.price_basic || selectedBeat.price_premium || selectedBeat.price_exclusive || selectedBeat.price || 0)
            });
          });
        } catch (err) {
          console.error("[ANALYTICS] Checkout start tracking error:", err);
        }
      }
    };
    window.addEventListener('showCheckout', handleShowCheckout as any);
    return () => window.removeEventListener('showCheckout', handleShowCheckout as any);
  }, [user]);

  const createOrder = async () => {
    if (!beat || !user || !supabase) {
        console.error("Missing dependencies:", { beat, user, supabase });
        alert("Erro de sistema: Tente recarregar a página.");
        return;
    }
    
    if (user.id === beat.producer_id) {
        alert("Você não pode comprar o seu próprio beat.");
        return;
    }
    
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      
      const response = await fetch('/api/orders/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          beatId: beat.id,
          licenseType: selectedLicense
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Erro ao processar criação de pedido.");
      }

      const resData = await response.json();
      if (resData.success && resData.order) {
        setOrder(resData.order);
        setStep('payment');
      } else {
        throw new Error("Resposta inválida do servidor de pedidos.");
      }
    } catch (error: any) {
      console.error("Order creation error:", error);
      alert("Erro ao criar pedido: " + error.message);
    }
  };

  const confirmPayment = async () => {
    if (!order || !supabase) return;
    const { error } = await supabase.from('orders').update({ status: 'waiting_confirmation' }).eq('id', order.id);
    
    if (error) {
        console.error("Payment confirmation error:", error);
        alert("Erro ao confirmar pagamento: " + error.message);
        return;
    }
    
    setStep('confirm');
  };

  if (!isOpen) return null;

  // Pricing helper
  const getLicensePrice = (type: 'basic' | 'premium' | 'exclusive') => {
    if (!beat || !beat.price) {
      return type === 'basic' ? 25000 : type === 'premium' ? 75000 : 250000;
    }
    return beat.price[type] || (type === 'basic' ? 25000 : type === 'premium' ? 75000 : 250000);
  };

  const licensesInfo = {
    basic: {
      name: 'Básica (Basic)',
      price: getLicensePrice('basic'),
      icon: FileText,
      color: 'border-white/10 hover:border-white/20 hover:bg-white/[0.02]',
      activeColor: 'border-[#5865F2] bg-[#5865F2]/5 text-white',
      description: 'Ideal para início ou gravações para testes rápidos não monetizados.',
      features: [
        'Formato de Ficheiro: MP3 Only',
        'Até 20.000 Streamings/Visualizações',
        'Uso Pessoal & Não-Comercial',
        'Licença Não-Exclusiva'
      ]
    },
    premium: {
      name: 'Premium (MP3 + WAV)',
      price: getLicensePrice('premium'),
      icon: ShieldCheck,
      color: 'border-white/10 hover:border-white/20 hover:bg-white/[0.02]',
      activeColor: 'border-[#5865F2] bg-[#5865F2]/5 text-white',
      recommended: true,
      description: 'Excelente para lançamentos oficiais no Spotify/Apple e redes sociais.',
      features: [
        'Formato: MP3 + WAV Alta Qualidade',
        'Até 100.000 Streamings/Visualizações',
        'Videoclipe Comercial Permitido',
        'Licença Não-Exclusiva'
      ]
    },
    exclusive: {
      name: 'Ilimitada (Exclusive)',
      price: getLicensePrice('exclusive'),
      icon: Check,
      color: 'border-white/10 hover:border-white/20 hover:bg-white/[0.02]',
      activeColor: 'border-[#5865F2] bg-[#5865F2]/5 text-white',
      description: 'Liberdade criativa máxima e direitos totais em todas as plataformas.',
      features: [
        'WAV Master + Stems/Pistas',
        'Streamings & Reproduções Ilimitadas',
        'Monetização & Uso Comercial Livre',
        'Licença Não-Exclusiva standard'
      ]
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className={`bg-[#0e0e11] border border-white/10 rounded-xl w-full ${step === 'license' ? 'max-w-4xl' : step === 'payment' ? 'max-w-2xl' : 'max-w-md'} p-5 md:p-6 relative shadow-2xl transition-all duration-300 my-auto`}>
        <button 
          onClick={() => setIsOpen(false)} 
          className="absolute top-4 right-4 p-1.5 rounded bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X size={15} />
        </button>
        
        {step === 'license' && (
          <div className="space-y-5">
            <div className="space-y-0.5 text-left border-b border-white/5 pb-3">
              <span className="text-[#5865F2] text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                <Sparkles size={10} /> Adquirir Instrumental
              </span>
              <h2 className="text-lg md:text-xl font-bold tracking-tight text-white mt-1">
                Escolha os direitos de utilização para o beat
              </h2>
              <p className="text-gray-400 text-xs font-medium">Selecione o nível que melhor se adapta às necessidades do seu projeto.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              {(['basic', 'premium', 'exclusive'] as const).map(l => {
                const isSelected = selectedLicense === l;
                const info = licensesInfo[l];
                const Icon = info.icon;
                
                return (
                  <button 
                    key={l} 
                    onClick={() => setSelectedLicense(l)} 
                    className={`text-left p-4 rounded-lg border flex flex-col justify-between transition-all duration-200 relative group cursor-pointer ${
                      isSelected ? info.activeColor : info.color
                    }`}
                  >
                    {l === 'premium' && (
                      <span className="absolute -top-2.5 right-3 bg-[#5865F2] text-white px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider">
                        Recomendado
                      </span>
                    )}
                    
                    <div className="space-y-2.5 w-full">
                      <div className="flex items-center justify-between">
                        <div className={`p-1.5 rounded ${isSelected ? 'bg-white/10 text-white' : 'bg-white/5 text-gray-400 group-hover:bg-white/10'} transition-all`}>
                          <Icon size={14} />
                        </div>
                        <span className={`text-[10px] font-bold uppercase tracking-wider ${isSelected ? 'text-white' : 'text-gray-400'}`}>{l}</span>
                      </div>
                      
                      <div>
                        <h4 className="font-bold text-xs text-white tracking-tight">{info.name}</h4>
                        <p className="text-[10px] mt-1 text-gray-400 line-clamp-2 leading-relaxed h-7 font-medium">{info.description}</p>
                      </div>

                      <div className="space-y-1 pt-1.5 border-t border-white/5 w-full">
                        {info.features.map((f, index1) => (
                          <div key={index1} className="flex items-start gap-1.5">
                            <Check size={8} className="text-emerald-500 mt-1 shrink-0" />
                            <span className="text-[10px] text-gray-300 font-normal leading-snug">{f}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-3 mt-3 border-t border-white/5 w-full flex items-baseline justify-between select-none">
                      <span className="text-[9px] text-gray-400 font-semibold uppercase tracking-wider">Investimento</span>
                      <span className="font-bold text-white text-base font-mono">{info.price.toLocaleString('pt') || '0'} Kz</span>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-white/5 items-center justify-between">
              <span className="text-[11px] text-gray-400 flex items-center gap-1.5">
                <Info size={12} className="text-gray-400 shrink-0" />
                Os direitos de autor originais permanecem sempre com o produtor.
              </span>
              <button 
                onClick={() => setStep('details')} 
                className="w-full sm:w-auto px-6 py-2 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded text-xs font-semibold tracking-wide transition-colors cursor-pointer shadow-sm"
              >
                Continuar
              </button>
            </div>
          </div>
        )}

        {step === 'details' && (
          <div className="space-y-5 text-left">
            <div className="space-y-0.5 border-b border-white/5 pb-3">
              <span className="text-[#5865F2] text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                <CheckCircle2 size={10} /> Confirmar Pedido
              </span>
              <h2 className="text-base font-bold tracking-tight text-white">Resumo da Encomenda</h2>
            </div>

            <div className="bg-white/5 border border-white/5 p-3 rounded-lg flex gap-3.5 items-center">
              <img 
                src={(beat?.image && beat.image.trim() !== "") ? beat.image : null} 
                alt={beat?.title} 
                className="w-12 h-12 rounded object-cover shrink-0 border border-white/10" 
                referrerPolicy="no-referrer"
              />
              <div className="space-y-0.5 min-w-0 pr-2">
                <h3 className="font-bold text-white text-sm truncate">{beat?.title}</h3>
                <p className="text-gray-400 text-xs">Produtor: {beat?.producer_name || 'BATUKADA'}</p>
              </div>
            </div>

            <div className="bg-[#18181b]/40 border border-white/5 p-4 rounded-lg space-y-3">
              <p className="text-gray-300 text-xs font-normal">
                Selecionou a licença <span className="text-[#5865F2] capitalize font-bold">{selectedLicense}</span> para este beat.
              </p>
              
              <div className="space-y-1">
                {licensesInfo[selectedLicense].features.map((f, index2) => (
                  <div key={index2} className="flex items-center gap-1.5">
                    <Check size={10} className="text-emerald-500" />
                    <span className="text-[10px] text-gray-300 font-medium">{f}</span>
                  </div>
                ))}
              </div>

              <div className="text-[10px] text-gray-400 bg-white/[0.02] p-2.5 rounded border border-white/5 font-medium leading-relaxed">
                * As licenças atribuídas aos instrumentais são de uso final do artista e não podem ser revendidas ou sub-licenciadas.
              </div>
            </div>

            <div className="border-t border-white/5 pt-3.5 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-400">Subtotal</span>
                <span className="text-white font-medium font-mono">{getLicensePrice(selectedLicense).toLocaleString('pt')} Kz</span>
              </div>
              <div className="flex justify-between items-center text-sm pt-1 border-t border-white/[0.03]">
                <span className="text-gray-200 font-bold">Total a Pagar</span>
                <span className="text-[#5865F2] font-semibold text-base font-mono">{getLicensePrice(selectedLicense).toLocaleString('pt')} Kz</span>
              </div>
            </div>

            <div className="flex gap-2.5 pt-1">
              <button 
                onClick={() => setStep('license')} 
                className="flex-1 py-2 bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded text-xs font-semibold tracking-wide transition-colors cursor-pointer"
              >
                Voltar
              </button>
              <button 
                onClick={createOrder} 
                className="flex-[2] py-2 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded text-xs font-semibold tracking-wide transition-colors cursor-pointer shadow-sm"
              >
                Confirmar e Avançar
              </button>
            </div>
          </div>
        )}
        
        {step === 'payment' && order && (
            <div className="space-y-5 animate-fadeIn">
                {/* HEADER CLEAN */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center py-3.5 border-b border-white/5 gap-3">
                  <div className="space-y-0.5 text-left">
                    <h2 className="text-sm font-bold tracking-tight text-white uppercase">Dados de Faturação</h2>
                    <p className="text-[11px] text-gray-400">Selecione o método de pagamento preferencial</p>
                    <div className="flex items-center gap-2 pt-1">
                      <span className="text-[10px] font-mono text-gray-500 uppercase">
                        Pedido <span className="text-[#5865F2] font-semibold">#{getDisplayId(order.id)}</span>
                      </span>
                      <button
                        onClick={() => handleCopyText(getDisplayId(order.id), 'pedido')}
                        type="button"
                        className="text-[9px] text-gray-400 hover:text-white transition-colors flex items-center gap-1 cursor-pointer active:scale-95"
                        title="Copiar número do pedido"
                      >
                        {copiedLabel === 'pedido' ? (
                          <span className="text-emerald-400 font-semibold mb-0.5">Copiado!</span>
                        ) : (
                          <>
                            <Copy size={9} />
                            <span>copiar</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                  <div className="bg-white/5 border border-white/5 px-3 py-1.5 rounded flex flex-col items-end shrink-0 select-none">
                    <span className="text-[9px] text-gray-400 font-semibold uppercase tracking-wider leading-none">Total</span>
                    <span className="text-sm font-mono font-bold text-white pt-1">{Number(order.amount).toLocaleString('pt')} AOA</span>
                  </div>
                </div>

                {/* PAYMENT METHODS GRID (Horizontal on desktop, stacked on mobile) */}
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {/* CARD 1: MULTICAIXA */}
                    <button
                      onClick={() => setSelectedMethod('multicaixa')}
                      type="button"
                      className={`p-4 rounded border text-left transition-all duration-200 relative overflow-hidden group cursor-pointer ${
                        selectedMethod === 'multicaixa'
                          ? 'bg-[#131317] border-[#5865F2] text-white shadow-sm scale-[1.01]'
                          : 'bg-white/[0.01] border-white/5 hover:bg-white/5 hover:border-white/10'
                      }`}
                    >
                      <div className="flex flex-col justify-between h-full gap-4">
                        <div className="flex items-center justify-between">
                          <div className="h-6 flex items-center justify-start overflow-hidden">
                            {!imgErrors.multicaixa ? (
                              <img 
                                src="https://i.ibb.co/KzSPvW7Z/20260528-124050.png" 
                                alt="Multicaixa Express" 
                                className="h-6 w-auto max-w-[100px] object-contain shrink-0 filter brightness-110"
                                onError={() => handleImgError('multicaixa')}
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <span className="text-[9px] font-bold uppercase text-[#5865F2] bg-[#5865F2]/10 px-1.5 py-0.5 rounded border border-[#5865F2]/20">
                                MC Express
                              </span>
                            )}
                          </div>
                          {selectedMethod === 'multicaixa' && (
                            <div className="w-3.5 h-3.5 rounded-full bg-[#5865F2] flex items-center justify-center">
                              <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                            </div>
                          )}
                        </div>
                        <div>
                          <h4 className="font-semibold text-[9px] text-gray-400 uppercase tracking-widest leading-none">Multicaixa</h4>
                          <p className="font-bold text-xs text-white mt-1">Express</p>
                        </div>
                      </div>
                    </button>

                    {/* CARD 2: BANK */}
                    <button
                      onClick={() => setSelectedMethod('bank')}
                      type="button"
                      className={`p-4 rounded border text-left transition-all duration-200 relative overflow-hidden group cursor-pointer ${
                        selectedMethod === 'bank'
                          ? 'bg-[#131317] border-[#5865F2] text-white shadow-sm scale-[1.01]'
                          : 'bg-white/[0.01] border-white/5 hover:bg-white/5 hover:border-white/10'
                      }`}
                    >
                      <div className="flex flex-col justify-between h-full gap-4">
                        <div className="flex items-center justify-between">
                          <div className="h-6 flex items-center justify-start overflow-hidden">
                            {!imgErrors.bank ? (
                              <img 
                                src="https://i.ibb.co/Xx86qPpQ/20260528-124119.png" 
                                alt="Transferência Bancária" 
                                className="h-6 w-auto max-w-[100px] object-contain shrink-0 filter brightness-110"
                                onError={() => handleImgError('bank')}
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <span className="text-[9px] font-bold uppercase text-[#5865F2] bg-[#5865F2]/10 px-1.5 py-0.5 rounded border border-[#5865F2]/20">
                                Banco IBAN
                              </span>
                            )}
                          </div>
                          {selectedMethod === 'bank' && (
                            <div className="w-3.5 h-3.5 rounded-full bg-[#5865F2] flex items-center justify-center">
                              <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                            </div>
                          )}
                        </div>
                        <div>
                          <h4 className="font-semibold text-[9px] text-gray-400 uppercase tracking-widest leading-none">Transferência</h4>
                          <p className="font-bold text-xs text-white mt-1">Bancária</p>
                        </div>
                      </div>
                    </button>

                    {/* CARD 3: PAYPAL */}
                    <button
                      onClick={() => setSelectedMethod('paypal')}
                      type="button"
                      className={`p-4 rounded border text-left transition-all duration-200 relative overflow-hidden group cursor-pointer ${
                        selectedMethod === 'paypal'
                          ? 'bg-[#131317] border-[#5865F2] text-white shadow-sm scale-[1.01]'
                          : 'bg-white/[0.01] border-white/5 hover:bg-white/5 hover:border-white/10'
                      }`}
                    >
                      <div className="flex flex-col justify-between h-full gap-4">
                        <div className="flex items-center justify-between">
                          <div className="h-6 flex items-center justify-start overflow-hidden">
                            {!imgErrors.paypal ? (
                              <img 
                                src="https://i.ibb.co/C341M6jR/20260528-124010.png" 
                                alt="PayPal" 
                                className="h-6 w-auto max-w-[100px] object-contain shrink-0"
                                onError={() => handleImgError('paypal')}
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <span className="text-[9px] font-bold uppercase text-[#5865F2] bg-[#5865F2]/10 px-1.5 py-0.5 rounded border border-[#5865F2]/20">
                                PayPal
                              </span>
                            )}
                          </div>
                          {selectedMethod === 'paypal' && (
                            <div className="w-3.5 h-3.5 rounded-full bg-[#5865F2] flex items-center justify-center">
                              <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                            </div>
                          )}
                        </div>
                        <div>
                          <h4 className="font-semibold text-[9px] text-gray-400 uppercase tracking-widest leading-none">Internacional</h4>
                          <p className="font-bold text-xs text-white mt-1">PayPal</p>
                        </div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* INFORMATION DISPLAY CARD */}
                <div className="relative z-10">
                  {selectedMethod === 'multicaixa' && (
                    <div className="bg-[#18181b]/30 border border-white/5 p-4 rounded-lg space-y-3 animate-fadeIn">
                      {/* TELEFONE/NÚMERO */}
                      <div className="flex items-center justify-between bg-white/[0.01] border border-white/5 px-3.5 py-3 rounded group hover:border-white/10 hover:bg-white/[0.02] transition-colors">
                        <div className="space-y-0.5 text-left">
                          <p className="text-[9px] text-gray-400 uppercase font-bold tracking-wider">Número para Transferência / Express</p>
                          <p className="font-mono text-white text-sm font-bold tracking-wider leading-none pt-1">934 337 023</p>
                        </div>
                        <button
                          onClick={() => handleCopyText('934337023', 'telefone')}
                          type="button"
                          className="px-3 py-1.5 rounded bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-all text-[10px] font-semibold tracking-wider flex items-center gap-1.5 cursor-pointer active:scale-95"
                        >
                          {copiedLabel === 'telefone' ? (
                            <>
                              <Check size={10} className="text-emerald-500" />
                              <span className="text-emerald-400">Copiado</span>
                            </>
                          ) : (
                            <>
                              <Copy size={10} />
                              <span>Copiar</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {selectedMethod === 'bank' && (
                    <div className="bg-[#18181b]/30 border border-white/5 p-4 rounded-lg space-y-2.5 animate-fadeIn">
                      {/* NOME / TITULAR */}
                      <div className="flex items-center justify-between bg-white/[0.01] border border-white/5 px-3.5 py-3 rounded group hover:border-white/10 hover:bg-white/[0.02] transition-colors">
                        <div className="space-y-0.5 text-left font-sans">
                          <p className="text-[9px] text-gray-400 uppercase font-bold tracking-wider">Beneficiário</p>
                          <p className="text-white text-xs font-bold leading-none pt-1">Miguel Francisco Alfredo</p>
                        </div>
                        <button
                          onClick={() => handleCopyText('Miguel Francisco Alfredo', 'titular')}
                          type="button"
                          className="px-3 py-1.5 rounded bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-all text-[10px] font-semibold tracking-wider flex items-center gap-1.5 cursor-pointer active:scale-95"
                        >
                          {copiedLabel === 'titular' ? (
                            <>
                              <Check size={10} className="text-emerald-500" />
                              <span className="text-emerald-400">Copiado</span>
                            </>
                          ) : (
                            <>
                              <Copy size={10} />
                              <span>Copiar</span>
                            </>
                          )}
                        </button>
                      </div>

                      {/* IBAN */}
                      <div className="flex items-center justify-between bg-white/[0.01] border border-white/5 px-3.5 py-3 rounded group hover:border-white/10 hover:bg-white/[0.02] transition-colors">
                        <div className="space-y-0.5 min-w-0 pr-2 text-left">
                          <p className="text-[9px] text-gray-400 uppercase font-bold tracking-wider">IBAN Angola</p>
                           <p className="font-mono text-white text-xs font-bold truncate leading-none pt-1 select-all">AO06 0006 0000 2373 3702 3017 1</p>
                        </div>
                        <button
                          onClick={() => handleCopyText('AO06000600002373370230171', 'iban')}
                          type="button"
                          className="px-3 py-1.5 rounded bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-all text-[10px] font-semibold tracking-wider flex items-center gap-1.5 cursor-pointer active:scale-95 shrink-0"
                        >
                          {copiedLabel === 'iban' ? (
                            <>
                              <Check size={10} className="text-emerald-500" />
                              <span className="text-emerald-400">Copiado</span>
                            </>
                          ) : (
                            <>
                              <Copy size={10} />
                              <span>Copiar</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {selectedMethod === 'paypal' && (
                    <div className="bg-[#18181b]/30 border border-white/5 p-4 rounded-lg space-y-3 animate-fadeIn">
                      <div className="flex items-center justify-between bg-white/[0.01] border border-white/5 p-3 rounded border-dashed">
                        <div className="space-y-0.5 text-left">
                          <p className="text-[9px] text-gray-400 uppercase font-bold tracking-wider">Internacional Equivalente</p>
                          <span className="font-semibold text-white text-base font-mono">${(Number(order.amount) / 850).toFixed(2)} USD</span>
                        </div>
                        <span className="text-[9px] text-gray-400 font-medium font-mono">(1 USD ≈ 850 Kz)</span>
                      </div>

                      {activePollOrderId ? (
                        <div className="p-3 bg-[#5865F2]/10 border border-[#5865F2]/20 text-[#5865F2] rounded text-center space-y-1.5">
                          <div className="flex items-center justify-center gap-2">
                            <div className="w-3.5 h-3.5 border-2 border-[#5865F2]/30 border-t-[#5865F2] rounded-full animate-spin"></div>
                            <span className="text-xs font-bold">{paypalPollingStatus || 'Aguardando pagamento PayPal...'}</span>
                          </div>
                          <p className="text-[10px] text-gray-400 font-medium leading-relaxed">Conclua o pagamento na janela ou aba aberta pelo PayPal.</p>
                        </div>
                      ) : (
                        <button
                          onClick={handlePayWithPayPal}
                          disabled={paypalLoading}
                          type="button"
                          className="w-full py-2 bg-[#0070ba] hover:bg-[#005ea6] disabled:opacity-50 text-white rounded font-semibold text-xs tracking-wide transition-colors cursor-pointer flex items-center justify-center gap-2"
                        >
                          {paypalLoading ? (
                             <>
                               <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                               <span>Processando...</span>
                             </>
                          ) : (
                            <span>Pagar com PayPal</span>
                          )}
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* BOTTOM ACTION AREA */}
                <div className="border-t border-white/5 pt-4 space-y-3 relative z-10 text-center">
                  {selectedMethod !== 'paypal' ? (
                     <div className="flex flex-col sm:flex-row gap-2 justify-center items-center">
                       <button 
                         onClick={confirmPayment} 
                         type="button"
                         className="w-full sm:max-w-md py-2 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded font-semibold text-xs tracking-wide transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
                       >
                         <span>Confirmar Pagamento</span>
                       </button>
                      <a 
                        href={`https://wa.me/27697273223?text=Olá, fiz o pagamento do pedido ${order.id} correspondente ao beat ${beat?.title}.`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="bg-white/5 border border-white/10 hover:bg-white/10 p-2 rounded text-white flex items-center justify-center transition-colors active:scale-[0.98] cursor-pointer shrink-0"
                        title="Enviar comprovativo pelo WhatsApp"
                      >
                        <MessageCircle size={16} className="text-[#25D366]" />
                      </a>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2">
                       {activePollOrderId ? (
                         <div className="w-full sm:max-w-md p-3 bg-white/5 border border-white/5 text-gray-300 rounded text-center">
                           <div className="flex items-center justify-center gap-2">
                             <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                             <span className="text-[11px] font-medium uppercase tracking-wider">{paypalPollingStatus}</span>
                           </div>
                         </div>
                       ) : (
                        <button 
                          onClick={handlePayWithPayPal} 
                          disabled={paypalLoading}
                          type="button"
                          className="w-full sm:max-w-md py-2 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded font-semibold text-xs tracking-wide transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
                        >
                          {paypalLoading ? (
                             <>
                               <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                               <span>A ligar ao PayPal...</span>
                             </>
                          ) : (
                            <span>Pagar com PayPal</span>
                          )}
                        </button>
                      )}
                      <a 
                        href={`https://wa.me/27697273223?text=Olá, preciso de suporte com o pagamento PayPal ${order.id} correspondente ao beat ${beat?.title}.`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-[10px] text-gray-400 hover:text-white font-medium tracking-wide transition-colors flex items-center gap-1"
                      >
                        <MessageCircle size={11} className="text-[#25D366]" />
                        <span>Suporte Técnico WhatsApp</span>
                      </a>
                    </div>
                  )}

                  {/* SECURITY AREA */}
                  <div className="py-1 select-none">
                    <img
                      src="https://i.ibb.co/W4FJsdMs/20260528-164246.png"
                      alt="Payment Methods"
                      className="h-7 w-auto object-contain mx-auto opacity-75"
                    />
                  </div>
                </div>
            </div>
        )}

        {step === 'confirm' && (
            <div className="text-center space-y-4 py-4">
                <CheckCircle2 size={48} className="text-emerald-500 mx-auto" />
                <h2 className="text-base font-bold tracking-tight text-white uppercase">Pedido Submetido!</h2>
                <div className="space-y-1.5 px-1">
                  <p className="text-gray-400 text-xs font-medium">O seu comprovativo de pagamento está a ser validado pela equipa Batukada.</p>
                  <p className="text-xs text-[#5865F2] font-semibold">Os ficheiros da licença ({selectedLicense.toUpperCase()}) estarão disponíveis de seguida na sua conta.</p>
                </div>
                <button 
                  onClick={() => setIsOpen(false)} 
                  className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded text-xs font-semibold tracking-wide transition-colors"
                >
                  Fechar Painel
                </button>
            </div>
        )}
      </div>
    </div>
  );
}

