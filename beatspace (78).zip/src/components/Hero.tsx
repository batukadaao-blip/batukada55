import { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { Search, Headphones, Zap, Users, ArrowRight } from 'lucide-react';
import { Beat } from '../types';

interface HeroProps {
  onExplore: () => void;
  onStartSelling: () => void;
  beats?: Beat[];
  currentBeat?: Beat | null;
  isPlaying?: boolean;
  onPlay?: (beat: Beat) => void;
}

export default function Hero({ 
  onExplore, 
  onStartSelling, 
  beats = [], 
  currentBeat = null, 
  isPlaying = false, 
  onPlay 
}: HeroProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const stats = [
    { label: 'Produtores', value: '1.200+', icon: Users },
    { label: 'Beats Vendidos', value: '15k+', icon: Zap },
    { label: 'Plays Mensais', value: '2M+', icon: Headphones },
  ];

  const handleSearchSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    const searchUrl = `/all-beats?q=${encodeURIComponent(searchQuery.trim())}`;
    window.history.pushState({}, '', searchUrl);
    window.dispatchEvent(new Event('popstate'));
  };

  return (
    <section 
      id="hero-cinematic" 
      className="relative min-h-[92vh] w-full bg-transparent flex items-center justify-start overflow-hidden pt-36 pb-24 px-6 sm:px-12 lg:px-20 text-left"
    >
      {/* Background overlay with premium dark look & very subtle editorial grid pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:4rem_4rem] mix-blend-overlay" />

      {/* Subtlest conceivable neutral vignette glow (less saturated) */}
      <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-[#5865F2]/[0.02] rounded-full blur-[140px] pointer-events-none -z-10" />

      <div className="w-full max-w-[1400px] mx-auto z-10 relative">
        <div className="max-w-[850px] space-y-12">
          
          {/* Tagline Badge */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.03] border border-white/[0.08]"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#5865F2]" />
            <span className="text-[10px] font-bold text-neutral-300 tracking-widest uppercase">BATUKADA HUB</span>
          </motion.div>

          {/* Headline - Editorial and Massive impact visual */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="space-y-6"
          >
            <h1 className="text-5xl sm:text-7xl lg:text-[88px] font-black text-white leading-[0.92] tracking-[-0.04em]">
              Venda Beats.<br />
              Construa Sua<br />
              <span className="text-[#5865F2]">História.</span>
            </h1>

            {/* Subheadline (Controlled spacing & size) */}
            <p className="text-neutral-400 text-sm sm:text-base md:text-lg max-w-[600px] leading-relaxed font-normal">
              O marketplace de eleição em Angola para produtores comercializarem beats, drum kits e loops profissionalmente com contratos digitais automáticos.
            </p>
          </motion.div>

          {/* Search Bar Grande (Airbit / High impact style) */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-full max-w-[680px]"
          >
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <div className="relative flex-1">
                <Search className="absolute left-5 text-neutral-500 top-1/2 -translate-y-1/2 cursor-default" size={20} />
                <input 
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Pesquise por ritmo, gênero, produtor..."
                  className="w-full h-16 pl-14 pr-32 sm:pr-40 bg-white text-neutral-900 placeholder-neutral-500 rounded-xl text-sm sm:text-base font-semibold focus:outline-none focus:ring-2 focus:ring-[#5865F2]/50 shadow-[0_20px_50px_rgba(0,0,0,0.6)] transition-all"
                />
              </div>
              <button
                type="submit"
                className="absolute right-2.5 px-5 sm:px-6 h-11 rounded-lg bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs sm:text-sm font-bold uppercase tracking-wider flex items-center gap-2 transition-all duration-150 active:scale-95 cursor-pointer"
              >
                <span>Pesquisar</span>
                <ArrowRight size={14} strokeWidth={2.5} />
              </button>
            </form>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-wrap items-center gap-4"
          >
            <button 
              onClick={onExplore}
              className="px-8 py-4 rounded-xl bg-white hover:bg-neutral-100 text-neutral-950 font-bold uppercase tracking-wider text-xs transition-all cursor-pointer select-none active:scale-[0.98] duration-150 flex items-center gap-2"
            >
              Explorar Catálogo
            </button>
            <button 
              onClick={onStartSelling}
              className="px-8 py-4 rounded-xl bg-[#121216] hover:bg-[#1a1a22] text-white border border-white/5 hover:border-white/10 font-bold uppercase tracking-wider text-xs transition-all cursor-pointer select-none active:scale-[0.98] duration-150"
            >
              Começar a Vender
            </button>
          </motion.div>

          {/* Stats below */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-3 gap-8 pt-10 border-t border-white/[0.04] max-w-xl"
          >
            {stats.map((stat, i) => (
              <div key={i} className="space-y-0.5">
                <div className="flex items-center gap-1.5 text-neutral-500">
                  <stat.icon size={11} className="text-[#5865F2]" />
                  <span className="text-[9px] uppercase font-bold tracking-wider">{stat.label}</span>
                </div>
                <div className="text-xl sm:text-2xl font-black text-white tracking-tight">{stat.value}</div>
              </div>
            ))}
          </motion.div>

        </div>
      </div>
    </section>
  );
}
