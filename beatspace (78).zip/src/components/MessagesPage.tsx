import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, MessageSquare, Search, ArrowLeft, Clock, Check, CheckCheck, Send, Radio, MoreVertical, Trash2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../hooks/useChat';
import { getSupabase } from '../lib/supabase';

export default function MessagesPage({ 
  onBack,
  targetUserId,
  clearTargetUserId,
  onSelectUser
}: { 
  onBack: () => void;
  targetUserId?: string | null;
  clearTargetUserId?: () => void;
  onSelectUser?: (userId: string) => void;
}) {
  const { user, profile } = useAuth();
  const { 
    conversations, 
    messages, 
    setMessages, 
    sendMessage, 
    sendTyping, 
    typingStatus, 
    activeConversationId,
    setActiveConversationId,
    deleteConversation,
    fetchConversations,
    setConversations
  } = useChat(user?.id);
  
  const [selectedConv, setSelectedConv] = useState<any>(null);
  const [input, setInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showDeleteMenu, setShowDeleteMenu] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const prevMessagesCountRef = useRef<number>(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize notifications audio chime
  useEffect(() => {
    audioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2358/2358-84.wav');
    audioRef.current.volume = 0.3;
  }, []);

  // Handle auto-conversations for targetUserId passed as prop
  useEffect(() => {
    if (targetUserId && user?.id) {
      console.log("[MESSAGES LOG] Cliked MESSAGE button. Initiating private chat viewport.", { buyerId: user.id, sellerId: targetUserId });
      
      fetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ buyerId: user.id, sellerId: targetUserId })
      })
        .then(res => {
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
          return res.json();
        })
        .then(async (newConv) => {
          console.log("[MESSAGES LOG] Conversation successfully fetched or created:", newConv);
          if (newConv && newConv.id) {
            await fetchConversations();
            setActiveConversationId(newConv.id);
            setSelectedConv(newConv);
            console.log("[MESSAGES LOG] Thread successfully selected. Active ID:", newConv.id);
          }
          if (clearTargetUserId) {
            console.log("[MESSAGES DEBUG] Clearing target recipient parameter from the router to stabilize active state.");
            clearTargetUserId();
          }
        })
        .catch(err => {
          console.error("[MESSAGES LOG] Error setting up private chat:", err);
          if (clearTargetUserId) clearTargetUserId();
        });
    }
  }, [targetUserId, user?.id]);

  // Synchronize selectedConv details with updated profiles from hook list (without creating infinite query loops)
  useEffect(() => {
    if (activeConversationId && conversations.length > 0) {
      const found = conversations.find((c: any) => String(c.id) === String(activeConversationId));
      if (found) {
        // Enforce update only when profiles change or on ID mismatch
        const hasDifferentId = !selectedConv || String(selectedConv.id) !== String(found.id);
        const p1 = JSON.stringify(selectedConv?.buyer_profile);
        const p2 = JSON.stringify(found.buyer_profile);
        const s1 = JSON.stringify(selectedConv?.seller_profile);
        const s2 = JSON.stringify(found.seller_profile);
        
        if (hasDifferentId || p1 !== p2 || s1 !== s2) {
          console.log("[MESSAGES DEBUG] Syncing rich participant profile detail inside selectedConv:", found);
          setSelectedConv(found);
        }
      }
    }
  }, [activeConversationId, conversations]);

  // Safeguard: Direct automatic profile loading on conversation load (Requirement 6)
  useEffect(() => {
    if (selectedConv) {
      const loadProfileDetails = async () => {
        const supabase = getSupabase();
        if (!supabase) return;
        
        const bId = selectedConv.buyer_id;
        const sId = selectedConv.seller_id;
        
        console.log(`[PROFILES LOAD - Req 6] Loading profiles for active conversation. Buyer ID: ${bId}, Seller ID: ${sId}`);
        
        try {
          const { data: fetchedProfiles, error } = await supabase
            .from('profiles')
            .select('id, artistic_name, display_name, username, avatar_url, role, is_verified')
            .in('id', [bId, sId]);
            
          if (error) {
            console.error('[PROFILES LOAD ERROR] Failed to load details from Supabase:', error);
            return;
          }
          
          if (fetchedProfiles && fetchedProfiles.length > 0) {
            const bProfile = fetchedProfiles.find((p: any) => String(p.id).toLowerCase() === String(bId).toLowerCase()) || null;
            const sProfile = fetchedProfiles.find((p: any) => String(p.id).toLowerCase() === String(sId).toLowerCase()) || null;
            
            // Log details as requested by Requirement 10
            console.log('[PROFILES LOAD - Req 10 Logs] Profiles resolved:');
            if (bProfile) {
              console.log(` - Buyer/Participant ID = "${bProfile.id}", Profile ID = "${bProfile.id}", artistic_name = "${bProfile.artistic_name}", display_name = "${bProfile.display_name}", username = "${bProfile.username}", avatar_url = "${bProfile.avatar_url}"`);
            } else {
              console.log(' - Buyer profile not found in tables.');
            }
            if (sProfile) {
              console.log(` - Seller/Participant ID = "${sProfile.id}", Profile ID = "${sProfile.id}", artistic_name = "${sProfile.artistic_name}", display_name = "${sProfile.display_name}", username = "${sProfile.username}", avatar_url = "${sProfile.avatar_url}"`);
            } else {
              console.log(' - Seller profile not found in tables.');
            }
            
            // Check if profiles have changed
            const bOld = JSON.stringify(selectedConv.buyer_profile);
            const bNew = JSON.stringify(bProfile);
            const sOld = JSON.stringify(selectedConv.seller_profile);
            const sNew = JSON.stringify(sProfile);
            
            if (bOld !== bNew || sOld !== sNew) {
              setSelectedConv((prev: any) => {
                if (!prev || String(prev.id) !== String(selectedConv.id)) return prev;
                return {
                  ...prev,
                  buyer_profile: bProfile,
                  seller_profile: sProfile
                };
              });
              
              // Also update in conversations list in our local hook state if possible so it reflects in sidebar
              setConversations((prevList: any[]) => 
                prevList.map((conv: any) => {
                  if (String(conv.id) === String(selectedConv.id)) {
                    return {
                      ...conv,
                      buyer_profile: bProfile,
                      seller_profile: sProfile
                    };
                  }
                  return conv;
                })
              );
            }
          }
        } catch (e) {
          console.error('[PROFILES LOAD FATAL] Crash during profiles load:', e);
        }
      };
      
      loadProfileDetails();
    }
  }, [selectedConv?.id]);

  // Fetch messages and mark as read on active conversation ID change
  useEffect(() => {
    if (selectedConv?.id) {
      const convId = selectedConv.id;
      setActiveConversationId(convId);
      
      // Fetch messages
      fetch(`/api/conversations/${convId}/messages`)
        .then(res => {
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
          return res.json();
        })
        .then(data => {
          const messagesArray = Array.isArray(data) ? data : [];
          console.log("[MESSAGES LOG] Historic messages successfully loaded for thread. Count:", messagesArray.length);
          setMessages(messagesArray);
          prevMessagesCountRef.current = messagesArray.length;
        })
        .catch(err => {
          console.error(`[MESSAGES LOG] Error loading thread messages for ID: ${convId}`, err);
          setMessages([]);
        });
        
      // Mark as read
      if (user?.id) {
        fetch(`/api/conversations/${convId}/read`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: user.id })
        })
          .then(() => {
            fetchConversations();
          })
          .catch(err => console.error(`[MESSAGES LOG] Error marking thread as read:`, err));
      }
    } else {
      setActiveConversationId(null);
      setMessages([]);
    }
  }, [selectedConv?.id, user?.id]);

  // Handle incoming message chime sound organically when count increments
  useEffect(() => {
    if (messages.length > prevMessagesCountRef.current) {
      const newestMsg = messages[messages.length - 1];
      // Only play chime sound on messages sent by the other user
      if (newestMsg && newestMsg.sender_id !== user?.id) {
        audioRef.current?.play().catch(() => {});
      }
    }
    prevMessagesCountRef.current = messages.length;
    scrollToBottom();
  }, [messages, user?.id]);

  const scrollToBottom = () => {
    // Scroll the messaging container directly to the bottom
    // this avoids calling scrollIntoView on child elements which scrolls the entire window to the footer
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
    }
    // Fallback delayed scroll to handle mounting & content animations
    setTimeout(() => {
      if (messagesContainerRef.current) {
        messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
      }
    }, 50);
  };

  const handleSend = () => {
    if (!input.trim() || !selectedConv) return;
    const recipientId = selectedConv.buyer_id === user?.id ? selectedConv.seller_id : selectedConv.buyer_id;
    sendMessage(recipientId, input, selectedConv.id);
    setInput('');
    sendTyping(recipientId, selectedConv.id, false);
  };

  const getOtherParticipant = (conv: any) => {
    if (!conv) return null;
    const currentUserId = String(user?.id || '').toLowerCase();
    
    const participants = [];
    if (conv.buyer_profile) participants.push(conv.buyer_profile);
    if (conv.seller_profile) participants.push(conv.seller_profile);
    
    const otherParticipant = participants.find(
      p => p && String(p.id || '').toLowerCase() !== currentUserId
    );
    if (otherParticipant) {
      return otherParticipant;
    }
    
    // Fallback if profiles are not resolved yet or ID match fails
    const isBuyerMe = String(conv.buyer_id || '').toLowerCase() === currentUserId;
    return isBuyerMe ? conv.seller_profile : conv.buyer_profile;
  };

  const isOtherParticipantVerified = (conv: any) => {
    const participant = getOtherParticipant(conv);
    return participant?.is_verified === true;
  };

  const getParticipantBadge = (conv: any) => {
    const participant = getOtherParticipant(conv);
    if (!participant) return null;

    const role = (participant.role || '').toLowerCase();
    const isVerified = participant.is_verified === true;

    if (role === 'admin') {
      return {
        text: 'ADMIN',
        style: 'bg-[#5865F2]/10 text-blue-400 border-[#5865F2]/20'
      };
    } else if (role === 'producer' || role === 'seller') {
      return {
        text: isVerified ? 'PRODUTOR VERIFICADO' : 'PRODUTOR',
        style: isVerified 
          ? 'bg-[#5865F2]/15 border-[#5865F2]/25 text-blue-300' 
          : 'bg-purple-500/10 text-purple-400 border-purple-500/20'
      };
    } else {
      // client, buyer, artist or standard fallback
      return {
        text: 'ARTISTA',
        style: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
      };
    }
  };

  // Resolve human friendly profile names gracefully with fallbacks (Requirement 7, 8, 10)
  const getDisplayNameForProfile = (profile: any) => {
    if (!profile) return '';

    // Log the profile attributes for diagnostic tracing (Requirement 10 logs)
    console.log("[MESSAGES DIAGNOSTIC REQUIREMENT 10] participant & profile info:", {
      "participant id": profile.id,
      "profile id": profile.id,
      "artistic_name": profile.artistic_name,
      "display_name": profile.display_name,
      "username": profile.username,
      "avatar_url": profile.avatar_url || profile.avatar
    });

    const nameCandidates = [
      profile.artistic_name,
      profile.display_name,
      profile.username
    ];

    for (const candidate of nameCandidates) {
      if (candidate && typeof candidate === 'string' && candidate.trim() !== '') {
        const trimmed = candidate.trim();
        if (trimmed.includes('@')) {
          // If the display name looks like an email address, extract clean local-part
          const stripped = trimmed.split('@')[0];
          if (stripped && stripped.trim() !== '') {
            return stripped.trim();
          }
        } else {
          return trimmed;
        }
      }
    }

    if (profile.username) return `@${profile.username}`;
    return '';
  };

  const otherUser = (conv: any) => {
    const participant = getOtherParticipant(conv);
    if (participant) {
      const name = getDisplayNameForProfile(participant);
      if (name) return name;
      
      const role = (participant.role || '').toLowerCase();
      const fallbackId = String(participant.id || '').slice(0, 4);
      return role === 'client' || role === 'buyer' || role === 'artist' 
        ? `Artista ${fallbackId}` 
        : `Produtor ${fallbackId}`;
    }
    
    const currentUserId = String(user?.id || '').toLowerCase();
    const isBuyer = String(conv.buyer_id || '').toLowerCase() === currentUserId;
    const fallbackId = isBuyer ? conv.seller_id : conv.buyer_id;
    return isBuyer ? `Produtor ${String(fallbackId || '').slice(0, 4)}` : `Artista ${String(fallbackId || '').slice(0, 4)}`;
  };

  const otherAvatar = (conv: any) => {
    const participant = getOtherParticipant(conv);
    
    const url = participant?.avatar_url || participant?.avatar;
    if (url && url !== "null" && url !== "undefined" && url.trim() !== "") {
      return url.trim();
    }
    return '';
  };

  const otherUsername = (conv: any) => {
    const participant = getOtherParticipant(conv);
    return participant?.username ? `@${participant.username}` : '';
  };

  // Filter conversations based on query
  const filteredConversations = conversations.filter((conv: any) => {
    const query = searchQuery.toLowerCase();
    const nameStr = otherUser(conv).toLowerCase();
    const usernameStr = otherUsername(conv).toLowerCase();
    return nameStr.includes(query) || usernameStr.includes(query);
  });

  return (
    <div className="max-w-6xl mx-auto h-[80vh] flex flex-col bg-[#08080a] border border-white/[0.04] rounded-2xl overflow-hidden shadow-[0_24px_64px_rgba(0,0,0,0.6)]">
      {/* Main Row container */}
      <div className="flex flex-grow overflow-hidden bg-[#08080a] h-full relative">
        
        {/* Left Sidebar: Conversations List */}
        <div className={`w-full md:w-80 border-r border-white/[0.03] flex flex-col bg-[#0c0c0f] select-none shrink-0 transition-all duration-300 ${
          selectedConv ? 'hidden md:flex' : 'flex'
        }`}>
          {/* Sidebar Header */}
          <div className="h-[76px] px-4 border-b border-white/[0.03] flex items-center justify-between bg-[#0e0e11] shrink-0">
            <div className="flex items-center gap-2.5">
              <button 
                onClick={onBack} 
                className="flex items-center justify-center p-2 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded-xl transition-all cursor-pointer"
                title="Voltar ao Painel"
              >
                <ArrowLeft size={16} />
              </button>
              <div>
                <h1 className="text-sm font-extrabold text-white tracking-tight flex items-center gap-1.5">
                  Inbox
                  <span className="flex h-1.5 w-1.5 relative">
                    <span className="absolute inline-flex h-full w-full rounded-full bg-[#5865F2] opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#5865F2]"></span>
                  </span>
                </h1>
                <p className="text-gray-500 text-[10px] tracking-wide">Mensagens Batukada</p>
              </div>
            </div>
            
            {/* Conversas count tag */}
            <div className="text-[10px] bg-white/[0.04] border border-white/5 text-gray-400 font-semibold px-2.5 py-1 rounded-lg uppercase tracking-wider">
              {conversations.length} {conversations.length === 1 ? 'Conversa' : 'Conversas'}
            </div>
          </div>

          {/* Search bar */}
          <div className="p-4 border-b border-white/[0.03] bg-[#0c0c0f] shrink-0">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-[#5865F2] transition-colors" size={13} />
              <input 
                type="text" 
                placeholder="Pesquisar conversas..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-[#121215]/80 hover:bg-[#15151a] border border-white/5 focus:border-[#5865F2]/30 focus:bg-[#15151d] rounded-xl text-xs text-white focus:outline-none transition-all placeholder:text-gray-500 font-medium"
              />
            </div>
          </div>

          {/* Conversations List View */}
          <div className="flex-grow overflow-y-auto p-3 space-y-1.5 scrollbar-none bg-[#0a0a0d]">
            {filteredConversations.length > 0 ? (
              filteredConversations.map(conv => {
                const isSelected = selectedConv && String(selectedConv.id) === String(conv.id);
                const hasUnread = conv.messages?.some((m: any) => !m.is_read && m.sender_id !== user?.id);
                const lastMsg = conv.messages?.[conv.messages.length - 1];
                const isLastMsgMine = lastMsg?.sender_id === user?.id;
                const targetId = getOtherParticipant(conv)?.id || (conv.buyer_id === user?.id ? conv.seller_id : conv.buyer_id);
                
                return (
                  <button 
                    key={conv.id}
                    onClick={() => setSelectedConv(conv)}
                    className={`w-full p-3 flex gap-3 text-left rounded-xl border transition-all duration-200 ease-out cursor-pointer relative items-center group ${
                      isSelected 
                        ? 'bg-[#5865F2] border-[#5865F2]/20 shadow-[0_4px_16px_rgba(88,101,242,0.25)] text-white' 
                        : 'bg-transparent border-transparent hover:bg-white/[0.03] text-gray-300 hover:text-white'
                    }`}
                  >
                    {/* Active side indicator */}
                    {isSelected && (
                      <div className="absolute left-1.5 top-3.5 bottom-3.5 w-1 bg-white rounded-full" />
                    )}

                    <div 
                      className="relative shrink-0 cursor-pointer group/avatar select-none"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (targetId && onSelectUser) {
                          onSelectUser(targetId);
                        }
                      }}
                      title={`Ver perfil de ${otherUser(conv)}`}
                    >
                      {otherAvatar(conv) ? (
                        <img 
                          src={otherAvatar(conv)} 
                          alt={otherUser(conv)} 
                          className={`w-11 h-11 object-cover rounded-xl transition-all duration-300 border ${
                            isSelected 
                              ? 'border-white/30 group-hover/avatar:border-emerald-400 group-hover/avatar:shadow-[0_0_12px_rgba(16,185,129,0.35)]' 
                              : 'border-white/5 group-hover/avatar:border-emerald-400 group-hover/avatar:shadow-[0_0_12px_rgba(16,185,129,0.35)]'
                          }`}
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className={`w-11 h-11 rounded-xl font-bold flex items-center justify-center text-xs transition-all border ${
                          isSelected 
                            ? 'bg-white/20 border-white/30 text-white group-hover/avatar:border-emerald-400 group-hover/avatar:text-emerald-450' 
                            : 'bg-white/5 border-white/5 text-gray-300 group-hover/avatar:bg-white/10 group-hover/avatar:text-emerald-400 group-hover/avatar:border-emerald-400 group-hover/avatar:shadow-[0_0_12px_rgba(16,185,129,0.35)]'
                        }`}>
                          {String(otherUser(conv) || '').slice(0, 2).toUpperCase()}
                        </div>
                      )}
                      
                      {/* Premium indicator marker */}
                      <span className="absolute -bottom-1 -right-1 flex h-3.5 w-3.5">
                        <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-[#09090b]"></span>
                      </span>
                    </div>
                    
                    <div className="flex-grow overflow-hidden pr-0.5">
                      <div className="flex justify-between items-baseline mb-0.5">
                        <span 
                          onClick={(e) => {
                            e.stopPropagation();
                            if (targetId && onSelectUser) {
                              onSelectUser(targetId);
                            }
                          }}
                          className={`text-[12px] truncate block pr-2 tracking-tight cursor-pointer hover:text-emerald-400 transition-colors duration-200 select-none ${
                            isSelected ? 'text-white font-bold' : 'text-gray-100 font-medium'
                          }`}
                          title={`Ver perfil de ${otherUser(conv)}`}
                        >
                          {otherUser(conv)}
                        </span>
                        <span className={`text-[9px] uppercase whitespace-nowrap pt-0.5 ${isSelected ? 'text-white/80' : 'text-gray-500'}`}>
                          {conv.updated_at ? new Date(conv.updated_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-1.5">
                        <p className={`text-[11px] truncate flex-grow ${
                          isSelected 
                            ? 'text-white/80' 
                            : hasUnread 
                              ? 'text-white font-semibold' 
                              : 'text-gray-400'
                        }`}>
                          {lastMsg ? (
                            <>
                              {isLastMsgMine && <span className={isSelected ? "text-white/60 mr-1 font-medium" : "text-gray-500 mr-1 font-medium"}>Tu:</span>}
                              <span>{lastMsg.content}</span>
                            </>
                          ) : (
                            <span className="italic text-gray-500">Sem mensagens</span>
                          )}
                        </p>
                        
                        {hasUnread && (
                          <span className={`w-2 h-2 rounded-full shrink-0 animate-pulse ${
                            isSelected ? 'bg-white' : 'bg-blue-400'
                          }`} />
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="py-20 text-center text-gray-500 flex flex-col items-center justify-center px-4">
                <div className="w-12 h-12 rounded-2xl bg-white/[0.01] border border-white/5 flex items-center justify-center mb-3">
                  <MessageSquare size={18} className="opacity-30 text-gray-400" />
                </div>
                <p className="text-[10px] font-semibold tracking-wider text-gray-400 uppercase">Nenhuma conversa encontrada</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Area: Messages Conversation Workspace */}
        <div className={`flex-grow flex-1 min-w-0 flex flex-col bg-[#07070a] overflow-hidden relative transition-all duration-300 ${
          selectedConv ? 'flex' : 'hidden md:flex'
        }`}>
          {selectedConv ? (
            <>
              {/* Chat Pane Header */}
              <div className="h-[76px] px-4 border-b border-white/[0.03] flex items-center justify-between bg-[#0e0e11] select-none shrink-0 relative z-20">
                <div className="flex items-center gap-3 min-w-0">
                  {/* Back button visible only on mobile/tablets */}
                  <button 
                    onClick={() => setSelectedConv(null)}
                    className="md:hidden p-2 -ml-1 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded-xl transition-all cursor-pointer"
                    title="Voltar às conversas"
                  >
                    <ArrowLeft size={16} />
                  </button>
                                    <div className="flex items-center gap-3 min-w-0">
                    <div 
                      className="relative cursor-pointer group/headerAvatar select-none"
                      onClick={() => {
                        const targetId = getOtherParticipant(selectedConv)?.id || (selectedConv.buyer_id === user?.id ? selectedConv.seller_id : selectedConv.buyer_id);
                        if (targetId && onSelectUser) onSelectUser(targetId);
                      }}
                      title={`Ver perfil de ${otherUser(selectedConv)}`}
                    >
                      {otherAvatar(selectedConv) ? (
                        <img 
                          src={otherAvatar(selectedConv)} 
                          alt={otherUser(selectedConv)} 
                          className="w-11 h-11 object-cover rounded-xl border border-white/10 group-hover/headerAvatar:border-emerald-400/80 transition-all duration-200 shadow-md group-hover/headerAvatar:shadow-[0_0_12px_rgba(16,185,129,0.25)]"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#5865F2]/25 to-[#804df5]/15 text-[#9da5ff] font-bold flex items-center justify-center text-sm border border-[#5865F2]/20 group-hover/headerAvatar:border-emerald-400/80 transition-all">
                          {String(otherUser(selectedConv) || '').slice(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#09090b] flex items-center justify-center">
                        <span className="block w-1.5 h-1.5 bg-emerald-200 rounded-full animate-pulse" />
                      </div>
                    </div>
                    
                    <div className="flex flex-col text-left min-w-0">
                      <span 
                        onClick={() => {
                          const targetId = getOtherParticipant(selectedConv)?.id || (selectedConv.buyer_id === user?.id ? selectedConv.seller_id : selectedConv.buyer_id);
                          if (targetId && onSelectUser) onSelectUser(targetId);
                        }}
                        className="text-xs font-bold text-white tracking-wide truncate flex items-center gap-1.5 cursor-pointer hover:text-emerald-400 transition-colors select-none"
                        title={`Ver perfil de ${otherUser(selectedConv)}`}
                      >
                        {otherUser(selectedConv)}
                        {isOtherParticipantVerified(selectedConv) && (
                          <span className="inline-flex items-center justify-center bg-[#5865F2]/10 text-[#7a88ff] rounded-full p-0.5 w-3.5 h-3.5 text-[8px] font-bold select-none" title="Produtor Verificado">
                            ✓
                          </span>
                        )}
                      </span>
                      
                      {typingStatus[selectedConv.id] ? (
                        <span className="text-[10px] text-[#5865F2] font-semibold animate-pulse">a digitar...</span>
                      ) : (
                        <span className="text-[10px] text-gray-400 truncate mt-0.5">
                          {otherUsername(selectedConv) || '@user_batukada'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Header Actions */}
                <div className="flex items-center gap-1.5">
                  {(() => {
                    const badge = getParticipantBadge(selectedConv);
                    if (!badge) return null;
                    return (
                      <span className={`hidden sm:inline-flex text-[9px] border font-bold px-3 py-1 rounded-full uppercase tracking-wider select-none ${badge.style}`}>
                        {badge.text}
                      </span>
                    );
                  })()}
                  
                  <div className="relative">
                    <button 
                      onClick={() => setShowDeleteMenu(!showDeleteMenu)}
                      className="w-10 h-10 flex items-center justify-center bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 text-gray-400 hover:text-white rounded-xl transition-all cursor-pointer"
                      title="Opções de conversa"
                    >
                      <MoreVertical size={16} />
                    </button>
                    
                    <AnimatePresence>
                      {showDeleteMenu && (
                        <>
                          <div 
                            className="fixed inset-0 z-40 bg-transparent" 
                            onClick={() => setShowDeleteMenu(false)} 
                          />
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.95, y: -5 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95, y: -5 }}
                            className="absolute right-0 mt-2 w-48 bg-[#0e0e11] border border-white/[0.08] rounded-xl shadow-xl z-50 py-1.5"
                          >
                            <button
                              onClick={() => {
                                setShowDeleteMenu(false);
                                if (window.confirm("Deseja mesmo apagar esta conversa e todas as mensagens associadas?")) {
                                  deleteConversation(selectedConv.id);
                                  setSelectedConv(null);
                                }
                              }}
                              className="w-full text-left px-3 py-2 text-xs text-red-400/90 hover:bg-red-500/10 hover:text-red-300 flex items-center gap-2.5 transition-all cursor-pointer font-medium"
                            >
                              <Trash2 size={14} strokeWidth={2.5} />
                              <span>Apagar conversa</span>
                            </button>
                          </motion.div>
                        </>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>

              {/* Messages Viewport with premium ambient glowing texture */}
              <div className="flex-grow overflow-hidden relative">
                {/* Discrete radial glows and textures */}
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(88,101,242,0.05),transparent_40%)] pointer-events-none z-0" />
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(128,77,245,0.03),transparent_50%)] pointer-events-none z-0" />
                
                <div 
                  ref={messagesContainerRef}
                  className="absolute inset-0 overflow-y-auto p-4 md:p-5 space-y-4 scroll-smooth scrollbar-none z-10"
                >
                  {messages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center opacity-40 select-none">
                      <MessageSquare size={28} className="text-gray-500 mb-2" />
                      <p className="text-xs font-semibold text-gray-300">Sem mensagens. Digite algo para iniciar a colaboração!</p>
                    </div>
                  ) : (
                    messages.map((m, i) => {
                      const isSelf = m.sender_id === user?.id;
                      return (
                        <motion.div 
                          initial={{ opacity: 0, y: 10, scale: 0.98 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          transition={{ type: "spring", stiffness: 350, damping: 25 }}
                          key={m.id || i}
                          className={`flex ${isSelf ? 'justify-end' : 'justify-start'}`}
                        >
                          {isSelf ? (
                            <div className="max-w-[70%] group">
                              <div className={`px-4.5 py-2.5 rounded-2xl text-xs md:text-[13px] leading-relaxed transition-all shadow-md bg-gradient-to-tr from-[#5865F2] to-[#4F46E5] text-white rounded-tr-sm hover:shadow-[0_4px_16px_rgba(88,101,242,0.25)] border border-white/5`}>
                                <span className="whitespace-pre-wrap break-words">{m.content}</span>
                              </div>
                              
                              <div className="flex items-center justify-end gap-1.5 mt-1.5 px-1.5 font-medium">
                                <span className="text-[9px] text-gray-500">
                                  {new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                                {m.is_read ? (
                                  <CheckCheck size={11} className="text-blue-400" />
                                ) : (
                                  <Check size={11} className="text-gray-500" />
                                )}
                              </div>
                            </div>
                          ) : (
                            <div className="flex gap-3 items-start max-w-[75%]">
                              {/* Left Avatar represents sender, clickable */}
                              <div 
                                onClick={() => {
                                  if (onSelectUser) onSelectUser(m.sender_id);
                                }}
                                className="w-8 h-8 rounded-lg overflow-hidden cursor-pointer shrink-0 select-none border border-white/5 hover:border-emerald-500/80 hover:shadow-[0_0_10px_rgba(16,185,129,0.35)] transition-all duration-200 mt-0.5 group/msgAvatar"
                                title={`Ver perfil de ${otherUser(selectedConv)}`}
                              >
                                {otherAvatar(selectedConv) ? (
                                  <img 
                                    src={otherAvatar(selectedConv)} 
                                    alt={otherUser(selectedConv)} 
                                    className="w-full h-full object-cover group-hover/msgAvatar:scale-105 transition-transform animate-fade-in"
                                    referrerPolicy="no-referrer"
                                  />
                                ) : (
                                  <div className="w-full h-full bg-white/5 text-gray-300 font-bold flex items-center justify-center text-[10px] group-hover/msgAvatar:bg-white/10 group-hover/msgAvatar:text-emerald-450 transition-colors">
                                    {String(otherUser(selectedConv) || '').slice(0, 2).toUpperCase()}
                                  </div>
                                )}
                              </div>

                              <div className="group flex flex-col items-start">
                                {/* Sender Name displayed above message bubble is clickable */}
                                <div className="mb-1 flex items-center gap-1 select-none">
                                  <span 
                                    onClick={() => {
                                      if (onSelectUser) onSelectUser(m.sender_id);
                                    }}
                                    className="text-[10px] font-bold text-gray-400 hover:text-emerald-400 cursor-pointer transition-colors"
                                    title={`Ver perfil de ${otherUser(selectedConv)}`}
                                  >
                                    {otherUser(selectedConv)}
                                  </span>
                                  {isOtherParticipantVerified(selectedConv) && (
                                    <span className="inline-flex items-center justify-center bg-[#5865F2]/10 text-[#7a88ff] rounded-full p-0.5 w-3 h-3 text-[7px] font-bold select-none" title="Verificado">
                                      ✓
                                    </span>
                                  )}
                                </div>

                                <div className="px-4.5 py-2.5 rounded-2xl text-xs md:text-[13px] leading-relaxed transition-all shadow-md bg-[#18181c]/90 text-gray-100 border border-white/[0.04] rounded-tl-sm hover:bg-[#1f1f25]">
                                  <span className="whitespace-pre-wrap break-words">{m.content}</span>
                                </div>
                                
                                <div className="flex items-center justify-start gap-1.5 mt-1.5 px-1.5">
                                  <span className="text-[9px] text-gray-500 font-medium">
                                    {new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  </span>
                                </div>
                              </div>
                            </div>
                          )}
                        </motion.div>
                      );
                    })
                  )}

                  {/* Bouncing Dots Typing Status indicator in chat Area */}
                  {typingStatus[selectedConv.id] && (
                    <motion.div 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex justify-start items-center gap-2 px-1"
                    >
                      <div className="px-4 py-3 bg-[#18181c]/50 border border-white/[0.04] rounded-2xl rounded-tl-sm text-gray-400 flex items-center gap-1 shadow-inner">
                        <span className="w-1.5 h-1.5 bg-[#5865F2] rounded-full animate-bounce [animation-delay:-0.3s]" />
                        <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                        <span className="w-1.5 h-1.5 bg-[#804df5] rounded-full animate-bounce" />
                      </div>
                    </motion.div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </div>
              
              {/* Message Input cockpit block */}
              <div className="p-4 bg-[#09090c] border-t border-white/[0.03] flex flex-col gap-2 shrink-0">
                <div className="flex gap-3 items-end">
                  <div className="flex-grow relative group">
                    <textarea 
                      placeholder="Escreva uma mensagem no Batukada..."
                      value={input}
                      rows={1}
                      onChange={(e) => {
                        setInput(e.target.value);
                        const otherId = selectedConv.buyer_id === user?.id ? selectedConv.seller_id : selectedConv.buyer_id;
                        sendTyping(otherId, selectedConv.id, e.target.value.length > 0);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSend();
                        }
                      }}
                      className="w-full bg-[#121215]/80 hover:bg-[#15151a] focus:bg-[#18181f] border border-white/5 focus:border-[#5865F2]/30 rounded-2xl pl-5 pr-5 py-3 text-xs text-white placeholder:text-gray-500 focus:outline-none transition-all scrollbar-none font-medium resize-none min-h-[44px] max-h-32 leading-relaxed"
                      style={{ height: 'auto' }}
                    />
                  </div>
                  
                  <button 
                    onClick={handleSend}
                    disabled={!input.trim()}
                    className={`w-11 h-11 shrink-0 rounded-2xl flex items-center justify-center transition-all duration-200 active:scale-95 cursor-pointer shadow-lg ${
                      input.trim() 
                        ? 'bg-[#5865F2] text-white hover:bg-[#4752C4] hover:shadow-[0_4px_12px_rgba(88,101,242,0.35)]' 
                        : 'bg-white/5 text-gray-500 cursor-not-allowed opacity-40'
                    }`}
                    title="Enviar mensagem"
                  >
                    <Send size={15} className={`${input.trim() ? 'translate-x-0.5 -translate-y-0.5' : ''} transition-transform`} />
                  </button>
                </div>
                
                {/* Visual helpers */}
                <div className="flex justify-between items-center px-1">
                  <span className="text-[9px] text-gray-500 font-medium">
                    Pressione <kbd className="bg-white/5 px-1 py-0.5 rounded text-gray-400">Enter</kbd> para enviar, <kbd className="bg-white/5 px-1 py-0.5 rounded text-gray-400">Shift + Enter</kbd> para nova linha
                  </span>
                  
                  {input.length > 0 && (
                    <span className="text-[9px] text-gray-500 font-medium animate-fade-in">
                      {input.length} caracteres
                    </span>
                  )}
                </div>
              </div>
            </>
          ) : (
            /* Premium Atmospheric Empty State */
            <div className="flex-grow flex flex-col items-center justify-center text-center p-8 relative select-none overflow-hidden bg-[#07070a]">
              {/* Outer atmospheric glows */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-[#5865F2]/5 rounded-full blur-[80px]" />
              <div className="absolute top-1/3 left-1/3 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-[#804df5]/3 rounded-full blur-[60px]" />
              
              <div className="relative z-10 max-w-sm space-y-5 animate-fade-in">
                {/* Visual Icon with music wave accent */}
                <div className="flex justify-center">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#5865F2]/10 to-[#804df5]/5 border border-[#5865F2]/20 flex items-center justify-center text-[#5865F2] hover:scale-105 transition-transform duration-300 shadow-[0_8px_24px_rgba(88,101,242,0.1)]">
                      <MessageSquare size={26} className="text-[#bfdbfe]" />
                    </div>
                    {/* Tiny pulsing decorator dots */}
                    <span className="absolute -top-1 -right-1 flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <h2 className="text-base font-extrabold text-white tracking-tight bg-gradient-to-r from-white via-gray-200 to-gray-400 bg-clip-text text-transparent">
                    Suas Conversas no Batukada
                  </h2>
                  <p className="text-xs text-gray-400 max-w-[280px] mx-auto leading-relaxed">
                    Conecte-se com produtores e artistas, partilhe ideias e leve os seus beats para outro nível.
                  </p>
                </div>

                {/* Minimalist music beat visualizer */}
                <div className="flex items-center justify-center gap-1 h-3 opacity-30 mt-4">
                  <span className="w-0.5 h-1 bg-blue-400 rounded-full animate-pulse" />
                  <span className="w-0.5 h-2 bg-purple-400 rounded-full animate-pulse delay-75" />
                  <span className="w-0.5 h-3 bg-[#5865F2] rounded-full animate-pulse delay-150" />
                  <span className="w-0.5 h-1.5 bg-blue-400 rounded-full animate-pulse delay-75" />
                  <span className="w-0.5 h-2.5 bg-pink-400 rounded-full animate-pulse delay-300" />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
