import React from 'react';

/**
 * Premium Shimmer & Skeleton Loaders for BATUKADA
 * Highly polished, dark-theme aligned, and smooth animations.
 */

export function ShimmerEffect() {
  return (
    <div className="absolute inset-0 -translate-x-full animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-white/5 to-transparent" />
  );
}

// 1. Beat Card Skeleton
export function BeatCardSkeleton() {
  return (
    <div className="bg-white/[0.01] border border-white/5 rounded-[2rem] p-5 relative overflow-hidden flex flex-col justify-between h-[380px]">
      <ShimmerEffect />
      <div className="space-y-4">
        {/* Aspect Image Area */}
        <div className="aspect-square w-full rounded-2xl bg-white/5 animate-pulse relative overflow-hidden" />
        
        {/* Title & Producer lines */}
        <div className="space-y-2">
          <div className="h-4 w-3/4 bg-white/10 rounded-full animate-pulse" />
          <div className="h-3 w-1/2 bg-white/5 rounded-full animate-pulse" />
        </div>
      </div>
      
      {/* Footer Details */}
      <div className="flex items-center justify-between pt-4 border-t border-white/5 mt-4">
        <div className="h-4 w-1/4 bg-white/10 rounded-full animate-pulse" />
        <div className="h-8 w-8 rounded-full bg-white/10 animate-pulse" />
      </div>
    </div>
  );
}

// 2. Playlists Skeleton
export function PlaylistSkeleton() {
  return (
    <div className="bg-white/[0.01] border border-white/5 rounded-[2rem] p-5 relative overflow-hidden flex flex-col justify-between h-[320px]">
      <ShimmerEffect />
      <div className="space-y-4">
        <div className="aspect-square w-full rounded-2xl bg-white/5 animate-pulse" />
        <div className="space-y-2">
          <div className="h-4 w-2/3 bg-white/10 rounded-full animate-pulse" />
          <div className="h-3 w-1/2 bg-white/5 rounded-full animate-pulse" />
        </div>
      </div>
      <div className="h-3 w-1/3 bg-white/5 rounded-full mt-4" />
    </div>
  );
}

// 3. Simple List Item (notifications, activity feeds, comments)
export function ListItemSkeleton() {
  return (
    <div className="p-4 bg-white/[0.01] border border-white/5 rounded-2xl flex items-center justify-between space-x-4 relative overflow-hidden select-none">
      <ShimmerEffect />
      <div className="flex items-center space-x-3 flex-grow">
        {/* Circle avatar */}
        <div className="w-10 h-10 rounded-full bg-white/5 animate-pulse shrink-0" />
        {/* Content line */}
        <div className="space-y-2 flex-grow">
          <div className="h-3 w-2/3 bg-white/10 rounded-full animate-pulse" />
          <div className="h-2 w-1/3 bg-white/5 rounded-full animate-pulse" />
        </div>
      </div>
      <div className="h-4 w-12 bg-white/10 rounded-full animate-pulse" />
    </div>
  );
}

// 4. Producer Profile Page Skeleton
export function ProducerProfileSkeleton() {
  return (
    <div className="space-y-8 relative overflow-hidden">
      <ShimmerEffect />
      {/* Banner */}
      <div className="h-64 sm:h-80 w-full rounded-[2.5rem] bg-white/5 animate-pulse" />
      
      {/* Bio / Details */}
      <div className="max-w-4xl mx-auto px-4 -mt-20 relative z-10 space-y-4">
        <div className="flex flex-col sm:flex-row items-center sm:items-end space-y-4 sm:space-y-0 sm:space-x-6">
          <div className="w-28 h-28 rounded-full bg-white/10 border-4 border-[#0B0B0F] animate-pulse" />
          <div className="space-y-2 text-center sm:text-left">
            <div className="h-6 w-48 bg-white/10 rounded-full animate-pulse" />
            <div className="h-4 w-32 bg-white/5 rounded-full animate-pulse" />
          </div>
        </div>
        <div className="h-4 w-full bg-white/5 rounded-full animate-pulse" />
        <div className="h-4 w-5/6 bg-white/5 rounded-full animate-pulse" />
      </div>

      {/* Grid of beats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-10">
        <BeatCardSkeleton />
        <BeatCardSkeleton />
        <BeatCardSkeleton />
      </div>
    </div>
  );
}

// 5. Grid list container helper
export function GridSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <BeatCardSkeleton key={i} />
      ))}
    </div>
  );
}

// 6. Generic page loader fallback
export function PremiumPageSkeleton() {
  return (
    <div className="p-6 md:p-10 space-y-8 max-w-7xl mx-auto w-full">
      <div className="space-y-3">
        <div className="h-8 w-48 bg-white/10 rounded-full animate-pulse" />
        <div className="h-4 w-96 bg-white/5 rounded-full animate-pulse" />
      </div>
      <GridSkeleton count={3} />
    </div>
  );
}
