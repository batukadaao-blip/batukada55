import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  HelpCircle, 
  Music, 
  DollarSign, 
  ShoppingBag, 
  UserPlus, 
  CheckCircle,
  TrendingUp,
  Award,
  ShieldCheck,
  ChevronRight,
  BookOpen
} from 'lucide-react';

interface OnboardingProps {
  role: 'producer' | 'artist';
}

export default function OnboardingElegante({ role }: OnboardingProps) {
  const [isVisible, setIsVisible] = useState(() => {
    const saved = localStorage.getItem(`batukada_onboarding_dismissed_${role}`);
    return saved !== 'true';
  });

  const [activeStep, setActiveStep] = useState(0);

    const steps = role === 'producer' ? [
    {
      title: '1. Configura as tuas Licenças',
      description: 'Define os preços para as licenças Básica, Premium e Exclusiva no teu painel. Isto garante clareza jurídica e atratividade para os artistas compradores.',
      icon: DollarSign,
      actionText: 'Configurar Licenças',
      badge: 'Definições Financeiras',
      color: 'text-white bg-white/[0.04] border-white/10'
    },
    {
      title: '2. Sobe os teus Instrumentais (Beats)',
      description: 'Faz upload dos ficheiros MP3 Demo (com tag de voz anti-cópia), Master WAV (qualidade profissional) e os ficheiros soltos (Stems/Pistas) em formato ZIP.',
      icon: Music,
      actionText: 'Fazer Primeiro Upload',
      badge: 'Upload Ativo',
      color: 'text-white bg-white/[0.04] border-white/10'
    },
    {
      title: '3. Divulga e Promove o teu Estúdio',
      description: 'Partilha o link do teu perfil oficial nas redes sociais. Os compradores podem ouvir o teu catálogo, seguir-te para receber novidades e comprar instantaneamente.',
      icon: UserPlus,
      actionText: 'Ver Meu Perfil Público',
      badge: 'Visibilidade Digital',
      color: 'text-[#6366f1] bg-[#6366f1]/10 border-[#6366f1]/20'
    },
    {
      title: '4. Recebe Ganhos em Tempo Real',
      description: 'Cada transação processada é adicionada ao teu saldo acumulado. Podes solicitar levantamentos directos para o teu cartão ou conta de forma totalmente segura.',
      icon: ShieldCheck,
      actionText: 'Ver Carteira',
      badge: 'Liquidez Garantida',
      color: 'text-[#6366f1] bg-[#6366f1]/10 border-[#6366f1]/20'
    }
  ] : [
    {
      title: '1. Explora o Catálogo Comercial',
      description: 'Pesquisa por género musical, BPM ou produtores em destaque no feed da Batukada. Usa filtros inteligentes para encontrar a sonoridade ideal para ti.',
      icon: Music,
      actionText: 'Ir para o Catálogo',
      badge: 'Descoberta',
      color: 'text-[#6366f1] bg-[#6366f1]/10 border-[#6366f1]/20'
    },
    {
      title: '2. Escolha o Licenciamento Perfeito',
      description: 'Adquire licenças Básica (não comercial rápida), Premium (comercial de alta qualidade) ou adquire os direitos Exclusivos para retirares o instrumental de venda.',
      icon: Award,
      actionText: 'Compreender Licenças',
      badge: 'Transparência Legal',
      color: 'text-white bg-white/[0.04] border-white/10'
    },
    {
      title: '3. Pagamento e Download Instantâneo',
      description: 'Paga de forma simplificada por transferência, wallet ou cartões. O download premium dos teus master e pistas WAV é disponibilizado de imediato na tua biblioteca.',
      icon: ShoppingBag,
      actionText: 'Compra em 1-Clique',
      badge: 'Infraestrutura Premium',
      color: 'text-[#6366f1] bg-[#6366f1]/10 border-[#6366f1]/20'
    },
    {
      title: '4. Segue e Apoia os Produtores',
      description: 'Cria uma rede de favoritos seguindo produtores. Recebe notificações de novos beattapes, sound kits e instrumentais assim que forem publicados no feed.',
      icon: UserPlus,
      actionText: 'Seguir Criadores',
      badge: 'Comunidade Ativa',
      color: 'text-white bg-white/[0.04] border-white/10'
    }
  ];

  const handleDismiss = () => {
    localStorage.setItem(`batukada_onboarding_dismissed_${role}`, 'true');
    setIsVisible(false);
  };

  const handleReset = () => {
    localStorage.removeItem(`batukada_onboarding_dismissed_${role}`);
    setIsVisible(true);
    setActiveStep(0);
  };

  if (!isVisible) {
    return (
      <button 
        onClick={handleReset}
        className="flex items-center gap-2 bg-transparent hover:bg-white/[0.04] border border-white/[0.08] rounded-lg px-3 py-1.5 text-[11px] font-semibold text-zinc-400 hover:text-white transition-all cursor-pointer inline-flex self-start"
      >
        <BookOpen size={12} className="text-zinc-400" />
        Guia de Iniciação
      </button>
    );
  }

  const current = steps[activeStep];
  const StepIcon = current.icon;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0, height: 0, scale: 0.98 }}
        animate={{ opacity: 1, height: 'auto', scale: 1 }}
        exit={{ opacity: 0, height: 0, scale: 0.98 }}
        className="relative group bg-[#050505] border border-white/[0.06] rounded-xl p-6 md:p-8 overflow-hidden space-y-6"
      >
        {/* Header */}
        <div className="flex justify-between items-start gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/[0.03] border border-white/[0.08] flex items-center justify-center text-zinc-300">
              <HelpCircle size={18} />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">Fluxo de Onboarding Batukada</span>
              <h3 className="text-sm font-bold tracking-tight text-white mt-0.5">
                {role === 'producer' ? 'Guia do Produtor de Sucesso' : 'Guia para Artistas e Compradores'}
              </h3>
            </div>
          </div>
          
          <button 
            onClick={handleDismiss}
            className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-500 hover:text-white transition-all border border-white/[0.02]"
            title="Minimizar Guia"
          >
            <X size={15} />
          </button>
        </div>

        {/* Active Step Panel */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center pt-2">
          {/* Main graphic / icon preview */}
          <div className="md:col-span-3 flex justify-center">
            <div className={`w-20 h-20 rounded-xl flex items-center justify-center border ${current.color} relative`}>
              <StepIcon size={32} className="stroke-[1.5]" />
            </div>
          </div>

          <div className="md:col-span-9 space-y-3">
            <div className="space-y-1.5 text-center md:text-left">
              <div className="inline-flex items-center gap-1.5">
                <span className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border border-white/5 bg-white/[0.02]">
                  {current.badge}
                </span>
              </div>
              <h4 className="text-sm font-bold text-white tracking-tight">
                {current.title}
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                {current.description}
              </p>
            </div>

            {/* Step Selection Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
              {/* Dot Indicators */}
              <div className="flex items-center gap-2">
                {steps.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveStep(i)}
                    className={`h-2.5 rounded-full transition-all duration-300 ${
                      i === activeStep ? 'w-8 bg-[#5865F2]' : 'w-2.5 bg-white/10 hover:bg-white/35'
                    }`}
                  />
                ))}
              </div>

              <div className="flex items-center gap-3">
                {activeStep > 0 && (
                  <button 
                    onClick={() => setActiveStep(prev => prev - 1)}
                    className="px-4 py-2.5 rounded-xl border border-white/[0.04] bg-white/[0.02] hover:bg-white/5 text-[10px] uppercase font-black tracking-wider text-gray-400 hover:text-white transition-all"
                  >
                    Anterior
                  </button>
                )}
                
                <button 
                  onClick={() => {
                    if (activeStep < steps.length - 1) {
                      setActiveStep(prev => prev + 1);
                    } else {
                      handleDismiss();
                    }
                  }}
                  className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-[10px] uppercase font-black tracking-widest text-white transition-all"
                >
                  {activeStep === steps.length - 1 ? 'Concluir Guia' : 'Seguinte'}
                  <ChevronRight size={13} strokeWidth={3} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
