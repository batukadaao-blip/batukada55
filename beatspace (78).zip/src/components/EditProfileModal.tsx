import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Save, Loader2, Globe, Instagram, Youtube, Twitter, Mail, Phone, MapPin, Tag } from 'lucide-react';
import { getSupabase, getPublicUrl } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Producer } from '../types';

const ANGOLA_LOCATIONS = [
  "Bengo",
  "Benguela",
  "Bié",
  "Cabinda",
  "Cuando",
  "Cuando Cubango",
  "Cuanza Norte",
  "Cuanza Sul",
  "Cunene",
  "Huambo",
  "Huíla",
  "Icolo e Bengo",
  "Luanda",
  "Lunda Norte",
  "Lunda Sul",
  "Malanje",
  "Moxico",
  "Moxico Leste",
  "Namibe",
  "Uíge",
  "Zaire"
];

interface Props {
  isOpen: boolean;
  onClose: () => void;
  producer: Producer;
  onSaveSuccess: (updated: Producer) => void;
}

export default function EditProfileModal({ isOpen, onClose, producer, onSaveSuccess }: Props) {
  const { user, refreshProfile } = useAuth();
  const { showToast } = useToast();
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);

  const [isOpenDrop, setIsOpenDrop] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Parse existing JSON data if query fields are packed in 'phone'
  const [displayName, setDisplayName] = useState(producer.name || '');
  const [username, setUsername] = useState(producer.username || ''); // Initialize using the actual username
  const [location, setLocation] = useState(producer.location || '');
  const [bio, setBio] = useState(producer.bio || '');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  
  const [instagram, setInstagram] = useState(producer.socials?.instagram || '');
  const [youtube, setYoutube] = useState(producer.socials?.youtube || '');
  const [twitter, setTwitter] = useState(producer.socials?.twitter || '');
  const [website, setWebsite] = useState(producer.socials?.web || '');
  const [genres, setGenres] = useState<string[]>(producer.genres || []);
  const [newGenre, setNewGenre] = useState('');

  const [avatarUrl, setAvatarUrl] = useState(producer.avatar || '');
  const [bannerUrl, setBannerUrl] = useState(producer.banner || '');
  const [themeAccent, setThemeAccent] = useState('#5865F2'); // Default to Indigo Brand (#5865F2)

  const [isSaving, setIsSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'images' | 'socials' | 'genres'>('info');

  // Once-per-mount initialization of packed values from DB (since JSON is packed in 'phone' field)
  React.useEffect(() => {
    const initPackedValues = async () => {
      const supabase = getSupabase();
      if (!supabase || !producer.id) return;

      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producer.id);
      if (!isUUID) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', producer.id)
        .maybeSingle();

      if (data) {
        setDisplayName(data.artistic_name || data.display_name || producer.name || '');
        
        const initialUsername = data.username || `user${data.id.replace(/[^a-z0-9]/gi, '').toLowerCase().substring(0, 6)}`;
        setUsername(initialUsername);
        setLocation(data.city || producer.location || '');
        
        if (data.phone && data.phone.startsWith('{')) {
          try {
            const ext = JSON.parse(data.phone);
            setContactPhone(ext.phone || '');
            setBio(ext.bio || data.bio || producer.bio || '');
            setBannerUrl(ext.banner_url || producer.banner || '');
            setInstagram(ext.instagram_url || '');
            setYoutube(ext.youtube_url || '');
            setTwitter(ext.twitter_url || '');
            setWebsite(ext.website_url || '');
            setContactEmail(ext.contact_email || data.email || '');
            setGenres(ext.genres || producer.genres || []);
            setThemeAccent(ext.theme_accent || '#5865F2');
          } catch (e) {
            console.error('Err parsing profile phone JSON', e);
            setContactPhone(data.phone || '');
          }
        } else {
          setContactPhone(data.phone || '');
          setBio(data.bio || producer.bio || '');
        }
      }
    };

    if (isOpen) {
      initPackedValues();
    }
  }, [isOpen, producer.id]);

  useEffect(() => {
    if (!isOpenDrop) return;
    const handleOutsideClick = (e: MouseEvent) => {
      const container = document.getElementById('province-select-container');
      if (container && !container.contains(e.target as Node)) {
        setIsOpenDrop(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [isOpenDrop]);

  if (!isOpen) return null;

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'banner') => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // File size evaluation (Limit: 4MB for high resolution images)
    if (file.size > 4 * 1024 * 1024) {
      showToast('O ficheiro excede o limite de 4MB.', 'error', 'Imagem Muito Grande');
      return;
    }

    // Type validation
    if (!file.type.startsWith('image/')) {
      showToast('Por favor, carrega uma imagem válida (PNG, JPG, WEBP).', 'error', 'Tipo de Ficheiro Inválido');
      return;
    }

    const setLoader = type === 'avatar' ? setUploadingAvatar : setUploadingBanner;
    setLoader(true);

    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Supabase Client not active');

      // Sanitized filename
      const sanitizedName = file.name.replace(/[^a-zA-Z0-9.]/g, '_');
      const filename = `${user.id}/${type}_${Date.now()}_${sanitizedName}`;

      let uploadError = null;
      let publicUrl = '';

      try {
        const { error } = await supabase.storage
          .from('avatars')
          .upload(filename, file, {
            cacheControl: '3600',
            upsert: true
          });
        uploadError = error;
        if (!uploadError) {
          publicUrl = getPublicUrl('avatars', filename);
        }
      } catch (directErr: any) {
        uploadError = directErr;
      }

      // If direct storage upload failed (e.g., due to RLS policies), retry via server-side proxy
      if (uploadError) {
        console.warn('[STORAGE] Direct upload failed, falling back to server-side proxy...', uploadError);
        try {
          const base64Data = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });

          const { data: { session } } = await supabase.auth.getSession();
          const token = session?.access_token;

          const proxyResponse = await fetch('/api/storage/upload', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...(token ? { 'Authorization': `Bearer ${token}` } : {})
            },
            body: JSON.stringify({
              base64Data,
              bucket: 'avatars',
              path: filename,
              contentType: file.type || 'application/octet-stream'
            })
          });

          if (!proxyResponse.ok) {
            const errDetails = await proxyResponse.json().catch(() => ({}));
            throw new Error(errDetails.error || `HTTP ${proxyResponse.status}`);
          }

          const proxyData = await proxyResponse.json();
          publicUrl = proxyData.fileUrl;
        } catch (proxyErr: any) {
          console.error('[STORAGE] Proxy upload also failed:', proxyErr);
          throw new Error(proxyErr.message || 'Falha no upload através do proxy e direto.');
        }
      }

      if (type === 'avatar') {
        setAvatarUrl(publicUrl);
        showToast('Foto de perfil carregada com sucesso!', 'success', 'Carregamento Concluído');
      } else {
        setBannerUrl(publicUrl);
        showToast('Banner de capa carregado com sucesso!', 'success', 'Carregamento Concluído');
      }
    } catch (err: any) {
      console.error('Carregamento falhou:', err);
      showToast(`Erro de Carregamento: ${err.message || 'Verifica o bucket avatars.'}`, 'error', 'Erro');
    } finally {
      setLoader(false);
    }
  };

  const handleAddGenre = () => {
    if (!newGenre.trim()) return;
    if (genres.includes(newGenre.trim())) {
      setNewGenre('');
      return;
    }
    setGenres([...genres, newGenre.trim()]);
    setNewGenre('');
  };

  const handleRemoveGenre = (indexToRemove: number) => {
    setGenres(genres.filter((_, i) => i !== indexToRemove));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) {
      showToast('O nome artístico é de preenchimento obrigatório.', 'error', 'Nome Requerido');
      return;
    }

    setIsSaving(true);

    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Canais descodificados indisponíveis.');

      // 1. Process and validate username
      const cleanUsername = username.toLowerCase().trim().replace(/\s+/g, '');
      const isValidUsernameRegex = /^[a-z0-9._]+$/.test(cleanUsername);

      if (!isValidUsernameRegex) {
        showToast('O teu username só pode conter letras minúsculas, números, pontos (.) ou underscores (_). Sem espaços!', 'error', 'Username Inválido');
        setIsSaving(false);
        return;
      }

      if (cleanUsername.length < 3) {
        showToast('O username deve ter pelo menos 3 caracteres.', 'error', 'Username Muito Curto');
        setIsSaving(false);
        return;
      }

      // 2. Check for uniqueness across of existing profiles using the real database 'username' column
      console.log('Saving username:', cleanUsername);
      const { data: existingProfiles, error: qError } = await supabase
        .from('profiles')
        .select('id, username')
        .neq('id', producer.id);

      if (qError) throw qError;

      if (existingProfiles) {
        const isTaken = existingProfiles.some((p: any) => p.username && p.username.toLowerCase() === cleanUsername);
        if (isTaken) {
          showToast('Este username já está em uso.', 'error', 'Username Indisponível');
          setIsSaving(false);
          return;
        }
      }

      // Pack custom profiles attributes in 'phone' JSON field (no username in JSON metadata)
      const packedMetadata = JSON.stringify({
        phone: contactPhone,
        bio: bio,
        banner_url: bannerUrl,
        instagram_url: instagram,
        youtube_url: youtube,
        twitter_url: twitter,
        website_url: website,
        contact_email: contactEmail,
        genres: genres,
        theme_accent: themeAccent
      });

      console.log('Updating profiles table with new username value and biography:', cleanUsername);
      const updatePayload: any = {
        artistic_name: displayName,
        display_name: displayName,
        avatar_url: avatarUrl,
        city: location,
        username: cleanUsername,
        bio: bio,
        phone: packedMetadata,
        updated_at: new Date().toISOString()
      };

      let { error: updateError } = await supabase
        .from('profiles')
        .update(updatePayload)
        .eq('id', producer.id);

      if (updateError && (updateError.message?.includes('bio') || updateError.message?.includes('schema cache') || updateError.code === 'PGRST204')) {
        console.warn("Column 'bio' not in profiles schema. Retrying update without 'bio' column in payload...");
        delete updatePayload.bio;
        const retryRes = await supabase
          .from('profiles')
          .update(updatePayload)
          .eq('id', producer.id);
        updateError = retryRes.error;
      }

      if (updateError) throw updateError;
      console.log('Updated profile successfully');

      // Reload structure
      const updatedProducer: Producer = {
        ...producer,
        name: displayName,
        username: cleanUsername,
        bio: bio,
        avatar: avatarUrl,
        banner: bannerUrl,
        location: location,
        genres: genres,
        socials: {
          instagram: instagram,
          youtube: youtube,
          twitter: twitter,
          web: website
        }
      };

      if (refreshProfile) {
        await refreshProfile().catch(e => console.error("Error refreshing profile after save:", e));
      }

      // Clear localStorage cache models to enforce dynamic sync
      localStorage.removeItem('artistProfile');
      localStorage.removeItem('producerProfile');
      localStorage.removeItem('user_profile');

      const updatedProfileModel = {
        artisticName: displayName,
        city: location,
        phone: (producer as any).phone || contactPhone || '',
        yearsExp: (producer as any).yearsExp || '5',
        bio: bio,
        profilePhotoUrl: avatarUrl,
        bannerPhotoUrl: bannerUrl,
        genres: genres,
        username: cleanUsername,
        socials: {
          ig: instagram,
          tw: twitter,
          yt: youtube,
          web: website,
          tiktok: ''
        }
      };
      window.dispatchEvent(new CustomEvent('profileUpdated', { detail: updatedProfileModel }));

      showToast('O teu perfil profissional foi atualizado!', 'success', 'Perfil Guardado');
      onSaveSuccess(updatedProducer);
      onClose();
    } catch (err: any) {
      console.error('Erro ao salvar perfil:', err);
      showToast(err.message || 'Falha ao gravar no Supabase.', 'error', 'Erro do Servidor');
    } finally {
      setIsSaving(false);
    }
  };

  const accentColors = [
    { name: 'Indigo Brand', color: '#5865F2' },
    { name: 'Roxo', color: '#a855f7' },
    { name: 'Azul', color: '#3b82f6' },
    { name: 'Rosa/Kizomba', color: '#ec4899' },
    { name: 'Verde/Angola', color: '#10b981' }
  ];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-[#0D0D12] border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-white/5 flex justify-between items-center bg-[#07070a]">
          <div>
            <h2 className="text-lg font-black text-white">Editar Perfil de Produtor</h2>
            <p className="text-xs text-gray-500">Atualiza a tua identidade pública e dados profissionais.</p>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 px-2.5 rounded-lg bg-white/5 text-gray-400 hover:text-white hover:bg-white/10 transition-all text-sm font-bold cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Navigation tabs */}
        <div className="flex border-b border-white/5 bg-[#08080c] px-4 overflow-x-auto scrollbar-none">
          {[
            { id: 'info', label: 'Informações de Perfil' },
            { id: 'images', label: 'Imagens' },
            { id: 'socials', label: 'Canais Sociais' },
            { id: 'genres', label: 'Géneros & tags' }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-4 py-3 text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all border-b-2 cursor-pointer ${
                activeTab === t.id 
                  ? 'border-orange-500 text-orange-500' 
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Form Container */}
        <form onSubmit={handleSave} className="flex-grow overflow-y-auto p-6 space-y-4">
          
          {/* TAB 1: GENERAL INFO */}
          {activeTab === 'info' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-gray-400 tracking-wider block mb-1">Nome Artístico / Exibição</label>
                  <input 
                    type="text" 
                    value={displayName} 
                    onChange={e => setDisplayName(e.target.value)}
                    className="w-full bg-white/[0.02] border border-white/5 rounded-xl p-3 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-600"
                    placeholder="Ex: Jay M Beats"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-gray-400 tracking-wider block mb-1">Username / Slug</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3.5 text-gray-500 font-bold text-xs select-none">@</span>
                    <input 
                      type="text" 
                      value={username} 
                      onChange={e => setUsername(e.target.value)}
                      className="w-full bg-white/[0.02] border border-white/5 rounded-xl py-3 pl-8 pr-3 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-600"
                      placeholder="Ex: jay_m_beats"
                    />
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1">
                    Preview oficial: <span className="text-orange-500 font-black font-mono">@{username.toLowerCase().trim().replace(/\s+/g, '') || 'username'}</span>
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-gray-400 tracking-wider block mb-1">Contacto Telefónico</label>
                  <div className="relative">
                    <Phone className="absolute left-3.5 top-3.5 text-gray-600" size={14} />
                    <input 
                      type="text" 
                      value={contactPhone} 
                      onChange={e => setContactPhone(e.target.value)}
                      className="w-full bg-white/[0.02] border border-white/5 rounded-xl py-3 pl-10 pr-3 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-600"
                      placeholder="Ex: +244 923..."
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-gray-400 tracking-wider block mb-1">E-mail Profissional</label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-3.5 text-gray-600" size={14} />
                    <input 
                      type="email" 
                      value={contactEmail} 
                      onChange={e => setContactEmail(e.target.value)}
                      className="w-full bg-white/[0.02] border border-white/5 rounded-xl py-3 pl-10 pr-3 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-600"
                      placeholder="Ex: comercial@jaymbeats.com"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div id="province-select-container" className="relative">
                  <label className="text-[10px] font-black uppercase text-gray-400 tracking-wider block mb-1">Localização (Província - Angola)</label>
                  <div className="relative">
                    <MapPin className="absolute left-3.5 top-3.5 text-gray-600 z-10" size={14} />
                    <button
                      type="button"
                      onClick={() => setIsOpenDrop(!isOpenDrop)}
                      className="w-full bg-white/[0.02] border border-white/5 rounded-xl py-3 pl-10 pr-10 text-xs font-medium text-white text-left outline-none transition-all hover:bg-white/[0.04] focus:border-indigo-500/50"
                    >
                      {location || "Selecionar Província"}
                    </button>
                    <div className="absolute right-3.5 top-3.5 pointer-events-none text-gray-500">
                      <svg className={`w-4 h-4 transition-transform duration-200 ${isOpenDrop ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>

                    {isOpenDrop && (
                      <div className="absolute left-0 right-0 mt-2 bg-[#12121a] border border-white/10 rounded-xl overflow-hidden shadow-2xl z-50 animate-in fade-in slide-in-from-top-2 duration-200">
                        <div className="p-2 border-b border-white/5">
                          <input
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-white/[0.03] border border-white/5 rounded-lg py-2 px-3 text-xs text-white focus:border-indigo-500 outline-none transition-all"
                            placeholder="Pesquisar província..."
                            onClick={(e) => e.stopPropagation()}
                          />
                        </div>
                        <div className="max-h-48 overflow-y-auto divide-y divide-white/[0.02] scrollbar-thin scrollbar-thumb-white/10 select-none">
                          {ANGOLA_LOCATIONS.filter(prov => prov.toLowerCase().includes(searchTerm.toLowerCase())).length === 0 ? (
                            <div className="p-3 text-xs text-gray-500 text-center">Nenhuma província encontrada</div>
                          ) : (
                            ANGOLA_LOCATIONS.filter(prov => prov.toLowerCase().includes(searchTerm.toLowerCase())).map((prov) => {
                              const valueStr = `${prov}, Angola`;
                              const isSelected = location === valueStr;
                              return (
                                <button
                                  key={prov}
                                  type="button"
                                  onClick={() => {
                                    setLocation(valueStr);
                                    setIsOpenDrop(false);
                                    setSearchTerm('');
                                  }}
                                  className={`w-full text-left px-4 py-2.5 text-xs hover:bg-white/[0.04] transition-colors flex items-center justify-between ${
                                    isSelected ? 'bg-indigo-600/25 text-white font-bold' : 'text-gray-300'
                                  }`}
                                >
                                  <span>{valueStr}</span>
                                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shadow-[0_0_8px_#5865F2]" />}
                                </button>
                              );
                            })
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-gray-400 tracking-wider block mb-1">Cor de Accent do Perfil (Tema)</label>
                  <div className="flex gap-2 py-1.5 overflow-x-auto scrollbar-none">
                    {accentColors.map(c => (
                      <button
                        key={c.color}
                        type="button"
                        onClick={() => setThemeAccent(c.color)}
                        className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
                          themeAccent === c.color ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-60 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: c.color }}
                        title={c.name}
                      >
                        {themeAccent === c.color && <div className="w-2 h-2 bg-black rounded-full" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-gray-400 tracking-wider block mb-1">Biografia Estúdio / Perfil</label>
                <textarea 
                  value={bio} 
                  onChange={e => setBio(e.target.value)}
                  className="w-full bg-white/[0.02] border border-white/5 rounded-xl p-3 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all h-24 placeholder:text-gray-600"
                  placeholder="Escreve uma biografia impactante sobre as tuas produções, estilo e experiência musical..."
                />
              </div>
            </div>
          )}

          {/* TAB 2: IMAGES */}
          {activeTab === 'images' && (
            <div className="space-y-6">
              {/* Profile Avatar Crop */}
              <div className="bg-white/[0.01] border border-white/5 p-4 rounded-xl space-y-3">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-xs font-black text-white uppercase tracking-wider">Foto de Perfil / Avatar</h4>
                    <p className="text-[10px] text-gray-500">Imagem quadrada recomendada. PNG, JPG ou WEBP (Max 4MB).</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    disabled={uploadingAvatar}
                    className="bg-white/5 border border-white/5 hover:bg-white/10 text-white hover:text-orange-500 p-2 rounded-xl text-xs font-black uppercase cursor-pointer tracking-wider flex items-center gap-2 transition-all disabled:opacity-50"
                  >
                    {uploadingAvatar ? (
                      <>
                        <Loader2 size={12} className="animate-spin" /> Carregando...
                      </>
                    ) : (
                      <>
                        <Upload size={12} /> Selecionar Foto
                      </>
                    )}
                  </button>
                  <input 
                    type="file" 
                    ref={avatarInputRef} 
                    className="hidden" 
                    accept="image/*"
                    onChange={e => handleImageUpload(e, 'avatar')}
                  />
                </div>

                <div className="flex items-center gap-4 pt-1">
                  <div className="w-16 h-16 rounded-full border border-white/10 overflow-hidden bg-gray-950 flex items-center justify-center shrink-0">
                    {avatarUrl ? (
                      <img src={avatarUrl} alt="Preview Avatar" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-[10px] text-gray-600 font-bold uppercase">Sem foto</span>
                    )}
                  </div>
                  <div className="text-[11px] text-gray-400 leading-normal">
                    <p className="font-bold text-white mb-0.5">Pré-visualização do Ícone</p>
                    <p>A foto do perfil aparece nas listas de produtores, beats, kits de áudio e pesquisa geral.</p>
                  </div>
                </div>
              </div>

              {/* Cover Banner Crop */}
              <div className="bg-white/[0.01] border border-white/5 p-4 rounded-xl space-y-3">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-xs font-black text-white uppercase tracking-wider">Imagem de Capa / Cover Banner</h4>
                    <p className="text-[10px] text-gray-500 font-medium">Recomendado formato largo. Dimensão ideal: 1200x400 (Max 4MB).</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => bannerInputRef.current?.click()}
                    disabled={uploadingBanner}
                    className="bg-white/5 border border-white/5 hover:bg-white/10 text-white hover:text-orange-500 p-2 rounded-xl text-xs font-black uppercase cursor-pointer tracking-wider flex items-center gap-2 transition-all disabled:opacity-50"
                  >
                    {uploadingBanner ? (
                      <>
                        <Loader2 size={12} className="animate-spin" /> Carregando...
                      </>
                    ) : (
                      <>
                        <Upload size={12} /> Selecionar Banner
                      </>
                    )}
                  </button>
                  <input 
                    type="file" 
                    ref={bannerInputRef} 
                    className="hidden" 
                    accept="image/*"
                    onChange={e => handleImageUpload(e, 'banner')}
                  />
                </div>

                <div className="pt-1">
                  <div className="h-24 rounded-lg overflow-hidden border border-white/10 relative bg-gray-950 flex items-center justify-center">
                    {bannerUrl ? (
                      <img src={bannerUrl} alt="Preview Banner" className="w-full h-full object-cover" />
                    ) : (
                      <p className="text-[10px] text-gray-600 font-bold uppercase">Sem imagem selecionada</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SOCIAL CHANNELS */}
          {activeTab === 'socials' && (
            <div className="space-y-4">
              <div className="space-y-3 bg-[#08080c] p-4 rounded-xl border border-white/5">
                <p className="text-[9px] font-black uppercase text-gray-500 tracking-wider">Canais Oficiais</p>
                
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-gray-400 flex items-center gap-1.5"><Instagram size={12} className="text-pink-500" /> Instagram</span>
                    </div>
                    <input 
                      type="text" 
                      value={instagram} 
                      onChange={e => setInstagram(e.target.value)}
                      className="w-full bg-white/[0.01] border border-white/5 rounded-xl p-2.5 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-700"
                      placeholder="Ex: https://instagram.com/jaymbeats"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-gray-400 flex items-center gap-1.5"><Youtube size={12} className="text-red-500" /> YouTube</span>
                    </div>
                    <input 
                      type="text" 
                      value={youtube} 
                      onChange={e => setYoutube(e.target.value)}
                      className="w-full bg-white/[0.01] border border-white/5 rounded-xl p-2.5 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-700"
                      placeholder="Ex: https://youtube.com/c/JayMBeatsChannel"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-gray-400 flex items-center gap-1.5"><Twitter size={12} className="text-blue-400" /> Twitter / X</span>
                    </div>
                    <input 
                      type="text" 
                      value={twitter} 
                      onChange={e => setTwitter(e.target.value)}
                      className="w-full bg-white/[0.01] border border-white/5 rounded-xl p-2.5 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-700"
                      placeholder="Ex: https://twitter.com/jaymbeats"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-gray-400 flex items-center gap-1.5"><Globe size={12} className="text-amber-500" /> Site Recomendado / Website</span>
                    </div>
                    <input 
                      type="text" 
                      value={website} 
                      onChange={e => setWebsite(e.target.value)}
                      className="w-full bg-white/[0.01] border border-white/5 rounded-xl p-2.5 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-700"
                      placeholder="Ex: https://www.jaymbeats.com"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: GENRES */}
          {activeTab === 'genres' && (
            <div className="space-y-4">
              <div className="bg-white/[0.01] border border-white/5 p-4 rounded-xl space-y-4">
                <div>
                  <h4 className="text-xs font-black text-white uppercase tracking-wider">Géneros Musicais & Estilos</h4>
                  <p className="text-[10px] text-gray-500 mb-2">Adiciona os géneros em que ganhaste destaque ou em que mais produzes (ex: Kizomba, Drill, Semba, Afro House).</p>
                </div>

                {/* Input row */}
                <div className="flex gap-2">
                  <div className="relative flex-grow">
                    <Tag className="absolute left-3.5 top-3 text-gray-600" size={14} />
                    <input 
                      type="text" 
                      value={newGenre}
                      onChange={e => setNewGenre(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleAddGenre())}
                      className="w-full bg-white/[0.01] border border-white/10 rounded-xl py-2 pl-10 pr-3 text-xs font-medium text-white focus:border-orange-500 outline-none transition-all placeholder:text-gray-600"
                      placeholder="Adicionar género (ex: Kizomba)"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleAddGenre}
                    className="bg-orange-600 hover:bg-orange-500 text-white text-xs px-4 py-2 rounded-xl font-bold cursor-pointer transition-all active:scale-95"
                  >
                    Adicionar
                  </button>
                </div>

                {/* Current tags display */}
                <div className="space-y-1.5 pt-2">
                  <p className="text-[9px] font-black uppercase text-gray-500 tracking-wider">Géneros Ativos ({genres.length})</p>
                  {genres.length === 0 ? (
                    <p className="text-xs text-gray-600 italic">Nenhum género adicionado.</p>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {genres.map((g, i) => (
                        <div key={g} className="bg-white/5 border border-white/5 rounded-lg px-2.5 py-1 flex items-center gap-1.5 text-xs text-white">
                          <span>{g}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveGenre(i)}
                            className="text-gray-500 hover:text-red-400 text-[10px] font-bold inline-block ml-1"
                          >
                            &times;
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

        </form>

        {/* Footer actions */}
        <div className="p-4 border-t border-white/5 bg-[#07070a] flex justify-end gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="p-2 px-5 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-300 hover:text-white transition-all cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="p-2 px-5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <Loader2 size={14} className="animate-spin" /> Gravando...
              </>
            ) : (
              <>
                <Save size={14} /> Guardar Perfil
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
