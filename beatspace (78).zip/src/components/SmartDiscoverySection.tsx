import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Pause, 
  ShoppingCart, 
  Heart, 
  Sparkles, 
  TrendingUp, 
  Flame, 
  Clock, 
  HelpCircle,
  TrendingDown,
  ChevronLeft,
  ChevronRight,
  Music,
  UserCheck,
  Zap,
  Bookmark,
  Disc,
  ArrowRight
} from 'lucide-react';
import { Beat, Producer } from '../types';
import { recommendationService } from '../lib/recommendationService';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import VerifiedBadge from './VerifiedBadge';

interface SmartDiscoverySectionProps {
  beats: Beat[];
  producers: Producer[];
  currentBeat: Beat | null;
  isPlaying: boolean;
  onPlay: (beat: Beat) => void;
  onAddToCart: (beat: Beat) => void;
  onSelectProducer: (producerName: string) => void;
  onSelectBeat: (beat: Beat) => void;
  onExploreGenre: (genreId: string) => void;
}

export default function SmartDiscoverySection({
  beats,
  producers,
  currentBeat,
  isPlaying,
  onPlay,
  onAddToCart,
  onSelectProducer,
  onSelectBeat,
  onExploreGenre
}: SmartDiscoverySectionProps) {
  const { user } = useAuth();
  const { showToast } = useToast();

  // Selected sub-tabs inside trending list
  const [trendingTab, setTrendingTab] = useState<'today' | 'week' | 'played' | 'saved'>('today');
  
  // Custom states for local user likes detection to update matching feeds instantly
  const [userLikesCount, setUserLikesCount] = useState(0);

  useEffect(() => {
    // Detect if user has favs or recently played to personalize subtitle
    try {
      const favsRaw = localStorage.getItem('batukada_local_favorites') || '[]';
      const favsList = JSON.parse(favsRaw);
      setUserLikesCount(favsList.length);
    } catch {}

    const handleLikesChange = () => {
      try {
        const favsRaw = localStorage.getItem('batukada_local_favorites') || '[]';
        setUserLikesCount(JSON.parse(favsRaw).length);
      } catch {}
    };

    window.addEventListener('favoriteStatusChanged', handleLikesChange);
    return () => {
      window.removeEventListener('favoriteStatusChanged', handleLikesChange);
    };
  }, []);

  // Compute recommendation chunks using recommendationService
  const recommendedBeats = recommendationService.getRecommendedBeats(beats, 8);
  const trendingToday = recommendationService.getTrendingToday(beats);
  const trendingThisWeek = recommendationService.getTrendingThisWeek(beats);
  const mostPlayed = recommendationService.getMostPlayed(beats);
  const mostSaved = recommendationService.getMostSaved(beats);

  // Setup genres categories
  const genresToRender = [
    { id: 'Afro House', label: 'Afro House', description: 'O groove eletrónico profundo de Luanda e África do Sul', icon: '💃' },
    { id: 'Amapiano', label: 'Amapiano', description: 'Log-drums pesadas, synths brilhantes e vibração deep', icon: '🎹' },
    { id: 'Drill', label: 'Drill / Afro-Drill', description: 'Linhas de baixo violentas e slides de alto-impacto', icon: '⚔' },
    { id: 'Trap', label: 'Trap', description: 'Riffs melancólicos e hi-hats ultra rápidos', icon: '💰' },
    { id: 'Afrobeat', label: 'Afrobeat', description: 'Sons orgânicos, brass ricos e polirritmia viciante', icon: '⚡' },
    { id: 'Kizomba', label: 'Kizomba / Semba', description: 'A alma e sensualidade da tradição angolana', icon: '🇦🇴' },
    { id: 'Lo-Fi', label: 'Lo-Fi Chill', description: 'Texturas nostálgicas para rimas calmas de estúdio', icon: '☕' },
    { id: 'R&B', label: 'R&B / Soul', description: 'Melodias e progressões harmónicas profissionais', icon: '🎤' }
  ];

  // Helper lists based on tab
  const getSelectedTrendingBeats = () => {
    switch (trendingTab) {
      case 'today': return trendingToday;
      case 'week': return trendingThisWeek;
      case 'played': return mostPlayed;
      case 'saved': return mostSaved;
    }
  };

  // Safe horizontal scroll helper for carousels
  const scrollContainer = (ref: React.RefObject<HTMLDivElement | null>, direction: 'left' | 'right') => {
    if (ref.current) {
      const scrollAmount = 450;
      ref.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  // Carousel refs mapping
  const carouselRefs: { [key: string]: React.RefObject<HTMLDivElement | null> } = {};
  genresToRender.forEach(g => {
    carouselRefs[g.id] = useRef<HTMLDivElement | null>(null);
  });
  
  const recommendedRef = useRef<HTMLDivElement | null>(null);

  return (
    <div id="smart-discovery-container" className="space-y-16 py-4 animate-in fade-in duration-500 pb-16">
      
      {/* SECTION 1: PERSONALIZED FEED ("VIVA & PERSONALIZADA") */}
      <div id="personalized-feed-section" className="space-y-6">
        <div className="flex flex-col text-left space-y-1">
          <div className="flex items-center gap-1.5">
            <span className="p-[2.5px] px-2 rounded-full bg-[#5865F2]/10 border border-[#5865F2]/15 text-[8px] font-black text-[#5865F2] tracking-wider uppercase flex items-center gap-1">
              <Sparkles size={10} className="animate-pulse" /> Inteligência Computada
            </span>
            <span className="text-[10px] uppercase font-bold text-gray-500">Curado para Ti</span>
          </div>
          
          <h3 className="text-xl md:text-2xl font-black italic text-white uppercase tracking-tight">
            {userLikesCount > 0 ? "Baseado nos teus favoritos" : "Recomendações Especiais"}
          </h3>
          <p className="text-gray-400 text-xs">
            {userLikesCount > 0 
              ? "Sons selecionados pelo nosso algoritmo combinando os teus géneros favoritos e métricas de engagement."
              : "Ainda não tens favoritos? Aqui estão hits quentes de Luanda recomendados para o teu estilo."
            }
          </p>
        </div>

        {/* Scrolling shelf of recommended cards */}
        <div className="relative group/carousel">
          <button 
            onClick={() => scrollContainer(recommendedRef, 'left')}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/80 hover:bg-[#5865F2] border border-white/5 hover:border-white/10 text-white rounded-full flex items-center justify-center opacity-0 group-hover/carousel:opacity-100 transition-opacity z-10 cursor-pointer shadow-xl"
            aria-label="Scroll Left"
          >
            <ChevronLeft size={16} />
          </button>
          <button 
            onClick={() => scrollContainer(recommendedRef, 'right')}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/80 hover:bg-[#5865F2] border border-white/5 hover:border-white/10 text-white rounded-full flex items-center justify-center opacity-0 group-hover/carousel:opacity-100 transition-opacity z-10 cursor-pointer shadow-xl"
            aria-label="Scroll Right"
          >
            <ChevronRight size={16} />
          </button>

          <div 
            ref={recommendedRef}
            className="flex gap-4 overflow-x-auto pb-3 scrollbar-none snap-x snap-mandatory select-none scroll-smooth"
          >
            {recommendedBeats.map((b) => {
              const isActive = currentBeat?.id === b.id;
              const isCurrentPlaying = isActive && isPlaying;
              return (
                <div 
                  key={`recom-${b.id}`}
                  onClick={() => {
                    recommendationService.trackClick(b.id, 'homepage_recommendations', user?.id);
                    onSelectBeat(b);
                  }}
                  className="w-[185px] shrink-0 snap-start select-none group/card bg-[#09090D] border border-white/5 hover:border-[#5865F2]/25 p-3.5 rounded-2xl flex flex-col justify-between aspect-[3/4] transition-all duration-300 hover:-translate-y-1 text-left relative overflow-hidden"
                >
                  <div className="relative aspect-square rounded-xl overflow-hidden bg-white/5 border border-white/5">
                    <img src={b.image || undefined} alt={b.title} className="w-full h-full object-cover transition-transform duration-500 group-hover/card:scale-105" />
                    
                    <div className="absolute inset-0 bg-black/45 opacity-0 group-hover/card:opacity-100 transition-opacity flex items-center justify-center">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onPlay(b);
                        }}
                        className="w-10 h-10 rounded-full bg-[#5865F2] text-white flex items-center justify-center shadow-lg transform scale-90 group-hover/card:scale-100 transition-transform hover:bg-[#4752C4]"
                      >
                        {isCurrentPlaying ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" className="ml-0.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="mt-3.5 min-w-0">
                    <h4 className={`font-black text-xs truncate uppercase tracking-tight leading-none ${isActive ? 'text-[#5865F2]' : 'text-white'}`}>{b.title}</h4>
                    <div className="flex items-center gap-1.5 mt-1.5">
                      <span className="text-[9px] font-bold text-gray-500 truncate leading-none uppercase">{b.producer}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-white/[0.03]">
                    <span className="text-[10px] font-mono font-bold text-[#F59E0B]">
                      {b.is_free_download || b.price?.basic === 0 || b.price?.basic === null || b.price?.basic === undefined ? (
                        <span className="text-emerald-400 font-extrabold text-[9px] uppercase tracking-wider">DOWNLOAD GRATUITO</span>
                      ) : (
                        `${Number(b.price.basic).toLocaleString('pt-AO')} Kz`
                      )}
                    </span>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        recommendationService.trackConversion(b.id, 'purchase', user?.id);
                        onAddToCart(b);
                      }}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-[#5865F2]/20 hover:text-[#5865F2] border border-white/5 text-gray-400 transition-colors cursor-pointer"
                      title="Adicionar ao carrinho"
                    >
                      <ShoppingCart size={11} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* SECTION 2: THE TRENDING DASHBOARD (SPOTIFY SINGLE TOP GRID) */}
      <div id="trending-system-section" className="bg-gradient-to-br from-[#0c0c12]/80 via-[#09090D]/90 to-black/80 border border-white/5 rounded-[2.5rem] p-6 md:p-8 space-y-8">
        
        {/* Nav Header Row */}
        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/5 pb-5 gap-4">
          <div className="text-left space-y-1">
            <div className="inline-flex items-center gap-1 h-5 px-2 rounded bg-amber-500/10 text-amber-500 text-[8px] font-black tracking-widest uppercase mb-1">
              <Flame size={10} className="fill-current animate-pulse" /> TRENDING CHARTS
            </div>
            <h3 className="text-xl md:text-2xl font-black italic uppercase tracking-tight text-white">Gira os Tops</h3>
            <p className="text-gray-400 text-xs">Métricas de streaming reais acumuladas por DJs e utilizadores em Angola.</p>
          </div>
          
          {/* Grid buttons switcher */}
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: 'today', label: '🔥 Alta Hoje' },
              { id: 'week', label: '📈 Ranking da Semana' },
              { id: 'played', label: '🎧 Mais Ouvidos' },
              { id: 'saved', label: '⭐ Guardados' }
            ].map((btn) => (
              <button
                key={btn.id}
                onClick={() => setTrendingTab(btn.id as any)}
                className={`px-4 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-wider border transition-all cursor-pointer ${
                  trendingTab === btn.id 
                    ? 'bg-white border-white text-black font-black'
                    : 'bg-white/5 border-white/5 text-gray-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>
        </div>

        {/* Top lists - 2 Cols Split: Left 3, Right 3 */}
        <div className="grid md:grid-cols-2 gap-x-12 gap-y-4">
          {getSelectedTrendingBeats().map((b, idx) => {
            const isActive = currentBeat?.id === b.id;
            const isCurrentPlaying = isActive && isPlaying;
            return (
              <div 
                key={`trending-dashboard-${b.id}-${idx}`}
                onClick={() => {
                  recommendationService.trackClick(b.id, `trending_${trendingTab}`, user?.id);
                  onSelectBeat(b);
                }}
                className="flex items-center justify-between p-3.5 bg-white/[0.01] hover:bg-white/[0.04] border-b border-white/[0.04] cursor-pointer group transition-all duration-150 rounded-xl"
              >
                <div className="flex items-center gap-4 min-w-0">
                  {/* Rank positioning index label */}
                  <span className="w-5 text-center font-black text-sm text-gray-400 group-hover:text-amber-500 transition-colors">
                    {idx + 1}
                  </span>
                  
                  {/* Artwork with play button hover overlay */}
                  <div className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-neutral-900 border border-white/10">
                    <img src={b.image || undefined} alt={b.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onPlay(b);
                        }}
                        className="p-1.5 bg-white text-black rounded-full hover:scale-110 active:scale-90 transition-transform flex items-center justify-center"
                      >
                        {isCurrentPlaying ? <Pause size={12} fill="currentColor" /> : <Play size={12} fill="currentColor" className="ml-0.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="min-w-0 text-left">
                    <h4 className={`font-black text-xs uppercase truncate block max-w-sm ${isActive ? 'text-amber-500' : 'text-white'}`}>{b.title}</h4>
                    <span className="text-[10px] text-gray-500 font-bold uppercase truncate">{b.producer}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 shrink-0">
                  {/* BPM text tags / kit labels */}
                  {!(b.type === 'kit' || (b.category && (b.category.toLowerCase().includes('kit') || b.category.toLowerCase().includes('pack')))) ? (
                    <span className="hidden sm:inline-block px-2 py-0.5 text-[8px] font-mono border border-white/5 rounded text-gray-500 font-bold bg-neutral-900">{b.bpm} BPM</span>
                  ) : (
                    <span className="px-2 py-0.5 text-[8px] font-mono border border-[#5865F2]/20 rounded text-[#5865F2] font-black bg-[#5865F2]/5 uppercase">SOUNDKIT</span>
                  )}
                  
                  {/* Popular plays velocity visual tag */}
                  <span className="text-[10px] font-mono font-black text-gray-400">
                    {b.plays_count || 0} plays
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 3: RECTANGULAR DISCOVERY CAROUSELS ("VILA & ORGÂNICO") */}
      <div id="cultural-carousel-section" className="space-y-12">
        
        <div className="flex flex-col text-left space-y-1">
          <div className="inline-flex items-center gap-1 bg-[#5865F2]/10 border border-[#5865F2]/15 px-2 py-0.5 rounded text-[#5865F2] text-[8px] font-black tracking-widest uppercase max-w-fit">
            🌍 EXPLORAR GÉNEROS EM FILA COM scrolling RESPONSIVO
          </div>
          <h3 className="text-xl md:text-2xl font-black italic uppercase text-white tracking-tight">Roteiro Cultural de Angola</h3>
          <p className="text-gray-400 text-xs">Coleções organizadas por subgénero para que encontres o ritmo perfeito com scroll fluido.</p>
        </div>

        {/* Mapping through our explicit genres */}
        {genresToRender.map((g) => {
          const matchedBeats = recommendationService.getCarouselByCategory(beats, g.id, 8);
          if (matchedBeats.length === 0) return null; // Only render if we have beats

          return (
            <div key={`cultural-${g.id}`} className="space-y-4 text-left border-l border-[#5865F2]/10 pl-4 md:pl-5">
              
              {/* Genre Slider Header */}
              <div className="flex items-end justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-black italic text-sm md:text-base text-white tracking-widest flex items-center gap-1.5 uppercase leading-none">
                    <span className="text-lg md:text-xl select-none leading-none">{g.icon}</span> {g.label}
                  </h4>
                  <p className="text-gray-500 text-[10px] md:text-xs tracking-wide">{g.description}</p>
                </div>
                
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => onExploreGenre(g.id)}
                    className="text-[10px] uppercase tracking-wider font-extrabold text-[#5865F2] hover:text-white transition-all cursor-pointer flex items-center gap-0.5 underline hover:no-underline"
                  >
                    Ver Tudo
                  </button>
                  
                  {/* Chevrons buttons for beautiful horizontal navigate */}
                  <div className="hidden md:flex items-center gap-1 ml-2">
                    <button 
                      onClick={() => scrollContainer(carouselRefs[g.id], 'left')}
                      className="w-7 h-7 bg-neutral-900 border border-white/5 text-gray-400 hover:text-white hover:bg-[#5865F2] rounded-full flex items-center justify-center transition-colors cursor-pointer"
                      title="Anterior"
                    >
                      <ChevronLeft size={13} />
                    </button>
                    <button 
                      onClick={() => scrollContainer(carouselRefs[g.id], 'right')}
                      className="w-7 h-7 bg-neutral-900 border border-white/5 text-gray-400 hover:text-white hover:bg-[#5865F2] rounded-full flex items-center justify-center transition-colors cursor-pointer"
                      title="Seguinte"
                    >
                      <ChevronRight size={13} />
                    </button>
                  </div>
                </div>
              </div>

              {/* Slider shelf list */}
              <div className="relative group/carousel-shelf">
                <div 
                  ref={carouselRefs[g.id]}
                  className="flex gap-4 overflow-x-auto pb-3 scrollbar-none snap-x snap-mandatory select-none scroll-smooth touch-pan-x"
                >
                  {matchedBeats.map((b) => {
                    const isActive = currentBeat?.id === b.id;
                    const isCurrentPlaying = isActive && isPlaying;
                    return (
                      <div 
                        key={`genrecar-${g.id}-${b.id}`}
                        onClick={() => {
                          recommendationService.trackClick(b.id, `carousel_${g.id}`, user?.id);
                          onSelectBeat(b);
                        }}
                        className="w-[180px] shrink-0 snap-start bg-[#0c0c12]/60 hover:bg-[#12121c]/80 border border-white/5 hover:border-[#5865F2]/20 p-3.5 rounded-2xl flex flex-col justify-between aspect-[3/4] transition-all duration-300 hover:-translate-y-1 relative"
                      >
                        <div className="relative aspect-square rounded-xl overflow-hidden bg-white/5 border border-white/5">
                          <img src={b.image || undefined} alt={b.title} className="w-full h-full object-cover transition-transform duration-500 group-hover/carousel-shelf:scale-102" />
                          
                          <div className="absolute inset-0 bg-black/45 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center group-hover/carousel-shelf:opacity-100">
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                onPlay(b);
                              }}
                              className="w-9 h-9 rounded-full bg-[#5865F2] text-white flex items-center justify-center shadow-lg transform scale-90 hover:scale-105 transition-transform"
                            >
                              {isCurrentPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
                            </button>
                          </div>
                        </div>

                        <div className="mt-3 min-w-0">
                          <h4 className={`font-black text-xs truncate uppercase tracking-tight leading-none ${isActive ? 'text-[#5865F2]' : 'text-white'}`}>{b.title}</h4>
                          <span className="text-[9px] text-gray-500 mt-1 truncate block font-bold uppercase">{b.producer}</span>
                        </div>

                        <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/[0.03]">
                          <span className="text-[10px] font-mono font-bold text-gray-400">
                            {b.bpm ? `${b.bpm} bpm` : (b.category || "SOUNDKIT")}
                          </span>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              recommendationService.trackConversion(b.id, 'purchase', user?.id);
                              onAddToCart(b);
                            }}
                            className="p-1 px-2.5 rounded-lg bg-[#5865F2]/5 hover:bg-[#5865F2] hover:text-white border border-[#5865F2]/10 text-gray-400 text-[9px] font-semibold transition-all cursor-pointer"
                          >
                            Carrinho
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
