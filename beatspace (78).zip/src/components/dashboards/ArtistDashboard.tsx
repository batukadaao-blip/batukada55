import React from 'react';

export default function ArtistDashboard() {
  return (
    <div className="p-8">
      <h2 className="text-3xl font-black text-white mb-6">Dashboard de Artista</h2>
      <p className="text-gray-400">Aqui podes ver os teus beats comprados, playlists e licenças.</p>
      {/* Add artist specific functionality here */}
    </div>
  );
}
