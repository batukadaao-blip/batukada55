import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Upload, 
  Sparkles, 
  AlertCircle, 
  Trash2, 
  FolderArchive, 
  Lock, 
  Check, 
  ChevronRight, 
  ChevronLeft, 
  Eye, 
  Layers, 
  Flame, 
  Activity, 
  HelpCircle,
  FileAudio,
  Coins,
  CheckCircle2,
  Package,
  Image as ImageIcon,
  Tag,
  List,
  Loader2,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getSupabase, isStorageDirectDisabled, setStorageDirectDisabled, getPublicUrl } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import GenreSelect from '../../GenreSelect';

const GENRES = ['Afro Beat', 'Kuduro', 'Trap', 'R&B', 'Kompa', 'Gospel', 'Semba', 'Kizomba', 'Ghetto Zouk', 'Afrotrap', 'Boom Bap', 'Outro'];
const SUGGESTED_TAGS = ['drumkit', 'loops', 'melody', 'drums', 'samples', 'vocals', '808s', 'midi', 'oneshots', 'afrobeat'];
const CONTENT_OPTIONS = ['Kicks', 'Snares', 'Hi-hats', 'Percussion', '808s', 'Vox', 'FX', 'Loops', 'MIDI', 'One Shots'];

interface AdicionarKitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (kit: any) => void;
}

const STEPS = [
  { number: 1, name: 'Ficheiros', desc: 'Capa & ZIP/RAR' },
  { number: 2, name: 'Metadados', desc: 'Estilo & Conteúdo' },
  { number: 3, name: 'Preço', desc: 'Valores' },
  { number: 4, name: 'Revisão', desc: 'Rever & Publicar' }
];

export default function AdicionarKitModal({ isOpen, onClose, onSuccess }: AdicionarKitModalProps) {
  const instanceId = useMemo(() => Math.random().toString(36).substring(7), []);
  const isSubmittingRef = React.useRef(false);

  useEffect(() => {
    if (isOpen) {
      console.log(`[AdicionarKitModal ${instanceId}] MOUNTED/OPENED`);
    } else {
      isSubmittingRef.current = false;
    }
    return () => {
      isSubmittingRef.current = false;
    };
  }, [isOpen, instanceId]);

  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [processingFiles, setProcessingFiles] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('drum-kit');
  const [genre, setGenre] = useState('');
  const [price, setPrice] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [contents, setContents] = useState<string[]>([]);

  const [isFreeDownload, setIsFreeDownload] = useState(false);
  const [freeDownloadRequiresFollow, setFreeDownloadRequiresFollow] = useState(false);
  const [freeDownloadRequiresComment, setFreeDownloadRequiresComment] = useState(false);
  const [freeDownloadRequiresEmail, setFreeDownloadRequiresEmail] = useState(false);

  // Drag and drop states
  const [dragActive, setDragActive] = useState<Record<string, boolean>>({
    cover: false,
    zip: false
  });

  interface UploadFileState {
    file: File | null;
    progress: number;
    status: 'idle' | 'ready' | 'uploading' | 'completed';
    speed?: string;
    uploadedSize?: string;
    totalSize?: string;
    timeLeft?: string;
    stageMessage?: string;
  }

  const [uploadsState, setUploadsState] = useState<{
    cover: UploadFileState;
    zip: UploadFileState;
  }>({
    cover: { file: null, progress: 0, status: 'idle' },
    zip: { file: null, progress: 0, status: 'idle' },
  });

  const coverPreviewUrl = useMemo(() => {
    if (uploadsState.cover.file) {
      return URL.createObjectURL(uploadsState.cover.file);
    }
    return null;
  }, [uploadsState.cover.file]);

  // Cleanup helper for blob URLs
  useEffect(() => {
    return () => {
      if (coverPreviewUrl) URL.revokeObjectURL(coverPreviewUrl);
    };
  }, [coverPreviewUrl]);

  const handleFileChange = (key: 'cover' | 'zip', file: File) => {
    console.log(`[${instanceId}] handleFileChange: ${key} -> ${file.name}`);
    setError(null);
    const MAX_FILE_SIZE = 50 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
      const currentSizeMB = (file.size / (1024 * 1024)).toFixed(1);
      setError(`file_size_error:${file.name}:${currentSizeMB}`);
      return;
    }
    setUploadsState(prev => ({ 
      ...prev, 
      [key]: { file, progress: 0, status: 'ready' } 
    }));
  };

  const removeFile = (key: 'cover' | 'zip') => {
    setUploadsState(prev => ({ ...prev, [key]: { file: null, progress: 0, status: 'idle' } }));
  };

  const validateAndSetCover = (file: File) => {
    setError(null);
    const MAX_FILE_SIZE = 50 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
      const currentSizeMB = (file.size / (1024 * 1024)).toFixed(1);
      setError(`file_size_error:${file.name}:${currentSizeMB}`);
      return;
    }
    if (!file.type.startsWith('image/')) {
      setError('Por favor, selecione uma imagem para a capa do kit.');
      return;
    }
    handleFileChange('cover', file);
  };

  // Drag over / leave handler
  const handleDrag = (e: React.DragEvent, key: string, active: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(prev => ({ ...prev, [key]: active }));
  };

  // Drop handler
  const handleDrop = (e: React.DragEvent, key: 'cover' | 'zip') => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(prev => ({ ...prev, [key]: false }));

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      
      const MAX_FILE_SIZE = 50 * 1024 * 1024;
      if (droppedFile.size > MAX_FILE_SIZE) {
        const currentSizeMB = (droppedFile.size / (1024 * 1024)).toFixed(1);
        setError(`file_size_error:${droppedFile.name}:${currentSizeMB}`);
        return;
      }

      if (key === 'cover') {
        validateAndSetCover(droppedFile);
      } else {
        const fileExt = droppedFile.name.split('.').pop()?.toLowerCase();
        const allowedMimeTypes = ['application/zip', 'application/x-zip-compressed', 'application/vnd.rar', 'application/x-rar-compressed'];
        if (fileExt !== 'zip' && fileExt !== 'rar' && !allowedMimeTypes.includes(droppedFile.type)) {
          setError('O arquivo do kit deve ser um ficheiro .zip ou .rar');
          return;
        }
        handleFileChange('zip', droppedFile);
      }
    }
  };

  const addTag = (tagToAdd?: string) => {
    const tag = tagToAdd || tagInput;
    if (tag.trim() && tags.length < 3 && !tags.includes(tag.trim().toLowerCase())) {
      setTags([...tags, tag.trim().toLowerCase()]);
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(t => t !== tagToRemove));
  };

  const toggleContent = (item: string) => {
    setContents(prev => 
      prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item]
    );
  };

  // Step Completeness Validation
  const step1Completeness = useMemo(() => {
    const missing = [];
    if (!uploadsState.cover.file) missing.push('Capa do Kit');
    if (!uploadsState.zip.file) missing.push('Ficheiro ZIP/RAR');
    return { complete: missing.length === 0, missing };
  }, [uploadsState.cover.file, uploadsState.zip.file]);

  const step2Completeness = useMemo(() => {
    const missing = [];
    if (!title.trim()) missing.push('Título');
    if (!description.trim()) missing.push('Descrição');
    if (!category) missing.push('Categoria');
    if (contents.length === 0) missing.push('Conteúdos');
    return { complete: missing.length === 0, missing };
  }, [title, description, category, contents]);

  const step3Completeness = useMemo(() => {
    const missing = [];
    if (!isFreeDownload && (!price || Number(price) <= 0)) missing.push('Preço válido');
    return { complete: missing.length === 0, missing };
  }, [price, isFreeDownload]);

  const uploadFileReal = async (
    up: { path: string; file: File; bucket: string; key: 'cover' | 'zip' },
    onProgress: (
      percent: number,
      speed?: string,
      uploadedSize?: string,
      totalSize?: string,
      timeLeft?: string,
      stageMessage?: string
    ) => void
  ): Promise<void> => {
    // Generate and log real connection endpoints
    const fallbackUrl = '/api/storage/upload-chunk';

    console.log('UPLOAD ENGINE INITIALIZATION');
    console.log('FALLBACK URL:', fallbackUrl);

    // Chunked uploader function that is shared
    const runChunkedUpload = async (): Promise<void> => {
      console.log('[CHUNK UPLOAD] Performing chunked upload to server:', up.file.name);
      
      const fileId = crypto.randomUUID();
      const chunkSize = 1024 * 1024; // 1MB chunks for maximum stability over proxy and browser memory limits
      const totalChunks = Math.ceil(up.file.size / chunkSize);
      const startTime = Date.now();

      onProgress(
        0,
        'A iniciar...',
        '0 MB',
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        'Calculando...',
        'A iniciar transferência de segurança...'
      );

      for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
        const start = chunkIndex * chunkSize;
        const end = Math.min(start + chunkSize, up.file.size);
        const chunkBlob = up.file.slice(start, end);
        
        // Convert blob to base64
        const chunkData = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const base64 = reader.result as string;
            resolve(base64);
          };
          reader.onerror = reject;
          reader.readAsDataURL(chunkBlob);
        });

        let response: Response | null = null;
        let attempt = 0;
        const maxAttempts = 5;
        let success = false;
        let lastError: any = null;

        while (attempt < maxAttempts && !success) {
          try {
            if (attempt > 0) {
              console.warn(`[CHUNK RETRY] ChunkIndex ${chunkIndex} attempt ${attempt + 1}/${maxAttempts} in 1500ms...`);
              onProgress(
                -1, // RETRY state trigger
                'A reconectar...',
                `${(start / (1024 * 1024)).toFixed(1)} MB`,
                `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
                 'A retomar...',
                `Falha temporária de rede. A tentar novamente (Tentativa ${attempt + 1}/${maxAttempts})...`
              );
              await new Promise(resolve => setTimeout(resolve, 1500));
            }

            const supabase = getSupabase();
            const { data: { session } } = await supabase.auth.getSession();
            const token = session?.access_token;

            response = await fetch(fallbackUrl, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                ...(token ? { 'Authorization': `Bearer ${token}` } : {})
              },
              body: JSON.stringify({
                fileId,
                chunkIndex,
                totalChunks,
                fileName: up.file.name,
                chunkData,
                bucket: up.bucket,
                path: up.path,
                fileType: up.key
              })
            });

            if (response.ok) {
              success = true;
            } else {
              const errBody = await response.json().catch(() => ({}));
              throw new Error(errBody.error || `HTTP ${response.status}`);
            }
          } catch (e: any) {
            lastError = e;
            attempt++;
          }
        }

        if (!success || !response) {
          throw new Error(`Erro de transferência no bloco ${chunkIndex + 1} de ${totalChunks}: ${lastError?.message || lastError}`);
        }

        const resData = await response.json();
        
        // Update progress
        const percent = Math.round(((chunkIndex + 1) / totalChunks) * 100);
        const elapsedMs = Date.now() - startTime;
        const elapsedSeconds = elapsedMs / 1000;
        
        let speedStr = '';
        let timeLeftStr = '';
        
        if (elapsedSeconds > 0) {
          const uploadedBytes = (chunkIndex + 1) * chunkSize;
          const speedBytesSec = uploadedBytes / elapsedSeconds;
          const speedMB = speedBytesSec / (1024 * 1024);
          speedStr = speedMB > 0.1 
            ? `${speedMB.toFixed(1)} MB/s` 
            : `${(speedBytesSec / 1024).toFixed(0)} KB/s`;

          const remainingBytes = up.file.size - uploadedBytes;
          const remainingSeconds = remainingBytes / speedBytesSec;
          if (remainingSeconds > 0) {
            timeLeftStr = remainingSeconds < 60
              ? `${Math.round(remainingSeconds)}s restantes`
              : `${Math.floor(remainingSeconds / 60)}m ${Math.round(remainingSeconds % 60)}s restantes`;
          }
        }

        const uploadedStr = `${(Math.min((chunkIndex + 1) * chunkSize, up.file.size) / (1024 * 1024)).toFixed(1)} MB`;
        const totalStr = `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`;

        onProgress(
          percent,
          speedStr,
          uploadedStr,
          totalStr,
          timeLeftStr,
          `A enviar parte ${chunkIndex + 1}/${totalChunks} (Canal de backup)...`
        );

        if (resData.fileUrl) {
          // Store combined fileUrl in the up object to resolve later
          (up as any).serverUrl = resData.fileUrl;
        }
      }

      onProgress(
        100,
        'Concluído',
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        'Concluído',
        'Transferência de segurança concluída com sucesso!'
      );
    };

    // If file is larger than 30MB, run chunked upload directly!
    if (up.file.size > 30 * 1024 * 1024) {
      console.log('[STORAGE UPLOAD] File larger than 30MB. Doing chunked upload...');
      await runChunkedUpload();
      return;
    }

    console.log('[STORAGE UPLOAD] Proxy Upload Starting:', {
      bucket: up.bucket,
      path: up.path,
      size: up.file.size
    });

    onProgress(
      10, 
      'A iniciar...', 
      '0 MB', 
      `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`, 
      'Calculando...', 
      'Iniciando upload através do canal expresso de segurança...'
    );

    // Track state and fake live updates to satisfy styling/progress bars
    const startTimeProxy = Date.now();
    let currentPercentProxy = 10;
    const intervalProxy = setInterval(() => {
      if (currentPercentProxy < 90) {
        currentPercentProxy += Math.floor(Math.random() * 8) + 2;
        if (currentPercentProxy > 90) currentPercentProxy = 90;

        const elapsedMs = Date.now() - startTimeProxy;
        const elapsedSeconds = elapsedMs / 1000;
        let speedStr = 'A carregar...';
        let timeLeftStr = 'Calculando...';

        if (elapsedSeconds > 0) {
          const estimatedLoaded = (up.file.size * currentPercentProxy) / 100;
          const speedBytesSec = estimatedLoaded / elapsedSeconds;
          const speedMB = speedBytesSec / (1024 * 1024);
          speedStr = speedMB > 0.1 
            ? `${speedMB.toFixed(1)} MB/s` 
            : `${(speedBytesSec / 1024).toFixed(0)} KB/s`;

          const remainingBytes = up.file.size - estimatedLoaded;
          const remainingSeconds = remainingBytes / speedBytesSec;
          if (remainingSeconds > 0) {
            timeLeftStr = remainingSeconds < 60
              ? `${Math.round(remainingSeconds)}s restantes`
              : `${Math.floor(remainingSeconds / 60)}m ${Math.round(remainingSeconds % 60)}s restantes`;
          }
        }

        const uploadedStr = `${((up.file.size * currentPercentProxy) / 100 / (1024 * 1024)).toFixed(1)} MB`;
        const totalStr = `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`;

        onProgress(
          currentPercentProxy,
          speedStr,
          uploadedStr,
          totalStr,
          timeLeftStr,
          'A transferir ficheiro (Canal expresso)...'
        );
      }
    }, 1000);

    try {
      // Convert to base64 with Data URL prefix
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(up.file);
      });

      const supabase = getSupabase();
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;

      console.log('[STORAGE UPLOAD] Sending base64 payload to server upload proxy...');
      const proxyResponse = await fetch('/api/storage/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          base64Data,
          bucket: up.bucket,
          path: up.path,
          contentType: up.file.type || 'application/octet-stream',
          fileType: up.key
        })
      });

      clearInterval(intervalProxy);

      if (!proxyResponse.ok) {
        const errDetails = await proxyResponse.json().catch(() => ({}));
        throw new Error(errDetails.error || `HTTP ${proxyResponse.status}`);
      }

      const resData = await proxyResponse.json().catch(() => ({}));
      if (resData && resData.fileUrl) {
        (up as any).serverUrl = resData.fileUrl;
      }

      onProgress(
        100,
        'Concluído',
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        'Concluído',
        'Upload finalizado com sucesso!'
      );
      console.log('[STORAGE UPLOAD] Proxy upload completed successfully');
    } catch (err: any) {
      clearInterval(intervalProxy);
      console.warn('[STORAGE UPLOAD] Proxy upload failed, activating local chunked upload fallback. Reason:', err?.message || err);
      try {
        await runChunkedUpload();
      } catch (fallbackErr: any) {
        console.error('[STORAGE EXCEPTION] Local chunked upload fallback failed:', fallbackErr);
        throw new Error(`Falha crítica de upload (Mecanismo principal e de segurança falharam): ${fallbackErr?.message || fallbackErr}`);
      }
    }
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (loading) return;
    if (isSubmittingRef.current) {
      console.log('[SUBMIT] Execution blocked: isSubmittingRef.current is true (double click / rapid submission lock)');
      return;
    }
    isSubmittingRef.current = true;
    setError(null);
    setLoading(true);
    setIsUploading(true);
    setProcessingFiles(true);

    const successfullyUploaded: { bucket: string; path: string }[] = [];

    try {
      if (!user) {
        throw new Error('Utilizador não autenticado.');
      }

      console.log('[SUBMIT] Preparing real kit uploads...');
      const sanitizeFileName = (name: string): string => {
        return name
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '') // remove accents
          .replace(/[^a-zA-Z0-9._-]/g, '_') // replace special chars/spaces/quotes/brackets with '_'
          .replace(/__+/g, '_'); // deduplicate underscores
      };

      const kitId = crypto.randomUUID();
      const timestamp = Date.now();
      
      const supabase = getSupabase();
      if (!supabase) throw new Error('Supabase client not initialized');

      // Centralized Function / Flow to standardize and protect Kit Cover upload & public URL resolving
      const uploadKitCover = async (file: File): Promise<string> => {
        const sanitized = sanitizeFileName(file.name);
        // Correctly structured template path format requested
        const path = `${user.id}/kits/covers/${timestamp}-${sanitized}`;
        
        const up = { key: 'cover' as const, path, file, bucket: 'beats' };
        
        console.log('[uploadKitCover] Starting standarized upload to path:', path);
        
        setUploadsState(prev => ({
          ...prev,
          cover: {
            ...prev.cover,
            status: 'uploading',
            progress: 0,
            stageMessage: 'Iniciando...'
          }
        }));

        await uploadFileReal(up, (percent, speed, uploadedSize, totalSize, timeLeft, stageMessage) => {
          setUploadsState(prev => {
            const currentItem = prev.cover;
            const currentProgress = currentItem.progress || 0;
            
            if (percent === -1) {
              return {
                ...prev,
                cover: {
                  ...currentItem,
                  progress: currentProgress,
                  stageMessage: stageMessage || 'A restabelecer ligação...',
                  speed: 'A reconectar...',
                  timeLeft: 'A retomar...'
                }
              };
            }

            const isPhysicalCatchUp = percent < currentProgress;
            let finalStageMessage = stageMessage || currentItem.stageMessage;
            if (isPhysicalCatchUp) {
              finalStageMessage = `A retomar do início... (físico: ${percent}%)`;
            }

            return {
              ...prev,
              cover: {
                ...currentItem,
                progress: Math.max(currentProgress, percent),
                speed: isPhysicalCatchUp ? (speed || 'A ler...') : (speed || currentItem.speed),
                uploadedSize: isPhysicalCatchUp ? (uploadedSize || currentItem.uploadedSize) : (uploadedSize || currentItem.uploadedSize),
                totalSize: totalSize || currentItem.totalSize,
                timeLeft: isPhysicalCatchUp ? `A recalcular... (${percent}%)` : (timeLeft || currentItem.timeLeft),
                stageMessage: finalStageMessage
              }
            };
          });
        });

        successfullyUploaded.push({ bucket: 'beats', path });

        setUploadsState(prev => ({
          ...prev,
          cover: {
            ...prev.cover,
            status: 'completed',
            progress: 100,
            stageMessage: 'Upload concluído'
          }
        }));

        // Fetching the verified public URL using standard Supabase storage method
        const publicUrl = getPublicUrl('beats', path);
        console.log('KIT COVER UPLOADED');
        console.log('KIT COVER URL', publicUrl);

        if (!publicUrl) {
          throw new Error('Kit cover URL inválida');
        }

        return publicUrl;
      };

      // 1. Upload cover icon using custom standardized handler
      const finalCoverUrl = await uploadKitCover(uploadsState.cover.file!);

      // 2. Upload zip package
      const zipPath = `${user.id}/kits/${kitId}/${timestamp}_kit_${sanitizeFileName(uploadsState.zip.file!.name)}`;
      const zipUp = { key: 'zip' as const, path: zipPath, file: uploadsState.zip.file!, bucket: 'beats-private' };

      setUploadsState(prev => ({
        ...prev,
        zip: {
          ...prev.zip,
          status: 'uploading',
          progress: 0,
          stageMessage: 'Iniciando...'
        }
      }));

      await uploadFileReal(zipUp, (percent, speed, uploadedSize, totalSize, timeLeft, stageMessage) => {
        setUploadsState(prev => {
          const currentItem = prev.zip;
          const currentProgress = currentItem.progress || 0;
          
          if (percent === -1) {
            return {
              ...prev,
              zip: {
                ...currentItem,
                progress: currentProgress,
                stageMessage: stageMessage || 'A restabelecer ligação...',
                speed: 'A reconectar...',
                timeLeft: 'A retomar...'
              }
            };
          }

          const isPhysicalCatchUp = percent < currentProgress;
          let finalStageMessage = stageMessage || currentItem.stageMessage;
          if (isPhysicalCatchUp) {
            finalStageMessage = `A retomar do início... (físico: ${percent}%)`;
          }

          return {
            ...prev,
            zip: {
              ...currentItem,
              progress: Math.max(currentProgress, percent),
              speed: isPhysicalCatchUp ? (speed || 'A ler...') : (speed || currentItem.speed),
              uploadedSize: isPhysicalCatchUp ? (uploadedSize || currentItem.uploadedSize) : (uploadedSize || currentItem.uploadedSize),
              totalSize: totalSize || currentItem.totalSize,
              timeLeft: isPhysicalCatchUp ? `A recalcular... (${percent}%)` : (timeLeft || currentItem.timeLeft),
              stageMessage: finalStageMessage
            }
          };
        });
      });

      setUploadsState(prev => ({
        ...prev,
        zip: {
          ...prev.zip,
          status: 'completed',
          progress: 100,
          stageMessage: 'Upload concluído'
        }
      }));

      successfullyUploaded.push({ bucket: zipUp.bucket, path: zipUp.path });

      // Find the absolute/full url or private path reference for the ZIP package
      const finalZipUrl = (zipUp as any).serverUrl || ("beats-private/" + zipPath);

      console.log('[SUBMIT] All kit uploads completed. Inserting db profile...');

      setIsUploading(false);
      setLoading(false);
      setProcessingFiles(false);

      let profileName = 'Produtor';
      try {
        const savedProfile = localStorage.getItem('producerProfile');
        if (savedProfile) {
          const parsedProfile = JSON.parse(savedProfile);
          if (parsedProfile && parsedProfile.artisticName) {
            profileName = parsedProfile.artisticName;
          }
        }
      } catch (e) {
        console.warn('Could not parse producer profile from localStorage:', e);
      }

      const artisticName = profileName !== 'Produtor' ? profileName : (user?.user_metadata?.artistic_name || user?.user_metadata?.display_name || user?.email?.split('@')[0] || 'Produtor');

      console.log('KIT CATEGORY', category);
      console.log('KIT STATUS', 'published');
      console.log('KIT PUBLISHED', true);

      const dbPayload = {
        producer_id: user.id,
        title: title.toUpperCase(),
        category: category || 'drum-kit',
        price_basic: isFreeDownload ? 0 : (Number(price) || 0),
        genre: genre || 'All Style',
        tags: tags,
        cover_url: finalCoverUrl,
        demo_url: finalZipUrl,
        master_url: finalZipUrl,
        status: 'published',
        is_published: true,
        visibility: 'public',
        artist_name: artisticName
      };

      console.log('[DB] Attempting insert with payload:', JSON.stringify(dbPayload, null, 2));

      let insertedRow: any = null;
      let dbError: any = null;

      try {
        const { data, error } = await supabase
          .from('beats')
          .insert(dbPayload)
          .select();
        dbError = error;
        if (data && data.length > 0) {
          insertedRow = data[0];
          console.log('[DB] Inserted successfully, received row:', insertedRow);
        }
      } catch (insertExc) {
        dbError = insertExc;
      }

      if (dbError) {
        console.error('[DB] Initial insert error:', dbError);

        if (dbError.code === '42703' || (dbError as any).status === 400 || (dbError.message && dbError.message.includes('column'))) {
          console.warn('[DB] Probable schema mismatch. Retrying with minimal legacy payload.');
          
          const minimalPayload = {
            producer_id: user.id,
            title: title.toUpperCase(),
            category: category || 'drum-kit',
            price_basic: isFreeDownload ? 0 : (Number(price) || 0),
            genre: genre || 'All Style',
            tags: tags,
            cover_url: finalCoverUrl,
            demo_url: finalZipUrl,
            master_url: finalZipUrl,
            status: 'published',
            is_published: true,
            visibility: 'public',
            artist_name: artisticName
          };

          try {
            const { data: retryData, error: retryError } = await supabase
              .from('beats')
              .insert(minimalPayload)
              .select();
            dbError = retryError;
            if (retryData && retryData.length > 0) {
              insertedRow = retryData[0];
              console.log('[DB] Retry insert successful, received row:', insertedRow);
            }
          } catch (retryExc) {
            dbError = retryExc;
          }
        }
      }

      if (dbError) throw dbError;

      const finalDatabaseId = insertedRow?.id || kitId;
      console.log('[DB] Resolved final database ID for new kit:', finalDatabaseId);

      const newKit = {
        id: finalDatabaseId,
        title: title.toUpperCase(),
        description,
        category,
        genre: genre || 'All Style',
        price: isFreeDownload ? 0 : (Number(price) || 0),
        tags: tags.join(', ').toUpperCase(),
        cover: finalCoverUrl,
        file: finalZipUrl,
        contents,
        status: 'published',
        date: new Date().toLocaleDateString('pt-AO'),
        sales: 0,
        earnings: 0,
        is_free_download: isFreeDownload,
        free_download_requires_follow: freeDownloadRequiresFollow,
        free_download_requires_comment: freeDownloadRequiresComment,
        free_download_requires_email: freeDownloadRequiresEmail,
        free_download_count: 0
      };

      // Register Social Activity
      try {
        const authorProf = JSON.parse(localStorage.getItem('user_profile') || '{}');
        const pName = authorProf.artisticName || authorProf.artistic_name || authorProf.display_name || user?.user_metadata?.artistic_name || user?.email?.split('@')[0] || 'Produtor';
        const pUsername = authorProf.username || user?.user_metadata?.username || user?.email?.split('@')[0]?.toLowerCase().replace(/\s+/g, '') || 'produtor';
        const pAvatar = authorProf.avatarUrl || authorProf.avatar_url || user?.user_metadata?.avatar_url || null;

        const urlResolver = getPublicUrl('beats', (newKit as any).cover_url || (newKit as any).cover || '');

        await fetch('/api/activity/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            user_id: user?.id,
            type: 'kit_upload',
            actor_name: pName,
            actor_username: pUsername,
            actor_avatar: pAvatar,
            target_id: newKit.id,
            target_title: newKit.title,
            target_cover: urlResolver,
            metadata: {
              category: newKit.category || 'Soundkit',
              genre: newKit.genre
            }
          })
        });
      } catch (actErr) {
        console.warn('[SUBMIT] Silent error logging kit activity upload:', actErr);
      }

      // 1. Detailed requested logging
      console.log('UPLOAD SUCCESS');
      console.log('KIT CREATED', newKit);
      console.log('FINAL STEP', 4);
      console.log('CURRENT STEP', step);
      console.log('PUBLISH RESPONSE', dbPayload);

      // 2. Persist kit in localStorage beatangola_kits so MeusKits.tsx displays it instantly
      try {
        const storedKits = localStorage.getItem('beatangola_kits');
        const list = storedKits ? JSON.parse(storedKits) : [];
        list.unshift(newKit);
        localStorage.setItem('beatangola_kits', JSON.stringify(list));
        console.log('[LOCALSTORAGE] Kit saved successfully in "beatangola_kits"');
      } catch (e) {
        console.error('[LOCALSTORAGE] Error saving kit to localStorage:', e);
      }

      // 3. Dispatch force refresh event for App.tsx to reload beats from DB bypass-cache
      try {
        window.dispatchEvent(new CustomEvent('beatangola_force_refresh_beats'));
        console.log('[ADD KIT] Dispatched beatangola_force_refresh_beats custom event.');
      } catch (evtErr) {
        console.warn('[ADD KIT] Error dispatching custom refresh event:', evtErr);
      }

      // 4. Safety try-catch around parent callback to protect against sandboxed alert() failures
      try {
        onSuccess(newKit);
      } catch (onSuccessErr) {
        console.warn('[SUBMIT] Eventual error in parent onSuccess callback:', onSuccessErr);
      }
      onClose();
    } catch (err: any) {
      console.error('[SUBMIT] Kit upload failed:', err);
      setError(err?.message || 'Ocorreu um erro ao carregar os teus ficheiros de Kit. Por favor, tenta novamente.');
      
      // Automatic Rollback Protection for Orphaning
      if (typeof successfullyUploaded !== 'undefined' && successfullyUploaded.length > 0) {
        console.warn(`[ROLLBACK EXECUTED] Kit publication failed after uploads. Cleaning up ${successfullyUploaded.length} uploaded files from Storage...`);
        const RollbackSupabase = getSupabase();
        if (RollbackSupabase) {
          for (const item of successfullyUploaded) {
            try {
              console.log(`[STORAGE AUDIT] [ROLLBACK EXECUTED] Removing uploaded orphan file: ${item.bucket} -> ${item.path}`);
              await RollbackSupabase.storage.from(item.bucket).remove([item.path]);
              console.log(`[STORAGE AUDIT] [ROLLBACK EXECUTED] Removed orphan successfully: ${item.path}`);
            } catch (rollbackErr) {
              console.error(`[STORAGE AUDIT] Rollback execution failed for ${item.bucket}/${item.path}:`, rollbackErr);
            }
          }
        }
      }
    } finally {
      setLoading(false);
      setIsUploading(false);
      setProcessingFiles(false);
      isSubmittingRef.current = false;
    }
  };

  const allUploadsComplete = useMemo(() => {
    return Object.values(uploadsState).every(upload => upload.status === 'completed' || upload.progress >= 100);
  }, [uploadsState]);

  console.log({
    isUploading,
    loading,
    processingFiles,
    uploadsState,
    allUploadsComplete
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/95 backdrop-blur-md p-4 overflow-y-auto overflow-x-hidden py-12 md:py-20 text-slate-100">
      <div className="bg-[#08080C] border border-white/5 rounded-[2.5rem] w-full max-w-5xl shadow-[0_32px_64px_-12px_rgba(0,0,0,0.9)] relative overflow-hidden">
        
        {/* Hidden Inputs triggered securely */}
        <div className="hidden" aria-hidden="true">
          <input 
            id="kit-cover-upload-input"
            type="file" 
            accept="image/*" 
            onChange={(e) => {
              if (e.target.files?.[0]) {
                validateAndSetCover(e.target.files[0]);
                e.target.value = ''; 
              }
            }} 
          />
          <input 
            id="kit-zip-upload-input"
            type="file" 
            accept=".zip,.rar,application/zip,application/x-zip-compressed,application/vnd.rar,application/x-rar-compressed" 
            onChange={(e) => {
              if (e.target.files?.[0]) {
                const selectedFile = e.target.files[0];
                const fileExt = selectedFile.name.split('.').pop()?.toLowerCase();
                const allowedMimeTypes = ['application/zip', 'application/x-zip-compressed', 'application/vnd.rar', 'application/x-rar-compressed'];
                
                if (fileExt !== 'zip' && fileExt !== 'rar' && !allowedMimeTypes.includes(selectedFile.type)) {
                  setError('O arquivo do kit deve ser um ficheiro .zip ou .rar');
                  return;
                }
                
                setError(null);
                handleFileChange('zip', selectedFile);
                e.target.value = '';
              }
            }} 
          />
        </div>

        {/* Ambient Glow Orbs */}
        <div className="absolute -top-40 -left-40 w-[450px] h-[450px] bg-gradient-to-tr from-amber-500/10 via-amber-500/5 to-transparent rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute -bottom-40 -right-40 w-[450px] h-[450px] bg-gradient-to-br from-blue-500/10 via-amber-500/5 to-transparent rounded-full blur-[140px] pointer-events-none" />

        {/* Header */}
        <div className="p-6 md:p-8 border-b border-white/[0.04] bg-[#0A0A0E]/80 backdrop-blur-md flex justify-between items-center sticky top-0 z-30">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/10">
                <Package size={22} className="text-black" strokeWidth={2.5} />
              </div>
              <div>
                  <h2 className="text-xl md:text-2xl font-black text-white italic tracking-tight uppercase leading-none">Subir Novo Kit</h2>
                  <p className="text-gray-500 text-[9px] font-black uppercase tracking-widest mt-1">Lança o teu Kit de Baterias ou Presets no Mercado</p>
              </div>
            </div>
            <button 
              onClick={onClose} 
              disabled={loading}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white disabled:opacity-30 transition-all cursor-pointer"
            >
              <X size={20} />
            </button>
        </div>

        {/* Stepper Wizard Indicator */}
        <div className="bg-[#040406] px-6 md:px-8 py-5 border-b border-white/[0.03] flex items-center justify-between overflow-x-auto whitespace-nowrap custom-scrollbar">
          <div className="flex items-center justify-between w-full max-w-4xl mx-auto gap-2 md:gap-4">
            {STEPS.map((s, idx) => {
              const isActive = step === s.number;
              const isCompleted = step > s.number;
              return (
                <React.Fragment key={s.number}>
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => setStep(s.number)}
                    className="flex items-center gap-3 transition-opacity disabled:opacity-50 text-left outline-none cursor-pointer group"
                  >
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs transition-all duration-300 ${
                      isActive ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20 scale-105' : 
                      isCompleted ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' : 
                      'bg-white/[0.03] text-gray-500 border border-white/[0.04] group-hover:border-white/10'
                    }`}>
                      {isCompleted ? <Check size={14} strokeWidth={3} /> : s.number}
                    </div>
                    <div className="hidden sm:block">
                      <p className={`text-[10px] font-black uppercase tracking-wider leading-none ${isActive ? 'text-white' : 'text-gray-500 group-hover:text-gray-400'}`}>{s.name}</p>
                      <p className="text-[8px] text-gray-600 font-bold uppercase tracking-widest mt-1">{s.desc}</p>
                    </div>
                  </button>
                  {idx < STEPS.length - 1 && (
                    <div className={`flex-grow h-[1px] rounded-full min-w-[20px] max-w-[80px] transition-colors duration-300 ${
                      step > s.number ? 'bg-emerald-500/20' : 'bg-white/[0.03]'
                    }`} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Step Contents Container */}
        <div className="p-6 md:p-10 min-h-[480px] relative">
          
          {error && (
            <div className="bg-rose-500/10 text-rose-400 p-5 rounded-2xl border border-rose-500/20 flex items-start gap-4 mb-8 text-left">
              <AlertCircle size={20} className="my-0.5 shrink-0 text-rose-400" />
              <div className="flex-1 min-w-0">
                {error.startsWith('file_size_error:') ? (() => {
                  const parts = error.split(':');
                  const fileName = parts[1] || 'Ficheiro';
                  const currentMB = parts[2] || '0.0';
                  return (
                    <div>
                      <p className="text-xs font-black uppercase tracking-widest text-rose-400 mb-2">
                        Limite de Upload Excedido
                      </p>
                      <p className="text-xs font-bold text-slate-100 mb-3 leading-relaxed">
                        Este ficheiro <span className="text-rose-300">"{fileName}"</span> excede o limite máximo de 50MB permitido atualmente.
                      </p>
                      
                      <div className="bg-black/40 border border-white/5 rounded-xl p-3 mb-4 max-w-sm">
                        <div className="flex justify-between text-[10px] font-black uppercase tracking-wider text-gray-400 mb-1.5">
                          <span>Tamanho Atual</span>
                          <span>Limite Máximo</span>
                        </div>
                        <div className="flex justify-between items-baseline">
                          <span className="text-sm font-black text-rose-400">{currentMB}MB</span>
                          <span className="text-xs font-bold text-gray-500">/ 50MB</span>
                        </div>
                        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mt-2 border border-white/5">
                          <div className="h-full bg-rose-500 rounded-full" style={{ width: '100%' }} />
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-3">
                        <p className="text-[10px] font-black uppercase tracking-widest text-[#5865F2] mb-2">
                          Recomendações do Batukada:
                        </p>
                        <ul className="space-y-1.5 text-[11px] font-bold text-gray-400">
                          <li className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                            Utilizar ZIP comprimido com compressão máxima
                          </li>
                          <li className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                            Otimizar stems (converter de WAV 32-bit para 24-bit ou 16-bit)
                          </li>
                          <li className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                            Remover ficheiros desnecessários do ficheiro compactado
                          </li>
                        </ul>
                      </div>
                    </div>
                  );
                })() : (
                  <>
                    <p className="text-xs font-black uppercase tracking-wider mb-0.5">Falha de Validação</p>
                    <p className="text-xs font-medium text-rose-300/80 leading-relaxed">{error}</p>
                  </>
                )}
              </div>
            </div>
          )}

          {/* REAL TIME UPLOADING OVERLAY */}
          {loading && (
            <div className="absolute inset-0 bg-[#08080C]/98 backdrop-blur-md z-40 flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-300">
              <div className="relative mb-8">
                <span className="absolute inset-0 rounded-full bg-amber-500/10 scale-150 animate-ping duration-[3s]" />
                <div className="w-16 h-16 rounded-[1.5rem] bg-gradient-to-br from-[#5865F2]/20 to-amber-500/20 border border-[#5865F2]/30 flex items-center justify-center relative shadow-2xl">
                  <Upload className="text-amber-400 animate-bounce" size={24} />
                </div>
              </div>

              <h3 className="text-xl font-black text-white uppercase italic tracking-tight">Portal de Transferência Ativo</h3>
              <p className="text-gray-400 text-xs font-semibold tracking-wider max-w-sm mt-2 mb-8 leading-relaxed">
                Estamos a carregar e a processar o seu kit de som na nossa infraestrutura descentralizada em tempo real. Não feche o navegador!
              </p>

              {/* Dynamic Progress List */}
              <div className="w-full max-w-md space-y-4">
                {[
                  { key: 'cover', icon: ImageIcon, name: 'Capa do Kit' },
                  { key: 'zip', icon: FolderArchive, name: 'Arquivo do Kit (ZIP/RAR)' }
                ].map((item) => {
                  const state = uploadsState[item.key as 'cover' | 'zip'];
                  const percent = state.progress;
                  const isUploading = state.status === 'uploading';
                  const isDone = state.status === 'completed';
                  return (
                    <div key={item.key} className="space-y-3.5 text-left bg-white/[0.01] border border-white/[0.04] p-5 rounded-[1.8rem] shadow-xl">
                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-wider">
                        <span className={`flex items-center gap-2 ${isDone ? 'text-emerald-400' : isUploading ? 'text-amber-400' : 'text-gray-500'}`}>
                          <item.icon size={14} className={isUploading ? "animate-pulse" : ""} />
                          {item.name}
                        </span>
                        <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black tracking-widest ${
                          isDone ? 'bg-emerald-500/10 text-emerald-400' : 
                          isUploading ? 'bg-amber-500/10 text-amber-500' : 
                          'bg-white/5 text-gray-500'
                        }`}>
                          {isDone ? 'COMPLETADO' : isUploading ? `${state.stageMessage || 'A ENVIAR'} ${percent}%` : 'EM ESPERA'}
                        </span>
                      </div>

                      {/* Display live upload details when uploading */}
                      {isUploading && (
                        <div className="grid grid-cols-2 gap-y-1.5 gap-x-4 text-[10px] font-mono text-gray-400 bg-black/30 p-2.5 rounded-xl border border-white/[0.03]">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Velocidade:</span> 
                            <span className="text-ash-50 font-semibold">{state.speed || '---'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Previsão:</span> 
                            <span className="text-ash-50 font-semibold">{state.timeLeft || 'A calcular...'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Enviado:</span> 
                            <span className="text-ash-50 font-semibold">{state.uploadedSize || '0 MB'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Tamanho:</span> 
                            <span className="text-ash-50 font-semibold">{state.totalSize || '---'}</span>
                          </div>
                        </div>
                      )}

                      {/* If done, show size */}
                      {isDone && state.totalSize && (
                        <p className="text-[10px] font-mono text-gray-500 mt-1">
                          Tamanho Final: <span className="text-emerald-400 font-black">{state.totalSize}</span>
                        </p>
                      )}

                      <div className="h-2 w-full bg-white/[0.02] border border-white/[0.04] rounded-full overflow-hidden relative">
                        <div 
                          className={`h-full transition-all duration-300 rounded-full ${
                            isDone ? 'bg-gradient-to-r from-emerald-500 to-teal-500 shadow-[0_0_12px_rgba(16,185,129,0.4)]' : 
                            isUploading ? 'bg-gradient-to-r from-[#5865F2] to-amber-500 shadow-[0_0_12px_rgba(88,101,242,0.4)] animate-pulse' : 
                            'bg-transparent'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 1: FILE MEDIA COMPONENT */}
          {step === 1 && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="space-y-8 animate-in fade-in"
            >
              <div className="text-center md:text-left">
                <h3 className="text-lg font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                  <Upload size={18} className="text-amber-500" />
                  Passo 1: Ficheiros & Capa do Kit
                </h3>
                <p className="text-gray-500 text-xs font-semibold mt-1">Carrega a arte e o arquivo compactado contendo todos os samples do teu kit.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Capa Upload Div (Left Span 5) */}
                <div className="md:col-span-   md:col-span-5 space-y-4">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] block">
                    Capa do Kit (Quadrada 1:1) <span className="text-amber-500">*</span>
                  </label>
                  
                  <div 
                    onDragOver={(e) => handleDrag(e, 'cover', true)}
                    onDragLeave={(e) => handleDrag(e, 'cover', false)}
                    onDrop={(e) => handleDrop(e, 'cover')}
                    className={`relative aspect-square border-2 border-dashed rounded-[2rem] flex flex-col items-center justify-center transition-all overflow-hidden ${
                      uploadsState.cover.file 
                        ? 'border-emerald-500/20 bg-emerald-500/[0.01]' 
                        : dragActive.cover 
                          ? 'border-amber-500 bg-amber-500/5' 
                          : 'border-white/5 hover:border-amber-500/30 bg-white/[0.01]'
                    }`}
                  >
                    {uploadsState.cover.file && coverPreviewUrl ? (
                      <div className="relative w-full h-full group">
                        <img src={coverPreviewUrl} alt="Preview da Capa" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                          <label htmlFor="kit-cover-upload-input" className="px-5 py-2.5 bg-white text-black text-[10px] font-black uppercase tracking-widest rounded-xl hover:scale-105 active:scale-95 transition-transform cursor-pointer">
                            Substituir Capa
                          </label>
                        </div>
                        
                        <button 
                          type="button"
                          onClick={() => removeFile('cover')}
                          className="absolute top-4 right-4 w-9 h-9 bg-rose-500 text-white rounded-xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all shadow-lg"
                        >
                          <Trash2 size={16} />
                        </button>

                        <div className="absolute bottom-4 left-4 bg-emerald-500/90 text-black text-[8px] font-black px-2.5 py-1 uppercase tracking-widest rounded-full flex items-center gap-1">
                          <Check size={10} strokeWidth={3} />
                          Arte Pronta
                        </div>
                      </div>
                    ) : (
                      <label htmlFor="kit-cover-upload-input" className="flex flex-col items-center justify-center p-8 w-full h-full cursor-pointer text-center group">
                        <div className="w-14 h-14 rounded-2xl bg-white/[0.02] border border-white/[0.05] flex items-center justify-center group-hover:bg-amber-500 group-hover:text-[#0C0C12] transition-colors mb-4 text-gray-500">
                          <Upload size={22} className="group-hover:animate-bounce" />
                        </div>
                        <span className="text-xs font-black text-white uppercase tracking-wider">Carregar Capa</span>
                        <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest mt-2 max-w-[180px] leading-relaxed">
                          Arraste a capa do kit JPEG/PNG quadrada aqui ou clique.
                        </span>
                      </label>
                    )}
                  </div>
                           {/* ZIP/RAR File (Right Span 7) */}
                <div className="md:col-span-7 space-y-5">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] block">
                    Ficheiro Principal do Kit (.ZIP / .RAR) <span className="text-amber-500">*</span>
                  </label>

                  <div 
                    onDragOver={(e) => handleDrag(e, 'zip', true)}
                    onDragLeave={(e) => handleDrag(e, 'zip', false)}
                    onDrop={(e) => handleDrop(e, 'zip')}
                    className={`relative border-2 border-dashed rounded-[2rem] p-8 flex flex-col items-center justify-center text-center transition-all ${
                      uploadsState.zip.file 
                        ? 'bg-slate-900/[0.08] border-emerald-500/20 py-10' 
                        : dragActive.zip 
                          ? 'border-amber-500 bg-amber-500/[0.02]' 
                          : 'bg-white/[0.01] border-white/5 hover:border-amber-500/30'
                    }`}
                  >
                    {uploadsState.zip.file ? (
                      <div className="flex flex-col items-center gap-4">
                        <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                          <FolderArchive size={32} strokeWidth={2} />
                        </div>
                        <div>
                          <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Ficheiro Selecionado</p>
                          <p className="text-sm font-black text-white uppercase mt-1 break-all px-4">{uploadsState.zip.file.name}</p>
                          <p className="text-[10px] text-[#5865F2] font-black uppercase tracking-widest mt-1">{(uploadsState.zip.file!.size / (1024 * 1024)).toFixed(1)}MB / 50MB</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFile('zip')}
                          className="px-4 py-2 bg-rose-500/10 text-rose-400 hover:bg-rose-500 hover:text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all"
                        >
                          Remover Arquivo
                        </button>
                      </div>
                    ) : (
                      <label htmlFor="kit-zip-upload-input" className="cursor-pointer flex flex-col items-center justify-center w-full group py-6">
                        <div className="w-14 h-14 rounded-2xl bg-white/[0.02] border border-white/[0.05] text-gray-400 group-hover:bg-amber-500 group-hover:text-black flex items-center justify-center transition-colors mb-4 shrink-0">
                          <FolderArchive size={24} className="group-hover:animate-bounce" />
                        </div>
                        <span className="text-xs font-black text-white uppercase tracking-wider group-hover:text-amber-400 transition-colors">Carregar Ficheiro ZIP ou RAR</span>
                        <span className="text-[8px] font-black bg-white/5 text-gray-400 uppercase tracking-widest px-2.5 py-0.5 rounded border border-white/5 mt-2">Até 2GB • ZIP ou RAR</span>
                        <p className="text-[9px] text-gray-500 font-semibold leading-relaxed mt-2 max-w-sm">Arraste o arquivo do drumkit/samples compactado (.zip ou .rar) aqui para anexar.</p>
                      </label>
                    )}
                  </div>
                </div>          </div>

              </div>
            </motion.div>
          )}

          {/* STEP 2: METADATA & CONTENT DESCRIPTORS */}
          {step === 2 && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="space-y-8 animate-in fade-in"
            >
              <div className="text-center md:text-left">
                <h3 className="text-lg font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                  <Activity size={18} className="text-amber-500" />
                  Passo 2: Metadados & Caracterização do Kit
                </h3>
                <p className="text-gray-500 text-xs font-semibold mt-1">Configura os metadados corretos para ajudar produtores a encontrar o teu kit de samples no mercado.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Visual Fields on Left */}
                <div className="space-y-5">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                      Título Oficial de Kit <span className="text-amber-500">*</span>
                    </label>
                    <input 
                      type="text"
                      className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 text-sm font-bold text-white placeholder:text-gray-700 focus:border-amber-500/50 outline-none transition-all uppercase" 
                      placeholder="Ex: ANGOLA DRUM KIT VOL.1"
                      value={title} 
                      onChange={e => setTitle(e.target.value.toUpperCase())} 
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                        Categoria <span className="text-amber-500">*</span>
                      </label>
                      <select 
                        className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 text-sm font-black text-white focus:border-amber-500/50 outline-none appearance-none" 
                        value={category} 
                        onChange={e => setCategory(e.target.value)}
                      >
                        <option value="drum-kit">Drum Kit</option>
                        <option value="loop-kit">Loop Kit</option>
                        <option value="sample-pack">Sample Pack</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                        Gênero Principal
                      </label>
                      <GenreSelect 
                        value={genre} 
                        onChange={setGenre} 
                        placeholder="Selecione o Gênero" 
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                      Descrição Detalhada <span className="text-amber-500">*</span>
                    </label>
                    <textarea 
                      className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 text-sm font-medium text-white placeholder:text-gray-700 focus:border-amber-500/50 outline-none h-32 transition-all resize-none" 
                      placeholder="Indique o que contém o seu kit (Ex: 20 kicks, 15 loops de percussão, midi files incluídos)..."
                      value={description} 
                      onChange={e => setDescription(e.target.value)} 
                    />
                  </div>
                </div>

                {/* Right Column: Contents list checkboxes & Tags */}
                <div className="space-y-6">
                  {/* Contents Category Select checkboxes */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 px-1">
                      <List size={12} className="text-amber-500" />
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">O que está incluído no Kit? <span className="text-amber-500">*</span></label>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {CONTENT_OPTIONS.map(option => {
                        const isChecked = contents.includes(option);
                        return (
                          <button
                            key={option}
                            type="button"
                            onClick={() => toggleContent(option)}
                            className={`px-4 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                              isChecked
                                ? 'bg-amber-500/10 border-amber-500 text-amber-500 shadow-lg shadow-amber-500/10'
                                : 'bg-white/5 border-white/10 text-gray-500 hover:border-white/20'
                            }`}
                          >
                            {option}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Tags component */}
                  <div className="space-y-3 pt-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] ml-1">
                      Tags Descritivas (Até 3) <span className="text-amber-500">*</span>
                    </label>
                    <div className="bg-[#111116] border border-white/5 rounded-2xl p-4 space-y-3 focus-within:border-amber-500/50 transition-colors">
                      <div className="flex flex-wrap gap-2">
                        {tags.map(t => (
                          <span key={t} className="px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 animate-in scale-in">
                            {t}
                            <button type="button" onClick={() => removeTag(t)} className="text-amber-500 hover:text-white">
                              <X size={10} strokeWidth={3} />
                            </button>
                          </span>
                        ))}
                        {tags.length === 0 && (
                          <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest py-1.5 px-1">Nenhuma tag inserida</span>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          disabled={tags.length >= 3}
                          className="flex-grow bg-transparent text-xs font-bold text-white placeholder:text-gray-700 outline-none disabled:opacity-20"
                          placeholder={tags.length >= 3 ? 'Limite de tags atingido' : 'Adicione uma tag (Enter ou Clique +)'}
                          value={tagInput}
                          onChange={e => setTagInput(e.target.value)}
                          onKeyDown={e => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addTag();
                            }
                          }}
                        />
                        <button 
                          type="button"
                          disabled={tags.length >= 3 || !tagInput.trim()}
                          onClick={() => addTag()}
                          className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center disabled:opacity-35 transition-colors"
                        >
                          <ChevronRight size={16} />
                        </button>
                      </div>
                    </div>

                    {/* Sugestões de tags */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {SUGGESTED_TAGS.map(st => {
                        const exists = tags.includes(st);
                        return (
                          <button
                            key={st}
                            type="button"
                            disabled={exists || tags.length >= 3}
                            onClick={() => addTag(st)}
                            className="px-2 py-1 rounded bg-white/[0.02] border border-white/5 hover:bg-white/5 disabled:opacity-20 text-[8px] font-bold text-gray-500 uppercase tracking-widest transition-colors"
                          >
                            +{st}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                </div>

              </div>
            </motion.div>
          )}

          {/* STEP 3: PRICING DEFINITION */}
          {step === 3 && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="space-y-8 animate-in fade-in animate-duration-500"
            >
              <div className="text-center md:text-left">
                <h3 className="text-lg font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                  <Coins size={18} className="text-amber-500" />
                  Passo 3: Precificação & Condições de Royalty
                </h3>
                <p className="text-gray-500 text-xs font-semibold mt-1">Insira o valor em Kwanzas que cobrará no kit de samples e loops.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Left Side: Pricing explanation card (Span 6) */}
                <div className="md:col-span-6 space-y-4">
                  <div className="bg-[#12121A]/80 border border-white/5 rounded-[2.2rem] p-6 space-y-6 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
                    
                    <div>
                      <span className="text-[8px] font-black text-amber-500 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-md uppercase tracking-wider">Distribuição Marketplace</span>
                      <h4 className="text-lg font-black text-white uppercase italic tracking-tight mt-3">Licença Comercial de Samples</h4>
                      <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                        Ao disponibilizar o seu kit de samples, os compradores recebem o direito sem royalties para loops e melodias incluídas, impulsionando a partilha e licenciamento na infraestrutura de venda rápida da Batukada.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-xs font-bold text-gray-300">
                        <Check size={14} className="text-emerald-400" strokeWidth={3} />
                        Royalty-Free completo para Vendas Menores
                      </div>
                      <div className="flex items-center gap-2 text-xs font-bold text-gray-300">
                        <Check size={14} className="text-emerald-400" strokeWidth={3} />
                        Direitos de Sync em Vídeos & Rádios locais
                      </div>
                      <div className="flex items-center gap-2 text-xs font-bold text-gray-300">
                        <Check size={14} className="text-emerald-400" strokeWidth={3} />
                        Retenção de 90% do pagamento no seu portfólio
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Side: Setup value (Span 6) or Free Download callout */}
                <div className="md:col-span-6 space-y-6 bg-white/[0.01] border border-white/5 p-6 rounded-[2.2rem]">
                  {!isFreeDownload ? (
                    <>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest block pl-1">
                          Definir Valor de Venda (Kz) <span className="text-amber-500">*</span>
                        </label>
                        <div className="relative">
                          <input 
                            type="number"
                            className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 pl-12 text-sm font-black text-white focus:border-amber-500/50 outline-none transition-all placeholder:text-gray-500" 
                            placeholder="Ex: 5000"
                            value={price} 
                            onChange={e => setPrice(e.target.value)} 
                          />
                          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[11px] font-black text-gray-600">Kz</span>
                        </div>
                        <p className="text-[8.5px] text-gray-500 font-bold uppercase tracking-widest text-left pl-1 mt-1 leading-relaxed">
                          Recomendado: ~5.000 Kz para drumkits standard.
                        </p>
                      </div>

                      <div className="pt-4 border-t border-white/[0.04] flex items-start gap-2.5 text-zinc-400">
                        <Lock size={14} className="text-amber-500 shrink-0 mt-0.5" />
                        <p className="text-[9px] font-medium leading-relaxed uppercase tracking-wide">
                          O preço inserido aqui é único para descarregamento ilimitado. O processamento de pagamentos locais ou bancários será automaticamente deduzido de forma limpa.
                        </p>
                      </div>
                    </>
                  ) : (
                    <div className="space-y-4">
                      <div className="p-4 bg-amber-500/5 border border-amber-500/10 rounded-2xl text-center">
                        <Coins size={28} className="text-amber-500 mx-auto mb-2 animate-pulse" />
                        <h4 className="text-xs font-black text-white uppercase tracking-wider">Distribuição Gratuita Ativa</h4>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Este kit será disponibilizado gratuitamente.</p>
                      </div>
                      <div className="pt-4 border-t border-white/[0.04] flex items-start gap-2.5 text-zinc-400">
                        <Download size={14} className="text-amber-500 shrink-0 mt-0.5" />
                        <p className="text-[9px] font-medium leading-relaxed uppercase tracking-wide">
                          Os utilizadores necessitarão de cumprir os requisitos selecionados abaixo para obter este kit, estimulando o crescimento da sua rede social e base de emails.
                        </p>
                      </div>
                    </div>
                  )}
                </div>

              </div>

              {/* Opções de Download Gratuito (Estilo BeatStars) */}
              <div className="mt-8 border-t border-white/[0.04] pt-8 space-y-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-500/10 text-amber-500 rounded-lg">
                    <Download size={18} />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white uppercase italic tracking-wider">Download Gratuito (Estilo BeatStars)</h4>
                    <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-widest mt-0.5">Disponibilize este kit gratuitamente em troca de engagement ou contacto do utilizador</p>
                  </div>
                </div>

                <div className="bg-white/[0.01] border border-white/5 rounded-[2rem] p-6 space-y-6">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <input 
                      type="checkbox"
                      checked={isFreeDownload}
                      onChange={(e) => {
                        setIsFreeDownload(e.target.checked);
                        if (!e.target.checked) {
                          setFreeDownloadRequiresFollow(false);
                          setFreeDownloadRequiresComment(false);
                          setFreeDownloadRequiresEmail(false);
                        }
                      }}
                      className="w-5 h-5 rounded border border-white/10 bg-black text-amber-500 focus:ring-0 cursor-pointer"
                    />
                    <div>
                      <span className="text-xs font-black text-white uppercase tracking-wider group-hover:text-amber-500 transition-colors">Permitir Download Gratuito</span>
                      <p className="text-[10px] text-gray-500 font-medium leading-relaxed mt-1">Os utilizadores poderão baixar o kit compactado (.zip ou .rar) gratuitamente.</p>
                    </div>
                  </label>

                  {isFreeDownload && (
                    <div className="border-t border-white/[0.04] pt-6 space-y-4 pl-8">
                      <h5 className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Requisitos para Desbloquear Download</h5>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <label className="flex items-start gap-3 cursor-pointer bg-[#111116] border border-white/5 hover:border-amber-500/30 p-4 rounded-2xl transition-all select-none">
                          <input 
                            type="checkbox"
                            checked={freeDownloadRequiresFollow}
                            onChange={(e) => setFreeDownloadRequiresFollow(e.target.checked)}
                            className="w-4 h-4 rounded border border-white/10 bg-black text-amber-500 mt-0.5"
                          />
                          <div>
                            <span className="text-xs font-bold text-white block">Exigir Follow</span>
                            <span className="text-[8px] text-gray-500 font-black tracking-widest uppercase block mt-1">Seguir produtor</span>
                          </div>
                        </label>

                        <label className="flex items-start gap-3 cursor-pointer bg-[#111116] border border-white/5 hover:border-amber-500/30 p-4 rounded-2xl transition-all select-none">
                          <input 
                            type="checkbox"
                            checked={freeDownloadRequiresComment}
                            onChange={(e) => setFreeDownloadRequiresComment(e.target.checked)}
                            className="w-4 h-4 rounded border border-white/10 bg-black text-amber-500 mt-0.5"
                          />
                          <div>
                            <span className="text-xs font-bold text-white block">Exigir Comentário</span>
                            <span className="text-[8px] text-gray-500 font-black tracking-widest uppercase block mt-1">Fazer feedback</span>
                          </div>
                        </label>

                        <label className="flex items-start gap-3 cursor-pointer bg-[#111116] border border-white/5 hover:border-amber-500/30 p-4 rounded-2xl transition-all select-none">
                          <input 
                            type="checkbox"
                            checked={freeDownloadRequiresEmail}
                            onChange={(e) => setFreeDownloadRequiresEmail(e.target.checked)}
                            className="w-4 h-4 rounded border border-white/10 bg-black text-amber-500 mt-0.5"
                          />
                          <div>
                            <span className="text-xs font-bold text-white block">Exigir Email</span>
                            <span className="text-[8px] text-gray-500 font-black tracking-widest uppercase block mt-1">Fornecer Email</span>
                          </div>
                        </label>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 4: PREVIEW REVIEW & CONFIRM */}
          {step === 4 && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="space-y-8 animate-in fade-in"
            >
              <div className="text-center md:text-left">
                <h3 className="text-lg font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                  <CheckCircle2 size={18} className="text-amber-500" />
                  Passo 4: Verificação Final & Publicação
                </h3>
                <p className="text-gray-500 text-xs font-semibold mt-1">Garante que todas as informações se encontram corretas antes de registar o teu kit.</p>
              </div>

              {/* Grid content review layout */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Column Left: Visual Mock Market Card (Span 5) */}
                <div className="md:col-span-5 space-y-4">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] block">
                    Visualização no Mercado (Pré-Visualização)
                  </label>

                  <div className="bg-[#12121A]/80 border border-white/5 rounded-[2.2rem] p-5 space-y-4 shadow-xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
                    
                    {/* Visual image preview square */}
                    <div className="aspect-square w-full rounded-2xl overflow-hidden relative bg-zinc-900 flex items-center justify-center">
                      {uploadsState.cover.file && coverPreviewUrl ? (
                        <img src={coverPreviewUrl} alt="Capa" className="w-full h-full object-cover" />
                      ) : (
                        <Package size={48} className="text-gray-800" />
                      )}
                      
                      <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-md px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 border border-white/5 text-[9px] font-black uppercase text-amber-400 tracking-wider">
                        {category === 'drum-kit' ? 'Drum Kit' : category === 'loop-kit' ? 'Loop Kit' : category === 'sample-pack' ? 'Sample Pack' : (category || 'Drum Kit')}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-md font-black text-white truncate italic uppercase tracking-tight">{title || 'Título do seu Kit'}</h4>
                        <span className="text-[9px] font-black bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded uppercase">{genre || 'Gênero'}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-gray-500 font-bold uppercase tracking-wider mt-1">
                        <span>{user?.email?.split('@')[0] || 'Produtor'}</span>
                        <span className="text-amber-400 font-black text-xs">{isFreeDownload ? 'GRÁTIS' : (price ? `${Number(price).toLocaleString('pt-AO')} Kz` : '0 Kz')}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Column Right: Review details list (Span 7) */}
                <div className="md:col-span-7 space-y-6">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] block">
                    Resumo Técnico dos Metadados
                  </label>

                  <div className="bg-white/[0.01] border border-white/5 rounded-[2rem] p-6 space-y-6 relative overflow-hidden">
                    <div className="grid grid-cols-2 gap-y-5 gap-x-4 border-b border-white/[0.04] pb-6">
                      <div>
                        <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest leading-none">Título do Kit</p>
                        <p className="text-xs font-black text-white uppercase mt-1 truncate">{title || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest leading-none">Categoria</p>
                        <p className="text-xs font-black text-amber-500 uppercase mt-1">{category === 'drum-kit' ? 'Drum Kit' : category === 'loop-kit' ? 'Loop Kit' : category === 'sample-pack' ? 'Sample Pack' : (category || 'Drum Kit')}</p>
                      </div>
                      <div>
                        <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest leading-none">Gênero Escrito</p>
                        <p className="text-xs font-black text-white uppercase mt-1">{genre || 'All Style'}</p>
                      </div>
                      <div>
                        <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest leading-none">Preço Cobrado</p>
                        <p className="text-xs font-black text-white uppercase mt-1">{isFreeDownload ? 'GRÁTIS (Download Grátis Directo)' : (price ? `${Number(price).toLocaleString('pt-AO')} Kz` : '0 Kz')}</p>
                      </div>
                    </div>

                    <div className="border-b border-white/[0.04] pb-6 space-y-2">
                      <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest leading-none">Conteúdo Compactado (ZIP/RAR)</p>
                      <div className="flex items-center gap-2 px-3 py-2 bg-white/[0.02] border border-white/5 rounded-xl text-xs font-bold text-gray-300">
                        <FolderArchive size={14} className="text-amber-500 shrink-0" />
                        <span className="truncate">{uploadsState.zip.file?.name || 'kit.zip'}</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest leading-none">Elementos do Kit Selecionados</p>
                      <div className="flex flex-wrap gap-1.5">
                        {contents.map(c => (
                          <span key={c} className="px-2.5 py-1 rounded bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[8px] font-black uppercase tracking-widest">
                            {c}
                          </span>
                        ))}
                        {contents.length === 0 && (
                          <span className="text-[9px] font-bold uppercase tracking-widest italic text-gray-500">Nenhum elemento selecionado</span>
                        )}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-white/[0.04] flex items-start gap-2.5 text-zinc-400">
                      <Lock size={12} className="text-amber-500 shrink-0 mt-0.5" />
                      <p className="text-[8.5px] font-medium leading-relaxed uppercase tracking-wide">
                        Ao publicar, o seu kit ficará imediatamente acessível e visível na aba de Drum Kits. Receba pagamentos automáticos diretamente no seu portfólio de vendas.
                      </p>
                    </div>

                  </div>
                </div>

              </div>
            </motion.div>
          )}

        </div>

        {/* Footer Navigation bar */}
        <footer className="p-6 md:p-8 border-t border-white/[0.04] bg-[#0A0A0E]/80 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-4 sticky bottom-0 z-30 font-sans">
          
          {/* Validation indicators */}
          <div className="text-center sm:text-left">
            {step === 1 && !step1Completeness.complete && (
              <p className="text-[9px] font-bold text-amber-500/80 uppercase tracking-wider">
                Faltam: {step1Completeness.missing.join(', ')}
              </p>
            )}
            {step === 2 && !step2Completeness.complete && (
              <p className="text-[9px] font-bold text-amber-500/80 uppercase tracking-wider">
                Faltam: {step2Completeness.missing.join(', ')}
              </p>
            )}
            {step === 3 && !step3Completeness.complete && (
              <p className="text-[9px] font-bold text-amber-500/80 uppercase tracking-wider">
                Defina um preço válido para continuar.
              </p>
            )}
            {step === 4 && (!step1Completeness.complete || !step2Completeness.complete || !step3Completeness.complete) && (
              <p className="text-[9px] font-bold text-rose-400 uppercase tracking-wider">
                Existem campos obrigatórios em falta noutros passos!
              </p>
            )}
            {((step === 1 && step1Completeness.complete) || 
              (step === 2 && step2Completeness.complete) || 
              (step === 3 && step3Completeness.complete)) && (
              <p className="text-[9px] font-bold text-emerald-400 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1">
                <Check size={11} strokeWidth={3} />
                Passo Validado & Completo
              </p>
            )}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto shrink-0 justify-end">
            
            {/* Voltar button */}
            {step > 1 && (
              <button 
                type="button"
                disabled={loading}
                onClick={() => setStep(prev => prev - 1)}
                className="w-1/2 sm:w-auto px-5 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-white/[0.04]"
              >
                <ChevronLeft size={14} strokeWidth={2.5} />
                Anterior
              </button>
            )}

            {/* Proximo / Submit button */}
            {step < 4 ? (
              <button 
                type="button"
                onClick={() => setStep(prev => prev + 1)}
                disabled={
                  (step === 1 && !step1Completeness.complete) || 
                  (step === 3 ? !step3Completeness.complete : false)
                }
                className="w-full sm:w-auto min-w-[130px] px-6 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest bg-white text-black hover:bg-amber-500 hover:text-black hover:scale-[1.02] disabled:opacity-30 disabled:pointer-events-none transition-all flex items-center justify-center gap-1.5 cursor-pointer ml-auto"
              >
                Próximo
                <ChevronRight size={14} strokeWidth={2.5} />
              </button>
            ) : (
              <button 
                type="button"
                onClick={() => handleSubmit()} 
                disabled={loading || !step1Completeness.complete || !step2Completeness.complete || !step3Completeness.complete} 
                className="w-full sm:w-auto min-w-[200px] px-8 py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.14em] bg-amber-500 text-black hover:bg-amber-400 shadow-xl shadow-amber-500/15 hover:scale-[1.04] active:scale-95 disabled:opacity-30 disabled:pointer-events-none transition-all flex items-center justify-center gap-2 cursor-pointer ml-auto"
              >
                Publicar Agora
                <Sparkles size={14} className="animate-pulse" />
              </button>
            )}

          </div>

        </footer>

      </div>
    </div>
  );
}
