import React, { useState, useEffect } from 'react';
import { CreditCard, DollarSign, ArrowUpRight, ArrowDownLeft, Receipt, ShieldCheck, Wallet, Loader2, X, Clock, CheckCircle2, AlertOctagon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getSupabase } from '@/src/lib/supabase';
import { useAuth } from '@/src/context/AuthContext';
import InstagramLoader from '../../InstagramLoader';

export default function Carteira() {
  const [walletState, setWalletState] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [withdrawalRequests, setWithdrawalRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const [bankingInfo, setBankingInfo] = useState<any>(null);
  
  // Withdrawal Form State
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('bank');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const { user } = useAuth();
  const supabase = getSupabase();

  const firstLoadedBalanceRef = React.useRef<any>(null);

  useEffect(() => {
    if (walletState) {
      console.log('WALLET STATE UPDATE:', walletState);
    }
  }, [walletState]);

  const loadData = async () => {
    if (!user || !supabase) return;
    console.time('WALLET LOAD');
    setLoading(true);
    try {
      console.log('CURRENT USER ID:', user.id);

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      console.log('FETCHED PROFILE:', profile);

      let transData: any[] = [];
      try {
        const { data: tData, error: tErr } = await supabase
          .from('wallet_transactions')
          .select('*')
          .eq('producer_id', user.id)
          .order('created_at', { ascending: false })
          .limit(10);
        if (!tErr && tData) {
          transData = tData;
        }
      } catch (e) {
        console.warn("wallet_transactions boundary caught error:", e);
      }

      console.log('WITHDRAWAL TABLE ACCESS');
      const reqsRes = await supabase
        .from('withdrawal_requests')
        .select('*')
        .eq('producer_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      const response = reqsRes;
      const error = reqsRes.error;
      console.log('SUPABASE RESPONSE:', response);
      console.log('SUPABASE ERROR:', error);

      const bankingRes = await supabase
        .from('producer_banking_info')
        .select('*')
        .eq('producer_id', user.id)
        .maybeSingle();

      // Fetch dynamic wallet information safely from wallets table and profiles fallback
      let dbPending = 0;
      let dbAvailable = 0;
      let dbEarned = 0;
      let dbWithdrawn = 0;
      let dbDebt = 0;

      try {
        const { data: wData } = await supabase
          .from('wallets')
          .select('available_balance, pending_balance, total_earned, total_withdrawn')
          .eq('producer_id', user.id)
          .maybeSingle();
        if (wData) {
          dbAvailable = parseFloat(wData.available_balance as any) || 0;
          dbPending = parseFloat(wData.pending_balance as any) || 0;
          dbEarned = parseFloat(wData.total_earned as any) || 0;
          dbWithdrawn = parseFloat(wData.total_withdrawn as any) || 0;
        }
      } catch (e) {
        console.warn("Error querying wallets directly in Carteira:", e);
      }

      try {
        const { data: pWallet } = await supabase
          .from('profiles')
          .select('wallet_pending_balance, wallet_available_balance, wallet_total_withdrawn, wallet_total_earned, wallet_pending_debt')
          .eq('id', user.id)
          .maybeSingle();
        if (pWallet) {
          if (dbAvailable === 0) dbAvailable = parseFloat(pWallet.wallet_available_balance as any) || 0;
          if (dbPending === 0) dbPending = parseFloat(pWallet.wallet_pending_balance as any) || 0;
          if (dbEarned === 0) dbEarned = parseFloat(pWallet.wallet_total_earned as any) || 0;
          if (dbWithdrawn === 0) dbWithdrawn = parseFloat(pWallet.wallet_total_withdrawn as any) || 0;
          dbDebt = parseFloat(pWallet.wallet_pending_debt as any) || 0;
        }
      } catch (e) {
        console.warn("Error querying legacy wallet columns in Carteira:", e);
      }

      const mappedWallet = {
        pending: dbPending !== 0 ? dbPending : (parseFloat((profile as any)?.wallet_pending_balance) || 0),
        available: dbAvailable !== 0 ? dbAvailable : (parseFloat((profile as any)?.wallet_available_balance) || 0),
        earned: dbEarned !== 0 ? dbEarned : (parseFloat((profile as any)?.wallet_total_earned) || 0),
        withdrawn: dbWithdrawn !== 0 ? dbWithdrawn : (parseFloat((profile as any)?.wallet_total_withdrawn) || 0),
        debt: dbDebt !== 0 ? dbDebt : (parseFloat((profile as any)?.wallet_pending_debt) || 0)
      };

      if (firstLoadedBalanceRef.current === null) {
        firstLoadedBalanceRef.current = mappedWallet;
        console.log('INITIAL PROFILE BALANCE:', profile);
      } else {
        const prev = firstLoadedBalanceRef.current;
        if (mappedWallet.available !== prev.available || mappedWallet.pending !== prev.pending) {
          console.log('SECONDARY OVERRIDE DETECTED');
          if (mappedWallet.available === 150000 || profile?.wallet_balance === 150000) {
            console.trace('WALLET OVERRIDE SOURCE');
            mappedWallet.available = prev.available;
            mappedWallet.pending = prev.pending;
          }
        }
      }

      console.trace('WALLET OVERRIDE SOURCE');
      setWalletState(mappedWallet);

      setTransactions(transData);
      setWithdrawalRequests(reqsRes.data || []);
      setBankingInfo(bankingRes.data || null);
      setIsVerified(bankingRes.data?.status === 'verified');
    } catch (e) {
      console.error("Error loading wallet details:", e);
    } finally {
      setLoading(false);
      console.timeEnd('WALLET LOAD');
    }
  };

  useEffect(() => {
    loadData();
  }, [user, supabase]);

  const openWithdrawalModal = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setAmount('');
    setDetails('');
    setIsModalOpen(true);
  };

  const requestWithdrawal = async () => {
    if (!user || !supabase || !amount) return;
    const requestedAmount = parseFloat(amount);
    if (isNaN(requestedAmount) || requestedAmount <= 0) {
      setErrorMsg('Por favor, insira um valor de levantamento válido.');
      return;
    }
    setSubmitting(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    
    try {
      // 1. Fetch latest wallet info to enforce rule:
      // producer can only withdraw if: wallets.available_balance >= requested amount
      let availableBalance = 0;
      let balanceFetched = false;

      try {
        const { data: walletData, error: walletErr } = await supabase
          .from('wallets')
          .select('available_balance')
          .eq('producer_id', user.id)
          .maybeSingle();
        if (walletData && !walletErr) {
          availableBalance = parseFloat(walletData.available_balance as any) || 0;
          balanceFetched = true;
        }
      } catch (err) {
        console.warn("Could not query wallets available balance:", err);
      }

      if (!balanceFetched) {
        // Fallback to legacy profiles table column
        const { data: profile, error: profileErr } = await supabase
          .from('profiles')
          .select('wallet_available_balance')
          .eq('id', user.id)
          .single();

        if (profileErr || !profile) {
          throw new Error('Não foi possível verificar o seu saldo disponível.');
        }

        availableBalance = parseFloat(profile.wallet_available_balance as any) || 0;
      }

      // if insufficient balance: show error
      if (availableBalance < requestedAmount) {
        setErrorMsg('Erro: Saldo insuficiente para realizar este levantamento.');
        setSubmitting(false);
        return;
      }

      const payload = {
        producer_id: user.id,
        amount: requestedAmount,
        status: 'pending',
        method: method,
        details: {
          bank_name: method === 'bank' ? (bankingInfo?.bank_name || 'Transferência Bancária') : 'Unitel Money',
          account_number: details || bankingInfo?.account_number || '',
          full_name: bankingInfo?.full_name || '',
          phone: method === 'unitel_money' ? (details || bankingInfo?.phone || '') : (bankingInfo?.phone || '')
        }
      };

      console.log('CREATING WITHDRAWAL REQUEST');
      console.log('WITHDRAWAL PAYLOAD:', payload);

      const { data, error } = await supabase
        .from('withdrawal_requests')
        .insert(payload)
        .select();

      console.log('WITHDRAWAL INSERT RESPONSE:', data);
      console.log('WITHDRAWAL INSERT ERROR:', error);

      if (error) {
        console.error("[WITHDRAW ERROR]", error);
        setErrorMsg(error.message);
      } else {
        setSuccessMsg('Pedido de levantamento enviado com sucesso! Aguarda a aprovação da administração.');
        
        // Refresh wallet state in background without showing the full screen loader block
        await loadData();
        
        // Modal only closes after a 2-second success screen so the user knows it was successful
        setTimeout(() => {
          setIsModalOpen(false);
          setAmount('');
          setDetails('');
          setSuccessMsg(null);
        }, 2000);
      }
    } catch (err: any) {
      console.error("[WITHDRAW ERROR]", err);
      setErrorMsg('Ocorreu um erro: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const canWithdraw = isVerified || bankingInfo?.status === 'verified' || !!bankingInfo?.account_number || !!bankingInfo?.phone;

  if (loading && !walletState) return <InstagramLoader label="A carregar a tua carteira..." />;

  return (
    <div className="p-6 md:py-8 md:pr-10 md:pl-4 space-y-8 text-white min-h-screen">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#050505] border border-white/5 p-6 rounded-xl hover:border-[#6366f1]/35 transition-all duration-300">
        <div className="flex items-center gap-4">
          <img 
            src="https://i.ibb.co/hF1MD85X/20260523-155411.png" 
            className="w-10 h-10 object-contain filter drop-shadow-[0_2px_8px_rgba(245,158,11,0.25)]" 
            referrerPolicy="no-referrer"
            alt="BATUKADA" 
          />
          <div>
            <h2 className="text-2xl font-black tracking-tighter uppercase mb-0.5">Minha Carteira</h2>
            <p className="text-xs text-gray-400 font-medium">Gere o teu saldo, solicita levantamentos e acompanha o teu histórico.</p>
          </div>
        </div>
      </header>

      {walletState?.debt > 0 && (
        <div className="bg-red-950/40 border border-red-500/20 p-5 rounded-2xl flex items-start gap-4">
          <AlertOctagon className="text-red-500 shrink-0 mt-0.5" size={24} />
          <div>
            <h4 className="font-extrabold text-sm text-red-400">Dívida Pendente de Estorno: {walletState.debt.toLocaleString('pt-AO')} Kz</h4>
            <p className="text-xs text-red-200/80 mt-1">Este valor refere-se a royalties de compras reembolsadas ou contestadas que já haviam sido levantadas. Futuras vendas serão automaticamente retidas até à liquidação total desta dívida.</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Saldo Disponível', value: walletState?.available || 0, icon: Wallet, color: 'text-emerald-500' },
          { label: 'Saldo Pendente', value: walletState?.pending || 0, icon: CreditCard, color: 'text-amber-500' },
          { label: 'Total Ganho', value: walletState?.earned || 0, icon: DollarSign, color: 'text-blue-500' },
          { label: 'Total Levantado', value: walletState?.withdrawn || 0, icon: Receipt, color: 'text-gray-400' },
        ].map((item, i) => (
          <motion.div key={i} whileHover={{ y: -3 }} className="bg-[#050505] border border-white/5 p-6 rounded-xl hover:border-[#6366f1]/35 transition-all duration-300">
            <item.icon className={`${item.color} mb-4`} />
            <p className="text-gray-400 text-sm font-medium">{item.label}</p>
            <h3 className="text-2xl font-black mt-1">{item.value.toLocaleString('pt-AO')} Kz</h3>
          </motion.div>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <motion.button 
            whileTap={{ scale: 0.95 }}
            onClick={() => canWithdraw ? openWithdrawalModal() : alert('Configura e guarda os teus dados bancários nas definições primeiro para verificar a tua conta!')}
            className={`px-8 py-4 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${canWithdraw ? 'bg-orange-600 hover:bg-orange-500 text-white shadow-xl shadow-orange-900/20' : 'bg-gray-800 text-gray-400 cursor-not-allowed'}`}
        >
            <ShieldCheck size={18}/> {canWithdraw ? 'Solicitar Levantamento' : 'Carteira Bloqueada (Configura os dados bancários)'}
        </motion.button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* WALLET TRANSACTIONS */}
        <section className="bg-[#050505] border border-white/5 p-6 rounded-xl space-y-6 hover:border-[#6366f1]/35 transition-all duration-300">
          <h3 className="font-bold flex items-center gap-2 text-lg"><Receipt size={20}/> Histórico de Vendas</h3>
          <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1">
            {transactions.length === 0 ? (
              <p className="text-gray-500 text-xs py-4 text-center">Nenhuma transação registrada.</p>
            ) : (
              transactions.map((t) => {
                const isReversal = t.transaction_type === 'reversal';
                const isCollab = !isReversal && (t.collab_percentage !== undefined && t.collab_percentage !== null 
                  ? true 
                  : (t.transaction_type && t.transaction_type.startsWith('collab_sale:')));
                  
                const percentage = t.collab_percentage !== undefined && t.collab_percentage !== null 
                  ? t.collab_percentage 
                  : (isCollab ? t.transaction_type.split(':')[1] : null);

                const isSale = !isReversal && (t.transaction_type === 'sale' || t.transaction_type === 'release' || isCollab);
                const valueReceived = Number(t.producer_amount !== undefined && t.producer_amount !== null ? t.producer_amount : t.amount);

                return (
                  <div key={t.id} className="flex items-center justify-between p-4 bg-black/40 rounded-xl hover:bg-black/60 transition shadow-[inset_0_1px_1px_rgba(255,255,255,0.02)]">
                    <div className="flex items-center gap-4">
                      <div className={`p-2 rounded-lg ${isSale ? 'bg-green-900/30 text-green-500' : 'bg-red-900/30 text-red-500'}`}>
                          {isSale ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}
                      </div>
                      <div>
                          <p className="font-semibold text-xs text-white flex items-center gap-1.5 flex-wrap">
                            {isReversal ? (
                              <span className="text-red-500 font-bold uppercase tracking-wider text-[10px]">Estorno / Reversão</span>
                            ) : isCollab ? (
                              <>
                                <span className="text-amber-500 font-bold font-sans uppercase tracking-wider text-[10px]">Venda Colaborativa</span>
                                <span className="px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-500 text-[9px] font-black">{percentage}%</span>
                              </>
                            ) : t.transaction_type === 'sale' ? (
                              'Venda de Beat'
                            ) : t.transaction_type === 'release' ? (
                              'Fundo Libertado'
                            ) : (
                              'Levantamento'
                            )}
                          </p>
                          {t.collab_beat_title && (
                            <p className="text-[10px] text-gray-400 font-semibold italic mt-0.5">Beat: {t.collab_beat_title}</p>
                          )}
                          <p className="text-[10px] text-gray-500 mt-0.5">{new Date(t.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <p className={`font-bold font-mono text-xs ${isSale ? 'text-green-500' : 'text-red-500'}`}>
                      {isSale ? '+' : ''}{valueReceived.toLocaleString('pt-AO')} Kz
                    </p>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* WITHDRAWAL REQUESTS */}
        <section className="bg-[#050505] border border-white/5 p-6 rounded-xl space-y-6 hover:border-[#6366f1]/35 transition-all duration-300">
          <h3 className="font-bold flex items-center gap-2 text-lg"><Clock size={20}/> Pedidos de Levantamento</h3>
          <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1">
            {withdrawalRequests.length === 0 ? (
              <p className="text-gray-500 text-xs py-4 text-center">Nenhum pedido de levantamento efetuado.</p>
            ) : (
              withdrawalRequests.map((r) => (
                <div key={r.id} className="flex items-center justify-between p-4 bg-black/40 rounded-xl hover:bg-black/60 transition">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg ${
                      r.status === 'approved' ? 'bg-green-950/45' : r.status === 'rejected' ? 'bg-red-950/45' : 'bg-yellow-950/45'
                    }`}>
                      {r.status === 'approved' ? <CheckCircle2 className="text-green-500" size={16} /> : 
                       r.status === 'rejected' ? <AlertOctagon className="text-red-500" size={16} /> : 
                       <Clock className="text-yellow-500 animate-pulse" size={16} />}
                    </div>
                    <div>
                      <p className="font-bold text-xs">{r.amount.toLocaleString('pt-AO')} Kz</p>
                      <p className="text-[10px] text-gray-400 capitalize">{r.method === 'bank' ? 'Transferência' : 'Unitel Money'} • {new Date(r.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border ${
                    r.status === 'approved' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 
                    r.status === 'rejected' ? 'bg-red-500/10 text-red-500 border-red-500/20' : 
                    'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
                  }`}>
                    {r.status === 'approved' ? 'concluído' : r.status === 'rejected' ? 'rejeitado' : 'pendente'}
                  </span>
                </div>
              ))
            )}
          </div>
        </section>
      </div>

      <AnimatePresence>
      {isModalOpen && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-gray-950 border border-white/[0.08] rounded-2xl w-full max-w-sm p-8 space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold">Solicitar Levantamento</h3>
                  <button onClick={() => !submitting && !successMsg && setIsModalOpen(false)} className={`cursor-pointer text-gray-400 hover:text-white ${(submitting || successMsg) ? 'opacity-30 cursor-not-allowed' : ''}`} disabled={submitting || !!successMsg}><X size={20}/></button>
                </div>

                {errorMsg && (
                  <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold leading-relaxed animate-in fade-in slide-in-from-top-2 flex gap-2 items-center">
                    <span className="shrink-0 p-1 bg-red-500/10 rounded-full inline-block text-[10px] font-bold">!</span>
                    <span>{errorMsg}</span>
                  </div>
                )}

                {successMsg && (
                  <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold leading-relaxed animate-in fade-in slide-in-from-top-2 flex gap-2 items-center">
                    <span className="shrink-0 p-1 bg-emerald-500/10 rounded-full inline-block text-[10px] font-bold">✓</span>
                    <span>{successMsg}</span>
                  </div>
                )}

                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-gray-500 block mb-1.5">Valor do Levantamento (Disponível: {walletState?.available.toLocaleString('pt-AO')} Kz)</label>
                  <input 
                    type="number" 
                    placeholder="Valor (Kz)" 
                    value={amount} 
                    onChange={e => setAmount(e.target.value)} 
                    max={walletState?.available}
                    disabled={submitting || !!successMsg}
                    className="w-full bg-black p-3 rounded-xl border border-white/5 outline-none focus:border-orange-500 text-sm font-medium transition-all disabled:opacity-55"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-gray-500 block mb-1.5">Método de Envio</label>
                  <select 
                    value={method} 
                    onChange={e => setMethod(e.target.value)} 
                    disabled={submitting || !!successMsg}
                    className="w-full bg-black p-3 rounded-xl border border-white/5 outline-none focus:border-orange-500 text-sm font-medium transition-all text-white disabled:opacity-55"
                  >
                      <option value="bank">Transferência Bancária</option>
                      <option value="unitel_money">Unitel Money</option>
                  </select>
                </div>
                <div>
                  <label className="text-[9px] font-black uppercase tracking-widest text-gray-500 block mb-1.5">IBAN de Destino ou N. de Telefone</label>
                  <input 
                    type="text" 
                    placeholder="IBAN ou N. Telefone" 
                    value={details} 
                    onChange={e => setDetails(e.target.value)} 
                    disabled={submitting || !!successMsg}
                    className="w-full bg-black p-3 rounded-xl border border-white/5 outline-none focus:border-orange-500 text-sm font-medium transition-all disabled:opacity-55"
                  />
                </div>
                
                <button 
                  onClick={requestWithdrawal} 
                  disabled={submitting || !!successMsg || !amount || parseFloat(amount) <= 0 || parseFloat(amount) > walletState?.available} 
                  className="w-full mt-4 bg-orange-600 p-3.5 rounded-xl font-black text-xs uppercase tracking-wider hover:bg-orange-500 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-orange-600/20 active:scale-95 flex items-center justify-center gap-2"
                >
                    {submitting ? (
                      <>
                        <Loader2 className="animate-spin" size={16} />
                        <span>A processar...</span>
                      </>
                    ) : successMsg ? (
                      <span>Pedido Enviado!</span>
                    ) : (
                      <span>Confirmar Pedido</span>
                    )}
                </button>
            </motion.div>
        </motion.div>
      )}
      </AnimatePresence>
    </div>
  );
}
