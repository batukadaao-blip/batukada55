import React, { useState, useEffect, useRef } from 'react';
import { User, Lock, Trash2, Save, Camera, CheckCircle, Upload, Loader2, Globe, Instagram, Youtube, Twitter, Mail, Phone, MapPin, Tag } from 'lucide-react';
import { getSupabase, getPublicUrl } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';

const ANGOLA_LOCATIONS = [
  "Bengo",
  "Benguela",
  "Bié",
  "Cabinda",
  "Cuando",
  "Cuando Cubango",
  "Cuanza Norte",
  "Cuanza Sul",
  "Cunene",
  "Huambo",
  "Huíla",
  "Icolo e Bengo",
  "Luanda",
  "Lunda Norte",
  "Lunda Sul",
  "Malanje",
  "Moxico",
  "Moxico Leste",
  "Namibe",
  "Uíge",
  "Zaire"
];

interface Profile {
  artisticName: string;
  city: string;
  phone: string;
  yearsExp: string;
  bio: string;
  profilePhotoUrl?: string;
  bannerPhotoUrl?: string;
  socials: { ig: string; tw: string; tiktok: string; web: string; yt?: string };
  genres?: string[];
  themeAccent?: string;
  username?: string;
}

interface Props {
  profile: Profile;
  setProfile: React.Dispatch<React.SetStateAction<Profile>>;
  hideHeader?: boolean;
}

export default function Settings({ profile, setProfile, hideHeader = false }: Props) {
  const { user, refreshProfile, setProfile: setAuthProfile } = useAuth();
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);

  const [isOpenDrop, setIsOpenDrop] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Load state from props / local input
  const [artisticName, setArtisticName] = useState(profile.artisticName || '');
  const [username, setUsername] = useState(profile.username || '');
  const [city, setCity] = useState(profile.city || '');
  const [phone, setPhone] = useState(profile.phone || '');
  const [yearsExp, setYearsExp] = useState(profile.yearsExp || '0');
  const [bio, setBio] = useState(profile.bio || '');
  const [profilePhotoUrl, setProfilePhotoUrl] = useState(profile.profilePhotoUrl || '');
  const [bannerPhotoUrl, setBannerPhotoUrl] = useState(profile.bannerPhotoUrl || '');

  // Socials
  const [instagram, setInstagram] = useState(profile.socials?.ig || '');
  const [youtube, setYoutube] = useState(profile.socials?.yt || '');
  const [twitter, setTwitter] = useState(profile.socials?.tw || '');
  const [website, setWebsite] = useState(profile.socials?.web || '');

  // Genres & Tag System
  const [genres, setGenres] = useState<string[]>(profile.genres || []);
  const [newGenre, setNewGenre] = useState('');

  // UI state
  const [activeTab, setActiveTab] = useState<'basic' | 'images' | 'socials' | 'genres'>('basic');
  const [notification, setNotification] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Sync state if props change
  useEffect(() => {
    setArtisticName(profile.artisticName || '');
    setUsername(profile.username || '');
    setCity(profile.city || '');
    setPhone(profile.phone || '');
    setYearsExp(profile.yearsExp || '0');
    setBio(profile.bio || '');
    setProfilePhotoUrl(profile.profilePhotoUrl || '');
    setBannerPhotoUrl(profile.bannerPhotoUrl || '');
    setInstagram(profile.socials?.ig || '');
    setYoutube(profile.socials?.yt || '');
    setTwitter(profile.socials?.tw || '');
    setWebsite(profile.socials?.web || '');
    setGenres(profile.genres || []);
  }, [profile]);

  // Clear notification automatically
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  useEffect(() => {
    if (!isOpenDrop) return;
    const handleOutsideClick = (e: MouseEvent) => {
      const container = document.getElementById('producer-province-select-container');
      if (container && !container.contains(e.target as Node)) {
        setIsOpenDrop(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [isOpenDrop]);

  // Handle files
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'banner') => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // Type validation
    if (!file.type.startsWith('image/')) {
      alert('Por favor, escolhe uma imagem válida (PNG, JPG, WEBP).');
      return;
    }

    // Size check
    if (file.size > 5 * 1024 * 1024) {
      alert('A imagem é muito grande. Escolhe um ficheiro menor que 5MB.');
      return;
    }

    const setLoader = type === 'avatar' ? setUploadingAvatar : setUploadingBanner;
    setLoader(true);

    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Supabase client is not active.');

      const filename = `${user.id}/${type}_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
      
      let uploadError = null;
      let publicUrl = '';

      try {
        const { error } = await supabase.storage
          .from('avatars')
          .upload(filename, file, {
            cacheControl: '3600',
            upsert: true
          });
        uploadError = error;
        if (!uploadError) {
          publicUrl = getPublicUrl('avatars', filename);
        }
      } catch (directErr: any) {
        uploadError = directErr;
      }

      // If direct storage upload failed (e.g., due to RLS policies), retry via server-side proxy
      if (uploadError) {
        console.warn('[STORAGE] Direct upload failed in settings, falling back to server-side proxy...', uploadError);
        try {
          const base64Data = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });

          const { data: { session } } = await supabase.auth.getSession();
          const token = session?.access_token;

          const proxyResponse = await fetch('/api/storage/upload', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...(token ? { 'Authorization': `Bearer ${token}` } : {})
            },
            body: JSON.stringify({
              base64Data,
              bucket: 'avatars',
              path: filename,
              contentType: file.type || 'application/octet-stream'
            })
          });

          if (!proxyResponse.ok) {
            const errDetails = await proxyResponse.json().catch(() => ({}));
            throw new Error(errDetails.error || `HTTP ${proxyResponse.status}`);
          }

          const proxyData = await proxyResponse.json();
          publicUrl = proxyData.fileUrl;
        } catch (proxyErr: any) {
          console.error('[STORAGE] Settings proxy upload also failed:', proxyErr);
          throw new Error(proxyErr.message || 'Falha no upload através do proxy e direto.');
        }
      }

      if (type === 'avatar') {
        setProfilePhotoUrl(publicUrl);
        setNotification('Foto de perfil carregada com sucesso!');
      } else {
        setBannerPhotoUrl(publicUrl);
        setNotification('Banner de capa carregado com sucesso!');
      }
    } catch (err: any) {
      console.error('Upload failed:', err);
      alert('Falha ao registar upload: ' + (err.message || err));
    } finally {
      setLoader(false);
    }
  };

  // Genre tags actions
  const handleAddGenre = () => {
    if (!newGenre.trim()) return;
    const clean = newGenre.trim();
    if (genres.includes(clean)) {
      setNewGenre('');
      return;
    }
    setGenres([...genres, clean]);
    setNewGenre('');
  };

  const handleRemoveGenre = (idx: number) => {
    setGenres(genres.filter((_, i) => i !== idx));
  };

  // Form validations
  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!artisticName.trim()) newErrors.artisticName = 'Nome artístico é obrigatório.';
    if (!username.trim()) {
      newErrors.username = 'O username é obrigatório.';
    } else if (username.trim().length < 3) {
      newErrors.username = 'O username deve ter pelo menos 3 caracteres.';
    }
    if (!city.trim()) newErrors.city = 'A cidade / localização é obrigatória.';
    if (!bio.trim()) newErrors.bio = 'Adiciona uma breve descrição profissional.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Save changes to Supabase
  const handleSave = async () => {
    if (!validate()) {
      setActiveTab('basic');
      return;
    }

    if (!user) {
      alert('Inicia sessão para guardar alterações.');
      return;
    }

    setIsSaving(true);
    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Conectividade Supabase indisponível.');

      // Match representation format of profiles & packed phone JSON
      const packedMetadata = JSON.stringify({
        phone: phone,
        bio: bio,
        banner_url: bannerPhotoUrl,
        instagram_url: instagram,
        youtube_url: youtube,
        twitter_url: twitter,
        website_url: website,
        genres: genres,
        years_exp: yearsExp
      });

      const cleanUsername = username.toLowerCase().trim().replace(/[^a-z0-9_.-]/g, '');

      const { error } = await supabase
        .from('profiles')
        .update({
          artistic_name: artisticName,
          display_name: artisticName,
          username: cleanUsername,
          avatar_url: profilePhotoUrl,
          city: city,
          phone: packedMetadata,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) throw error;

      // Invalidate local caches to prompt parent layouts to read freshly from DB
      localStorage.removeItem('artistProfile');
      localStorage.removeItem('producerProfile');
      localStorage.removeItem('user_profile');

      // Executar SELECT imediato da mesma linha
      console.log('PRODUCER SETTINGS: Fetching fresh profile from DB immediately...');
      const { data: freshDbData, error: selectError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (selectError) {
        console.error('PRODUCER SETTINGS: Failed to select fresh profile:', selectError);
      } else if (freshDbData) {
        // Executar setProfile(freshProfile)
        setAuthProfile(freshDbData as any);
      }

      // Notify parent layout context
      const updatedProfileModel: Profile = {
        artisticName,
        city,
        phone,
        yearsExp,
        bio,
        profilePhotoUrl,
        bannerPhotoUrl,
        genres,
        username: cleanUsername,
        socials: {
          ig: instagram,
          tw: twitter,
          yt: youtube,
          web: website,
          tiktok: profile.socials?.tiktok || ''
        }
      };

      setProfile(updatedProfileModel);
      setNotification('Perfil oficial atualizado na base de dados Supabase com sucesso!');

      if (refreshProfile) {
        await refreshProfile().catch(e => console.error("Error refreshing profile in settings save:", e));
      }

      // Also trigger a global event so that other components instantly refresh their dynamic stats/cache
      window.dispatchEvent(new CustomEvent('profileUpdated', { detail: updatedProfileModel }));

    } catch (err: any) {
      console.error('Failed to save settings:', err);
      alert('Erro do Supabase ao gravar alterações: ' + (err.message || err));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className={hideHeader ? "space-y-6 relative" : "p-6 md:p-10 space-y-8 max-w-4xl relative"}>
      {notification && (
        <div className="fixed top-20 right-8 bg-emerald-600 text-white px-6 py-3 rounded-xl shadow-lg flex items-center gap-2 z-50 animate-fade-in-down border border-white/10 font-medium">
          <CheckCircle size={18} />
          <span className="text-xs">{notification}</span>
        </div>
      )}

      {/* Title */}
      {!hideHeader && (
        <header>
          <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter">Definições do Perfil</h2>
          <p className="text-gray-400 font-medium mt-1 text-sm">Atualiza os dados públicos do teu estúdio profissional.</p>
        </header>
      )}

      {/* Tabs list */}
      <div className="flex border-b border-white/5 p-1 gap-1.5 overflow-x-auto scrollbar-none">
        {[
          { id: 'basic', label: 'Info Básica', icon: User },
          { id: 'images', label: 'Imagens (Avatar/Banner)', icon: Camera },
          { id: 'socials', label: 'Redes Sociais', icon: Globe },
          { id: 'genres', label: 'Géneros & Tags', icon: Tag }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`flex items-center gap-2 px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
              activeTab === t.id 
                ? 'bg-amber-500 text-black font-extrabold shadow-md' 
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <t.icon size={13} />
            {t.label}
          </button>
        ))}
      </div>

      {/* RENDER ACTIVE TAB */}
      <div className="space-y-6">
        
        {/* TAB 1: BASIC INFO */}
        {activeTab === 'basic' && (
          <div className="space-y-6">
            <h3 className="text-sm font-black uppercase tracking-widest text-amber-500 border-b border-white/5 pb-2">Informação Oficial</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Nome Artístico / Exibição</label>
                <input 
                  type="text"
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
                  value={artisticName}
                  onChange={e => setArtisticName(e.target.value)}
                  placeholder="Ex: Jay M Beats"
                />
                {errors.artisticName && <p className="text-red-500 text-xs mt-1.5 font-bold">{errors.artisticName}</p>}
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Username / Link do Perfil (@)</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-[15px] text-xs font-black text-gray-600 pointer-events-none">@</span>
                  <input 
                    type="text"
                    className="w-full bg-[#06060A] border border-white/5 rounded-xl py-3.5 pl-8 pr-4 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700 font-mono tracking-wider lowercase"
                    value={username}
                    onChange={e => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_.-]/g, ''))}
                    placeholder="ex: jaymbeats"
                  />
                </div>
                {errors.username && <p className="text-red-500 text-xs mt-1.5 font-bold">{errors.username}</p>}
              </div>

              <div id="producer-province-select-container" className="relative">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Localização (Província - Angola)</label>
                <div className="relative">
                  <MapPin className="absolute left-3.5 top-[15px] text-gray-600 z-10" size={14} />
                  <button
                    type="button"
                    onClick={() => setIsOpenDrop(!isOpenDrop)}
                    className="w-full bg-[#06060A] border border-white/5 rounded-xl py-3.5 pl-10 pr-10 text-xs font-medium text-white text-left outline-none transition-all hover:bg-white/[0.04] focus:border-amber-500 active:scale-[0.99]"
                  >
                    {city || "Selecionar Província"}
                  </button>
                  <div className="absolute right-3.5 top-[15px] pointer-events-none text-gray-500">
                    <svg className={`w-4 h-4 transition-transform duration-200 ${isOpenDrop ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>

                  {isOpenDrop && (
                    <div className="absolute left-0 right-0 mt-2 bg-[#0c0c14] border border-white/10 rounded-xl overflow-hidden shadow-2xl z-50 animate-in fade-in slide-in-from-top-2 duration-200">
                      <div className="p-2 border-b border-white/5">
                        <input
                          type="text"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="w-full bg-white/[0.03] border border-white/5 rounded-lg py-2 px-3 text-xs text-white focus:border-amber-500 outline-none transition-all"
                          placeholder="Pesquisar província..."
                          onClick={(e) => e.stopPropagation()}
                        />
                      </div>
                      <div className="max-h-48 overflow-y-auto divide-y divide-white/[0.02] scrollbar-thin scrollbar-thumb-white/10 select-none">
                        {ANGOLA_LOCATIONS.filter(prov => prov.toLowerCase().includes(searchTerm.toLowerCase())).length === 0 ? (
                          <div className="p-3 text-xs text-gray-500 text-center">Nenhuma província encontrada</div>
                        ) : (
                          ANGOLA_LOCATIONS.filter(prov => prov.toLowerCase().includes(searchTerm.toLowerCase())).map((prov) => {
                            const valueStr = `${prov}, Angola`;
                            const isSelected = city === valueStr;
                            return (
                              <button
                                key={prov}
                                type="button"
                                onClick={() => {
                                  setCity(valueStr);
                                  setIsOpenDrop(false);
                                  setSearchTerm('');
                                }}
                                className={`w-full text-left px-4 py-2.5 text-xs hover:bg-white/[0.04] transition-colors flex items-center justify-between ${
                                  isSelected ? 'bg-amber-500/15 text-amber-500 font-bold' : 'text-gray-300'
                                }`}
                              >
                                <span>{valueStr}</span>
                                {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]" />}
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>
                  )}
                </div>
                {errors.city && <p className="text-red-500 text-xs mt-1.5 font-bold">{errors.city}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Contacto Telefónico</label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-3.5 text-gray-600" size={14} />
                  <input 
                    type="text"
                    className="w-full bg-[#06060A] border border-white/5 rounded-xl py-3.5 pl-10 pr-4 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="Ex: +244 923 000 000"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Anos de Experiência</label>
                <input 
                  type="number"
                  min="0"
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all"
                  value={yearsExp}
                  onChange={e => setYearsExp(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Biografia do Estúdio / Produtor</label>
              <textarea 
                className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all h-28 placeholder:text-gray-700 leading-relaxed"
                value={bio}
                onChange={e => setBio(e.target.value)}
                placeholder="Introduz uma biografia marcante sobre as tuas produções musicais, conquistas, e parcerias..."
              />
              {errors.bio && <p className="text-red-500 text-xs mt-1.5 font-bold">{errors.bio}</p>}
            </div>
          </div>
        )}

        {/* TAB 2: IMAGES UPDATE */}
        {activeTab === 'images' && (
          <div className="space-y-6">
            <h3 className="text-sm font-black uppercase tracking-widest text-amber-500 border-b border-white/5 pb-2">Identidade Visual</h3>
            
            {/* Avatar block */}
            <div className="bg-white/[0.01] border border-white/5 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-1">
                <h4 className="text-xs font-black text-white uppercase tracking-wider">Foto de Perfil / Avatar</h4>
                <p className="text-[10px] text-gray-500">Recomendado formato quadrado de alta qualidade. JPG, PNG ou WEBP (Max 5MB).</p>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full border border-white/10 overflow-hidden bg-gray-950 flex items-center justify-center shrink-0">
                  {profilePhotoUrl ? (
                    <img src={profilePhotoUrl} alt="Avatar" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-[9px] text-gray-600 font-bold uppercase">Sem foto</span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => avatarInputRef.current?.click()}
                  disabled={uploadingAvatar}
                  className="bg-white/5 border border-white/5 hover:bg-white/10 text-white hover:text-amber-500 px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  {uploadingAvatar ? (
                    <>
                      <Loader2 size={12} className="animate-spin" /> Carregando...
                    </>
                  ) : (
                    <>
                      <Upload size={12} /> Selecionar
                    </>
                  )}
                </button>
                <input 
                  type="file"
                  ref={avatarInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={e => handleFileUpload(e, 'avatar')}
                />
              </div>
            </div>

            {/* Banner block */}
            <div className="bg-white/[0.01] border border-white/5 p-5 rounded-2xl space-y-4">
              <div className="flex justify-between items-center">
                <div className="space-y-1">
                  <h4 className="text-xs font-black text-white uppercase tracking-wider">Cover Banner / Fundo do Canal</h4>
                  <p className="text-[10px] text-gray-500">Formato horizontal retangular largo (Recomendado 1200x400).</p>
                </div>

                <button
                  type="button"
                  onClick={() => bannerInputRef.current?.click()}
                  disabled={uploadingBanner}
                  className="bg-white/5 border border-white/5 hover:bg-white/10 text-white hover:text-amber-500 px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  {uploadingBanner ? (
                    <>
                      <Loader2 size={12} className="animate-spin" /> Carregando...
                    </>
                  ) : (
                    <>
                      <Upload size={12} /> Selecionar
                    </>
                  )}
                </button>
                <input 
                  type="file"
                  ref={bannerInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={e => handleFileUpload(e, 'banner')}
                />
              </div>

              <div className="h-28 rounded-xl overflow-hidden border border-white/10 bg-gray-950 relative flex items-center justify-center">
                {bannerPhotoUrl ? (
                  <img src={bannerPhotoUrl} alt="Preview do Banner" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-[10px] text-gray-600 font-bold uppercase">Sem imagem configurada</span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: SOCIAL CHANNELS */}
        {activeTab === 'socials' && (
          <div className="space-y-6">
            <h3 className="text-sm font-black uppercase tracking-widest text-amber-500 border-b border-white/5 pb-2">Links & Perfis Externos</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 flex items-center gap-1.5 mb-2">
                  <Instagram size={12} className="text-pink-500" /> Instagram
                </label>
                <input 
                  type="text"
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
                  value={instagram}
                  onChange={e => setInstagram(e.target.value)}
                  placeholder="Ex: https://instagram.com/teu_perfil"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 flex items-center gap-1.5 mb-2">
                  <Youtube size={12} className="text-red-500" /> YouTube
                </label>
                <input 
                  type="text"
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
                  value={youtube}
                  onChange={e => setYoutube(e.target.value)}
                  placeholder="Ex: https://youtube.com/c/teu_canal"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 flex items-center gap-1.5 mb-2">
                  <Twitter size={12} className="text-blue-400" /> Twitter / X
                </label>
                <input 
                  type="text"
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
                  value={twitter}
                  onChange={e => setTwitter(e.target.value)}
                  placeholder="Ex: https://twitter.com/teu_perfil"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 flex items-center gap-1.5 mb-2">
                  <Globe size={12} className="text-amber-500" /> Website Oficial
                </label>
                <input 
                  type="text"
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
                  value={website}
                  onChange={e => setWebsite(e.target.value)}
                  placeholder="Ex: https://www.teusite.com"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: GENRES & TAGS */}
        {activeTab === 'genres' && (
          <div className="space-y-6">
            <h3 className="text-sm font-black uppercase tracking-widest text-amber-500 border-b border-white/5 pb-2">Géneros Musicais & Tags</h3>
            <p className="text-xs text-gray-400 leading-relaxed">Adiciona etiquetas com os estilos que melhor definem a tua sonoridade de estúdio (ex: Kizomba, Drill, Semba, Kuduro, Afro House, Trap).</p>
            
            <div className="flex gap-3">
              <div className="relative flex-grow">
                <Tag className="absolute left-3.5 top-3.5 text-gray-600" size={14} />
                <input 
                  type="text"
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl py-3.5 pl-10 pr-4 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
                  value={newGenre}
                  onChange={e => setNewGenre(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddGenre();
                    }
                  }}
                  placeholder="Digita um estilo e prime Enter... (Ex: Semba)"
                />
              </div>

              <button
                type="button"
                onClick={handleAddGenre}
                className="bg-amber-500 hover:bg-amber-400 text-black text-xs font-extrabold uppercase px-6 rounded-xl transition-all cursor-pointer whitespace-nowrap active:scale-95"
              >
                Adicionar
              </button>
            </div>

            <div className="space-y-2 pt-2">
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-500">Estilos Adicionados ({genres.length})</p>
              
              {genres.length === 0 ? (
                <p className="text-xs text-gray-600 italic">Nenhum género configurado de momento.</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {genres.map((g, idx) => (
                    <div key={g} className="bg-white/5 border border-white/5 rounded-xl px-3 py-1.5 flex items-center gap-2 text-xs text-white">
                      <span className="font-semibold">{g}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveGenre(idx)}
                        className="text-gray-500 hover:text-red-400 font-extrabold text-xs inline-block"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="border-t border-white/5 pt-6 flex justify-end gap-3">
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="bg-amber-500 hover:bg-amber-400 text-black px-8 py-3.5 rounded-xl font-black uppercase tracking-widest text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-500/15 disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <Loader2 size={13} className="animate-spin" /> Atualizando...
              </>
            ) : (
              <>
                <Save size={13} /> Guardar Alterações
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
}
