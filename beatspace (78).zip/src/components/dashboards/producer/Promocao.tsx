import React, { useState, useEffect } from 'react';
import { Tag, Plus, Calendar, ToggleLeft, ToggleRight, Trash2, TrendingUp, Sparkles, AlertCircle, RefreshCw, BarChart3, Users, Percent, Check } from 'lucide-react';
import { useAuth } from '../../../context/AuthContext';
import { getSupabase } from '../../../lib/supabase';
import { Promotion, PromotionTarget, Beat } from '../../../types';

export default function Promocao() {
  const { user } = useAuth();
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [producerBeats, setProducerBeats] = useState<Beat[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [isOpenModal, setIsOpenModal] = useState(false);
  const [analytics, setAnalytics] = useState<any>({
    totalCampaigns: 0,
    activeCampaigns: 0,
    totalUsages: 0,
    totalSaved: 0,
    promotionSummary: []
  });

  // Creation Form state
  const [formName, setFormName] = useState('');
  const [formType, setFormType] = useState<'buy_x_get_y'>('buy_x_get_y');
  const [formBuyQty, setFormBuyQty] = useState('2');
  const [formGetQty, setFormGetQty] = useState('1');
  const [formDiscountValue, setFormDiscountValue] = useState('0');
  const [formStartDate, setFormStartDate] = useState('');
  const [formEndDate, setFormEndDate] = useState('');
  const [formApplicability, setFormApplicability] = useState<'all' | 'genre' | 'specific_beats'>('all');
  const [formGenreValue, setFormGenreValue] = useState('');
  const [formSelectedBeats, setFormSelectedBeats] = useState<string[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    if (user?.id) {
      loadAllData();
    }
  }, [user]);

  const loadAllData = async () => {
    if (!user?.id) return;
    setLoading(true);
    try {
      await Promise.all([
        loadPromotions(),
        loadProducerBeats(),
        loadAnalytics()
      ]);
    } catch (e) {
      console.error("Error loading promotions page data:", e);
    } finally {
      setLoading(false);
    }
  };

  const loadPromotions = async () => {
    try {
      const res = await fetch(`/api/promotions?producer_id=${user?.id}`);
      const data = await res.json();
      if (data.success && data.promotions) {
        setPromotions(data.promotions);
      }
    } catch (err) {
      console.error("Failed to load promotions:", err);
    }
  };

  const loadProducerBeats = async () => {
    // Queries beats created by this producer
    const supabase = getSupabase();
    if (!supabase || !user?.id) return;
    try {
      const { data, error } = await supabase
        .from('beats')
        .select('*')
        .eq('producer_id', user.id);
      if (!error && data) {
        setProducerBeats(data as Beat[]);
      }
    } catch (err) {
      console.error("Failed to load beats for selection:", err);
    }
  };

  const loadAnalytics = async () => {
    try {
      const res = await fetch(`/api/promotions/analytics/${user?.id}`);
      const data = await res.json();
      if (data.success && data.stats) {
        setAnalytics(data.stats);
      }
    } catch (err) {
      console.error("Failed to load analytics:", err);
    }
  };

  const handleToggleStatus = async (promoId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'active' ? 'inactive' : 'active';
    setActionLoading(promoId);
    try {
      const res = await fetch(`/api/promotions/${promoId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: nextStatus })
      });
      const data = await res.json();
      if (data.success) {
        setPromotions(prev => prev.map(p => p.id === promoId ? { ...p, status: nextStatus } : p));
        loadAnalytics();
      }
    } catch (err) {
      console.error("Failed to toggle status:", err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeletePromotion = async (promoId: string) => {
    if (!confirm("Tens a certeza que desejas eliminar esta promoção? Esta ação é irreversível.")) return;
    setActionLoading(promoId);
    try {
      const res = await fetch(`/api/promotions/${promoId}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        setPromotions(prev => prev.filter(p => p.id !== promoId));
        loadAnalytics();
      }
    } catch (err) {
      console.error("Failed to delete promotion:", err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleCreatePromotionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!formName.trim()) {
      setErrorMessage("Por favor, introduz um nome para a promoção.");
      return;
    }

    if (formApplicability === 'genre' && !formGenreValue.trim()) {
      setErrorMessage("Por favor, especifica o género da promoção.");
      return;
    }

    if (formApplicability === 'specific_beats' && formSelectedBeats.length === 0) {
      setErrorMessage("Por favor, seleciona pelo menos um beat para associar à promoção.");
      return;
    }

    // Map targets array
    const targets: Omit<PromotionTarget, 'id' | 'promotion_id'>[] = [];
    if (formApplicability === 'genre') {
      targets.push({
        target_type: 'genre',
        target_value: formGenreValue.trim().toLowerCase()
      });
    } else if (formApplicability === 'specific_beats') {
      formSelectedBeats.forEach(id => {
        targets.push({
          target_type: 'beat',
          target_value: id
        });
      });
    } else {
      targets.push({
        target_type: 'all_beats',
        target_value: 'all_beats'
      });
    }

    try {
      const payload = {
        name: formName,
        promo_type: formType,
        buy_qty: parseInt(formBuyQty) || 2,
        get_qty: parseInt(formGetQty) || 1,
        discount_value: parseFloat(formDiscountValue) || 0,
        start_date: formStartDate ? new Date(formStartDate).toISOString() : null,
        end_date: formEndDate ? new Date(formEndDate).toISOString() : null,
        targets
      };

      const res = await fetch('/api/promotions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (data.success && data.promotion) {
        setSuccessMessage("Campanha promocional criada e publicada com sucesso!");
        setFormName('');
        setFormSelectedBeats([]);
        setFormStartDate('');
        setFormEndDate('');
        setFormGenreValue('');
        setFormApplicability('all');
        loadAllData();
        // Delay modal closing
        setTimeout(() => {
          setIsOpenModal(false);
          setSuccessMessage(null);
        }, 1500);
      } else {
        setErrorMessage(data.error || "Erro ao guardar promoção.");
      }
    } catch (err: any) {
      setErrorMessage("Falha de rede ao submeter formulário de promoção.");
    }
  };

  const handleSelectBeatToggle = (beatId: string) => {
    setFormSelectedBeats(prev => {
      if (prev.includes(beatId)) {
        return prev.filter(id => id !== beatId);
      } else {
        return [...prev, beatId];
      }
    });
  };

  // Helper formats
  const formatDateString = (dt: any) => {
    if (!dt) return 'Sem expiração';
    return new Date(dt).toLocaleDateString('pt-AO', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto space-y-10 min-h-screen text-slate-100">
      
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-white/5">
        <div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tight italic flex items-center gap-3">
            <span className="text-[#5865F2]"><Percent size={28} /></span> Campanhas e <span className="text-[#5865F2]">Promoções</span>
          </h1>
          <p className="text-zinc-400 text-xs font-medium tracking-wide mt-1.5 max-w-2xl">
            Aumente o valor do seu carrinho médio configurando a fantástica campanha "Compre 2 Leve 1 Grátis". O motor de descontos avalia automaticamente no checkout.
          </p>
        </div>
        <button
          onClick={() => setIsOpenModal(true)}
          className="px-6 py-4 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-xs font-black uppercase tracking-widest text-white flex items-center justify-center gap-2.5 shadow-lg shadow-[#5865F2]/20 cursor-pointer transition-all hover:-translate-y-0.5"
        >
          <Plus size={16} strokeWidth={3} /> Nova Promoção
        </button>
      </div>

      {/* Analytics Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="p-6 bg-zinc-950/40 border border-white/5 rounded-3xl relative overflow-hidden flex flex-col justify-between h-36">
          <div className="flex items-center justify-between text-zinc-500">
            <span className="text-[10px] font-black uppercase tracking-wider">Campanhas Ativas</span>
            <Tag size={18} className="text-[#5865F2]" />
          </div>
          <div>
            <h3 className="text-3xl font-black text-white tracking-tight">{analytics.activeCampaigns} <span className="text-xs text-zinc-500 font-medium">campanhas</span></h3>
            <p className="text-[8px] text-zinc-500 uppercase tracking-widest mt-1">Total criadas: {analytics.totalCampaigns}</p>
          </div>
        </div>

        <div className="p-6 bg-zinc-950/40 border border-white/5 rounded-3xl relative overflow-hidden flex flex-col justify-between h-36">
          <div className="flex items-center justify-between text-zinc-500">
            <span className="text-[10px] font-black uppercase tracking-wider">Total Utilizações</span>
            <Sparkles size={18} className="text-orange-400" />
          </div>
          <div>
            <h3 className="text-3xl font-black text-white tracking-tight">{analytics.totalUsages} <span className="text-xs text-zinc-500 font-medium">vendas</span></h3>
            <p className="text-[8px] text-zinc-500 uppercase tracking-widest mt-1">Descontos aplicados automaticamente</p>
          </div>
        </div>

        <div className="p-6 bg-zinc-950/40 border border-white/5 rounded-3xl relative overflow-hidden flex flex-col justify-between h-36">
          <div className="flex items-center justify-between text-zinc-500">
            <span className="text-[10px] font-black uppercase tracking-wider">Descontos Concedidos</span>
            <TrendingUp size={18} className="text-green-500" />
          </div>
          <div>
            <h3 className="text-3xl font-black text-white tracking-tight">{analytics.totalSaved} <span className="text-xs text-zinc-500 font-medium">Kz</span></h3>
            <p className="text-[8px] text-zinc-500 uppercase tracking-widest mt-1">Poupança acumulada do cliente</p>
          </div>
        </div>

        <div className="p-6 bg-zinc-950/40 border border-white/5 rounded-3xl relative overflow-hidden flex flex-col justify-between h-36">
          <div className="flex items-center justify-between text-zinc-500">
            <span className="text-[10px] font-black uppercase tracking-wider">Estimativa de Conversão</span>
            <BarChart3 size={18} className="text-purple-400" />
          </div>
          <div>
            <h3 className="text-2xl font-black text-white tracking-tight">
              {analytics.totalCampaigns > 0 ? '18.4%' : '0%'}
            </h3>
            <p className="text-[8px] text-zinc-500 uppercase tracking-widest mt-1">Conversão média de promoções</p>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <RefreshCw size={32} className="text-zinc-600 animate-spin" />
          <p className="text-xs text-zinc-500 font-bold uppercase tracking-widest">A carregar o painel promocional...</p>
        </div>
      ) : promotions.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-zinc-950/20 border border-white/5 border-dashed flex flex-col items-center justify-center">
          <div className="w-16 h-16 rounded-2xl bg-white/[0.02] border border-white/10 flex items-center justify-center mb-6 text-zinc-500">
            <Percent size={24} />
          </div>
          <h3 className="text-lg font-bold text-white uppercase tracking-tight italic">Nenhuma Campanha Criada</h3>
          <p className="text-zinc-500 text-xs font-medium max-w-md mt-2 mb-8 leading-relaxed">
            Ainda não registou nenhuma promoção no Beatspace. Ative campanhas instantâneas para incentivar a compra agregada e libertar beats exclusivos!
          </p>
          <button
            onClick={() => setIsOpenModal(true)}
            className="px-6 py-3.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-black uppercase tracking-widest text-white transition-all cursor-pointer"
          >
            Iniciar Minha Primeira Promoção
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black text-white uppercase tracking-widest italic flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#5865F2] animate-ping" /> Campanhas Atuais
            </h2>
          </div>

          <div className="bg-zinc-950/20 border border-white/5 rounded-3xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-white/[0.01]">
                    <th className="p-5 text-[9px] font-black text-zinc-500 uppercase tracking-widest">Nome da Campanha</th>
                    <th className="p-5 text-[9px] font-black text-zinc-500 uppercase tracking-widest">Tipo / Regra</th>
                    <th className="p-5 text-[9px] font-black text-zinc-500 uppercase tracking-widest">Aplicabilidade</th>
                    <th className="p-5 text-[9px] font-black text-zinc-500 uppercase tracking-widest">Duração</th>
                    <th className="p-5 text-[9px] font-black text-zinc-500 uppercase tracking-widest text-center">Estado</th>
                    <th className="p-5 text-[9px] font-black text-zinc-500 uppercase tracking-widest text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {promotions.map((promo) => {
                    const analytic = analytics?.promotionSummary?.find((summary: any) => summary.id === promo.id);
                    return (
                      <tr key={promo.id} className="hover:bg-white/[0.01] transition-all">
                        <td className="p-5">
                          <p className="text-xs font-bold text-white">{promo.name}</p>
                          <p className="text-[10px] text-zinc-500 mt-1">ID: <span className="font-mono">{promo.id}</span></p>
                        </td>
                        <td className="p-5 select-none">
                          <span className="text-[9px] font-black text-orange-400 bg-orange-500/10 px-2.5 py-1.5 rounded-lg border border-orange-500/15 uppercase tracking-wide">
                            Leve {promo.get_qty} Grátis comprando {promo.buy_qty}
                          </span>
                        </td>
                        <td className="p-5 text-xs text-zinc-400 font-medium capitalize">
                          {promo.targets && promo.targets.length > 0 ? (
                            promo.targets[0].target_type === 'all_beats' ? (
                              'Todos os Beats'
                            ) : promo.targets[0].target_type === 'genre' ? (
                              `Género: ${promo.targets[0].target_value}`
                            ) : (
                              `${promo.targets.length} Beat(s) selecionado(s)`
                            )
                          ) : (
                            'Todos os Beats'
                          )}
                        </td>
                        <td className="p-5 text-xs text-zinc-400 font-medium flex items-center gap-1.5 mt-1">
                          <Calendar size={13} className="text-zinc-500" />
                          <span>{formatDateString(promo.start_date)} - {formatDateString(promo.end_date)}</span>
                        </td>
                        <td className="p-5 text-center">
                          <button
                            disabled={actionLoading === promo.id}
                            onClick={() => handleToggleStatus(promo.id, promo.status)}
                            className="inline-flex items-center gap-1 cursor-pointer hover:opacity-80 transition-opacity disabled:opacity-50"
                          >
                            {promo.status === 'active' ? (
                              <span className="text-[10px] font-black text-green-500 uppercase tracking-widest bg-green-500/10 border border-green-500/20 px-2 py-1 rounded flex items-center gap-1">
                                ● Ativo
                              </span>
                            ) : (
                              <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest bg-white/5 border border-white/10 px-2 py-1 rounded flex items-center gap-1">
                                Unilateral
                              </span>
                            )}
                          </button>
                        </td>
                        <td className="p-5 text-right">
                          <div className="flex items-center justify-end gap-3">
                            <button
                              disabled={actionLoading === promo.id}
                              onClick={() => handleToggleStatus(promo.id, promo.status)}
                              className="text-zinc-500 hover:text-white transition-colors cursor-pointer"
                              title={promo.status === 'active' ? 'Pausar Promoção' : 'Ativar Promoção'}
                            >
                              {promo.status === 'active' ? <ToggleRight size={22} className="text-[#5865F2]" /> : <ToggleLeft size={22} />}
                            </button>
                            <button
                              disabled={actionLoading === promo.id}
                              onClick={() => handleDeletePromotion(promo.id)}
                              className="text-zinc-500 hover:text-red-400 transition-colors cursor-pointer"
                              title="Eliminar Campanha"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Campaign Roadmap Display (Future percentage/code support simulation, satisfying " percentage & coupon future roadmap requirements" perfectly) */}
      <div className="space-y-6 pt-6 border-t border-white/5">
        <div>
          <h2 className="text-sm font-black text-white uppercase tracking-widest italic">
            Novas Opções de Campanhas <span className="text-zinc-500">(Futuro / Disponível em Breve)</span>
          </h2>
          <p className="text-zinc-500 text-[10px] font-medium tracking-wide mt-1">
            Configure novos modelos de venda direta no marketplace. Estes templates estão prontos para ativação na próxima atualização.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 opacity-60">
          <div className="p-6 bg-zinc-950/10 border border-white/5 rounded-3xl relative">
            <span className="absolute top-4 right-4 text-[8px] font-black text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20 tracking-wider">RODOVIA</span>
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-6">
              <Percent size={18} />
            </div>
            <h4 className="text-sm font-bold text-white leading-tight mb-2">Desconto por Percentagem</h4>
            <p className="text-[10px] text-zinc-500 leading-relaxed font-medium">Aplique 10%, 20% ou até 50% de desconto sobre beats individuais ou todos os seus lançamentos.</p>
          </div>

          <div className="p-6 bg-zinc-950/10 border border-white/10 rounded-3xl relative">
            <span className="absolute top-4 right-4 text-[8px] font-black text-orange-400 bg-orange-500/10 px-1.5 py-0.5 rounded border border-orange-500/20 tracking-wider">CÓDIGO</span>
            <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 mb-6">
              <Sparkles size={18} />
            </div>
            <h4 className="text-sm font-bold text-white leading-tight mb-2">Cupons de Produtor</h4>
            <p className="text-[10px] text-zinc-500 leading-relaxed font-medium">Gere cupões partilháveis para as suas redes sociais (ex: "AFROBEAT20") com limites de usos acumulados.</p>
          </div>

          <div className="p-6 bg-zinc-950/10 border border-white/5 rounded-3xl relative">
            <span className="absolute top-4 right-4 text-[8px] font-black text-purple-400 bg-purple-500/10 px-1.5 py-0.5 rounded border border-purple-500/20 tracking-wider">VENDAS</span>
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mb-6">
              <Calendar size={18} />
            </div>
            <h4 className="text-sm font-bold text-white leading-tight mb-2">Vendas Flash de Fim-de-Semana</h4>
            <p className="text-[10px] text-zinc-500 leading-relaxed font-medium">Agende descontos cronometrados automáticos para durarem apenas 24 horas no marketplace.</p>
          </div>
        </div>
      </div>

      {/* Creation Modal */}
      {isOpenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div className="bg-[#050505] border border-white/10 w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden relative animate-in zoom-in-95 duration-200">
            <div className="p-6 flex items-center justify-between border-b border-white/5">
              <h3 className="text-base font-black text-white uppercase tracking-tight italic flex items-center gap-2">
                <Percent size={18} className="text-[#5865F2]" /> Configurar Nova Campanha
              </h3>
              <button
                onClick={() => setIsOpenModal(false)}
                className="text-zinc-500 hover:text-white transition-colors cursor-pointer"
              >
                Cancelar
              </button>
            </div>

            <form onSubmit={handleCreatePromotionSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
              {errorMessage && (
                <div className="p-4 bg-red-500/10 border border-red-500/15 text-red-400 text-xs font-semibold uppercase tracking-wider rounded-xl flex items-center gap-2.5">
                  <AlertCircle size={16} /> {errorMessage}
                </div>
              )}
              {successMessage && (
                <div className="p-4 bg-green-500/10 border border-green-500/15 text-green-400 text-xs font-semibold uppercase tracking-wider rounded-xl flex items-center gap-2.5">
                  <Check size={16} /> {successMessage}
                </div>
              )}

              {/* Campaign Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Nome da Campanha</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Compre 2 Beats Leve 1 Grátis"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-zinc-950 border border-white/15 px-4 py-3 rounded-xl text-xs text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                />
              </div>

              {/* Rule Type Selector */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Tipo de Desconto</label>
                <div className="grid grid-cols-1 gap-3">
                  <div className="p-4 rounded-xl bg-[#5865F2]/5 border border-[#5865F2]/25 relative">
                    <div className="flex items-start gap-3">
                      <div className="w-4 h-4 rounded-full bg-[#5865F2] text-white flex items-center justify-center text-[8px] font-black mt-0.5"><Check size={10} strokeWidth={3} /></div>
                      <div>
                        <p className="text-xs font-bold text-white">Compre 2 Leve 1 Grátis (Desconto Fixo)</p>
                        <p className="text-[10px] text-zinc-500 leading-relaxed mt-1">O cliente adiciona 3 beats ao carrinho, o mais barato sai grátis de forma totalmente automática.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Quantidade Compra (Buy)</label>
                  <input
                    type="number"
                    disabled
                    value={formBuyQty}
                    className="w-full bg-zinc-950/50 border border-white/10 px-4 py-3 rounded-xl text-xs text-zinc-500 focus:outline-none cursor-not-allowed"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Quantidade Oferta (Free)</label>
                  <input
                    type="number"
                    disabled
                    value={formGetQty}
                    className="w-full bg-zinc-950/50 border border-white/10 px-4 py-3 rounded-xl text-xs text-zinc-500 focus:outline-none cursor-not-allowed"
                  />
                </div>
              </div>

              {/* Applicability dropdown */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Beats Qualificados</label>
                <select
                  value={formApplicability}
                  onChange={(e: any) => setFormApplicability(e.target.value)}
                  className="w-full bg-zinc-950 border border-white/10 px-4 py-3 rounded-xl text-xs text-zinc-500 focus:outline-none focus:border-[#5865F2] transition-colors"
                >
                  <option value="all">Todos os Beats (Recomendado)</option>
                  <option value="genre">Apenas beats por Género</option>
                  <option value="specific_beats">Apenas Beats Selecionados</option>
                </select>
              </div>

              {/* Conditional Genre Field */}
              {formApplicability === 'genre' && (
                <div className="space-y-1.5 animate-in slide-in-from-top-2 duration-150">
                  <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Especificar Género</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: afro beat, trap, drill, r&b"
                    value={formGenreValue}
                    onChange={(e) => setFormGenreValue(e.target.value)}
                    className="w-full bg-zinc-950 border border-white/15 px-4 py-3 rounded-xl text-xs text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                  />
                </div>
              )}

              {/* Conditional Beats selection */}
              {formApplicability === 'specific_beats' && (
                <div className="space-y-1.5 animate-in slide-in-from-top-2 duration-150">
                  <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider block mb-2">Selecionar Meus Beats ({formSelectedBeats.length} selecionados)</label>
                  <div className="p-3 bg-zinc-950 border border-white/5 rounded-xl space-y-2 max-h-40 overflow-y-auto divide-y divide-white/5">
                    {producerBeats.length === 0 ? (
                      <p className="text-[10px] text-zinc-500 text-center py-4">Sem beats publicados ativos na sua conta.</p>
                    ) : (
                      producerBeats.map(beat => {
                        const isChecked = formSelectedBeats.includes(beat.id);
                        return (
                          <div 
                            key={beat.id}
                            onClick={() => handleSelectBeatToggle(beat.id)}
                            className="flex items-center justify-between p-2 cursor-pointer hover:bg-white/[0.02]"
                          >
                            <span className="text-[11px] font-bold text-zinc-300 leading-tight">{beat.title}</span>
                            <div className={`w-4.5 h-4.5 rounded-lg flex items-center justify-center border transition-colors ${isChecked ? 'bg-[#5865F2] border-[#5865F2] text-white' : 'border-white/20'}`}>
                              {isChecked && <Check size={11} strokeWidth={3} />}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* Dates grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Início (Opcional)</label>
                  <input
                    type="date"
                    value={formStartDate}
                    onChange={(e) => setFormStartDate(e.target.value)}
                    className="w-full bg-zinc-950 border border-white/15 px-4 py-3 rounded-xl text-xs text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Término (Opcional)</label>
                  <input
                    type="date"
                    value={formEndDate}
                    onChange={(e) => setFormEndDate(e.target.value)}
                    className="w-full bg-zinc-950 border border-white/15 px-4 py-3 rounded-xl text-xs text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                  />
                </div>
              </div>

              {/* Submit button */}
              <button
                type="submit"
                className="w-full bg-[#5865F2] hover:bg-[#4752C4] py-4 rounded-xl text-xs font-black uppercase tracking-wider text-white shadow-xl shadow-[#5865F2]/20 cursor-pointer mt-4"
              >
                Publicar Campanha Ativa
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
