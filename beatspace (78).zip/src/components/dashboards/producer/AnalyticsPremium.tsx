import React, { useState, useEffect, useMemo } from 'react';
import { 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid 
} from 'recharts';
import { 
  TrendingUp, 
  Heart, 
  Download, 
  DollarSign, 
  Users, 
  Sparkles, 
  RefreshCw,
  Activity,
  Award,
  Flame,
  Zap,
  ChevronDown
} from 'lucide-react';
import { motion } from 'motion/react';
import { getSupabase } from '@/src/lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import { getLocalAnalyticsReport } from '@/src/lib/analytics';
import { playService } from '../../../lib/playService';

interface AnalyticsStatCardProps {
  title: string;
  value: string | number;
  description: string;
  change: string;
  isPositive: boolean;
  icon: React.ComponentType<any>;
}

function AnalyticsStatCard({ title, value, description, change, isPositive, icon: Icon }: AnalyticsStatCardProps) {
  return (
    <div className="relative overflow-hidden bg-[#050505] border border-white/5 rounded-xl p-4 shadow-sm transition-all duration-300 hover:border-[#6366f1]/35 group flex flex-col justify-between">
      <div>
        <div className="flex justify-between items-center mb-3">
          <span className="text-[9px] font-bold uppercase tracking-wider text-neutral-500">{title}</span>
          <div className="p-2 rounded-lg bg-white/[0.02] border border-white/[0.05] text-neutral-400 group-hover:text-white transition-colors">
            <Icon size={14} />
          </div>
        </div>
        
        <div className="text-xl font-bold text-white tracking-tight mb-0.5">
          {value}
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <span className="text-[11px] text-zinc-400">{description}</span>
        <span className={`text-[11px] font-bold flex items-center gap-0.5 ${change === 'Sem dados suficientes' ? 'text-zinc-500' : (isPositive ? 'text-[#5865F2]' : 'text-[#5865F2]')}`}>
          {change === 'Sem dados suficientes' ? '' : (isPositive ? '▲ ' : '◆ ')}{change}
        </span>
      </div>
    </div>
  );
}

const COLORS = ['#5865F2', '#3B82F6', '#60A5FA', '#1D4ED8', '#8B5CF6'];

function calculateGrowth(currentValue: number, previousValue: number): {
  percentage: number;
  direction: 'up' | 'down' | 'neutral';
  text: string;
} {
  if (previousValue === 0) {
    if (currentValue > 0) {
      // rule 9: se previous = 0, se atual > 0, mostrar NEW ou +100%
      return { percentage: 100, direction: 'up', text: 'NEW' };
    }
    // rule 8: quando nao existir dados historicos, mostrar Sem dados suficientes
    return { percentage: 0, direction: 'neutral', text: 'Sem dados suficientes' };
  }
  
  const ratio = (currentValue - previousValue) / previousValue;
  const percentage = Math.round(ratio * 100 * 10) / 10;
  
  let direction: 'up' | 'down' | 'neutral' = 'neutral';
  if (percentage > 0) direction = 'up';
  else if (percentage < 0) direction = 'down';
  
  const prefix = direction === 'up' ? '+' : '';
  return { 
    percentage: Math.abs(percentage), 
    direction, 
    text: `${prefix}${percentage}%` 
  };
}

function isInPeriod(
  dateStr: string,
  period: 'current' | 'previous',
  timeRange: 'today' | '7' | '30' | '90' | 'lifetime'
): boolean {
  if (!dateStr) return false;
  const d = new Date(dateStr).getTime();
  const now = new Date();
  
  if (timeRange === 'today') {
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const startOfYesterday = new Date();
    startOfYesterday.setDate(startOfYesterday.getDate() - 1);
    startOfYesterday.setHours(0, 0, 0, 0);
    
    if (period === 'current') {
      return d >= startOfToday.getTime();
    } else {
      return d >= startOfYesterday.getTime() && d < startOfToday.getTime();
    }
  }
  
  const days = timeRange === '7' ? 7 : timeRange === '30' ? 30 : timeRange === '90' ? 90 : 0;
  if (days === 0) return false;
  
  const cut1 = now.getTime() - days * 24 * 60 * 60 * 1000;
  const cut2 = now.getTime() - 2 * days * 24 * 60 * 60 * 1000;
  
  if (period === 'current') {
    return d >= cut1;
  } else {
    return d >= cut2 && d < cut1;
  }
}

const formatGrowthText = (growth: { text: string }, range: string) => {
  if (range === 'lifetime') {
    return 'Total';
  }
  return growth.text;
};

const isGrowthPositive = (growth: { direction: 'up' | 'down' | 'neutral' }, range: string) => {
  return range !== 'lifetime' && growth.direction === 'up';
};

export default function AnalyticsPremium() {
  console.log("ANALYTICS PREMIUM LOADED");
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'today' | '7' | '30' | '90' | 'lifetime'>('30');
  const [beats, setBeats] = useState<any[]>([]);
  const [salesList, setSalesList] = useState<any[]>([]);
  const [likesCount, setLikesCount] = useState(0);
  const [followersCount, setFollowersCount] = useState(0);
  const [profileViewsCount, setProfileViewsCount] = useState(0);
  const [playsLogs, setPlaysLogs] = useState<any[]>([]);
  const [downloadsCount, setDownloadsCount] = useState(0);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const [followersList, setFollowersList] = useState<any[]>([]);
  const [likesList, setLikesList] = useState<any[]>([]);
  const [downloadsList, setDownloadsList] = useState<any[]>([]);

  const supabase = getSupabase();

  const [linkAnalytics, setLinkAnalytics] = useState<any>(null);
  const [linksLoading, setLinksLoading] = useState(false);
  const [isLinksSectionOpen, setIsLinksSectionOpen] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    async function fetchLinkMetrics() {
      if (!user?.id) return;
      setLinksLoading(true);
      try {
        const days = timeRange === 'today' ? 1 : timeRange === '7' ? 7 : timeRange === '30' ? 30 : timeRange === '90' ? 90 : 0;
        const res = await fetch(`/api/short-links/analytics/${user.id}?days=${days}`);
        const data = await res.json();
        if (data.success) {
          setLinkAnalytics(data.analytics);
        } else {
          console.warn('Failed to fetch short links analytics:', data.error);
        }
      } catch (err) {
        console.error('Error fetching short links analytics:', err);
      } finally {
        setLinksLoading(false);
      }
    }
    fetchLinkMetrics();
  }, [user?.id, timeRange, refreshTrigger]);

  useEffect(() => {
    async function fetchDatabaseMetrics() {
      if (!supabase || !user?.id) {
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        await playService.loadPlayCounts();
      } catch (err) {
        console.warn('Error loading play counts in AnalyticsPremium:', err);
      }
      try {
        // Fetch Beats
        const { data: beatsRes } = await supabase
          .from('beats')
          .select('id, title, price_basic, price_premium, price_exclusive, created_at, plays_count')
          .eq('producer_id', user.id);

        const loadedBeats = beatsRes || [];
        setBeats(loadedBeats);
        const beatIds = loadedBeats.map(b => b.id);

        let loadedSales: any[] = [];
        let loadedFavs: any[] = [];
        let playsForAnalytics: any[] = [];
        let realDownloads: any[] = [];

        if (beatIds.length > 0) {
          // Fetch Vendas/Sales - includes status checking inside orders lookup
          const { data: salesRes } = await supabase
            .from('order_items')
            .select('id, price, created_at, beat_id, orders(status)')
            .in('beat_id', beatIds);
          
          loadedSales = salesRes || [];
          setSalesList(loadedSales);

          // Fetch Likes/Favorites
          const queryBeatIds = beatIds.flatMap(id => {
            const strId = String(id);
            const padded = strId.padStart(12, '0');
            return [strId, `00000000-0000-0000-0000-${padded}`];
          });

          const { data: favsRes } = await supabase
            .from('favorites')
            .select('beat_id, created_at')
            .in('beat_id', queryBeatIds);

          loadedFavs = favsRes || [];
          setLikesCount(loadedFavs.length);

          // Fetch Real Plays Count from BOTH play_events and legacy beat_plays tables with absolute real dates
          try {
            const { data: playsEvents } = await supabase
              .from('play_events')
              .select('id, beat_id, created_at')
              .in('beat_id', beatIds);
            if (playsEvents && playsEvents.length > 0) {
              playsForAnalytics = [...playsEvents];
            }
          } catch (peErr) {
            console.warn("Could not query play_events for analytics:", peErr);
          }

          try {
            const { data: realPlaysRes } = await supabase
              .from('beat_plays')
              .select('id, beat_id, created_at')
              .in('beat_id', beatIds);
            if (realPlaysRes && realPlaysRes.length > 0) {
              const existingIds = new Set(playsForAnalytics.map(p => p.id));
              realPlaysRes.forEach((p: any) => {
                if (!existingIds.has(p.id)) {
                  playsForAnalytics.push(p);
                }
              });
            }
          } catch (bpErr) {
            console.warn("Could not query beat_plays for analytics:", bpErr);
          }

          setPlaysLogs(playsForAnalytics);

          // Fetch actual database download events (no math multipliers!)
          try {
            const { data: dlsRes } = await supabase
              .from('download_events')
              .select('id, beat_id, created_at')
              .in('beat_id', beatIds);
            if (dlsRes && dlsRes.length > 0) {
              realDownloads = dlsRes;
            }
          } catch (dbError) {
            console.warn('download_events query caught helper warning:', dbError);
          }
        }

        // Fetch Follows with timestamps
        const { data: followersResData, count: followersRes } = await supabase
          .from('followers')
          .select('id, created_at', { count: 'exact' })
          .eq('following_id', user.id);

        const realFollowersCount = followersRes || 0;
        setFollowersCount(realFollowersCount);
        setFollowersList(followersResData || []);

        // Retrieve client side analytics reports
        const localEvents = getLocalAnalyticsReport(user.id, 'lifetime');

        // Extract profile views
        const views = localEvents.filter(e => e.event_type === 'profile_visit').length;
        setProfileViewsCount(views);

        // Combine download events cleanly from database and local interactive logs (NO artificial dates, NO simulation)
        const localDownloads = localEvents.filter(e => e.event_type === 'download').map(d => ({ created_at: d.created_at, beat_id: d.beat_id }));
        const combinedDownloads = [...realDownloads];
        localDownloads.forEach(ld => {
          combinedDownloads.push(ld);
        });
        
        setDownloadsList(combinedDownloads);
        setDownloadsCount(combinedDownloads.length);

        // Filter and compile favors (likes)
        const realLikes = (loadedFavs || []).filter(f => f.created_at).map(f => ({ created_at: f.created_at }));
        const localLikes = localEvents.filter(e => e.event_type === 'like').map(l => ({ created_at: l.created_at }));
        setLikesList([...realLikes, ...localLikes]);

      } catch (err) {
        console.error('Error fetching analytics overview:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchDatabaseMetrics();
  }, [user?.id, refreshTrigger, salesList.length, playsLogs.length]);

  // Real-time integration using Supabase channels
  useEffect(() => {
    if (!supabase || !user?.id) return;

    const channel = supabase.channel('realtime_analytics_premium')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'play_events' }, () => {
        setRefreshTrigger(p => p + 1);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'beat_plays' }, () => {
        setRefreshTrigger(p => p + 1);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'favorites' }, () => {
        setRefreshTrigger(p => p + 1);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, () => {
        setRefreshTrigger(p => p + 1);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'order_items' }, () => {
        setRefreshTrigger(p => p + 1);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'followers' }, () => {
        setRefreshTrigger(p => p + 1);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'download_events' }, () => {
        setRefreshTrigger(p => p + 1);
      });

    channel.subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [supabase, user?.id]);

  // Listen for local playback trackings for seamless real-time refresh
  useEffect(() => {
    const handleBeatPlayTracked = () => {
      console.log('[REALTIME UPDATE] beatPlayTracked caught in AnalyticsPremium, refreshing...');
      setRefreshTrigger(prev => prev + 1);
    };
    window.addEventListener('beatPlayTracked' as any, handleBeatPlayTracked);
    return () => {
      window.removeEventListener('beatPlayTracked' as any, handleBeatPlayTracked);
    };
  }, []);

  // Aggregate metrics depending on filter
  const processedMetrics = useMemo(() => {
    const now = new Date();
    let cutOff = new Date();

    if (timeRange === 'today') {
      cutOff.setHours(0, 0, 0, 0);
    } else if (timeRange === '7') {
      cutOff.setDate(now.getDate() - 7);
    } else if (timeRange === '30') {
      cutOff.setDate(now.getDate() - 30);
    } else if (timeRange === '90') {
      cutOff.setDate(now.getDate() - 90);
    } else {
      cutOff = new Date(0); // Lifetime
    }

    const isLifetime = timeRange === 'lifetime';

    // 1. Plays filtered
    const totalBeatsPlays = beats.reduce((sum, b) => sum + Number(playService.getPlayCount(b.id, b.plays_count || 0)), 0);
    const filteredPlays = playsLogs.filter(p => isLifetime || new Date(p.created_at) >= cutOff);
    const playEventsCount = isLifetime 
      ? totalBeatsPlays 
      : (playsLogs.length > 0 ? filteredPlays.length : totalBeatsPlays);

    // 2. Sales confirmadas only
    const confirmedSales = salesList.filter(s => {
      const orderStatus = String(s.orders?.status || '').toLowerCase();
      const isConfirmed = ['paid', 'completed', 'concluido', 'sucesso', 'confirmed', 'confirmado'].includes(orderStatus);
      return isConfirmed && (isLifetime || new Date(s.created_at) >= cutOff);
    });
    
    const salesVolume = confirmedSales.length;
    const salesRevenue = confirmedSales.reduce((sum, s) => sum + Number(s.price || 0), 0);

    // 3. Downloads filtered
    const downloadsFiltered = downloadsList.filter(d => isLifetime || new Date(d.created_at) >= cutOff).length;

    // 4. Views values filtered (100% real clicks)
    const localEventsFiltered = user?.id ? getLocalAnalyticsReport(user.id, timeRange) : [];
    const viewsFiltered = localEventsFiltered.filter(e => e.event_type === 'profile_visit').length;

    return {
      plays: playEventsCount,
      sales: salesVolume,
      revenue: salesRevenue,
      downloads: downloadsFiltered,
      views: viewsFiltered,
    };
  }, [timeRange, playsLogs, salesList, downloadsList, user?.id, beats]);

  // Growth percentage calculations comparing current period vs previous period
  const growthMetrics = useMemo(() => {
    // 1. Plays (no plays_count used for growth calculation, only play_events & beat_plays)
    const currentPlays = playsLogs.filter(p => isInPeriod(p.created_at, 'current', timeRange)).length;
    const previousPlays = playsLogs.filter(p => isInPeriod(p.created_at, 'previous', timeRange)).length;
    const playsGrowth = calculateGrowth(currentPlays, previousPlays);

    // 2. Likes
    const currentLikes = likesList.filter(l => isInPeriod(l.created_at, 'current', timeRange)).length;
    const previousLikes = likesList.filter(l => isInPeriod(l.created_at, 'previous', timeRange)).length;
    const likesGrowth = calculateGrowth(currentLikes, previousLikes);

    // 3. Downloads
    const currentDownloads = downloadsList.filter(d => isInPeriod(d.created_at, 'current', timeRange)).length;
    const previousDownloads = downloadsList.filter(d => isInPeriod(d.created_at, 'previous', timeRange)).length;
    const downloadsGrowth = calculateGrowth(currentDownloads, previousDownloads);

    // 4. Confirmed Sales Count
    const confirmedSales = salesList.filter(s => {
      const orderStatus = String(s.orders?.status || '').toLowerCase();
      return ['paid', 'completed', 'concluido', 'sucesso', 'confirmed', 'confirmado'].includes(orderStatus);
    });
    const currentSales = confirmedSales.filter(s => isInPeriod(s.created_at, 'current', timeRange)).length;
    const previousSales = confirmedSales.filter(s => isInPeriod(s.created_at, 'previous', timeRange)).length;
    const salesGrowth = calculateGrowth(currentSales, previousSales);

    // 5. Revenue
    const currentRevenue = confirmedSales
      .filter(s => isInPeriod(s.created_at, 'current', timeRange))
      .reduce((sum, s) => sum + Number(s.price || 0), 0);
    const previousRevenue = confirmedSales
      .filter(s => isInPeriod(s.created_at, 'previous', timeRange))
      .reduce((sum, s) => sum + Number(s.price || 0), 0);
    const revenueGrowth = calculateGrowth(currentRevenue, previousRevenue);

    // 6. Followers
    const currentFollowers = followersList.filter(f => isInPeriod(f.created_at, 'current', timeRange)).length;
    const previousFollowers = followersList.filter(f => isInPeriod(f.created_at, 'previous', timeRange)).length;
    const followersGrowth = calculateGrowth(currentFollowers, previousFollowers);

    return {
      plays: playsGrowth,
      likes: likesGrowth,
      downloads: downloadsGrowth,
      sales: salesGrowth,
      revenue: revenueGrowth,
      followers: followersGrowth
    };
  }, [timeRange, playsLogs, likesList, downloadsList, salesList, followersList]);

  // Chart Data: Plays & Sales history over actual timeline buckets (no fake generators)
  const historyChartData = useMemo(() => {
    const points: any[] = [];
    const today = new Date();

    const fetchInterval = timeRange === 'today' ? 24 : timeRange === '7' ? 7 : timeRange === '30' ? 10 : 12;

    for (let i = fetchInterval - 1; i >= 0; i--) {
      const datePoint = new Date();
      if (timeRange === 'today') {
        datePoint.setHours(today.getHours() - i);
      } else {
        const step = timeRange === 'lifetime' ? i * 15 : i * (timeRange === '90' ? 6 : timeRange === '30' ? 3 : 1);
        datePoint.setDate(today.getDate() - step);
      }

      const pointDateStr = datePoint.toLocaleDateString('pt-AO', { day: '2-digit', month: 'short' });
      const pointTimeStr = datePoint.toLocaleTimeString('pt-AO', { hour: '2-digit', minute: '2-digit' });
      const labelStr = timeRange === 'today' ? pointTimeStr : pointDateStr;

      // Filter events relative to this timeline bucket
      const playsInBucket = playsLogs.filter(p => {
        const d = new Date(p.created_at);
        if (timeRange === 'today') {
          return d.getHours() === datePoint.getHours() && d.getDate() === datePoint.getDate();
        } else {
          const diffTime = Math.abs(today.getTime() - d.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          return diffDays <= i + 1 && diffDays >= i - 1;
        }
      }).length;

      const confirmedSales = salesList.filter(s => {
        const orderStatus = String(s.orders?.status || '').toLowerCase();
        return ['paid', 'completed', 'concluido', 'sucesso', 'confirmed', 'confirmado'].includes(orderStatus);
      });

      const salesInBucket = confirmedSales.filter(s => {
        const d = new Date(s.created_at);
        if (timeRange === 'today') {
          return d.getHours() === datePoint.getHours() && d.getDate() === datePoint.getDate();
        } else {
          const diffTime = Math.abs(today.getTime() - d.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          return diffDays <= i + 1 && diffDays >= i - 1;
        }
      });

      const revenueInBucket = salesInBucket.reduce((sum, s) => sum + Number(s.price || 0), 0);

      points.push({
        name: labelStr,
        plays: playsInBucket,
        vendas: salesInBucket.length,
        faturação: revenueInBucket
      });
    }

    return points;
  }, [timeRange, playsLogs, salesList]);

  // Top Performing Beats by verified/confirmed revenue
  const topBeats = useMemo(() => {
    return beats.map(b => {
      const playsCount = Number(playService.getPlayCount(b.id, b.plays_count || 0));
      
      const confirmedSales = salesList.filter(s => {
        const orderStatus = String(s.orders?.status || '').toLowerCase();
        return ['paid', 'completed', 'concluido', 'sucesso', 'confirmed', 'confirmado'].includes(orderStatus);
      });

      const salesCount = confirmedSales.filter(s => String(s.beat_id) === String(b.id)).length;
      const beatRevenue = confirmedSales
        .filter(s => String(s.beat_id) === String(b.id))
        .reduce((sum, s) => sum + Number(s.price || 0), 0);

      const CTRValue = playsCount > 0 ? Math.round((salesCount / playsCount) * 100) : 0;

      return {
        id: b.id,
        title: b.title,
        plays: playsCount,
        vendas: salesCount,
        revenue: beatRevenue,
        ctr: CTRValue,
      };
    })
    .sort((a, b) => b.revenue - a.revenue || b.plays - a.plays)
    .slice(0, 5);
  }, [beats, playsLogs, salesList]);

  // Sales Distribution for license types pie chart
  const licenseDistributionData = useMemo(() => {
    let basicCount = 0;
    let premCount = 0;
    let exclCount = 0;

    const confirmedSales = salesList.filter(s => {
      const orderStatus = String(s.orders?.status || '').toLowerCase();
      return ['paid', 'completed', 'concluido', 'sucesso', 'confirmed', 'confirmado'].includes(orderStatus);
    });

    confirmedSales.forEach(s => {
      if (s.price > 25000) exclCount++;
      else if (s.price > 12000) premCount++;
      else basicCount++;
    });

    return [
      { name: 'Licença Básica', value: basicCount },
      { name: 'Licença Premium', value: premCount },
      { name: 'Licença Exclusiva', value: exclCount },
    ];
  }, [salesList]);

  // Smart Creator Insights based purely on true numbers 
  const smartInsights = useMemo(() => {
    const list = [];
    
    if (beats.length === 0) {
      list.push({
        type: 'warning',
        icon: Flame,
        color: 'text-amber-500 bg-amber-500/10 border-amber-500/20',
        title: 'Impulsiona o teu Perfil',
        text: 'Ainda não tens beats ativos. Publica o teu primeiro beat para começares a acumular estatísticas de visualizações e plays.'
      });
      return list;
    }

    // High CTR insight
    const bestCTRBeat = [...topBeats].sort((a, b) => b.ctr - a.ctr)[0];
    if (bestCTRBeat && bestCTRBeat.ctr > 5) {
      list.push({
        type: 'success',
        icon: Sparkles,
        color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
        title: `Alta Conversão em "${bestCTRBeat.title}"`,
        text: `O teu beat "${bestCTRBeat.title}" está com um excelente CTR de conversão de ${bestCTRBeat.ctr}%. Excelente escolha de arranjo!`
      });
    }

    // High Plays, but no sales insights
    const highPlaysBeat = [...topBeats].sort((a, b) => b.plays - a.plays)[0];
    if (highPlaysBeat && highPlaysBeat.plays > 10 && highPlaysBeat.vendas === 0) {
      list.push({
        type: 'warning',
        icon: Flame,
        color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20',
        title: `Optimiza o Preço em "${highPlaysBeat.title}"`,
        text: `Este beat tem ${highPlaysBeat.plays} plays mas nenhuma venda ainda. Considera ajustar ligeiramente o preço da licença Básica.`
      });
    }

    // Follower momentum
    if (followersCount > 0) {
      list.push({
        type: 'success',
        icon: Award,
        color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
        title: 'Crescimento de Audiência Constante',
        text: `Parabéns! Já tens ${followersCount} seguidores ativos que são notificados sobre cada novo lançamento teu.`
      });
    }

    return list.slice(0, 3);
  }, [beats.length, topBeats, followersCount]);

  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'sales' | 'streams' | 'links'>('overview');

  return (
    <div className="p-6 md:py-8 md:pr-10 md:pl-4 space-y-8 max-w-7xl mx-auto pb-24">
      {/* Premium Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-white/5">
        <div className="space-y-1.5Packed">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded bg-amber-500/10 text-amber-500 text-[10px] font-black uppercase tracking-widest border border-amber-500/20">
              PRO STUDIO INSIGHTS
            </span>
          </div>
          <h2 className="text-3xl font-black text-white uppercase tracking-tight flex items-center gap-2">
            ANALYTICS CENTER
          </h2>
          <p className="text-neutral-400 text-sm">
            Monitoriza reproduções, engajamento e a conversão de vendas dos teus beats em tempo real.
          </p>
        </div>

        {/* Time filters & Actions */}
        <div className="flex items-center gap-2 self-start md:self-center">
          <div className="flex bg-[#0D0D0D] border border-white/10 p-1.5 rounded-2xl gap-1">
            {(['today', '7', '30', '90', 'lifetime'] as const).map((r) => {
              const labels = { today: 'Hoje', '7': '7D', '30': '30D', '90': '90D', lifetime: 'Sempre' };
              return (
                <button
                  key={r}
                  onClick={() => setTimeRange(r)}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all duration-300 ${
                    timeRange === r 
                      ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/10' 
                      : 'text-neutral-500 hover:text-white'
                  }`}
                >
                  {labels[r]}
                </button>
              );
            })}
          </div>

          <button 
            onClick={() => setRefreshTrigger(p => p + 1)}
            className="p-2.5 bg-[#0D0D0D] border border-white/10 rounded-2xl text-neutral-400 hover:text-white hover:border-white/20 transition-all duration-300"
            title="Atualizar Dados"
          >
            <RefreshCw size={15} className={loading ? 'animate-spin text-amber-500' : ''} />
          </button>
        </div>
      </header>

      {/* Sub Tabs Navigation */}
      <div className="flex border-b border-white/5 gap-2 overflow-x-auto scrollbar-none pb-0.5">
        {[
          { id: 'overview', label: 'Visão Geral' },
          { id: 'sales', label: 'Vendas' },
          { id: 'streams', label: 'Streams & Plays' },
          { id: 'links', label: 'Link Analytics' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`px-4 py-3 text-xs uppercase font-black tracking-wider transition-all duration-300 relative ${
              activeSubTab === tab.id 
                ? 'text-amber-500 border-b-2 border-amber-500 font-bold' 
                : 'text-neutral-500 hover:text-neutral-200 font-semibold'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeSubTab === 'overview' && (
        <div className="space-y-8 animate-fadeIn">
          {/* Main Core Quantities row */}
          <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <AnalyticsStatCard 
          title="TOTAL PLAYS" 
          value={processedMetrics.plays.toLocaleString()} 
          description="Cliques no play" 
          change={formatGrowthText(growthMetrics.plays, timeRange)} 
          isPositive={isGrowthPositive(growthMetrics.plays, timeRange)} 
          icon={TrendingUp} 
        />
        <AnalyticsStatCard 
          title="TOTAL LIKES" 
          value={likesCount.toLocaleString()} 
          description="Adições aos favoritos" 
          change={formatGrowthText(growthMetrics.likes, timeRange)} 
          isPositive={isGrowthPositive(growthMetrics.likes, timeRange)} 
          icon={Heart} 
        />
        <AnalyticsStatCard 
          title="DOWNLOADS" 
          value={processedMetrics.downloads.toLocaleString()} 
          description="Downloads" 
          change={formatGrowthText(growthMetrics.downloads, timeRange)} 
          isPositive={isGrowthPositive(growthMetrics.downloads, timeRange)} 
          icon={Download} 
        />
        <AnalyticsStatCard 
          title="PEDIDOS" 
          value={processedMetrics.sales.toLocaleString()} 
          description="Vendas convertidas" 
          change={formatGrowthText(growthMetrics.sales, timeRange)} 
          isPositive={isGrowthPositive(growthMetrics.sales, timeRange)} 
          icon={Award} 
        />
        <AnalyticsStatCard 
          title="REVENUE" 
          value={`${processedMetrics.revenue.toLocaleString()} Kz`} 
          description="Faturação período" 
          change={formatGrowthText(growthMetrics.revenue, timeRange)} 
          isPositive={isGrowthPositive(growthMetrics.revenue, timeRange)} 
          icon={DollarSign} 
        />
        <AnalyticsStatCard 
          title="FOLLOWERS" 
          value={followersCount.toLocaleString()} 
          description="Fãs no portal" 
          change={formatGrowthText(growthMetrics.followers, timeRange)} 
          isPositive={isGrowthPositive(growthMetrics.followers, timeRange)} 
          icon={Users} 
        />
      </section>

      {/* Premium Chart Layouts */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Plays and Sales history Graph */}
        <div className="lg:col-span-8 bg-[#050505] border border-white/5 rounded-xl p-5 md:p-6 flex flex-col justify-between shadow-sm hover:border-[#6366f1]/35 transition-all duration-300">
          <div className="flex justify-between items-center mb-6">
            <div className="space-y-1">
              <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <Activity size={16} className="text-[#5865F2]" />
                Plays e Vendas no Tempo
              </h2>
              <p className="text-[11px] text-zinc-400 mt-0.5">Estatísticas de reprodução e intenção de licenciamento no catálogo.</p>
            </div>
            <div className="flex gap-4 items-center">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded bg-amber-500" />
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Plays</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded bg-[#5865F2]" />
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Vendas</span>
              </div>
            </div>
          </div>

          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={historyChartData} margin={{ top: 20, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff03" />
                <XAxis 
                  dataKey="name" 
                  stroke="#666" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  stroke="#666" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#050505', borderColor: 'rgba(255,255,255,0.05)', borderRadius: '8px' }} 
                  labelStyle={{ color: '#fff', fontWeight: 'bold', fontSize: 11 }}
                  itemStyle={{ fontSize: 13 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="plays" 
                  stroke="#F59E0B" 
                  strokeWidth={2} 
                  dot={{ r: 3, stroke: "#F59E0B", strokeWidth: 1 }} 
                  activeDot={{ r: 5 }} 
                  name="Plays"
                />
                <Line 
                  type="monotone" 
                  dataKey="vendas" 
                  stroke="#5865F2" 
                  strokeWidth={2} 
                  dot={{ r: 3, stroke: "#5865F2", strokeWidth: 1 }} 
                  name="Vendas"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sales distribution by license type */}
        <div className="lg:col-span-4 bg-[#050505] border border-white/5 rounded-xl p-5 md:p-6 flex flex-col justify-between shadow-sm hover:border-[#6366f1]/35 transition-all duration-300">
          <div className="space-y-1 mb-6">
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              Distribuição de Licenças
            </h3>
            <p className="text-[11px] text-zinc-400 mt-0.5">Canais e formatos de compras preferidos.</p>
          </div>

          {/* Pie Chart container */}
          <div className="h-60 w-full flex items-center justify-center relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={licenseDistributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {licenseDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#222', borderRadius: '12px' }}
                  itemStyle={{ fontSize: 12, color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
            
            <div className="absolute text-center">
              <span className="block text-[10px] font-black tracking-widest text-neutral-500 uppercase">Faturação</span>
              <span className="text-white font-black">{processedMetrics.revenue ? processedMetrics.revenue.toLocaleString() : '0'} Kz</span>
            </div>
          </div>

          <div className="space-y-2 mt-4 pt-4 border-t border-white/5">
            {licenseDistributionData.map((item, idx) => (
              <div key={item.name} className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                  <span className="text-neutral-400 font-medium">{item.name}</span>
                </div>
                <span className="text-white font-bold">{item.value} vendas</span>
              </div>
            ))}
          </div>
        </div>

      </section>

      {/* Top Performing Beats list & Creator Insights Column */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Top 5 list */}
        <div className="lg:col-span-8 bg-[#050505] border border-white/5 rounded-xl p-5 md:p-6 shadow-sm hover:border-[#6366f1]/35 transition-all duration-300">
          <div className="space-y-1 mb-6">
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              Top 5 Beats em Performance
            </h3>
            <p className="text-[11px] text-zinc-400 mt-0.5">Os teus beats de maior destaque e impacto financeiro atual.</p>
          </div>

          {beats.length === 0 ? (
            <div className="py-12 text-center text-neutral-500 text-sm">
              Nenhuma música lançada para ranqueamento.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/5 text-[10px] font-bold uppercase tracking-wider text-gray-500">
                    <th className="py-3 px-3">Beat</th>
                    <th className="py-3 px-3 text-right">Plays</th>
                    <th className="py-3 px-3 text-right">Vendas</th>
                    <th className="py-3 px-3 text-right">Conversão</th>
                    <th className="py-3 px-3 text-right">Faturação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {topBeats.map((b, index) => (
                    <tr key={b.id || index} className="text-xs font-semibold hover:bg-white/[0.01] transition-colors group">
                      <td className="py-3 px-3 flex items-center gap-3">
                        <span className="text-xs font-mono font-bold text-zinc-500 group-hover:text-[#5865F2] transition-colors">
                           0{index + 1}
                        </span>
                        <div>
                          <p className="text-white font-bold text-xs">{b.title}</p>
                          <span className="text-[10px] text-zinc-500 font-mono">ID #{String(b.id).substring(0, 6)}</span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right text-xs font-mono text-zinc-300">
                        {b.plays.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right text-xs font-mono text-zinc-300">
                        {b.vendas.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right">
                        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-xs font-bold border border-emerald-500/10">
                          {b.ctr}%
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-blue-400 text-xs font-mono">
                        {b.revenue.toLocaleString()} Kz
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Pro Creator Insights AI */}
        <div className="lg:col-span-4 bg-[#050505] border border-white/5 rounded-xl p-5 md:p-6 shadow-sm flex flex-col justify-between hover:border-[#6366f1]/35 transition-all duration-300">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={16} className="text-[#5865F2]" />
              <h3 className="text-base font-bold text-white tracking-tight">Insights Inteligentes</h3>
            </div>
            <p className="text-[11px] text-zinc-400 mb-6 font-medium">Sugestões de produção automáticas baseadas em métricas.</p>

            <div className="space-y-4">
              {smartInsights.length === 0 ? (
                <div className="p-4 rounded-xl border border-white/5 text-neutral-500 text-center text-xs">
                  Sem insights no momento.
                </div>
              ) : (
                smartInsights.map((insight, idx) => (
                  <div key={idx} className={`p-4 rounded-xl border text-xs flex gap-3 ${insight.color} border-white/5`}>
                    <div className="shrink-0 mt-0.5">
                      <insight.icon size={15} />
                    </div>
                    <div className="space-y-1">
                      <p className="font-bold text-zinc-100">{insight.title}</p>
                      <p className="text-zinc-400 font-medium leading-relaxed">{insight.text}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-8 p-4 rounded-lg bg-[#5865F2]/5 border border-[#5865F2]/10 text-zinc-400 text-[11px] leading-relaxed">
            <span className="font-bold text-[#5865F2] uppercase tracking-wider block mb-1">PRO TIP</span>
            Promove o teu beat de melhor conversão nas redes sociais para maximizares os teus lucros com menos cliques.
          </div>
        </div>

        {/* SECTION: LINK ANALYTICS (COLLAPSIBLE) */}
      </section>
    </div>
  )}

  {activeSubTab === 'sales' && (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fadeIn font-sans">
      {/* Sales specific cards on Left */}
      <div className="lg:col-span-8 space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-[#050505] border border-white/5 rounded-xl p-4 font-sans">
            <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest font-black">FATURAÇÃO TOTAL</p>
            <p className="text-2xl font-black text-white tracking-tight mt-2">{processedMetrics.revenue.toLocaleString()} Kz</p>
          </div>
          <div className="bg-[#050505] border border-white/5 rounded-xl p-4 font-sans">
            <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest font-black">PEDIDOS CONFIRMADOS</p>
            <p className="text-2xl font-black text-white tracking-tight mt-2">{processedMetrics.sales}</p>
          </div>
          <div className="bg-[#050505] border border-white/5 rounded-xl p-4 font-sans">
            <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest font-black">TICKET MÉDIO</p>
            <p className="text-2xl font-black text-white tracking-tight mt-2 font-mono">
              {Math.round(processedMetrics.sales > 0 ? processedMetrics.revenue / processedMetrics.sales : 0).toLocaleString()} Kz
            </p>
          </div>
        </div>

        {/* List of recent orders */}
        <div className="bg-[#050505] border border-white/5 rounded-xl p-5 md:p-6 shadow-sm">
          <h3 className="text-base font-bold text-white tracking-tight mb-4 flex items-center gap-2">
            <DollarSign size={16} className="text-emerald-500" />
            Histórico de Transações de Vendas
          </h3>
          {salesList.length === 0 ? (
            <div className="py-8 text-neutral-500 text-xs text-center uppercase tracking-wider font-semibold">Nenhuma transação concluída.</div>
          ) : (
            <div className="overflow-x-auto font-sans">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-white/5 text-[10px] font-black uppercase tracking-wider text-neutral-500">
                    <th className="py-3 px-3">ID Pedido</th>
                    <th className="py-3 px-3">Beat Associado</th>
                    <th className="py-3 px-3 col-span-2">Faturação</th>
                    <th className="py-2.5 px-3 font-semibold">Data da Venda</th>
                    <th className="py-3 px-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.02]">
                  {salesList.slice(0, 10).map((sale, idx) => (
                    <tr key={sale.id || idx} className="hover:bg-white/[0.01]">
                      <td className="py-2.5 px-3 font-mono text-zinc-400 text-[10px] uppercase font-bold">#{String(sale.id || '').substring(0, 8)}</td>
                      <td className="py-2.5 px-3 text-white font-bold">
                        {beats.find(b => b.id === sale.beat_id)?.title || 'Assinatura Batukada'}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-emerald-400" colSpan={2}>{Number(sale.price || 0).toLocaleString()} Kz</td>
                      <td className="py-2.5 px-3 text-neutral-500 font-mono">{sale.created_at ? new Date(sale.created_at).toLocaleDateString("pt-AO") : "---"}</td>
                      <td className="py-2.5 px-3 text-right">
                        <span className="px-2.5 py-0.5 rounded bg-[#10b981]/10 text-[#10b981] text-[8px] font-black uppercase tracking-widest border border-[#10b981]/10 font-sans font-bold">
                          {sale.orders?.status || 'pago'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* License Pie on Right */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-[#050505] border border-white/5 rounded-xl p-5 shadow-sm font-sans">
          <h3 className="text-base font-bold text-white tracking-tight mb-4 flex items-center gap-2">
            Formatos de Licença
          </h3>
          <div className="h-60 w-full flex items-center justify-center relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={licenseDistributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {licenseDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute text-center">
              <span className="block text-[10px] font-black tracking-widest text-[#5865F2] uppercase">Formatos</span>
              <span className="text-white font-black">{processedMetrics.sales} Vendas</span>
            </div>
          </div>
          <div className="space-y-2 mt-4 pt-4 border-t border-white/5">
            {licenseDistributionData.map((item, idx) => (
              <div key={item.name} className="flex justify-between items-center text-xs text-sans">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                  <span className="text-neutral-400 font-medium">{item.name}</span>
                </div>
                <span className="text-white font-bold">{item.value} vendas</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )}

  {activeSubTab === 'streams' && (
    <div className="space-y-8 animate-fadeIn font-sans">
      {/* Plays key metrics */}
      <section className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-[#050505] border border-white/5 rounded-xl p-4 font-sans">
          <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest font-black">REPRODUÇÕES TOTAIS</p>
          <p className="text-2xl font-black text-white tracking-tight mt-2">{processedMetrics.plays.toLocaleString()}</p>
        </div>
        <div className="bg-[#050505] border border-white/5 rounded-xl p-4 font-sans">
          <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest font-black font-bold">DOWNLOADS TOTAIS</p>
          <p className="text-2xl font-black text-white tracking-tight mt-2">{processedMetrics.downloads.toLocaleString()}</p>
        </div>
        <div className="bg-[#050505] border border-white/5 rounded-xl p-4 font-sans">
          <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest font-black font-bold">RELEVÂNCIA / LIKES</p>
          <p className="text-2xl font-black text-white tracking-tight mt-2">{likesCount}</p>
        </div>
        <div className="bg-[#050505] border border-white/5 rounded-xl p-4 font-sans">
          <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest font-black font-bold">RÁCIO LIKES / PLAYS</p>
          <p className="text-2xl font-black text-[#5865F2] tracking-tight mt-2">
            {processedMetrics.plays > 0 ? ((likesCount / processedMetrics.plays) * 100).toFixed(1) : '0'}%
          </p>
        </div>
      </section>

      {/* Ranking list */}
      <div className="bg-[#050505] border border-white/5 rounded-xl p-5 md:p-6 shadow-sm">
        <h3 className="text-base font-bold text-white tracking-tight mb-4 flex items-center gap-2">
          <Activity size={16} className="text-amber-500" />
          Engajamento Vocal e Escuta de Catálogo (Todos os Beats)
        </h3>
        {beats.length === 0 ? (
          <div className="py-8 text-neutral-500 text-xs text-center uppercase tracking-wider font-semibold">Sem beats ativos.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-sans">
            <div className="border border-white/5 bg-black/30 rounded-xl p-5">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-b border-white/5 pb-2">Clube de Líderes (Top Escutados)</h4>
              <div className="space-y-3 font-sans">
                {[...beats].sort((a,b) => (b.plays_count || 0) - (a.plays_count || 0)).slice(0, 10).map((beat, idx) => (
                  <div key={beat.id || idx} className="flex justify-between items-center text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-zinc-500 font-mono font-bold">0{idx + 1}</span>
                      <span className="font-semibold text-zinc-100">{beat.title}</span>
                    </div>
                    <span className="font-mono text-amber-500 font-black">{beat.plays_count || 0} plays</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="border border-white/5 bg-[#5865F2]/5 rounded-xl p-5 flex flex-col justify-between">
              <div className="space-y-3 font-sans">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Sparkles size={14} className="text-[#5865F2]" />
                  Análise de Engajamento Vocal
                </h4>
                <p className="text-neutral-400 text-xs leading-relaxed font-normal">
                  A reprodução do player e os downloads de rascunhos marcam a relevância orgânica da sua marca. Beats com mais de 7% de rácio "Like-para-Play" possuem enorme tração e devem receber prioridade de envio para curadores e emails.
                </p>
              </div>
              <div className="pt-4 border-t border-white/5 text-[10px] text-zinc-500 font-medium font-sans">
                Sugestão Pro: Use a aba ao lado de "Link Analytics" para distribuir os links encurtados de forma limpa e rastreável no YouTube!
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )}

  {activeSubTab === 'links' && (
    <div className="space-y-8 animate-fadeIn font-sans">
      {linksLoading && !linkAnalytics ? (
        <div className="py-20 text-center text-xs text-zinc-500 animate-pulse uppercase tracking-wider font-bold">
          Recuperando registros e cliques dos teus links inteligentes...
        </div>
      ) : (
        <>
                  {/* Top quick stats blocks */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Stat CARD 1: Link clicks */}
                    <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-4 flex flex-col justify-between">
                      <span className="text-[9px] font-bold uppercase tracking-wider text-neutral-500">CLIQUES EM LINKS</span>
                      <div className="mt-2.5">
                        <div className="text-2xl font-black text-white tracking-tight">
                          {linkAnalytics?.totalClicks || 0}
                        </div>
                        <p className="text-[10px] text-zinc-400 mt-1">Cliques no período selecionado</p>
                      </div>
                    </div>
                    {/* Stat CARD 2: Click Growth */}
                    <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-4 flex flex-col justify-between">
                      <span className="text-[9px] font-bold uppercase tracking-wider text-neutral-500">CRESCIMENTO</span>
                      <div className="mt-2.5">
                        <div className={`text-2xl font-black tracking-tight ${(linkAnalytics?.growthPercentage || 0) >= 0 ? 'text-[#5865F2]' : 'text-rose-500'}`}>
                          {(linkAnalytics?.growthPercentage || 0) >= 0 ? '+' : ''}{linkAnalytics?.growthPercentage || 0}%
                        </div>
                        <p className="text-[10px] text-zinc-400 mt-1">Comparado com período anterior</p>
                      </div>
                    </div>
                    {/* Stat CARD 3: Top referrer */}
                    <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-4 flex flex-col justify-between">
                      <span className="text-[9px] font-bold uppercase tracking-wider text-neutral-500">PRINCIPAL ORIGEM</span>
                      <div className="mt-2.5">
                        <div className="text-lg font-black text-zinc-100 truncate">
                          {linkAnalytics?.referrerDistribution?.[0]?.name || 'Nenhuma registrada'}
                        </div>
                        <p className="text-[10px] text-zinc-400 mt-1">canal de entrada com maior conversão</p>
                      </div>
                    </div>
                    {/* Stat CARD 4: Sync control */}
                    <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-4 flex flex-col justify-between">
                      <span className="text-[9px] font-bold uppercase tracking-wider text-neutral-500">SINCRONIZADOR</span>
                      <div className="mt-2">
                        <button
                          type="button"
                          disabled={isSyncing}
                          onClick={async () => {
                            setIsSyncing(true);
                            try {
                              const res = await fetch('/api/short-links/sync', { method: 'POST' });
                              const r = await res.json();
                              if (r.success) {
                                alert(`Sincronização concluída com sucesso:\n- Batidas: ${r.report.beatsSynced}\n- Soundkits: ${r.report.kitsSynced}\n- Perfis: ${r.report.profilesSynced}`);
                                setRefreshTrigger(p => p + 1);
                              } else {
                                alert(`Falha ao sincronizar: ${r.error || 'Erro inesperado'}`);
                              }
                            } catch (e) {
                              alert('Erro ao processar sincronização.');
                            } finally {
                              setIsSyncing(false);
                            }
                          }}
                          className="w-full py-1.5 px-3 bg-zinc-900 border border-white/10 hover:border-amber-500/35 rounded-xl text-[10px] font-black text-white hover:text-amber-500 transition-colors uppercase tracking-wider flex items-center justify-center gap-1.5"
                        >
                          <RefreshCw size={11} className={isSyncing ? 'animate-spin' : ''} />
                          {isSyncing ? 'A Guardar...' : 'Sincronizar Links'}
                        </button>
                        <p className="text-[8px] text-zinc-500 mt-1.5 text-center leading-normal">Cria links para novas batidas e kits retroativamente</p>
                      </div>
                    </div>
                  </div>

                  {/* Layout split: Left Top performance lists, Right donuts devices & referrals */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* Left block (performance lists) */}
                    <div className="lg:col-span-8 space-y-6">
                      {/* Top links performance */}
                      <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-5">
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3.5">Links Mais Acedidos</h4>
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse font-sans text-[11px]">
                            <thead>
                              <tr className="border-b border-white/[0.04]">
                                <th className="pb-3 text-zinc-500 uppercase tracking-widest font-black text-[9px]">Código</th>
                                <th className="pb-3 text-zinc-500 uppercase tracking-widest font-black text-[9px]">Tipo</th>
                                <th className="pb-3 text-zinc-500 uppercase tracking-widest font-black text-[9px] min-w-[200px]">Destino Real</th>
                                <th className="pb-3 text-zinc-500 uppercase tracking-widest font-black text-[9px] text-right">Cliques</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-white/[0.02]">
                              {(linkAnalytics?.linksPerformance || []).length === 0 ? (
                                <tr>
                                  <td colSpan={4} className="py-4 text-center text-zinc-650">Nenhum clique registrado no período selecionado.</td>
                                </tr>
                              ) : (
                                (linkAnalytics.linksPerformance).map((link: any) => (
                                  <tr key={link.id} className="hover:bg-white/[0.01]">
                                    <td className="py-2.5 font-mono font-bold text-amber-500 flex items-center gap-1.5">
                                      {link.code}
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const fullShortUrl = `${window.location.origin}/${link.type === 'profile' ? 'p' : link.type === 'beat' ? 'b' : link.type === 'kit' ? 'k' : 'x'}/${link.code}`;
                                          navigator.clipboard.writeText(fullShortUrl);
                                          alert('Link copiado com sucesso!');
                                        }}
                                        className="text-[9px] text-zinc-500 hover:text-white border border-white/5 rounded px-1.5 py-0.5 bg-[#0a0a0f] font-sans font-normal"
                                      >
                                        Copiar
                                      </button>
                                    </td>
                                    <td className="py-2.5 uppercase font-black text-[9px]">
                                      <span className={`px-2 py-0.5 rounded text-[8px] ${
                                        link.type === 'beat' ? 'bg-[#5865F2]/10 text-[#5865F2]' :
                                        link.type === 'kit' ? 'bg-cyan-500/10 text-cyan-500' :
                                        link.type === 'profile' ? 'bg-purple-500/10 text-purple-500' : 'bg-amber-500/10 text-amber-500'
                                      }`}>
                                        {link.type}
                                      </span>
                                    </td>
                                    <td className="py-2.5 text-zinc-400 max-w-[250px] truncate">{link.target_url}</td>
                                    <td className="py-2.5 text-right text-zinc-100 font-bold">{link.clicks}</td>
                                  </tr>
                                ))
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      {/* Beats & Kits sub lists */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Most Shared Beats */}
                        <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-5">
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Batidas Mais Partilhadas</h4>
                          <div className="space-y-3">
                            {(linkAnalytics?.mostSharedBeats || []).length === 0 ? (
                              <p className="text-[10px] text-zinc-650 py-3 text-center">Nenhum clique em links de batidas.</p>
                            ) : (
                              (linkAnalytics.mostSharedBeats).slice(0, 5).map((b: any) => (
                                <div key={b.id} className="flex justify-between items-center text-[11px] border-b border-white/[0.02] pb-2 last:border-0 last:pb-0">
                                  <span className="font-mono text-zinc-300 font-medium truncate max-w-[150px]">{b.code}</span>
                                  <span className="font-bold text-zinc-100">{b.clicks} <span className="text-[9px] text-zinc-500 font-normal">cliques</span></span>
                                </div>
                              ))
                            )}
                          </div>
                        </div>

                        {/* Most Clicked Kits */}
                        <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-5">
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Soundkits Mais Clicados</h4>
                          <div className="space-y-3">
                            {(linkAnalytics?.mostClickedKits || []).length === 0 ? (
                              <p className="text-[10px] text-zinc-650 py-3 text-center">Nenhum clique em links de soundkits.</p>
                            ) : (
                              (linkAnalytics.mostClickedKits).slice(0, 5).map((k: any) => (
                                <div key={k.id} className="flex justify-between items-center text-[11px] border-b border-white/[0.02] pb-2 last:border-0 last:pb-0">
                                  <span className="font-mono text-zinc-300 font-medium truncate max-w-[150px]">{k.code}</span>
                                  <span className="font-bold text-zinc-100">{k.clicks} <span className="text-[9px] text-zinc-500 font-normal">cliques</span></span>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Right block (demographics referrer and country and device distribution maps) */}
                    <div className="lg:col-span-4 space-y-6">
                      {/* Referrer Traffic network list */}
                      <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-5">
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Fontes de Tráfego</h4>
                        <div className="space-y-3">
                          {(linkAnalytics?.referrerDistribution || []).length === 0 ? (
                            <p className="text-xs text-zinc-650 text-center py-4">Sem fontes registradas.</p>
                          ) : (
                            (linkAnalytics.referrerDistribution).slice(0, 5).map((ref: any, idx: number) => {
                              const total = linkAnalytics.totalClicks || 1;
                              const pct = Math.round((ref.value / total) * 100);
                              return (
                                <div key={idx} className="space-y-1.5">
                                  <div className="flex justify-between text-[11px]">
                                    <span className="font-bold text-zinc-200">{ref.name}</span>
                                    <span className="text-zinc-500 font-medium">{ref.value} clicks ({pct}%)</span>
                                  </div>
                                  <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                                    <div className="h-full bg-amber-500 rounded-full" style={{ width: `${pct}%` }} />
                                  </div>
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>

                      {/* Device breakdown and Countries List */}
                      <div className="bg-[#050505] border border-white/[0.03] rounded-xl p-5 space-y-4">
                        <div>
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Distribuição de Dispositivos</h4>
                          <div className="grid grid-cols-3 gap-2 text-center">
                            {['MOBILE', 'DESKTOP', 'TABLET'].map(dev => {
                              const item = (linkAnalytics?.deviceDistribution || []).find((d: any) => d.name === dev);
                              const value = item ? item.value : 0;
                              return (
                                <div key={dev} className="p-2 border border-white/[0.02] bg-[#020202] rounded-lg">
                                  <p className="text-[8px] font-bold text-neutral-500">{dev}</p>
                                  <p className="text-sm font-black text-white mt-1">{value}</p>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        <div className="border-t border-white/[0.04] pt-4">
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Demografia por Países</h4>
                          <div className="space-y-2.5">
                            {(linkAnalytics?.countryDistribution || []).length === 0 ? (
                              <p className="text-[10px] text-zinc-650 text-center py-2">Sem dados demográficos.</p>
                            ) : (
                              (linkAnalytics.countryDistribution).slice(0, 4).map((cObj: any, idx: number) => {
                                const total = linkAnalytics.totalClicks || 1;
                                const pct = Math.round((cObj.value / total) * 100);
                                return (
                                  <div key={idx} className="flex justify-between items-center text-[11px]">
                                    <span className="text-zinc-300 font-medium">{cObj.name}</span>
                                    <span className="font-bold text-zinc-100">{cObj.value} <span className="text-[9px] text-zinc-500 font-normal">clicks ({pct}%)</span></span>
                                  </div>
                                );
                              })
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      );
    }
