import React, { useState, useEffect } from 'react';
import { getSupabase } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import { Music, Users, DollarSign, Calendar, TrendingUp, AlertCircle, Coins, Shield } from 'lucide-react';
import { motion } from 'motion/react';

interface CollabBeat {
  id: string;
  beat_id: number;
  producer_id: string;
  split_percentage: number;
  created_at: string;
  beats?: {
    id: number;
    title: string;
    cover_url: string;
    artist_name: string;
    price_basic: number;
  };
}

export default function Colaboracoes() {
  const { user } = useAuth();
  const [collabs, setCollabs] = useState<CollabBeat[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [earningsMap, setEarningsMap] = useState<Record<number, number>>({});

  useEffect(() => {
    if (user?.id) {
      loadCollabData();
    }
  }, [user?.id]);

  const loadCollabData = async () => {
    setLoading(true);
    const supabase = getSupabase();
    if (!supabase) {
      setLoading(false);
      return;
    }

    try {
      // 1. Fetch collaborations for this producer
      const res = await fetch(`/api/collabs/producer/${user.id}`);
      const rData = await res.json();
      const collabsList = rData.success ? rData.data : [];
      setCollabs(collabsList);

      // 2. Fetch wallet transactions to calculate accumulated earnings per beat
      const { data: tData } = await supabase
        .from('wallet_transactions')
        .select('*')
        .eq('producer_id', user.id);

      const trans = tData || [];
      setTransactions(trans);

      // Calculate accumulated earnings per beat ID or beat title
      const map: Record<number, number> = {};
      collabsList.forEach((collab: CollabBeat) => {
        if (!collab.beats) return;
        
        // Find transactions corresponding to this collab sale
        const beatTrans = trans.filter((t: any) => {
          // Check for either explicit beat title or beat id if stored
          const isCollabSale = t.transaction_type && t.transaction_type.startsWith('collab_sale:');
          const matchesTitle = t.collab_beat_title && t.collab_beat_title.toLowerCase() === collab.beats?.title.toLowerCase();
          const matchesTypePercentage = isCollabSale && Number(t.transaction_type.split(':')[1]) === Number(collab.split_percentage);
          
          return isCollabSale && matchesTitle;
        });

        const totalEarned = beatTrans.reduce((sum, t) => sum + Number(t.producer_amount || t.amount || 0), 0);
        map[collab.beat_id] = totalEarned;
      });

      setEarningsMap(map);
    } catch (err) {
      console.error('[COLLAB DASHBOARD] Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const totalCollabEarnings = Object.values(earningsMap).reduce((sum, val) => sum + val, 0);

  if (loading) {
    return (
      <div className="p-8 flex flex-col items-center justify-center min-h-[400px]">
        <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-gray-400 text-xs mt-4">A carregar as tuas colaborações...</p>
      </div>
    );
  }

  return (
    <div id="collabs-dashboard-root" className="p-6 space-y-8 max-w-7xl mx-auto pb-24">
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Users className="text-amber-500" size={24} /> Sistema de Colaborações (Collab Splits)
          </h2>
          <p className="text-sm text-gray-400 mt-1">
            Gere as tuas co-produções de beats e acompanha os teus royalties automatizados.
          </p>
        </div>
      </div>

      {/* STATS OVERVIEW */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-[#0B0B0B] border border-white/5 space-y-2">
          <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">Total Colaborações</p>
          <div className="flex items-center justify-between">
            <p className="text-2xl font-bold text-white font-mono">{collabs.length}</p>
            <div className="p-2 bg-amber-500/10 rounded-xl text-amber-500">
              <Music size={20} />
            </div>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-[#0B0B0B] border border-white/5 space-y-2">
          <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">Ganhos de Colab</p>
          <div className="flex items-center justify-between">
            <p className="text-2xl font-bold text-green-500 font-mono">
              +{totalCollabEarnings.toLocaleString('pt-AO')} Kz
            </p>
            <div className="p-2 bg-green-500/10 rounded-xl text-green-500">
              <Coins size={20} />
            </div>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-[#0B0B0B] border border-white/5 space-y-2 col-span-1 sm:col-span-2 md:col-span-1">
          <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">Estado do Sistema</p>
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-white flex items-center gap-1.5">
              <Shield size={16} className="text-emerald-500" /> Royatlies 100% Autónomos
            </p>
            <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-500">
              <TrendingUp size={20} />
            </div>
          </div>
        </div>
      </div>

      {collabs.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 bg-[#0B0B0B] border border-white/5 rounded-2xl text-center space-y-4">
          <div className="p-4 bg-white/5 rounded-full text-gray-400">
            <Users size={32} />
          </div>
          <div className="space-y-1">
            <h4 className="font-bold text-white">Nenhuma colaboração encontrada</h4>
            <p className="text-xs text-gray-400 max-w-md">
              Não estás associado a nenhum beat como colaborador secundário ainda. Quando outro produtor te adicionar nas percentagens de split de um beat, ele aparecerá aqui.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-[#0B0B0B] border border-white/5 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-white/5">
            <h3 className="font-bold text-white text-sm">Histórico de Beats Colaborativos</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/5 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  <th className="py-4 px-6">Beat / Obra</th>
                  <th className="py-4 px-6 text-center">A Tua Percentagem</th>
                  <th className="py-4 px-6 text-right">Ganhos Acumulados</th>
                  <th className="py-4 px-6 text-center">Adicionado Em</th>
                  <th className="py-4 px-6 text-center">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {collabs.map((collab) => {
                  const beat = collab.beats;
                  const coverUrl = beat?.cover_url || '/placeholder_cover.jpg';
                  const beatTitle = beat?.title || 'Beat Inexistente';
                  const artist = beat?.artist_name || 'Produtor Principal';
                  const splitPercent = collab.split_percentage;
                  const earned = earningsMap[collab.beat_id] || 0;
                  const dateStr = new Date(collab.created_at).toLocaleDateString('pt-AO');

                  return (
                    <tr key={collab.id} className="hover:bg-white/[0.02] transition">
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <img
                            src={coverUrl}
                            alt={beatTitle}
                            className="w-12 h-12 rounded-lg object-cover bg-neutral-900 border border-white/5"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=120&auto=format&fit=crop';
                            }}
                          />
                          <div>
                            <p className="font-bold text-white text-xs">{beatTitle}</p>
                            <p className="text-[10px] text-gray-400">Por {artist}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6 text-center">
                        <span className="px-2.5 py-1 bg-amber-500/10 text-amber-500 rounded-full text-xs font-mono font-bold">
                          {splitPercent}%
                        </span>
                      </td>
                      <td className="py-4 px-6 text-right font-mono font-bold text-xs text-green-500">
                        +{earned.toLocaleString('pt-AO')} Kz
                      </td>
                      <td className="py-4 px-6 text-center text-[10px] text-gray-400">
                        {dateStr}
                      </td>
                      <td className="py-4 px-6 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-green-500/10 text-green-500 border border-green-500/20">
                          Ativo (Online)
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* INFO FOOTER CARD */}
      <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 flex gap-3 text-xs text-amber-400 leading-relaxed">
        <AlertCircle size={18} className="shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Como funcionam os pagamentos de colaborações?</span>
          <p className="mt-0.5 text-gray-300">
            Sempre que um beat em que colaboras é comprado, a comissão de 10% da plataforma é descontada e o montante líquido restante é automaticamente dividido com base nos splits configurados e depositado diretamente na tua carteira.
          </p>
        </div>
      </div>
    </div>
  );
}
