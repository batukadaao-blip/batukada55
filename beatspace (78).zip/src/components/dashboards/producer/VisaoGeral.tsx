import React from 'react';
import { 
  TrendingUp, 
  Activity, 
  Music, 
  DollarSign, 
  Play, 
  Heart,
  Plus,
  Package,
  CheckCircle2,
  Users,
  UserPlus,
  MessageSquare,
  Award,
  Eye,
  Calendar,
  ArrowUpRight,
  Zap,
  Volume2,
  ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getSupabase, getPublicUrl } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import { playService } from '../../../lib/playService';
import InstagramLoader from '../../InstagramLoader';
import OnboardingElegante from '../../OnboardingElegante';

export default function VisaoGeral({ artisticName, onAddBeat, onAddKit, onViewProfile }: { artisticName: string, onAddBeat: () => void, onAddKit: () => void, onViewProfile?: () => void }) {
  if (typeof window !== 'undefined') {
    console.count('Dashboard render (VisaoGeral)');
  }
  const [isMounted, setIsMounted] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [beatsList, setBeatsList] = React.useState<any[]>([]);
  const [orderItemsList, setOrderItemsList] = React.useState<any[]>([]);
  const [favsList, setFavsList] = React.useState<any[]>([]);
  const [profileData, setProfileData] = React.useState<any>(null);
  const [realPlaysList, setRealPlaysList] = React.useState<any[]>([]);
  const [stats, setStats] = React.useState({
    totalSales: 0,
    totalRevenue: 0,
    pendingBalance: 0,
    availableBalance: 0,
    totalWithdrawn: 0,
    activeLicenses: 0,
    totalPlays: 0,
    ordersCount: 0,
    likesReceived: 0,
    followers: 0,
  });
  const [trendData, setTrendData] = React.useState<any[]>([]);
  const [revenueData, setRevenueData] = React.useState<any[]>([]);
  const [notificationsList, setNotificationsList] = React.useState<any[]>([]);

  const supabase = getSupabase();
  const { user, profile } = useAuth();
  const userId = user?.id;

  React.useEffect(() => {
    if (profile) {
      setProfileData((prev: any) => prev ? { ...prev, ...profile } : profile);
    }
  }, [profile]);

  const [refreshTrigger, setRefreshTrigger] = React.useState(0);

  React.useEffect(() => {
    setIsMounted(true);
  }, []);

  React.useEffect(() => {
    const handleRefresh = () => {
      console.log('[REALTIME UPDATE] financialMetricsChanged event caught, refreshing dashboard in VisaoGeral...');
      setRefreshTrigger(prev => prev + 1);
    };

    const handleBeatPlay = () => {
      console.log('[REALTIME UPDATE] beatPlayTracked event caught, refreshing dashboard in VisaoGeral...');
      setRefreshTrigger(prev => prev + 1);
    };

    window.addEventListener('financialMetricsChanged', handleRefresh);
    window.addEventListener('beatPlayTracked' as any, handleBeatPlay);

    let bc: BroadcastChannel | null = null;
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        bc = new BroadcastChannel('financial_updates');
        bc.onmessage = (event) => {
          if (event.data === 'refresh') {
            console.log('[REALTIME UPDATE] BroadcastChannel financial_updates message caught, refreshing dashboard in VisaoGeral...');
            setRefreshTrigger(prev => prev + 1);
          }
        };
      } catch (err) {
        console.error('Error starting BroadcastChannel in VisaoGeral:', err);
      }
    }

    return () => {
      window.removeEventListener('financialMetricsChanged', handleRefresh);
      window.removeEventListener('beatPlayTracked' as any, handleBeatPlay);
      if (bc) {
        bc.close();
      }
    };
  }, []);

  React.useEffect(() => {
    async function loadRealMetrics() {
      if (!supabase || !userId) {
        setLoading(false);
        return;
      }

      console.log('DASHBOARD FETCH START');

      try {
        await playService.loadPlayCounts();
      } catch (playErr) {
        console.warn('Error loading play counts in VisaoGeral:', playErr);
      }

      let totalSalesCount = 0;
      let totalRevenue = 0;
      let pendingBalance = 0;
      let availableBalance = 0;
      let totalWithdrawn = 0;
      let activeLicenses = 0;
      let totalPlaysCount = 0;
      let ordersCount = 0;
      let likesCountVal = 0;
      let followersCount = 0;

      const last30Days: Record<string, { plays: number; sales: number }> = {};
      for (let i = 29; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dayStr = date.toLocaleDateString('pt-AO', { day: '2-digit' });
        last30Days[dayStr] = { plays: 0, sales: 0 };
      }

      const last6Months: Record<string, number> = {};
      const monthNames = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
      for (let i = 5; i >= 0; i--) {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        const mKey = `${monthNames[date.getMonth()]} ${date.getFullYear().toString().slice(-2)}`;
        last6Months[mKey] = 0;
      }

      const withTimeout = async (promise: any, timeoutMs = 3000, fallbackValue: any = { data: null, error: null }) => {
        let timeoutId: any;
        const timeoutPromise = new Promise((resolve) => {
          timeoutId = setTimeout(() => {
            console.warn(`Query timed out after ${timeoutMs}ms`);
            resolve(fallbackValue);
          }, timeoutMs);
        });
        try {
          return await Promise.race([Promise.resolve(promise), timeoutPromise]);
        } catch (err) {
          console.error("Query timeout wrapper error:", err);
          return fallbackValue;
        } finally {
          clearTimeout(timeoutId);
        }
      };

      try {
        // Query 1: Fetch beats
        let beatIds: any[] = [];
        let rawBeats: any[] = [];
        try {
          const { data: beatsData, error: beatsError } = await withTimeout(
            supabase.from('beats').select('id, title, category, plays_count, created_at, cover_url, genre, bpm').eq('producer_id', userId)
          );
          if (beatsError) {
            console.log('DASHBOARD FETCH ERROR (beats query):', beatsError);
          } else if (beatsData) {
            rawBeats = beatsData;
            beatIds = beatsData.map((b: any) => b.id);
            setBeatsList(beatsData);
          }
        } catch (err) {
          console.log('DASHBOARD FETCH ERROR (beats exception):', err);
        }

        // Query 2: Fetch order items with orders nested status
        let orderItems: any[] = [];
        try {
          const { data: itemsData, error: itemsError } = await withTimeout(
            supabase.from('order_items').select('id, price, order_id, created_at, beat_id, orders(status, created_at, buyer_id)').eq('producer_id', userId)
          );
          if (itemsError) {
            console.log('DASHBOARD FETCH ERROR (order_items query):', itemsError);
          } else if (itemsData) {
            orderItems = itemsData;
            setOrderItemsList(itemsData);
          }
        } catch (err) {
          console.log('DASHBOARD FETCH ERROR (order_items exception):', err);
        }

        const paidOrderItems = orderItems.filter((item: any) => {
          const s = (item.orders?.status || '').toString().toLowerCase();
          return ['paid', 'completed', 'concluido', 'sucesso'].includes(s);
        });

        const totalSalesAmount = paidOrderItems.reduce((acc: number, item: any) => acc + (parseFloat(item.price) || 0), 0);
        totalSalesCount = paidOrderItems.length;
        const uniqueOrders = new Set(paidOrderItems.map((item: any) => item.order_id));
        ordersCount = uniqueOrders.size;
        activeLicenses = paidOrderItems.length;

        // Query 3: Fetch profile details safely and load wallet values from wallets table
        try {
          const { data: profile, error: profileError } = await withTimeout(
            supabase.from('profiles').select('id, username, city, avatar_url').eq('id', userId).maybeSingle()
          );
          if (profile && !profileError) {
            setProfileData(profile);
          }
        } catch (err) {
          console.log('DASHBOARD FETCH ERROR (basic profiles info exception):', err);
        }

        // Fetch wallet balances from 'wallets' table
        try {
          const { data: wallet, error: walletError } = await withTimeout(
            supabase.from('wallets').select('available_balance, pending_balance, total_earned, total_withdrawn').eq('producer_id', userId).maybeSingle()
          );
          if (wallet && !walletError) {
            pendingBalance = parseFloat(wallet.pending_balance) || 0;
            availableBalance = parseFloat(wallet.available_balance) || 0;
            totalWithdrawn = parseFloat(wallet.total_withdrawn) || 0;
            totalRevenue = parseFloat(wallet.total_earned) || 0;
            console.log('WALLETS TABLE SUCCESS:', { pendingBalance, availableBalance, totalWithdrawn, totalRevenue });
          }
        } catch (err) {
          console.log('DASHBOARD FETCH ERROR (wallets table exception):', err);
        }

        // Safe legacy fallback query to profiles table for wallet columns (in case they reside in profiles on some DB builds)
        try {
          const { data: legacyProfile, error: legacyError } = await withTimeout(
            supabase.from('profiles').select('wallet_pending_balance, wallet_available_balance, wallet_total_withdrawn, wallet_total_earned').eq('id', userId).maybeSingle()
          );
          if (legacyProfile && !legacyError) {
            if (pendingBalance === 0) pendingBalance = parseFloat(legacyProfile.wallet_pending_balance) || 0;
            if (availableBalance === 0) availableBalance = parseFloat(legacyProfile.wallet_available_balance) || 0;
            if (totalWithdrawn === 0) totalWithdrawn = parseFloat(legacyProfile.wallet_total_withdrawn) || 0;
            if (totalRevenue === 0) totalRevenue = parseFloat(legacyProfile.wallet_total_earned) || 0;
            console.log('LEGACY PROFILES COLS SUCCESS:', { pendingBalance, availableBalance, totalWithdrawn, totalRevenue });
          }
        } catch (err) {
          console.log('DASHBOARD FETCH INFO (profiles table legacy wallet select bypassed):', err);
        }

        // Final safe fallbacks if totalRevenue is still empty
        if (totalRevenue === 0 && totalSalesAmount > 0) {
          totalRevenue = totalSalesAmount;
        }

        // Query 4: Real database plays count and logs list
        let playsForHistory: any[] = [];
        if (beatIds.length > 0) {
          try {
            // Try fetch from new play_events table
            try {
              const { data: playsEvents } = await supabase
                .from('play_events')
                .select('id, beat_id, created_at')
                .in('beat_id', beatIds);
              if (playsEvents && playsEvents.length > 0) {
                playsForHistory = [...playsEvents];
              }
            } catch (peErr) {
              console.warn("Could not query play_events for overview dashboard:", peErr);
            }

            // Try fetch from old beat_plays table for back compatibility
            try {
              const { data: oldPlays } = await supabase
                .from('beat_plays')
                .select('id, beat_id, created_at')
                .in('beat_id', beatIds);
              if (oldPlays && oldPlays.length > 0) {
                const existingIds = new Set(playsForHistory.map(p => p.id));
                oldPlays.forEach((p: any) => {
                  if (!existingIds.has(p.id)) {
                    playsForHistory.push(p);
                  }
                });
              }
            } catch (bpErr) {
              console.warn("Could not query beat_plays for overview dashboard:", bpErr);
            }

            setRealPlaysList(playsForHistory);
            
            const totalPlaysFromBeats = rawBeats.reduce((sum, b) => {
              const liveCount = Number(playService.getPlayCount(b.id, b.plays_count || 0));
              return sum + liveCount;
            }, 0);
            totalPlaysCount = Math.max(playsForHistory.length, totalPlaysFromBeats);
          } catch (e) {
            console.error('Error fetching dynamic plays for dashboard:', e);
          }
        }

        // Query 4.5: Real database followers count
        try {
          const { count: realFollowersCountRes } = await supabase
            .from('followers')
            .select('id', { count: 'exact', head: true })
            .eq('following_id', userId);
          if (realFollowersCountRes !== null) {
            followersCount = realFollowersCountRes;
          }
        } catch (e) {
          console.error('Error fetching dynamic followers for dashboard:', e);
        }

        // Query 5: Favorites (likes received)
        if (beatIds.length > 0) {
          try {
            const queryBeatIds: string[] = [];
            beatIds.forEach((id: any) => {
              const strId = String(id);
              queryBeatIds.push(strId);
              const padded = strId.padStart(12, '0');
              queryBeatIds.push(`00000000-0000-0000-0000-${padded}`);
            });

            const { data: favsData, error: favsError } = await withTimeout(
              supabase.from('favorites').select('beat_id').in('beat_id', queryBeatIds)
            );
            if (favsError) {
              console.log('DASHBOARD FETCH ERROR (favorites query):', favsError);
            } else if (favsData) {
              setFavsList(favsData);
              const stringifiedBeatIds = beatIds.map(String);
              likesCountVal = favsData.filter((fav: any) => {
                const favId = String(fav.beat_id);
                if (stringifiedBeatIds.includes(favId)) return true;
                if (favId.startsWith('00000000-0000-0000-0000-')) {
                  const cleaned = favId.split('-')[4].replace(/^0+/, '');
                  return stringifiedBeatIds.includes(cleaned);
                }
                return false;
              }).length;
            }
          } catch (err) {
            console.log('DASHBOARD FETCH ERROR (favorites exception):', err);
          }
        }

         // Generate sales and real database plays history from loaded records
         if (playsForHistory && playsForHistory.length > 0) {
           try {
             playsForHistory.forEach((play: any) => {
               if (play.created_at) {
                 const playDate = new Date(play.created_at);
                 const ageMs = Date.now() - playDate.getTime();
                 if (ageMs <= 30 * 24 * 3600 * 1000) {
                   const dayStr = playDate.toLocaleDateString('pt-AO', { day: '2-digit' });
                   if (last30Days[dayStr]) {
                     last30Days[dayStr].plays += 1;
                   }
                 }
               }
             });
           } catch (e) {
             console.error('Error calculating dynamic play history inside dashboard:', e);
           }
         }

        paidOrderItems.forEach((item: any) => {
          let dateStr = item.created_at || (item.orders && item.orders.created_at);
          if (dateStr) {
            const saleDate = new Date(dateStr);
            const ageMs = Date.now() - saleDate.getTime();
            if (ageMs <= 30 * 24 * 3600 * 1000) {
              const dayStr = saleDate.toLocaleDateString('pt-AO', { day: '2-digit' });
              if (last30Days[dayStr]) {
                last30Days[dayStr].sales += 1;
              }
            }
          }
        });

        // Generate Monthly Revenue History
        paidOrderItems.forEach((item: any) => {
          let dateStr = item.created_at || (item.orders && item.orders.created_at);
          if (dateStr) {
            const saleDate = new Date(dateStr);
            const mKey = `${monthNames[saleDate.getMonth()]} ${saleDate.getFullYear().toString().slice(-2)}`;
            if (last6Months[mKey] !== undefined) {
              last6Months[mKey] += parseFloat(item.price) || 0;
            }
          }
        });

        // Query notifications for recent comments, follows, with limit 10
        try {
          const { data: notificationsData } = await supabase
            .from('notifications')
            .select('*')
            .eq('user_id', userId)
            .order('created_at', { ascending: false })
            .limit(10);
          if (notificationsData) {
            setNotificationsList(notificationsData);
          }
        } catch (notifErrAll) {
          console.error('[ACTIVITIES FETCH] Error fetching notifications:', notifErrAll);
        }

      } catch (err) {
        console.log('DASHBOARD FETCH ERROR (outer exception):', err);
      } finally {
        setStats({
          totalSales: totalSalesCount,
          totalRevenue,
          pendingBalance,
          availableBalance,
          totalWithdrawn,
          activeLicenses,
          totalPlays: totalPlaysCount,
          ordersCount,
          likesReceived: likesCountVal,
          followers: followersCount
        });

        const sortedTrend = Object.entries(last30Days).map(([day, val]) => ({
          day,
          plays: val.plays, 
          sales: val.sales
        }));
        setTrendData(sortedTrend);

        const sortedRevenue = Object.entries(last6Months).map(([month, rev]) => ({
          month,
          revenue: rev
        }));
        setRevenueData(sortedRevenue);

        setLoading(false);
        console.log('DASHBOARD FETCH COMPLETE');
      }
    }
    
    if (isMounted && userId) {
      loadRealMetrics();
    }
  }, [isMounted, userId, refreshTrigger]);

  // Compute stats per beat to find top-performing ones
  const computedBeats = React.useMemo(() => {
    return beatsList.map(beat => {
      // Plays from real database logs list with fallback to playService/atomic plays_count
      const playsCount = Math.max(
        realPlaysList.filter((play: any) => String(play.beat_id) === String(beat.id)).length,
        Number(playService.getPlayCount(beat.id, beat.plays_count || 0))
      );

      // Sales
      const beatSales = orderItemsList.filter((item: any) => item.beat_id === beat.id);
      const salesCount = beatSales.length;
      const revenue = beatSales.reduce((acc: number, item: any) => acc + (parseFloat(item.price) || 0), 0);

      const coverUrl = beat.cover_url ? getPublicUrl('beats', beat.cover_url) : 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=100';

      const stringifiedId = String(beat.id);
      const likesCount = favsList.filter((fav: any) => {
        const favId = String(fav.beat_id);
        if (favId === stringifiedId) return true;
        if (favId.startsWith('00000000-0000-0000-0000-')) {
          const cleaned = favId.split('-')[4].replace(/^0+/, '');
          return cleaned === stringifiedId;
        }
        return false;
      }).length;

      return {
        id: beat.id,
        title: beat.title,
        genre: beat.genre || 'Desconhecido',
        plays: playsCount,
        likes: likesCount,
        sales: salesCount,
        revenue: revenue,
        cover: coverUrl,
        bpm: beat.bpm || 120
      };
    }).sort((a, b) => (b.revenue * 5 + b.plays) - (a.revenue * 5 + a.plays)).slice(0, 4);
  }, [beatsList, orderItemsList, favsList, realPlaysList]);

  // Create standard Activity elements
  const activities = React.useMemo(() => {
    // Real sales
    const realSales = orderItemsList.map((item: any) => {
      const bDetail = beatsList.find(b => b.id === item.beat_id);
      const beatName = bDetail?.title || 'Instrumental';
      const createdTime = item.orders?.created_at || item.created_at;
      const coverUrl = bDetail?.cover || '';
      
      return {
        id: `real-sale-${item.id}`,
        type: 'sale',
        user: `Iniciais #${item.order_id?.slice(-4).toUpperCase() || 'VIP'}`,
        detail: `comprou o instrumental`,
        target: beatName,
        time: createdTime ? new Date(createdTime).toLocaleDateString('pt-AO', { day: '2-digit', month: '2-digit' }) : 'Recente',
        icon: DollarSign,
        color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
        timestamp: createdTime ? new Date(createdTime).getTime() : 0,
        avatar: '',
        cover: coverUrl
      };
    });

    // Real uploads
    const realUploads = beatsList.map((beat: any) => {
      const userPhoto = profileData?.avatar_url || user?.user_metadata?.avatar_url || undefined;
      const coverUrl = beat.cover || '';

      return {
        id: `real-upload-${beat.id}`,
        type: 'upload',
        user: artisticName || 'Tu',
        detail: `publicou o instrumental`,
        target: beat.title,
        time: beat.created_at ? new Date(beat.created_at).toLocaleDateString('pt-AO', { day: '2-digit', month: '2-digit' }) : 'Recente',
        icon: Music,
        color: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
        timestamp: beat.created_at ? new Date(beat.created_at).getTime() : 0,
        avatar: userPhoto,
        cover: coverUrl
      };
    });

    // Real likes (favorites)
    const beatIdsStr = beatsList.map(b => String(b.id));
    const realLikes = favsList.filter((fav: any) => {
      const favId = String(fav.beat_id);
      if (beatIdsStr.includes(favId)) return true;
      if (favId.startsWith('00000000-0000-0000-0000-')) {
        const cleaned = favId.split('-')[4].replace(/^0+/, '');
        return beatIdsStr.includes(cleaned);
      }
      return false;
    }).map((fav: any, idx: number) => {
      const bDetail = beatsList.find((b: any) => {
        const favId = String(fav.beat_id);
        const beatIdStr = String(b.id);
        if (favId === beatIdStr) return true;
        if (favId.startsWith('00000000-0000-0000-0000-')) {
          const cleaned = favId.split('-')[4].replace(/^0+/, '');
          return cleaned === beatIdStr;
        }
        return false;
      });
      const beatName = bDetail?.title || 'Instrumental';
      const createdTime = fav.created_at;
      const coverUrl = bDetail?.cover || '';

      return {
        id: `real-like-${idx}`,
        type: 'like',
        user: 'Um artista',
        detail: 'guardou nos favoritos o beat',
        target: beatName,
        time: createdTime ? new Date(createdTime).toLocaleDateString('pt-AO', { day: '2-digit', month: '2-digit' }) : 'Recente',
        icon: Heart,
        color: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
        timestamp: createdTime ? new Date(createdTime).getTime() : 0,
        avatar: '',
        cover: coverUrl
      };
    });

    // Real comments, followers and other events from the notifications list
    const mappedNotifications = notificationsList.map((notif: any) => {
      let icon = Activity;
      let colorClass = 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      let titleUser = notif.title || 'Atividade';
      let detailMsg = notif.message || '';
      let detectedBeatTitleValue = '';
      
      const parsedMatch = notif.message?.match(/"([^"]+)"/);
      if (parsedMatch) {
         detectedBeatTitleValue = parsedMatch[1];
      }

      if (notif.type === 'follower' || notif.type === 'follow') {
        icon = UserPlus;
        colorClass = 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      } else if (notif.type === 'like') {
        icon = Heart;
        colorClass = 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      } else if (notif.type === 'comment') {
        icon = MessageSquare;
        colorClass = 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20';
      } else if (notif.type === 'purchase' || notif.type === 'payment') {
        icon = DollarSign;
        colorClass = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      }

      const cleanUserName = titleUser.replace('Novo Comentário! 💬', '').replace('Novo Favorito! ❤️', '').replace('Nova Venda Realizada! 💰', '').trim() || 'Parceiro';

      return {
        id: `notif-act-${notif.id}`,
        type: notif.type,
        user: cleanUserName,
        detail: detailMsg,
        target: detectedBeatTitleValue,
        time: notif.created_at ? new Date(notif.created_at).toLocaleDateString('pt-AO', { day: '2-digit', month: '2-digit' }) : 'Recente',
        icon,
        color: colorClass,
        timestamp: notif.created_at ? new Date(notif.created_at).getTime() : 0,
        avatar: notif.sender_avatar || notif.avatar_url || '',
        cover: notif.cover_url || ''
      };
    });

    const combined = [...realSales, ...realUploads, ...realLikes, ...mappedNotifications]
      .sort((a, b) => b.timestamp - a.timestamp);
    return combined.slice(0, 7);
  }, [beatsList, orderItemsList, favsList, notificationsList, artisticName, user]);

  // Create standard Sales elements
  const recentSales = React.useMemo(() => {
    const list = orderItemsList.map((item: any) => {
      const bDetail = beatsList.find(b => b.id === item.beat_id);
      return {
        id: item.id,
        beatTitle: bDetail?.title || 'Beat Premium',
        buyer: `Comprador #${item.order_id?.slice(-4) || '9239'}`,
        cover: bDetail?.cover_url ? getPublicUrl('beats', bDetail.cover_url) : 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=50',
        license: 'Licença Básica',
        amount: parseFloat(item.price) || 12000,
        date: item.created_at ? new Date(item.created_at).toLocaleDateString('pt-AO', { day: '2-digit', month: '2-digit' }) : 'Recente'
      };
    });

    return list.slice(0, 4);
  }, [orderItemsList, beatsList]);

  const metricas = [
    { 
      label: 'Faturamento Total', 
      value: `${stats.totalRevenue.toLocaleString('pt-AO')} Kz`, 
      icon: DollarSign,
      color: 'from-zinc-500/5 to-zinc-500/5',
      iconColor: 'text-[#5865F2]',
      tagline: 'Ganhos acumulados'
    },
    { 
      label: 'Saldo Disponível', 
      value: `${stats.availableBalance.toLocaleString('pt-AO')} Kz`, 
      icon: DollarSign,
      color: 'from-zinc-500/5 to-zinc-500/5',
      iconColor: 'text-zinc-400',
      tagline: 'Pronto a retirar'
    },
    { 
      label: 'Seguidores Reais', 
      value: `${stats.followers.toLocaleString('pt-AO')}`, 
      icon: Users,
      color: 'from-zinc-500/5 to-zinc-500/5',
      iconColor: 'text-zinc-400',
      tagline: 'Fãs registados'
    },
    { 
      label: 'Total de Plays', 
      value: `${stats.totalPlays.toLocaleString('pt-AO')}`, 
      icon: Play,
      color: 'from-zinc-500/5 to-zinc-500/5',
      iconColor: 'text-[#5865F2]',
      tagline: 'Reproduções dos beats'
    },
    { 
      label: 'Gostos Recebidos', 
      value: `${stats.likesReceived.toLocaleString('pt-AO')}`, 
      icon: Heart,
      color: 'from-zinc-500/5 to-zinc-500/5',
      iconColor: 'text-zinc-400',
      tagline: 'Reações dos artistas'
    }
  ];

  if (loading) {
    return <InstagramLoader label="A carregar métricas do teu estúdio..." />;
  }

  return (
    <div className="p-6 md:p-8 space-y-8 text-white min-h-screen bg-[#000000]">
      {/* Premium Breadcrumb and Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-white/[0.04]">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-wider text-zinc-500">
            <span>Estúdio</span>
            <span className="text-zinc-700">/</span>
            <span className="text-zinc-300">Visão Geral</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">Painel de Controlo</h1>
        </div>
        <div className="text-right text-zinc-500 text-[10px] font-mono">
          Horário Local: {new Date().toLocaleDateString('pt-AO')}
        </div>
      </div>

      {/* Producer Identity Page Header */}
      <motion.div 
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.15 }}
        className="relative bg-[#050505] border border-white/[0.06] p-4 md:py-4 md:px-5 rounded-xl overflow-hidden hover:border-white/10 transition-all duration-150"
      >
        <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-4 z-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="relative shrink-0">
              {(() => {
                const hasCustomAvatar = !!profileData?.avatar_url && profileData.avatar_url.trim() !== '';
                const initials = artisticName
                  ? artisticName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
                  : 'P';
                
                return hasCustomAvatar ? (
                  <div className="w-[72px] h-[72px] rounded-full border border-white/10 overflow-hidden shadow-sm">
                    <img 
                      src={profileData.avatar_url} 
                      alt={artisticName}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                ) : (
                  <div className="w-[72px] h-[72px] rounded-full bg-white/[0.03] border border-white/10 flex items-center justify-center text-gray-300 font-bold text-lg uppercase shadow-sm">
                    {initials}
                  </div>
                );
              })()}
            </div>

            <div className="space-y-1.5 animate-none">
              <h2 className="text-base md:text-lg font-semibold text-white tracking-tight leading-none mb-0.5">
                {artisticName}
              </h2>
              
              <div className="flex flex-wrap items-center gap-x-1.5 text-xs text-zinc-400 leading-none">
                {profileData?.username && (
                  <span className="text-zinc-500 font-medium">@{profileData.username}</span>
                )}
                <span className="text-zinc-700">•</span>
                <span>{profileData?.city || 'Luanda, Angola'}</span>
              </div>

              {/* STATS IN_LINE */}
              <div className="flex items-center gap-2 text-xs text-zinc-500 pt-0.5 leading-none">
                <span className="flex items-center gap-1 text-zinc-300 font-medium">
                  <span>♫</span>
                  <span>{beatsList.length} {beatsList.length === 1 ? 'Beat' : 'Beats'}</span>
                </span>
                <span className="text-zinc-700">•</span>
                <span className="flex items-center gap-1 text-zinc-300 font-medium font-sans">
                  <span>▷</span>
                  <span>
                    {(() => {
                      const plays = stats.totalPlays || 0;
                      if (plays >= 1000) return (plays / 1000).toFixed(0) + 'K';
                      return plays;
                    })()} {stats.totalPlays === 1 ? 'Play' : 'Plays'}
                  </span>
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto self-stretch md:self-auto">
            {onViewProfile && (
              <button 
                onClick={onViewProfile} 
                type="button"
                className="flex-1 md:flex-initial h-10 px-4 group flex items-center justify-center gap-2 bg-transparent hover:bg-white/[0.04] border border-white/[0.08] text-zinc-300 hover:text-white rounded-lg text-xs font-semibold transition-all duration-200 cursor-pointer"
              >
                <ExternalLink size={13} className="text-zinc-400 group-hover:text-white transition-colors animate-none" />
                Ver Perfil
              </button>
            )}
            <button 
              onClick={onAddKit} 
              type="button"
              className="flex-1 md:flex-initial h-10 px-4 group flex items-center justify-center gap-2 bg-transparent hover:bg-white/[0.04] border border-white/[0.08] text-zinc-300 hover:text-white rounded-lg text-xs font-semibold transition-all duration-200 cursor-pointer"
            >
              <Package size={13} className="text-zinc-400 group-hover:text-white transition-colors animate-none" />
              Subir Kit
            </button>
            <button 
              onClick={onAddBeat} 
              type="button"
              className="flex-1 md:flex-initial h-10 px-4 group flex items-center justify-center gap-2 bg-[#6366f1] hover:bg-[#5254e2] text-white text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer"
            >
              <Plus size={14} className="animate-none" />
              Publicar Beat
            </button>
          </div>
        </div>
      </motion.div>

      {/* Onboarding Guide */}
      <OnboardingElegante role="producer" />

      {/* Stats Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {metricas.map((m, idx) => (
          <motion.div 
            key={m.label} 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.15, delay: idx * 0.02 }}
            className="group relative bg-[#050505] border border-white/[0.06] p-4 rounded-xl transition-all duration-150 hover:border-white/10"
          >
            <div className="relative flex flex-col justify-between h-full space-y-4">
              <div className="flex justify-between items-start">
                <span className="text-zinc-400 text-[9px] font-bold uppercase tracking-wider">{m.label}</span>
                <div className={`p-2 rounded-lg bg-white/[0.02] border border-white/[0.05] ${m.iconColor}`}>
                  <m.icon size={13} />
                </div>
              </div>
              
              <div>
                <p className="text-lg font-bold text-white tracking-tight mb-0.5">{m.value}</p>
                <div className="flex items-center gap-1 text-[9px] text-zinc-500 font-semibold uppercase tracking-wider">
                  <span>{m.tagline}</span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </section>

      {/* Main SaaS Dashboard Columns layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Columns (Col Span 2) */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Quick Operational Actions & Studio Health */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15, delay: 0.05 }}
            className="bg-[#050505] border border-white/[0.06] rounded-xl p-5 md:p-6 space-y-5 relative overflow-hidden hover:border-white/10 transition-all duration-150"
          >
            <div>
              <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <Activity size={16} className="text-[#5865F2]" />
                Centro de Atividade Operacional
              </h3>
              <p className="text-[11px] text-gray-400 mt-0.5">Gestão rápida e optimização das operações do teu catálogo.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white/[0.02] border border-white/[0.06] p-4 rounded-xl flex flex-col justify-between space-y-3">
                <div className="space-y-1">
                  <span className="text-[9px] font-bold text-[#5865F2] uppercase tracking-wider block">Estado do Catálogo</span>
                  <p className="text-sm font-bold text-white">{beatsList.length} Beats Publicados</p>
                  <p className="text-[11px] text-gray-400 leading-normal">Os teus instrumentos estão catalogados e visíveis no marketplace oficial e perfil público.</p>
                </div>
                <button 
                  onClick={onAddBeat}
                  className="text-xs font-bold text-white bg-white/5 hover:bg-white/10 px-3.5 py-2 rounded-lg transition-all w-fit flex items-center gap-1 cursor-pointer"
                >
                  <Plus size={12} /> Publicar Mais Instrumentais
                </button>
              </div>

              <div className="bg-white/[0.02] border border-white/[0.06] p-4 rounded-xl flex flex-col justify-between space-y-3">
                <div className="space-y-1">
                  <span className="text-[9px] font-bold text-amber-500 uppercase tracking-wider block">Kits de Som</span>
                  <p className="text-sm font-bold text-white">{beatsList.filter(b => b.category === 'kit').length || '0'} Sound Kits Ativos</p>
                  <p className="text-[11px] text-gray-400 leading-normal">Oferecer loops ou kits de som é uma das melhores formas de engajar outros produtores da comunidade.</p>
                </div>
                <button 
                  onClick={onAddKit}
                  className="text-xs font-bold text-white bg-white/5 hover:bg-white/10 px-3.5 py-2 rounded-lg transition-all w-fit flex items-center gap-1 cursor-pointer"
                >
                  <Package size={12} className="text-amber-500" /> Subir Sound Kit de Bateria
                </button>
              </div>
            </div>

            <div className="bg-white/[0.02] border border-white/[0.06] p-4 rounded-xl flex items-start gap-4">
              <div className="p-2 bg-white/[0.04] border border-white/[0.08] rounded-lg text-zinc-400 shrink-0 mt-0.5">
                <Zap size={13} />
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-white tracking-tight">Análise completa de retargeting disponível</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Queres ver estatísticas detalhadas de reproduções diárias, downloads de demos, conversão por beat e audiência geográfica? Navega até ao separador <span className="text-white font-bold">"Analytics"</span> no menu lateral para visualizar relatórios profissionais de performance.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Top Performing Beats */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15, delay: 0.05 }}
            className="bg-[#050505] border border-white/[0.06] rounded-xl p-5 md:p-6 space-y-4 hover:border-white/10 transition-all duration-150"
          >
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                  <Zap size={16} className="text-[#5865F2]" />
                  Beats Mais Populares
                </h3>
                <p className="text-[11px] text-gray-400 mt-0.5">Instrumentais com maior engajamento</p>
              </div>
            </div>

            {computedBeats.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 text-center border border-dashed border-white/5 rounded-lg bg-white/[0.01]">
                <Volume2 size={24} className="text-gray-600 mb-2" />
                <p className="text-xs font-bold text-white mb-0.5">Nenhum beat elegível</p>
                <p className="text-[11px] text-gray-500">Publica novos beats para começar a carregar estatísticas populares.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {computedBeats.map((b) => (
                  <div key={b.id} className="group flex items-center gap-4 bg-white/[0.02] border border-white/5 hover:border-white/10 p-3 rounded-xl transition-all duration-300">
                    <img 
                      src={b.cover || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=120&auto=format&fit=crop&q=60'} 
                      alt={b.title} 
                      loading="lazy"
                      decoding="async"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=120&auto=format&fit=crop&q=60';
                      }}
                      className="w-12 h-12 object-cover rounded-lg border border-white/5"
                    />
                    <div className="flex-grow min-w-0">
                      <h4 className="text-sm font-bold text-white truncate group-hover:text-[#5865F2] transition-colors">{b.title}</h4>
                      <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider mt-0.5">{b.genre} • {b.bpm} BPM</p>
                    </div>
                    <div className="text-right flex flex-col items-end gap-1">
                      <span className="text-[10px] font-bold uppercase bg-blue-500/10 text-[#5865F2] px-2 py-0.5 rounded-full">
                        {b.plays} plays
                      </span>
                      <span className="text-[10px] font-semibold text-gray-400">
                        {b.likes} gostos
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>

          {/* Recent Sales Section */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15, delay: 0.1 }}
            className="bg-[#050505] border border-white/[0.06] rounded-xl p-5 md:p-6 space-y-4 hover:border-white/10 transition-all duration-150"
          >
            <div>
              <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <DollarSign size={16} className="text-[#5865F2]" />
                Vendas Recentes
              </h3>
              <p className="text-[11px] text-gray-400 mt-0.5">As transações mais recentes do teu portfólio</p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[500px]">
                <thead>
                  <tr className="border-b border-white/5 text-[10px] font-bold uppercase tracking-wider text-gray-500">
                    <th className="pb-3 text-left">Beat / Instrumental</th>
                    <th className="pb-3 text-left">Comprador</th>
                    <th className="pb-3 text-left">Tipo Licença</th>
                    <th className="pb-3 text-right">Valor Ganhado</th>
                    <th className="pb-3 text-right">Data</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {recentSales.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-10 text-center text-gray-400 text-xs text-center">
                        <div className="flex flex-col items-center justify-center gap-2 py-4">
                          <DollarSign size={20} className="text-gray-600" />
                          <p className="font-bold text-white uppercase tracking-wider text-[10px]">Ainda sem vendas</p>
                          <p className="text-gray-500 text-[11px] max-w-[280px] mx-auto">As transações de licenciamento do teu catálogo de beats aparecerão aqui.</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    recentSales.map((s) => (
                      <tr key={s.id} className="group hover:bg-white/[0.01] transition-all">
                        <td className="py-3 flex items-center gap-3">
                          <img 
                            src={s.cover || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=80&auto=format&fit=crop&q=60'} 
                            alt={s.beatTitle} 
                            loading="lazy"
                            decoding="async"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=80&auto=format&fit=crop&q=60';
                            }}
                            className="w-8 h-8 object-cover rounded-lg border border-white/5 text-[10px]" 
                          />
                          <span className="text-xs font-semibold text-white group-hover:text-[#5865F2] transition-colors">{s.beatTitle}</span>
                        </td>
                        <td className="py-3 text-xs text-gray-300">
                          {s.buyer}
                        </td>
                        <td className="py-3">
                          <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                            s.license.includes('Exclusiva') 
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/15'
                              : s.license.includes('Premium')
                              ? 'bg-blue-500/10 text-blue-400 border border-blue-500/15'
                              : 'bg-amber-500/10 text-amber-500 border border-amber-500/15'
                          }`}>
                            {s.license}
                          </span>
                        </td>
                        <td className="py-3 text-xs font-bold text-right text-blue-400">
                          +{s.amount.toLocaleString()} Kz
                        </td>
                        <td className="py-3 text-xs font-medium text-gray-500 text-right">
                          {s.date}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </motion.div>

        </div>

        {/* Right Columns (Col Span 1) */}
        <div className="space-y-8">
          
          {/* Recent Activity Feed */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15, delay: 0.08 }}
            className="bg-[#050505] border border-white/[0.06] rounded-xl p-5 md:p-6 space-y-4 relative overflow-hidden flex flex-col justify-between hover:border-white/10 transition-all duration-150"
          >
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                  <Activity size={16} className="text-[#5865F2]" />
                  Atividade do Estúdio
                </h3>
                <p className="text-[11px] text-zinc-400 mt-0.5">Eventos em tempo real na Batukada</p>
              </div>

              <div className="space-y-3.5 relative">
                {/* Visual connecting thread line for timeline */}
                {activities.length > 0 && (
                  <div className="absolute left-[20px] top-6 bottom-6 w-[1.5px] bg-white/5" />
                )}

                {activities.length === 0 ? (
                  <div className="flex flex-col items-center justify-center p-8 text-center border border-dashed border-white/5 rounded-xl bg-white/[0.005]">
                    <Activity size={20} className="text-gray-600 mb-1" />
                    <p className="text-xs font-bold text-gray-400">Ainda sem atividade.</p>
                    <p className="text-[10px] text-gray-500 max-w-[200px] mx-auto mt-1 leading-normal">
                      Os uploads, gostos e vendas do teu estúdio aparecerão aqui em tempo real.
                    </p>
                  </div>
                ) : (
                  activities.map((act) => {
                    const ActIcon = act.icon || Activity;
                    return (
                      <div key={act.id} className="flex gap-3 items-center justify-between group bg-white/[0.01] hover:bg-white/[0.02] border border-transparent p-1.5 px-2 rounded-xl transition-all duration-300">
                        <div className="flex gap-3 items-center min-w-0">
                          {/* Left visual layer: Avatar and mini badge */}
                          <div className="relative shrink-0 select-none">
                            {act.avatar && act.avatar.startsWith('http') && !act.avatar.includes('photo-1') ? (
                              <img 
                                src={act.avatar} 
                                alt="user profile" 
                                className="w-10 h-10 rounded-full object-cover border border-white/10"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded-full bg-purple-600/[0.15] border border-purple-500/20 flex items-center justify-center text-[10px] font-bold text-[#5865F2] uppercase">
                                {act.user ? act.user.replace('Iniciais #', '#').split(' ').map((w: string) => w[0] || '').join('').slice(0, 2).toUpperCase() : 'US'}
                              </div>
                            )}
                            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded bg-zinc-800 border border-white/10 flex items-center justify-center text-white font-bold">
                              <ActIcon size={8} />
                            </div>
                          </div>

                          {/* Content */}
                          <div className="min-w-0">
                            <p className="text-xs text-gray-300 font-medium leading-snug">
                              <span className="font-bold text-white text-xs">{act.user}</span>{' '}
                              <span className="text-gray-400">{act.detail}</span>{' '}
                              {act.target && (
                                <span className="text-[#5865F2] font-semibold">{`"${act.target}"`}</span>
                              )}
                            </p>
                            <p className="text-[9px] text-gray-500 font-bold uppercase tracking-wider mt-0.5">{act.time}</p>
                          </div>
                        </div>

                        {/* Right: mini cover if type supports beat references */}
                        {act.cover ? (
                          <div className="shrink-0 w-8 h-8 rounded-lg overflow-hidden border border-white/5 relative shadow group-hover:scale-105 transition-transform">
                            <img 
                              src={act.cover || undefined} 
                              alt="beat cover" 
                              className="w-full h-full object-cover" 
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        ) : (
                          ['sale', 'upload', 'like'].includes(act.type || '') && (
                            <div className="shrink-0 w-8 h-8 rounded-lg overflow-hidden border border-white/5 bg-white/[0.02] flex items-center justify-center shadow">
                              <Music size={10} className="text-gray-600" />
                            </div>
                          )
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-white/5 text-center mt-4">
              <span className="text-[9px] font-bold uppercase text-gray-500 tracking-wider">Sincronização Ativa</span>
            </div>
          </motion.div>

          {/* Tips / Interactive Creator card */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15, delay: 0.12 }}
            className="bg-[#050505] border border-white/[0.06] p-6 rounded-xl relative overflow-hidden space-y-4 hover:border-white/10 transition-all duration-150"
          >
            <div className="w-10 h-10 bg-blue-500/10 text-[#5865F2] flex items-center justify-center rounded-xl font-bold border border-blue-500/20">
              <Volume2 size={18} />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-white tracking-tight leading-snug">
                É hora de produzir o próximo hit!
              </h3>
              <p className="text-xs text-zinc-400 font-medium leading-relaxed">
                Produtores ativos que postam beats semanalmente recebem 4x mais recomendações na home page da Batukada.
              </p>
            </div>

            <button 
              onClick={onAddBeat}
              type="button"
              className="w-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold uppercase tracking-wider text-[10px] py-3 rounded-lg transition-all duration-150 text-center cursor-pointer"
            >
              Publicar Agora
            </button>
          </motion.div>

          {/* Quick promotion state */}
          <div className="bg-[#050505] border border-white/[0.06] p-5 rounded-xl flex items-center gap-4 hover:border-white/10 transition-all duration-150">
            <div className="w-10 h-10 bg-blue-500/10 flex items-center justify-center text-[#5865F2] rounded-xl shrink-0">
              <Zap size={18} />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Aumenta a tua exposição</h4>
              <p className="text-[10px] text-gray-400 font-medium leading-normal">
                Beats com tags correspondentes aparecem 3x mais nos rankings automáticos.
              </p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
