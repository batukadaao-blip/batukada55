
import React, { useEffect, useState } from 'react';
import { BarChart, TrendingUp, Download, Heart, DollarSign, ArrowLeft } from 'lucide-react';
import { getSupabase } from '@/src/lib/supabase';
import { playService } from '../../../lib/playService';

export default function EstatisticasBeat({ beatId, onBack }: { beatId: string, onBack: () => void }) {
  const [beat, setBeat] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [statsData, setStatsData] = useState({
    plays: 0,
    likes: 0,
    downloads: 0,
    vendas: 0,
  });

  useEffect(() => {
    async function loadStats() {
      const supabase = getSupabase();
      if (!supabase) {
        setLoading(false);
        return;
      }
      
      const { data, error } = await supabase.from('beats').select('title, plays_count').eq('id', beatId).maybeSingle();
      if (data) {
        setBeat(data);
      }

      // 1. Vendas
      const { data: orderItemData } = await supabase
        .from('order_items')
        .select('id, orders(status)')
        .eq('beat_id', beatId);
      const vendasCount = orderItemData
        ? orderItemData.filter((item: any) =>
            ['paid', 'completed', 'concluido', 'sucesso'].includes(String(item.orders?.status || '').toLowerCase())
          ).length
        : 0;

      // 2. Downloads
      const { data: purchaseData } = await supabase
        .from('purchased_beats')
        .select('id')
        .eq('beat_id', beatId);
      const downloadsCount = purchaseData ? purchaseData.length : 0;

      // 3. Likes
      let likesCount = 0;
      const strBeatId = String(beatId);
      const paddedId = strBeatId.padStart(12, '0');
      const uuidBeatId = `00000000-0000-0000-0000-${paddedId}`;

      const { data: favsData } = await supabase
        .from('favorites')
        .select('beat_id')
        .in('beat_id', [strBeatId, uuidBeatId]);
      if (favsData) {
        const targetIdStr = String(beatId);
        likesCount = favsData.filter((fav: any) => {
          const mId = String(fav.beat_id);
          if (mId === targetIdStr) return true;
          if (mId.startsWith('00000000-0000-0000-0000-')) {
            const cleaned = mId.split('-')[4].replace(/^0+/, '');
            return cleaned === targetIdStr;
          }
          return false;
        }).length;
      }

      // 4. Plays
      let playsCount = 0;
      try {
        await playService.loadPlayCounts();
        playsCount = Number(playService.getPlayCount(beatId, data?.plays_count || 0));
      } catch (e) {
        console.warn('Error fetching play count in EstatisticasBeat:', e);
        playsCount = Number(data?.plays_count || 0);
      }

      setStatsData({
        plays: playsCount,
        likes: likesCount,
        downloads: downloadsCount,
        vendas: vendasCount,
      });

      setLoading(false);
    }
    loadStats();
  }, [beatId]);

  if (loading) return <div className="p-8 text-white">Carregando estatísticas...</div>;
  if (!beat) return <div className="p-8 text-white">Beat não encontrado</div>;

  const stats = [
    { label: 'Plays', value: statsData.plays.toLocaleString(), icon: TrendingUp, color: 'text-blue-500' },
    { label: 'Likes', value: statsData.likes.toLocaleString(), icon: Heart, color: 'text-red-500' },
    { label: 'Downloads', value: statsData.downloads.toLocaleString(), icon: Download, color: 'text-green-500' },
    { label: 'Vendas', value: statsData.vendas.toLocaleString(), icon: DollarSign, color: 'text-yellow-500' },
  ];

  return (
    <div className="p-6 md:py-8 md:pr-10 md:pl-4 space-y-6">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-gray-900 dark:hover:text-white mb-4">
            <ArrowLeft size={20} /> Voltar aos Beats
        </button>
      <header className="flex justify-between items-center">
        <h2 className="text-3xl font-black">Estatísticas: <span className="text-gray-500">{beat.title}</span></h2>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map(stat => (
            <div key={stat.label} className="bg-white dark:bg-[#111] border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                    <stat.icon className={stat.color} size={24} />
                    <span className="font-bold text-gray-400">{stat.label}</span>
                </div>
                <div className="text-3xl font-black">{stat.value}</div>
            </div>
        ))}
      </div>
    </div>
  );
}
