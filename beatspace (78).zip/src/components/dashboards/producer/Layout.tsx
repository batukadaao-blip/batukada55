import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Music, DollarSign, Wallet, Settings as SettingsIcon, Moon, Sun, Package, TrendingUp, Users, Percent } from 'lucide-react';
import VisaoGeral from './VisaoGeral';
import MeusBeats from './MeusBeats';
import MeusKits from './MeusKits';
import EstatisticasBeat from './EstatisticasBeat';
import Vendas from './Vendas';
import Carteira from './Carteira';
import Colaboracoes from './Colaboracoes';
import DefinicoesConta from './DefinicoesConta';
import AdicionarBeatModal from './AdicionarBeatModal';
import AdicionarKitModal from './AdicionarKitModal';
import AnalyticsPremium from './AnalyticsPremium';
import Promocao from './Promocao';
import { useDarkMode } from '@/src/lib/useDarkMode';
import { useAuth } from '../../../context/AuthContext';
import { getSupabase } from '../../../lib/supabase';
import { mapDbToClient } from '../../../lib/profileMapper';

export default function ProducerDashboardLayout({ onSelectProducer }: { onSelectProducer?: (name: string) => void }) {
  console.log('PARENT COMPONENT RENDER');
  const { user, profile: authProfile, setProfile: setAuthProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('Visão Geral');
  const [selectedBeatId, setSelectedBeatId] = useState<string | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isKitModalOpen, setIsKitModalOpen] = useState(false);
  const [isDarkMode, toggleDarkMode] = useDarkMode();
  const [refreshBeats, setRefreshBeats] = useState(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const profile = React.useMemo<any>(() => {
    if (authProfile) {
      return mapDbToClient(authProfile as any);
    }

    return {
      artisticName: 'Produtor Pro',
      city: 'Luanda',
      phone: '+244 900 000 000',
      yearsExp: '5',
      bio: 'Produtor de Beats focado em Afro Beat e Trap.',
      profilePhotoUrl: '',
      bannerPhotoUrl: '',
      socials: { ig: '', tw: '', yt: '', tiktok: '', web: '' },
      genres: [] as string[]
    };
  }, [authProfile]);

  const setProfile = React.useCallback((value: any) => {
    if (setAuthProfile) {
      setAuthProfile(value);
    }
  }, [setAuthProfile]);

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  // Listen for direct navigation upload triggers from the premium navbar
  useEffect(() => {
    const tab = localStorage.getItem('producer_dashboard_tab');
    if (tab) {
      setActiveTab(tab);
      localStorage.removeItem('producer_dashboard_tab');
    }
  }, []);

  useEffect(() => {
    if (sessionStorage.getItem('trigger_upload_modal') === 'true') {
      sessionStorage.removeItem('trigger_upload_modal');
      setIsUploadModalOpen(true);
    }

    const handleOpenUpload = () => {
      setIsUploadModalOpen(true);
    };

    window.addEventListener('openUploadModal', handleOpenUpload);
    return () => window.removeEventListener('openUploadModal', handleOpenUpload);
  }, []);

  const navItems = [
    { name: 'Visão Geral', icon: LayoutDashboard },
    { name: 'Analytics', icon: TrendingUp },
    { name: 'Meus Beats', icon: Music },
    { name: 'Meus Kits', icon: Package },
    { name: 'Vendas', icon: DollarSign },
    { name: 'Carteira', icon: Wallet },
    { name: 'Colaborações', icon: Users },
    { name: 'Promoções', icon: Percent },
    { name: 'Definições da Conta', icon: SettingsIcon },
  ];

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-[#000000] text-white">
      <AdicionarKitModal 
        isOpen={isKitModalOpen} 
        onClose={() => setIsKitModalOpen(false)}
        onSuccess={() => {
            setIsKitModalOpen(false);
            setToastMessage('Kit de som publicado com sucesso!');
        }}
      />
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-e border-white/5 bg-[#000000] p-6 shrink-0 h-screen sticky top-0">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-white/[0.04] border border-white/[0.08]">
              <img 
                src="https://i.ibb.co/hF1MD85X/20260523-155411.png" 
                className="w-4 h-4 object-contain" 
                referrerPolicy="no-referrer"
                alt="Logo" 
              />
            </div>
            <div>
              <p className="text-xs font-bold tracking-tight text-white mb-0 leading-tight">Batukada</p>
              <p className="text-[9px] font-semibold text-zinc-500 uppercase tracking-widest leading-none">Studio</p>
            </div>
          </div>
          <span className="text-[8px] font-semibold uppercase tracking-wider bg-white/5 border border-white/10 text-zinc-400 px-1.5 py-0.5 rounded">
            Live
          </span>
        </div>

        {/* Small Session Info */}
        <div className="mb-6 p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-zinc-800 border border-white/10 flex items-center justify-center text-xs font-bold text-zinc-300 uppercase shrink-0">
            {profile.artisticName ? profile.artisticName.substring(0, 2).toUpperCase() : 'P'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-black pointer-events-none truncate text-white leading-tight mb-0.5">{profile.artisticName}</p>
            <p className="text-[9px] text-[#5865F2] font-semibold tracking-wider uppercase leading-none">Produtor Verificado</p>
          </div>
        </div>

        <nav className="space-y-1 flex-1">
          {navItems.map((item) => (
            <button
              key={item.name}
              onClick={() => setActiveTab(item.name)}
              className={`flex items-center space-x-3 w-full px-3.5 py-2.5 cursor-pointer rounded-lg transition-all duration-150 group relative ${
                activeTab === item.name 
                  ? 'bg-white/[0.04] text-white font-semibold border-white/[0.08]' 
                  : 'text-zinc-400 hover:text-white hover:bg-white/[0.02]'
              }`}
            >
              {activeTab === item.name && (
                <div className="absolute left-0 top-2 bottom-2 w-1 rounded bg-[#5865F2]" />
              )}
              <item.icon size={15} strokeWidth={activeTab === item.name ? 2.2 : 1.8} className={activeTab === item.name ? 'text-[#5865F2]' : 'text-zinc-500 group-hover:text-white transition-colors'} />
              <span className={`text-[11px] tracking-wide font-medium ${activeTab === item.name ? 'text-white font-bold' : ''}`}>
                {item.name}
              </span>
            </button>
          ))}
        </nav>

        <div className="mt-auto pt-4 border-t border-white/5">
          <button onClick={toggleDarkMode} className="flex items-center space-x-2.5 px-3 py-2.5 cursor-pointer w-full text-zinc-400 hover:text-white rounded-lg hover:bg-white/[0.02] transition-colors">
              {isDarkMode ? <Sun size={15} /> : <Moon size={15} />}
              <span className="font-semibold text-[9px] tracking-wider uppercase">{isDarkMode ? 'Brilho' : 'Escuro'}</span>
          </button>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 bg-[#000000]">
        {activeTab === 'Visão Geral' && (
          <VisaoGeral 
            artisticName={profile.artisticName} 
            onAddBeat={() => setIsUploadModalOpen(true)} 
            onAddKit={() => setIsKitModalOpen(true)} 
            onViewProfile={onSelectProducer ? () => onSelectProducer(profile.artisticName) : undefined}
          />
        )}
        {activeTab === 'Analytics' && <AnalyticsPremium />}
        {activeTab === 'Meus Beats' && (selectedBeatId ? (
            <EstatisticasBeat beatId={selectedBeatId} onBack={() => { setSelectedBeatId(null); setActiveTab('Meus Beats'); }} />
        ) : (
            <div key={refreshBeats}>
              <MeusBeats onAddBeat={() => setIsUploadModalOpen(true)} onSelectEstatisticas={(id) => setSelectedBeatId(id)} />
            </div>
        ))}
        {activeTab === 'Meus Kits' && <MeusKits />}
        {activeTab === 'Vendas' && <Vendas />}
        {activeTab === 'Carteira' && <Carteira />}
        {activeTab === 'Colaborações' && <Colaboracoes />}
        {activeTab === 'Promoções' && <Promocao />}
        {activeTab === 'Definições da Conta' && <DefinicoesConta profile={profile} setProfile={setProfile} />}
        {/* Add other pages here */}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full bg-[#000000]/95 border-t border-white/5 backdrop-blur-xl flex justify-around p-2 pb-6 z-50">
        {navItems.map((item) => (
            <button
                key={item.name}
                onClick={() => setActiveTab(item.name)}
                className={`flex flex-col items-center p-2 transition-all ${
                    activeTab === item.name ? 'text-[#5865F2]' : 'text-gray-500'
                }`}
            >
                <item.icon size={20} strokeWidth={activeTab === item.name ? 2.5 : 2} />
                <span className="text-[9px] font-black uppercase tracking-widest mt-1.5">
                    {item.name === 'Definições da Conta' ? 'Definições' : item.name}
                </span>
            </button>
        ))}
      </nav>

      <AdicionarBeatModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)}
        onSuccess={() => {
            setRefreshBeats(prev => prev + 1);
            setIsUploadModalOpen(false);
            setToastMessage('Beat publicado com sucesso!');
        }}
      />
      {toastMessage && (
        <div className="fixed top-6 right-6 z-[100] animate-in slide-in-from-top-4 fade-in duration-300">
          <div className="bg-[#050505] border border-white/10 text-white px-6 py-4 rounded-xl shadow-lg flex items-center gap-3 backdrop-blur-md">
            <div className="w-5 h-5 rounded-full bg-[#5865F2]/10 flex items-center justify-center text-[#5865F2] shrink-0">
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="#5865F2" strokeWidth={3}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <p className="text-xs font-bold uppercase tracking-wider text-slate-100">{toastMessage}</p>
          </div>
        </div>
      )}
    </div>
  );
}
