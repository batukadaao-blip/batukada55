import React, { useState, useEffect } from 'react';
import { useAuth } from '@/src/context/AuthContext';
import { ShieldCheck, AlertCircle, Save, Loader2, Landmark, CheckCircle, XCircle } from 'lucide-react';

const defaultBanks = [
  "BAI (Banco Angolano de Investimentos)",
  "BFA (Banco de Fomento Angola)",
  "Banco BIC",
  "BPC (Banco de Poupança e Crédito)",
  "Banco Millennium Atlântico (BMA)",
  "Banco Caixa Geral Angola (BCGA)",
  "Banco Económico",
  "BNI (Banco de Negócios Internacional)",
  "Banco Sol",
  "Banco Keve",
  "Standard Bank Angola",
  "BCI (Banco de Comércio e Indústria)",
  "Banco Yetu"
];

const matchBank = (savedName: string): string => {
  if (!savedName) return '';
  const cleanSaved = savedName.trim().toLowerCase();
  
  // Exact match first
  for (const b of defaultBanks) {
    if (b.toLowerCase() === cleanSaved) return b;
  }
  
  // Substring or abbreviation match
  for (const b of defaultBanks) {
    if (b.toLowerCase().includes(cleanSaved) || cleanSaved.includes(b.toLowerCase())) {
      return b;
    }
  }
  
  return savedName; // fallback if completely custom or not matches
};

export default function PayoutSettings() {
  const [bankingInfo, setBankingInfo] = useState({
    full_name: '', 
    bank_name: '', 
    account_number: '', 
    phone: '', 
    swift_bic: '',
    country: 'Angola',
    status: 'pending'
  });
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const { user } = useAuth();

  const showToast = (type: 'success' | 'error', message: string) => {
    console.log(`[TOAST ${type.toUpperCase()}] ${message}`);
    setNotification({ type, message });
    // Auto-dismiss after 4 seconds
    setTimeout(() => {
      setNotification(prev => prev?.message === message ? null : prev);
    }, 4000);
  };

  useEffect(() => {
    async function loadInfo() {
      if (!user) {
        console.log("loadInfo skipped: No authenticated user found yet.");
        return;
      }
      try {
        console.log(`[PayoutSettings] Loading banking info for user: ${user.id}`);
        const response = await fetch(`/api/producer/banking-info/${user.id}`);
        if (response.ok) {
          const data = await response.json();
          if (data) {
            console.log("[PayoutSettings] Banking info loaded successfully from backend:", data);
            setBankingInfo({
              full_name: data.full_name || '',
              bank_name: matchBank(data.bank_name || ''),
              account_number: data.account_number || '',
              phone: data.phone || '',
              swift_bic: data.swift_bic || '',
              country: data.country || 'Angola',
              status: data.status || 'pending'
            });
          } else {
            console.log("[PayoutSettings] Empty response from backend, using default banking info values.");
          }
        } else {
          console.warn("[PayoutSettings] Failed to load banking info, status:", response.status);
        }
      } catch (err) {
        console.error("[PayoutSettings] Exception while loading banking info:", err);
      }
    }
    loadInfo();
  }, [user]);

  const saveInfo = async () => {
    console.log("[PayoutSettings] saveInfo clicked! Current user state:", user);
    if (!user) {
      showToast('error', 'Utilizador não autenticado.');
      return;
    }

    console.log("[PayoutSettings] Current bankingInfo state:", bankingInfo);

    // CLIENT VALIDAÇÃO
    if (!bankingInfo.full_name.trim()) {
      showToast('error', 'Por favor, indique o Nome Completo do Titular.');
      return;
    }
    if (!bankingInfo.bank_name.trim()) {
      showToast('error', 'Por favor, indique o Nome do Banco.');
      return;
    }
    if (!bankingInfo.account_number.trim()) {
      showToast('error', 'Por favor, indique o IBAN ou Número de Conta.');
      return;
    }
    if (!bankingInfo.country.trim()) {
      showToast('error', 'Por favor, selecione o País.');
      return;
    }

    setLoading(true);
    console.log("[PayoutSettings] Set loading to true. Sending request to backend...");

    try {
      const payload = {
        userId: user.id,
        full_name: bankingInfo.full_name,
        bank_name: bankingInfo.bank_name,
        account_number: bankingInfo.account_number,
        phone: bankingInfo.phone,
        swift_bic: bankingInfo.swift_bic,
        country: bankingInfo.country
      };
      
      console.log('[PayoutSettings] POST payload:', payload);
      const response = await fetch('/api/producer/banking-info', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();
      console.log('[PayoutSettings] Backend API Response:', response.status, result);

      if (response.ok && result.success) {
        setBankingInfo(prev => ({
          ...prev,
          status: 'verified',
          full_name: result.data?.full_name || prev.full_name,
          bank_name: result.data?.bank_name ? matchBank(result.data.bank_name) : prev.bank_name,
          account_number: result.data?.account_number || prev.account_number,
          phone: result.data?.phone || prev.phone,
          swift_bic: result.data?.swift_bic || prev.swift_bic,
          country: result.data?.country || prev.country
        }));
        showToast('success', 'Dados bancários guardados com sucesso');
      } else {
        const errorText = result.error || 'Erro desconhecido da API';
        showToast('error', `Erro ao guardar dados bancários: ${errorText}`);
      }
    } catch (err: any) {
      console.error('[PayoutSettings] Network or runtime exception trying to save banking info:', err);
      showToast('error', `Erro de rede ao guardar dados bancários: ${err.message}`);
    } finally {
      setLoading(false);
      console.log("[PayoutSettings] saveInfo request finished. Set loading to false.");
    }
  };

  return (
    <div className="space-y-6 relative">
      {notification && (
        <div className={`absolute top-4 right-4 text-white px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg animate-fade-in-down z-50 ${
          notification.type === 'success' ? 'bg-emerald-600' : 'bg-rose-600'
        }`}>
          {notification.type === 'success' ? <CheckCircle size={14} /> : <XCircle size={14} />}
          <span>{notification.message}</span>
        </div>
      )}

      <header className="flex items-center gap-3 border-b border-white/5 pb-4">
        <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500">
          <Landmark size={20} />
        </div>
        <div>
          <h3 className="text-sm font-black uppercase tracking-wider text-white">Informação para Levantamentos</h3>
          <p className="text-[10px] text-gray-400 mt-0.5">Configura a tua conta de faturação para receber transferências bancárias.</p>
        </div>
      </header>

      {bankingInfo.status !== 'verified' ? (
        <div className="bg-amber-500/5 border border-amber-500/10 p-4 rounded-xl flex items-start gap-3 text-amber-500">
           <AlertCircle className="shrink-0 mt-0.5" size={16} />
           <div className="text-xs space-y-1">
             <p className="font-bold uppercase tracking-wider">Conta sob verificação ({bankingInfo.status || 'pendente'})</p>
             <p className="text-gray-400 leading-relaxed">Os teus dados bancários encontram-se em validação. Completa a verificação para poderes efetuar levantamentos das tuas vendas.</p>
           </div>
        </div>
      ) : (
        <div className="bg-emerald-500/5 border border-emerald-500/10 p-4 rounded-xl flex items-start gap-3 text-emerald-500">
           <ShieldCheck className="shrink-0 mt-0.5" size={16} />
           <div className="text-xs space-y-1">
             <p className="font-bold uppercase tracking-wider">Conta Verificada</p>
             <p className="text-gray-400 leading-relaxed">Os teus dados estão confirmados e aptos para receber pagamentos diretamente em Angola.</p>
           </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Nome Completo do Titular</label>
          <input 
            type="text" 
            placeholder="Ex: João Manuel Francisco" 
            value={bankingInfo.full_name} 
            onChange={e => setBankingInfo({...bankingInfo, full_name: e.target.value})} 
            className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
          />
        </div>

        <div>
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Banco</label>
          <select 
            value={bankingInfo.bank_name} 
            onChange={e => setBankingInfo({...bankingInfo, bank_name: e.target.value})} 
            className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all cursor-pointer"
          >
            <option value="" disabled className="bg-[#06060A] text-gray-500">Selecione o seu banco...</option>
            {[...defaultBanks, ...(bankingInfo.bank_name && !defaultBanks.includes(bankingInfo.bank_name) ? [bankingInfo.bank_name] : [])].map(bank => (
              <option key={bank} value={bank} className="bg-[#06060A] text-white">
                {bank}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">IBAN / Número de Conta</label>
          <input 
            type="text" 
            placeholder="Ex: AO06 0000 0000 0000 0000 0" 
            value={bankingInfo.account_number} 
            onChange={e => setBankingInfo({...bankingInfo, account_number: e.target.value})} 
            className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
          />
        </div>

        <div>
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">Código SWIFT / BIC (Opcional)</label>
          <input 
            type="text" 
            placeholder="Ex: BAIAAOLL" 
            value={bankingInfo.swift_bic} 
            onChange={e => setBankingInfo({...bankingInfo, swift_bic: e.target.value})} 
            className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
          />
        </div>

        <div>
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2 font-mono">Telemóvel Associado (Unitel / Movicel)</label>
          <input 
            type="text" 
            placeholder="Ex: 923 000 000" 
            value={bankingInfo.phone} 
            onChange={e => setBankingInfo({...bankingInfo, phone: e.target.value})} 
            className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all placeholder:text-gray-700"
          />
        </div>

        <div>
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 block mb-2">País da Conta</label>
          <select 
            value={bankingInfo.country} 
            onChange={e => setBankingInfo({...bankingInfo, country: e.target.value})} 
            className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-amber-500 outline-none transition-all cursor-pointer"
          >
            <option value="Angola" className="bg-[#06060A] text-white">Angola</option>
            <option value="Brasil" className="bg-[#06060A] text-white">Brasil</option>
            <option value="Portugal" className="bg-[#06060A] text-white">Portugal</option>
            <option value="Moçambique" className="bg-[#06060A] text-white">Moçambique</option>
            <option value="Cabo Verde" className="bg-[#06060A] text-white">Cabo Verde</option>
            <option value="Outro" className="bg-[#06060A] text-white">Outro</option>
          </select>
        </div>
      </div>

      <div className="border-t border-white/5 pt-6 flex justify-end">
        <button 
          onClick={saveInfo} 
          disabled={loading}
          className="bg-amber-500 hover:bg-amber-400 text-black px-6 py-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 disabled:opacity-50"
        >
          {loading ? (
            <>
              <Loader2 size={14} className="animate-spin" /> Guardando...
            </>
          ) : (
            <>
              <Save size={14}/> Guardar Dados Bancários
            </>
          )}
        </button>
      </div>
    </div>
  );
}
