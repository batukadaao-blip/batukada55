import React, { useState } from 'react';
import { User, Landmark, Shield, Bell, CheckCircle, Info, Key, Smartphone, ToggleLeft, ToggleRight, Radio } from 'lucide-react';
import Settings from './Settings';
import PayoutSettings from './PayoutSettings';

interface Profile {
  artisticName: string;
  city: string;
  phone: string;
  yearsExp: string;
  bio: string;
  profilePhotoUrl?: string;
  bannerPhotoUrl?: string;
  socials: { ig: string; tw: string; tiktok: string; web: string; yt?: string };
  genres?: string[];
  themeAccent?: string;
  username?: string;
}

interface Props {
  profile: Profile;
  setProfile: React.Dispatch<React.SetStateAction<Profile>>;
}

export default function DefinicoesConta({ profile, setProfile }: Props) {
  const [activeParentTab, setActiveParentTab] = useState<'profile' | 'payout' | 'security' | 'notifications'>('profile');

  // Dummy Security States for professional feel & interaction
  const [passwordForm, setPasswordForm] = useState({ current: '', new: '', confirm: '' });
  const [twoFactor, setTwoFactor] = useState(false);
  const [secLoading, setSecLoading] = useState(false);
  const [secSuccess, setSecSuccess] = useState(false);

  // Dummy Notification States for interactive feel & saving preferences local-backed
  const [notifState, setNotifState] = useState({
    salesEmail: true,
    salesSound: true,
    weeklyDigest: false,
    orderSms: false
  });
  const [notifSuccess, setNotifSuccess] = useState(false);

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    setSecLoading(true);
    setTimeout(() => {
      setSecLoading(false);
      setSecSuccess(true);
      setPasswordForm({ current: '', new: '', confirm: '' });
      setTimeout(() => setSecSuccess(false), 3000);
    }, 1200);
  };

  const handleSaveNotifications = () => {
    setNotifSuccess(true);
    setTimeout(() => setNotifSuccess(false), 3000);
  };

  return (
    <div className="p-6 md:py-8 md:pr-10 md:pl-4 space-y-8 max-w-5xl">
      {/* Page Header */}
      <header>
        <h1 className="text-2xl font-black text-white tracking-tight">Definições da Conta</h1>
        <p className="text-zinc-400 mt-1 text-xs">Organiza os teus dados de perfil, preferências de segurança e canais de faturação bancária.</p>
      </header>

      {/* Main Settings Navigation Rail */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        {/* Left Side: Parent Tabs Rail */}
        <div className="space-y-1.5 lg:sticky lg:top-8 p-1">
          <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 px-3 py-1">Definições</p>
          {[
            { id: 'profile', label: 'Editar Perfil', icon: User, desc: 'Nome, biografia, redes e fotos' },
            { id: 'payout', label: 'Dados de Pagamento', icon: Landmark, desc: 'IBAN e bancos em Angola' },
            { id: 'security', label: 'Segurança & Conta', icon: Shield, desc: 'Palavra-passe e acesso 2FA' },
            { id: 'notifications', label: 'Notificações', icon: Bell, desc: 'Sons de venda e emails' }
          ].map(tab => {
            const Icon = tab.icon;
            const isSelected = activeParentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveParentTab(tab.id as any)}
                className={`w-full text-left p-3 rounded-lg flex items-start gap-3 transition-all outline-none cursor-pointer ${
                  isSelected 
                    ? 'bg-[#5865F2] text-white shadow-md' 
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon size={16} className={`shrink-0 mt-0.5 ${isSelected ? 'text-white' : 'text-zinc-500'}`} />
                <div>
                  <p className="text-xs font-bold tracking-tight">{tab.label}</p>
                  <p className={`text-[9px] mt-0.5 leading-tight ${isSelected ? 'text-white/85 font-medium' : 'text-zinc-500'}`}>{tab.desc}</p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Side: Tab Viewports Panel */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* TAB 1: EDIT PROFILE */}
          {activeParentTab === 'profile' && (
            <div className="animate-fade-in">
              <Settings profile={profile} setProfile={setProfile} hideHeader={true} />
            </div>
          )}

          {/* TAB 2: PAYOUT SETTINGS */}
          {activeParentTab === 'payout' && (
            <div className="animate-fade-in">
              <PayoutSettings />
            </div>
          )}

          {/* TAB 3: SECURITY SETTINGS */}
          {activeParentTab === 'security' && (
            <div className="animate-fade-in space-y-6 relative">
              {secSuccess && (
                <div className="absolute top-4 right-4 bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg animate-fade-in-down">
                  <CheckCircle size={14} />
                  <span>Segurança atualizada com sucesso!</span>
                </div>
              )}

              <header className="flex items-center gap-3 border-b border-white/5 pb-4">
                <div className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-zinc-300">
                  <Key size={18} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white tracking-tight">Alterar Palavra-passe</h3>
                  <p className="text-[10px] text-zinc-400 mt-0.5">Mantém o teu painel seguro atualizando as tuas credenciais regularmente.</p>
                </div>
              </header>

              <form onSubmit={handleSaveSecurity} className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block mb-2">Palavra-passe Atual</label>
                  <input 
                    type="password" 
                    placeholder="••••••••" 
                    required
                    value={passwordForm.current}
                    onChange={e => setPasswordForm({ ...passwordForm, current: e.target.value })}
                    className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-[#5865F2] outline-none transition-all placeholder:text-zinc-700"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block mb-2">Nova Palavra-passe</label>
                    <input 
                      type="password" 
                      placeholder="Mínimo 6 caracteres" 
                      required
                      value={passwordForm.new}
                      onChange={e => setPasswordForm({ ...passwordForm, new: e.target.value })}
                      className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-[#5865F2] outline-none transition-all placeholder:text-zinc-700"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block mb-2">Confirmar Nova Palavra-passe</label>
                    <input 
                      type="password" 
                      placeholder="Mínimo 6 caracteres" 
                      required
                      value={passwordForm.confirm}
                      onChange={e => setPasswordForm({ ...passwordForm, confirm: e.target.value })}
                      className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs font-medium text-white focus:border-[#5865F2] outline-none transition-all placeholder:text-zinc-700"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button 
                    type="submit"
                    disabled={secLoading}
                    className="bg-[#5865F2] hover:bg-[#4752C4] text-white px-5 py-2.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
                  >
                    {secLoading ? 'Atualizando...' : 'Atualizar Credenciais'}
                  </button>
                </div>
              </form>

              <div className="border-t border-white/5 pt-6 space-y-4">
                <div className="flex items-center justify-between bg-white/[0.01] border border-white/5 p-4 rounded-xl">
                  <div className="flex gap-3 items-center">
                    <Smartphone className="text-zinc-500" size={20} />
                    <div>
                      <h4 className="text-xs font-bold text-white tracking-tight">Verificação de Dois Passos (2FA)</h4>
                      <p className="text-[9px] text-zinc-500 mt-0.5">Adiciona uma camada extra de segurança à tua conta do estúdio via SMS ou Autenticador.</p>
                    </div>
                  </div>
                  <button 
                    type="button" 
                    onClick={() => setTwoFactor(!twoFactor)}
                    className="text-zinc-400 hover:text-white transition-colors"
                  >
                    {twoFactor ? <ToggleRight size={38} className="text-[#5865F2]" /> : <ToggleLeft size={38} />}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: NOTIFICATIONS SETTINGS */}
          {activeParentTab === 'notifications' && (
            <div className="animate-fade-in space-y-6 relative">
              {notifSuccess && (
                <div className="absolute top-4 right-4 bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg animate-fade-in-down">
                  <CheckCircle size={14} />
                  <span>Preferências de Notificações atualizadas!</span>
                </div>
              )}

              <header className="flex items-center gap-3 border-b border-white/5 pb-4">
                <div className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-zinc-300">
                  <Bell size={18} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white tracking-tight">Preferências de Alerta</h3>
                  <p className="text-[10px] text-zinc-400 mt-0.5">Escolhe como pretendes ser notificado a cada venda na plataforma.</p>
                </div>
              </header>

              <div className="space-y-4">
                {[
                  { key: 'salesEmail', title: 'Alerta de Novas Vendas por Email', desc: 'Recebe uma fatura detalhada no teu email a cada beat ou licença vendida.' },
                  { key: 'salesSound', title: 'Efeito Sonoro de "Nova Venda"', desc: 'Ativa efeito sonoro na aplicação a cada notificação instantânea de compra.' },
                  { key: 'weeklyDigest', title: 'Resumo Estatístico Semanal', desc: 'Recebe um relatório de performance com os teus beats mais ouvidos e lucros da semana.' },
                  { key: 'orderSms', title: 'Aviso SMS de Levantamento Realizado', desc: 'Notificação telefónica quando o teu pedido de levantamento for concluído com sucesso.' }
                ].map(item => (
                  <div key={item.key} className="flex items-center justify-between bg-white/[0.01] border border-white/5 p-4 rounded-xl">
                    <div className="space-y-0.5 pr-4">
                      <h4 className="text-xs font-bold text-white tracking-tight leading-relaxed">{item.title}</h4>
                      <p className="text-[9px] text-zinc-500 leading-normal">{item.desc}</p>
                    </div>
                    <button 
                      type="button"
                      onClick={() => setNotifState({ ...notifState, [item.key]: !notifState[item.key as keyof typeof notifState] })}
                      className="text-zinc-400 hover:text-white transition-colors shrink-0"
                    >
                      {notifState[item.key as keyof typeof notifState] ? (
                        <ToggleRight size={38} className="text-[#5865F2]" />
                      ) : (
                        <ToggleLeft size={38} />
                      )}
                    </button>
                  </div>
                ))}
              </div>

              <div className="border-t border-white/5 pt-6 flex justify-end">
                <button 
                  type="button"
                  onClick={handleSaveNotifications}
                  className="bg-[#5865F2] hover:bg-[#4752C4] text-white px-5 py-2.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md"
                >
                  <CheckCircle size={14} /> Guardar Preferências
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
