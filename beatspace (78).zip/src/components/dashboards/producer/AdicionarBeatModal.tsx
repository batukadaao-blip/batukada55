import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Upload, 
  Music, 
  Loader2, 
  Sparkles, 
  AlertCircle, 
  Headphones, 
  Trash2, 
  FolderArchive, 
  Lock, 
  Check, 
  ChevronRight, 
  ChevronLeft, 
  Eye, 
  Layers, 
  Flame, 
  Activity, 
  HelpCircle,
  FileAudio,
  Coins,
  CheckCircle2,
  Download,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getSupabase, getPublicUrl, isStorageDirectDisabled, setStorageDirectDisabled } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import GenreSelect from '../../GenreSelect';

const GENRES = ['Afro Beat', 'Kuduro', 'Trap', 'R&B', 'Kompa', 'Gospel', 'Semba', 'Kizomba', 'Ghetto Zouk', 'Afrotrap', 'Boom Bap', 'Outro'];
const SUGGESTED_TAGS = ['trap', 'melódico', 'dark', 'lo-fi', 'rnb', 'drill', 'house', 'phonk', 'afrobeat', 'kizomba'];

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  mode?: 'create' | 'edit';
  beatId?: string;
  initialData?: any;
}

const STEPS = [
  { number: 1, name: 'Ficheiros', desc: 'Media & Capa' },
  { number: 2, name: 'Metadados', desc: 'BPM & Estilo' },
  { number: 3, name: 'Preço', desc: 'Licenciamento' },
  { number: 4, name: 'Revisão', desc: 'Rever & Publicar' }
];

export default function AdicionarBeatModal({ 
  isOpen, 
  onClose, 
  onSuccess,
  mode = 'create',
  beatId,
  initialData
}: Props) {
  // Instance tracking to detect remounts
  const instanceId = useMemo(() => Math.random().toString(36).substring(7), []);
  const isSubmittingRef = React.useRef(false);
  
  useEffect(() => {
    if (isOpen) {
      console.log(`[AdicionarBeatModal ${instanceId}] MOUNTED/OPENED`);
    } else {
      isSubmittingRef.current = false;
    }
    return () => {
      if (isOpen) console.log(`[AdicionarBeatModal ${instanceId}] UNMOUNTED/CLOSED`);
      isSubmittingRef.current = false;
    };
  }, [isOpen, instanceId]);

  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [processingFiles, setProcessingFiles] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState('');
  const [bpm, setBpm] = useState('');
  const [scale, setScale] = useState('Maior');
  const [key, setKey] = useState('C');
  const [tags, setTags] = useState<string[]>([]);
  const [prices, setPrices] = useState({ basic: '', premium: '', exclusive: '' });
  const [tagInput, setTagInput] = useState('');

  const [replacedFiles, setReplacedFiles] = useState<{
    master: boolean;
    demo: boolean;
    stems: boolean;
    cover: boolean;
  }>({
    master: false,
    demo: false,
    stems: false,
    cover: false,
  });

  // Collab fields
  const [collaborators, setCollaborators] = useState<any[]>([]);
  const [allProducersList, setAllProducersList] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [producers, setProducers] = useState<any[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);

  // 3. Log search term changes
  useEffect(() => {
    console.log('SEARCH TERM STATE:', searchTerm);
  }, [searchTerm]);

  useEffect(() => {
    console.log('MODAL MOUNTED');
    return () => console.log('MODAL UNMOUNTED');
  }, []);

  useEffect(() => {
    console.log('DROPDOWN OPEN:', showDropdown);
  }, [showDropdown]);

  // 5. searchProducers helper with Supabase query
  const searchProducers = async (term: string) => {
    console.log('SEARCH FUNCTION CALLED');
    const supabase = getSupabase();
    if (!supabase) {
      console.log('SUPABASE RESPONSE: null');
      console.log('SUPABASE ERROR: no connection');
      const matched = allProducersList.filter((p: any) => {
        if (p.id === user?.id) return false;

        // Exclude if both artistic_name and display_name are empty
        if (!p.artistic_name?.trim() && !p.display_name?.trim()) return false;

        const artName = (p.artistic_name || '').toLowerCase();
        const dispName = (p.display_name || '').toLowerCase();
        return artName.includes(term.toLowerCase()) || dispName.includes(term.toLowerCase());
      });
      setProducers(matched);
      setShowDropdown(matched.length > 0);
      console.log('PRODUCERS FOUND:', matched);
      console.log('DROPDOWN OPEN:', matched.length > 0);
      return;
    }

    try {
      console.log('QUERYING PROFILES TABLE');
      const { data, error } = await supabase
        .from('profiles')
        .select('id, display_name, artistic_name, username, email, avatar_url, role')
        .or(`display_name.ilike.%${term}%,artistic_name.ilike.%${term}%`);

      console.log('SUPABASE PRODUCERS RESPONSE:', data);
      console.log('SUPABASE PRODUCERS ERROR:', error);
      console.log('PRODUCERS FOUND:', data);

      if (error) {
        setProducers([]);
        setShowDropdown(false);
        console.log('PRODUCERS FOUND: []');
        console.log('DROPDOWN OPEN: false');
        return;
      }

      console.log('RAW PRODUCERS FROM SUPABASE:', data);
      if (data) {
        data.forEach(p => {
          console.log('PRODUCER RECORD:', {
            id: p.id,
            display_name: p.display_name,
            artistic_name: p.artistic_name,
            username: p.username,
            email: p.email
          });
        });
      }

      const mainProdId = user?.id;

      // Diagnostic logging after each filter step
      const afterCurrentUserFilter = (data || []).filter((p: any) => {
        const keep = p.id !== mainProdId;
        console.log(`CURRENT USER FILTER FOR ${p.display_name || p.artistic_name || p.id}:`, { keep, p_id: p.id, mainProdId });
        return keep;
      });
      console.log('AFTER CURRENT USER FILTER:', afterCurrentUserFilter);

      const afterNameFilter = afterCurrentUserFilter.filter((p: any) => {
        const keep = !!(p.artistic_name?.trim() || p.display_name?.trim());
        console.log(`NAME FILTER FOR ${p.display_name || p.artistic_name || p.id}:`, { keep, artistic_name: p.artistic_name, display_name: p.display_name });
        return keep;
      });
      console.log('AFTER NAME FILTER:', afterNameFilter);

      const afterRoleFilter = afterNameFilter.filter((p: any) => {
        const r = (p.role || '').toLowerCase();
        const keep = r === 'producer' || r === 'seller' || r === 'admin';
        console.log(`ROLE FILTER FOR ${p.display_name || p.artistic_name || p.id}:`, { keep, role: p.role });
        return keep;
      });
      console.log('AFTER ROLE FILTER:', afterRoleFilter);

      // There are no local collaborator exclusion rules in this main search block, but we add the placeholder as requested
      console.log('AFTER COLLABORATOR FILTER:', afterRoleFilter);
      console.log('FINAL FILTERED PRODUCERS:', afterRoleFilter);

      const filtered = (data || []).filter((p: any) => {
        if (p.id === mainProdId) return false;

        // Exclude if both artistic_name and display_name are empty
        if (!p.artistic_name?.trim() && !p.display_name?.trim()) return false;

        const r = (p.role || '').toLowerCase();
        return r === 'producer' || r === 'seller' || r === 'admin';
      });

      setProducers(filtered);
      setShowDropdown(filtered.length > 0);
      console.log('FILTERED PRODUCERS FOUND:', filtered);
      console.log('DROPDOWN OPEN:', filtered.length > 0);
    } catch (err: any) {
      console.log('SUPABASE ERROR:', err);
      setProducers([]);
      setShowDropdown(false);
      console.log('PRODUCERS FOUND: []');
      console.log('DROPDOWN OPEN: false');
    }
  };

  // 4. useEffect that triggers search
  useEffect(() => {
    if (!searchTerm?.trim()) {
      setProducers([]);
      setShowDropdown(false);
      console.log('DROPDOWN OPEN: false');
      return;
    }

    console.log('QUERY STARTING');
    searchProducers(searchTerm);
  }, [searchTerm]);

  const handleAddCollaborator = (producer: any) => {
    // 7. Prevent adding the main producer as secondary collaborator
    if (producer.id === user?.id) {
      alert("Não podes adicionar o produtor principal como colaborador.");
      return;
    }

    // 6. Prevent adding the same producer twice
    const exists = collaborators.some(c => c.producer_id === producer.id);
    if (exists) {
      alert("Este produtor já está adicionado como colaborador.");
      return;
    }

    console.log('SELECTED PRODUCER:', producer);

    const producerName =
      producer.artistic_name?.trim() ||
      producer.display_name?.trim();

    const updated = [
      ...collaborators,
      {
        producer_id: producer.id,
        artistic_name: producerName,
        split_percentage: 0
      }
    ];

    setCollaborators(updated);
    console.log('COLLABORATORS:', updated);

    // Clear search Term
    setSearchTerm('');
    setProducers([]);
    setShowDropdown(false);
    console.log('DROPDOWN OPEN: false');
  };

  useEffect(() => {
    if (isOpen) {
      // Diagnostic check requested by user
      const supabase = getSupabase();
      if (supabase) {
        supabase
          .from('profiles')
          .select('id, display_name, artistic_name, role')
          .limit(20)
          .then(({ data, error }) => {
            console.log('PROFILES FOUND:', data);
            if (error) {
              console.log('DIAGNOSTIC ERROR:', error);
            }
          });
      }

      fetch("/api/collabs/producers")
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            setAllProducersList(data.data || []);
          }
        })
        .catch(err => console.error("Error loading producers for collab splits:", err));
    }
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      if (mode === 'edit' && initialData) {
        setTitle(initialData.title || '');
        setGenre(initialData.genre || '');
        setBpm(initialData.bpm ? String(initialData.bpm) : '');
        setScale(initialData.scale || 'Maior');
        setKey(initialData.key || 'C');
        
        let initialTags = initialData.tags || [];
        const keyTag = initialTags.find((t: string) => t.startsWith('_key:'));
        if (keyTag) setKey(keyTag.split(':')[1]);
        const scaleTag = initialTags.find((t: string) => t.startsWith('_scale:'));
        if (scaleTag) setScale(scaleTag.split(':')[1]);
        
        const filteredTags = initialTags.filter((t: string) => !t.startsWith('_key:') && !t.startsWith('_scale:'));
        setTags(filteredTags);
        
        setPrices({
          basic: initialData.price_basic ? String(initialData.price_basic) : '',
          premium: initialData.price_premium ? String(initialData.price_premium) : '',
          exclusive: initialData.price_exclusive ? String(initialData.price_exclusive) : '',
        });
        
        setIsFreeDownload(initialData.is_free_download || false);
        setFreeDownloadRequiresFollow(initialData.free_download_requires_follow || false);
        setFreeDownloadRequiresComment(initialData.free_download_requires_comment || false);
        setFreeDownloadRequiresEmail(initialData.free_download_requires_email || false);

        setUploadsState({
          master: { file: null, progress: 0, status: 'idle' },
          demo: { file: null, progress: 0, status: 'idle' },
          stems: { file: null, progress: 0, status: 'idle' },
          cover: { file: null, progress: 0, status: 'idle' },
        });

        setReplacedFiles({
          master: false,
          demo: false,
          stems: false,
          cover: false,
        });

        // Fetch current beat collaborators
        fetch(`/api/collabs/beat/${initialData.id}`)
          .then(res => res.json())
          .then(data => {
            if (data.success && data.data && data.data.length > 0) {
              const mapped = data.data.map((c: any) => {
                const producerName =
                  c.profiles?.artistic_name?.trim() ||
                  c.profiles?.display_name?.trim() ||
                  'Produtor';

                return {
                  producer_id: c.producer_id,
                  artistic_name: producerName,
                  split_percentage: Number(c.split_percentage)
                };
              });
              setCollaborators(mapped);
            } else {
              const mainProdName = initialData.artist_name || 'Tu';
              setCollaborators([
                { producer_id: initialData.producer_id || user?.id, artistic_name: `${mainProdName} (Principal)`, split_percentage: 100 }
              ]);
            }
          })
          .catch(err => {
            console.error("Error loading collab list:", err);
            const mainProdName = initialData.artist_name || 'Tu';
            setCollaborators([
              { producer_id: initialData.producer_id || user?.id, artistic_name: `${mainProdName} (Principal)`, split_percentage: 100 }
            ]);
          });
      } else {
        setTitle('');
        setGenre('');
        setBpm('');
        setScale('Maior');
        setKey('C');
        setTags([]);
        setPrices({ basic: '', premium: '', exclusive: '' });
        
        setIsFreeDownload(false);
        setFreeDownloadRequiresFollow(false);
        setFreeDownloadRequiresComment(false);
        setFreeDownloadRequiresEmail(false);

        setUploadsState({
          master: { file: null, progress: 0, status: 'idle' },
          demo: { file: null, progress: 0, status: 'idle' },
          stems: { file: null, progress: 0, status: 'idle' },
          cover: { file: null, progress: 0, status: 'idle' },
        });

        setReplacedFiles({
          master: false,
          demo: false,
          stems: false,
          cover: false,
        });

        if (user) {
          const storedProf = JSON.parse(localStorage.getItem('user_profile') || '{}');
          const myArtName = storedProf.artisticName || storedProf.artistic_name || storedProf.display_name || user?.user_metadata?.artistic_name || user?.email?.split('@')[0] || 'Tu';
          setCollaborators([
            { producer_id: user.id, artistic_name: `${myArtName} (Tu)`, split_percentage: 100 }
          ]);
        }
      }
      setStep(1);
    }
  }, [isOpen, mode, initialData, user]);
  
  const [isFreeDownload, setIsFreeDownload] = useState(false);
  const [freeDownloadRequiresFollow, setFreeDownloadRequiresFollow] = useState(false);
  const [freeDownloadRequiresComment, setFreeDownloadRequiresComment] = useState(false);
  const [freeDownloadRequiresEmail, setFreeDownloadRequiresEmail] = useState(false);

  // Drag and drop states
  const [dragActive, setDragActive] = useState<Record<string, boolean>>({
    cover: false,
    master: false,
    demo: false,
    stems: false
  });
  
  const addTag = (tagToAdd?: string) => {
      const tag = tagToAdd || tagInput;
      if (tag.trim() && tags.length < 3 && !tags.includes(tag.trim().toLowerCase())) {
          setTags([...tags, tag.trim().toLowerCase()]);
          setTagInput('');
      }
  };
  
  const validateAndSetCover = (file: File) => {
    console.log(`[${instanceId}] validateAndSetCover:`, file.name);
    setError(null);
    
    const MAX_FILE_SIZE = 50 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
      const currentSizeMB = (file.size / (1024 * 1024)).toFixed(1);
      setError(`file_size_error:${file.name}:${currentSizeMB}`);
      return;
    }

    if (!file.type.startsWith('image/')) {
        setError('Por favor, selecione uma imagem para a capa.');
        return;
    }

    const img = new Image();
    const objectUrl = URL.createObjectURL(file);
    
    img.onload = () => {
        console.log(`[${instanceId}] Image loaded:`, img.width, 'x', img.height);
        URL.revokeObjectURL(objectUrl);
        
        // Allow a 10% deviation for "squareness"
        const isSquare = Math.abs(img.width - img.height) < (Math.max(img.width, img.height) * 0.1);
        if (!isSquare) {
            setError(`A imagem deve ser aproximadamente quadrada (1:1). Atual: ${img.width}x${img.height}.`);
            return;
        }
        
        console.log(`[${instanceId}] Cover valid, updating state`);
        setUploadsState(prev => ({ 
            ...prev, 
            cover: { file, progress: 0, status: 'ready' } 
        }));
        if (mode === 'edit') {
          setReplacedFiles(prev => ({ ...prev, cover: true }));
        }
    };
    
    img.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        setError('Erro ao processar a imagem da capa.');
    };
    
    img.src = objectUrl;
  };

  interface UploadFileState {
    file: File | null;
    progress: number;
    status: 'idle' | 'ready' | 'uploading' | 'completed';
    speed?: string;
    uploadedSize?: string;
    totalSize?: string;
    timeLeft?: string;
    stageMessage?: string;
  }

  const [uploadsState, setUploadsState] = useState<{
    master: UploadFileState;
    demo: UploadFileState;
    stems: UploadFileState;
    cover: UploadFileState;
  }>({
    master: { file: null, progress: 0, status: 'idle' },
    demo: { file: null, progress: 0, status: 'idle' },
    stems: { file: null, progress: 0, status: 'idle' },
    cover: { file: null, progress: 0, status: 'idle' },
  });

  const isFileLoaded = (key: 'master' | 'demo' | 'stems' | 'cover') => {
    const fileState = uploadsState[key];
    if (fileState.file !== null) return true;
    if (mode === 'edit' && initialData?.[`${key}_url`] && !replacedFiles[key]) return true;
    return false;
  };

  const coverPreviewUrl = useMemo(() => {
    if (uploadsState.cover.file) {
      return URL.createObjectURL(uploadsState.cover.file);
    }
    if (mode === 'edit' && initialData?.cover_url && !replacedFiles.cover) {
      return getPublicUrl('beats', initialData.cover_url);
    }
    return null;
  }, [uploadsState.cover.file, mode, initialData, replacedFiles.cover]);

  // Cleanup helper for blob URLs
  useEffect(() => {
    return () => {
        if (uploadsState.cover.file && coverPreviewUrl) {
          URL.revokeObjectURL(coverPreviewUrl);
        }
    };
  }, [uploadsState.cover.file, coverPreviewUrl]);

  const demoPreviewUrl = useMemo(() => {
    if (uploadsState.demo.file) {
      return URL.createObjectURL(uploadsState.demo.file);
    }
    if (mode === 'edit' && initialData?.demo_url && !replacedFiles.demo) {
      return getPublicUrl('beats', initialData.demo_url);
    }
    return null;
  }, [uploadsState.demo.file, mode, initialData, replacedFiles.demo]);

  useEffect(() => {
    return () => {
        if (uploadsState.demo.file && demoPreviewUrl) {
          URL.revokeObjectURL(demoPreviewUrl);
        }
    };
  }, [uploadsState.demo.file, demoPreviewUrl]);

  const getFileName = (key: 'master' | 'demo' | 'stems' | 'cover') => {
    if (uploadsState[key].file) {
      return uploadsState[key].file.name;
    }
    if (mode === 'edit' && initialData?.[`${key}_url`] && !replacedFiles[key]) {
      const url = initialData[`${key}_url`];
      const parts = url.split('/');
      const lastPart = parts[parts.length - 1] || 'Ficheiro Existente';
      const subParts = lastPart.split('_');
      if (subParts.length >= 3) {
        return subParts.slice(2).join('_');
      }
      return lastPart;
    }
    return 'Não Carregado';
  };

  const handleFileChange = (key: 'master' | 'demo' | 'stems', file: File) => {
    console.log(`[${instanceId}] handleFileChange: ${key} -> ${file.name}`);
    setError(null);
    const MAX_FILE_SIZE = 50 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
      const currentSizeMB = (file.size / (1024 * 1024)).toFixed(1);
      setError(`file_size_error:${file.name}:${currentSizeMB}`);
      return;
    }
    setUploadsState(prev => ({ 
        ...prev, 
        [key]: { file, progress: 0, status: 'ready' } 
    }));
    if (mode === 'edit') {
      setReplacedFiles(prev => ({ ...prev, [key]: true }));
    }
  };

  const removeFile = (key: 'master' | 'demo' | 'stems' | 'cover') => {
    setUploadsState(prev => ({ ...prev, [key]: { file: null, progress: 0, status: 'idle' } }));
    if (mode === 'edit') {
      setReplacedFiles(prev => ({ ...prev, [key]: true }));
    }
  };

  // Drag over / leave handler
  const handleDrag = (e: React.DragEvent, key: string, active: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(prev => ({ ...prev, [key]: active }));
  };

  // Drop handler
  const handleDrop = (e: React.DragEvent, key: 'master' | 'demo' | 'stems' | 'cover') => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(prev => ({ ...prev, [key]: false }));

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      
      const MAX_FILE_SIZE = 50 * 1024 * 1024;
      if (droppedFile.size > MAX_FILE_SIZE) {
        const currentSizeMB = (droppedFile.size / (1024 * 1024)).toFixed(1);
        setError(`file_size_error:${droppedFile.name}:${currentSizeMB}`);
        return;
      }

      if (key === 'cover') {
        validateAndSetCover(droppedFile);
      } else {
        // Simple type verification
        if (key === 'stems' && !droppedFile.name.endsWith('.zip')) {
          setError('O ficheiro Trackout must be formatted as .zip');
          return;
        }
        handleFileChange(key, droppedFile);
      }
    }
  };

  const uploadFileReal = async (
    up: { path: string; file: File; bucket: string; key?: 'master' | 'demo' | 'stems' | 'cover' },
    onProgress: (
      percent: number,
      speed?: string,
      uploadedSize?: string,
      totalSize?: string,
      timeLeft?: string,
      stageMessage?: string
    ) => void
  ): Promise<void> => {
    // Generate and log real connection endpoints
    const fallbackUrl = '/api/storage/upload-chunk';

    console.log('UPLOAD ENGINE INITIALIZATION');
    console.log('FALLBACK URL:', fallbackUrl);

    // Chunked uploader function that is shared
    const runChunkedUpload = async (): Promise<void> => {
      console.log('[CHUNK UPLOAD] Performing chunked upload to server:', up.file.name);
      
      const fileId = crypto.randomUUID();
      const chunkSize = 1024 * 1024; // 1MB chunks for maximum stability over proxy and browser memory limits
      const totalChunks = Math.ceil(up.file.size / chunkSize);
      const startTime = Date.now();

      onProgress(
        0,
        'A iniciar...',
        '0 MB',
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        'Calculando...',
        'A iniciar transferência de segurança...'
      );

      for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
        const start = chunkIndex * chunkSize;
        const end = Math.min(start + chunkSize, up.file.size);
        const chunkBlob = up.file.slice(start, end);
        
        // Convert blob to base64
        const chunkData = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const base64 = reader.result as string;
            resolve(base64);
          };
          reader.onerror = reject;
          reader.readAsDataURL(chunkBlob);
        });

        let response: Response | null = null;
        let attempt = 0;
        const maxAttempts = 5;
        let success = false;
        let lastError: any = null;

        while (attempt < maxAttempts && !success) {
          try {
            if (attempt > 0) {
              console.warn(`[CHUNK RETRY] ChunkIndex ${chunkIndex} attempt ${attempt + 1}/${maxAttempts} in 1500ms...`);
              onProgress(
                -1, // RETRY state trigger
                'A reconectar...',
                `${(start / (1024 * 1024)).toFixed(1)} MB`,
                `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
                'A retomar...',
                `Falha temporária de rede. A tentar novamente (Tentativa ${attempt + 1}/${maxAttempts})...`
              );
              await new Promise(resolve => setTimeout(resolve, 1500));
            }

            const supabase = getSupabase();
            const { data: { session } } = await supabase.auth.getSession();
            const token = session?.access_token;

            response = await fetch(fallbackUrl, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                ...(token ? { 'Authorization': `Bearer ${token}` } : {})
              },
              body: JSON.stringify({
                fileId,
                chunkIndex,
                totalChunks,
                fileName: up.file.name,
                chunkData,
                bucket: up.bucket,
                path: up.path,
                fileType: up.key
              })
            });

            if (response.ok) {
              success = true;
            } else {
              const errBody = await response.json().catch(() => ({}));
              throw new Error(errBody.error || `HTTP ${response.status}`);
            }
          } catch (e: any) {
            lastError = e;
            attempt++;
          }
        }

        if (!success || !response) {
          throw new Error(`Erro de transferência no bloco ${chunkIndex + 1} de ${totalChunks}: ${lastError?.message || lastError}`);
        }

        const resData = await response.json();
        
        // Update progress
        const percent = Math.round(((chunkIndex + 1) / totalChunks) * 100);
        const elapsedMs = Date.now() - startTime;
        const elapsedSeconds = elapsedMs / 1000;
        
        let speedStr = '';
        let timeLeftStr = '';
        
        if (elapsedSeconds > 0) {
          const uploadedBytes = (chunkIndex + 1) * chunkSize;
          const speedBytesSec = uploadedBytes / elapsedSeconds;
          const speedMB = speedBytesSec / (1024 * 1024);
          speedStr = speedMB > 0.1 
            ? `${speedMB.toFixed(1)} MB/s` 
            : `${(speedBytesSec / 1024).toFixed(0)} KB/s`;

          const remainingBytes = up.file.size - uploadedBytes;
          const remainingSeconds = remainingBytes / speedBytesSec;
          if (remainingSeconds > 0) {
            timeLeftStr = remainingSeconds < 60
              ? `${Math.round(remainingSeconds)}s restantes`
              : `${Math.floor(remainingSeconds / 60)}m ${Math.round(remainingSeconds % 60)}s restantes`;
          }
        }

        const uploadedStr = `${(Math.min((chunkIndex + 1) * chunkSize, up.file.size) / (1024 * 1024)).toFixed(1)} MB`;
        const totalStr = `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`;

        onProgress(
          percent,
          speedStr,
          uploadedStr,
          totalStr,
          timeLeftStr,
          `A enviar parte ${chunkIndex + 1}/${totalChunks} (Canal de backup)...`
        );

        if (resData.fileUrl) {
          // Store combined fileUrl in the up object to resolve later
          (up as any).serverUrl = resData.fileUrl;
        }
      }

      onProgress(
        100,
        'Concluído',
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        'Concluído',
        'Transferência de segurança concluída com sucesso!'
      );
    };

    // If file is larger than 30MB, run chunked upload directly!
    if (up.file.size > 30 * 1024 * 1024) {
      console.log('[STORAGE UPLOAD] File larger than 30MB. Doing chunked upload...');
      await runChunkedUpload();
      return;
    }

    console.log('[STORAGE UPLOAD] Proxy Upload Starting:', {
      bucket: up.bucket,
      path: up.path,
      size: up.file.size
    });

    onProgress(
      10, 
      'A iniciar...', 
      '0 MB', 
      `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`, 
      'Calculando...', 
      'Iniciando upload através do canal expresso de segurança...'
    );

    // Track state and fake live updates to satisfy styling/progress bars
    const startTimeProxy = Date.now();
    let currentPercentProxy = 10;
    const intervalProxy = setInterval(() => {
      if (currentPercentProxy < 90) {
        currentPercentProxy += Math.floor(Math.random() * 8) + 2;
        if (currentPercentProxy > 90) currentPercentProxy = 90;

        const elapsedMs = Date.now() - startTimeProxy;
        const elapsedSeconds = elapsedMs / 1000;
        let speedStr = 'A carregar...';
        let timeLeftStr = 'Calculando...';

        if (elapsedSeconds > 0) {
          const estimatedLoaded = (up.file.size * currentPercentProxy) / 100;
          const speedBytesSec = estimatedLoaded / elapsedSeconds;
          const speedMB = speedBytesSec / (1024 * 1024);
          speedStr = speedMB > 0.1 
            ? `${speedMB.toFixed(1)} MB/s` 
            : `${(speedBytesSec / 1024).toFixed(0)} KB/s`;

          const remainingBytes = up.file.size - estimatedLoaded;
          const remainingSeconds = remainingBytes / speedBytesSec;
          if (remainingSeconds > 0) {
            timeLeftStr = remainingSeconds < 60
              ? `${Math.round(remainingSeconds)}s restantes`
              : `${Math.floor(remainingSeconds / 60)}m ${Math.round(remainingSeconds % 60)}s restantes`;
          }
        }

        const uploadedStr = `${((up.file.size * currentPercentProxy) / 100 / (1024 * 1024)).toFixed(1)} MB`;
        const totalStr = `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`;

        onProgress(
          currentPercentProxy,
          speedStr,
          uploadedStr,
          totalStr,
          timeLeftStr,
          'A transferir ficheiro (Canal expresso)...'
        );
      }
    }, 1000);

    try {
      // Convert to base64 with Data URL prefix
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(up.file);
      });

      const supabase = getSupabase();
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;

      console.log('[STORAGE UPLOAD] Sending base64 payload to server upload proxy...');
      const proxyResponse = await fetch('/api/storage/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          base64Data,
          bucket: up.bucket,
          path: up.path,
          contentType: up.file.type || 'application/octet-stream',
          fileType: up.key
        })
      });

      clearInterval(intervalProxy);

      if (!proxyResponse.ok) {
        const errDetails = await proxyResponse.json().catch(() => ({}));
        throw new Error(errDetails.error || `HTTP ${proxyResponse.status}`);
      }

      const resData = await proxyResponse.json().catch(() => ({}));
      if (resData && resData.fileUrl) {
        (up as any).serverUrl = resData.fileUrl;
      }

      onProgress(
        100,
        'Concluído',
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        `${(up.file.size / (1024 * 1024)).toFixed(1)} MB`,
        'Concluído',
        'Upload finalizado com sucesso!'
      );
      console.log('[STORAGE UPLOAD] Proxy upload completed successfully');
    } catch (err: any) {
      clearInterval(intervalProxy);
      console.warn('[STORAGE UPLOAD] Proxy upload failed, activating local chunked upload fallback. Reason:', err?.message || err);
      try {
        await runChunkedUpload();
      } catch (fallbackErr: any) {
        console.error('[STORAGE EXCEPTION] Local chunked upload fallback failed:', fallbackErr);
        throw new Error(`Falha crítica de upload (Mecanismo principal e de segurança falharam): ${fallbackErr?.message || fallbackErr}`);
      }
    }
  };

  const handleSubmit = async () => {
    if (isLoading) return;
    if (isSubmittingRef.current) {
        console.log('[SUBMIT] Execution blocked: isSubmittingRef.current is true (double click / rapid submission lock)');
        return;
    }
    isSubmittingRef.current = true;
    console.log(`[SUBMIT ${instanceId}] Starting handleSubmit process`);
    setError(null);
    setIsLoading(true);
    setIsUploading(true);
    setLoading(true);
    setProcessingFiles(true);

    const successfullyUploaded: { bucket: string; path: string }[] = [];

    try {
        if (!user) {
            console.error('[SUBMIT] No user found in AuthContext');
            throw new Error('Utilizador não autenticado.');
        }
        
        console.log('[SUBMIT] Validating form fields...');
        
        const missingFields = [];
        if (!title.trim()) missingFields.push('Título');
        if (!bpm) missingFields.push('BPM');
        if (!genre) missingFields.push('Género');
        if (tags.length === 0) missingFields.push('Tags');
        
        if (!isFileLoaded('cover')) missingFields.push('Capa');
        if (!isFileLoaded('master')) missingFields.push('Mix Master');
        if (!isFileLoaded('demo')) missingFields.push('Demo');
        if (!isFileLoaded('stems')) missingFields.push('Stems');
        
        if (prices.basic === '') missingFields.push('Preço Básica');
        
        if (missingFields.length > 0) {
            console.warn('[SUBMIT] Validation failed:', missingFields);
            throw new Error('Por favor, preencha todos os campos obrigatórios: ' + missingFields.join(', '));
        }

        if (collaborators.length > 1) {
          const sum = collaborators.reduce((acc, c) => acc + Number(c.split_percentage || 0), 0);
          if (Math.abs(sum - 100) > 0.01) {
            throw new Error("As percentagens dos colaboradores devem totalizar exatamente 100%.");
          }
        }
        
        console.log('[SUBMIT] Preparing file paths and IDs...');
        const sanitizeFileName = (name: string): string => {
          return name
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '') // remove accents
            .replace(/[^a-zA-Z0-9._-]/g, '_') // replace special chars/spaces/quotes/brackets with '_'
            .replace(/__+/g, '_'); // deduplicate underscores
        };

        const activeBeatId = beatId || crypto.randomUUID();
        
        const timestamp = Date.now();
        const masterPath = uploadsState.master.file
          ? `${user.id}/${activeBeatId}/${timestamp}_master_${sanitizeFileName(uploadsState.master.file.name)}`
          : (initialData?.master_url || '');

        const demoPath = uploadsState.demo.file
          ? `${user.id}/${activeBeatId}/${timestamp}_demo_${sanitizeFileName(uploadsState.demo.file.name)}`
          : (initialData?.demo_url || '');

        const stemsPath = uploadsState.stems.file
          ? `${user.id}/${activeBeatId}/${timestamp}_stems_${sanitizeFileName(uploadsState.stems.file.name)}`
          : (initialData?.stems_url || '');

        const coverPath = uploadsState.cover.file
          ? `${user.id}/${activeBeatId}/${timestamp}_cover_${sanitizeFileName(uploadsState.cover.file.name)}`
          : (initialData?.cover_url || '');

        const supabase = getSupabase();
        if (!supabase) throw new Error('Supabase client not initialized');

        const uploads = [
          { key: 'master' as const, path: masterPath, file: uploadsState.master.file, bucket: 'beats-private' },
          { key: 'demo' as const, path: demoPath, file: uploadsState.demo.file, bucket: 'beats' },
          { key: 'stems' as const, path: stemsPath, file: uploadsState.stems.file, bucket: 'beats-private' },
          { key: 'cover' as const, path: coverPath, file: uploadsState.cover.file, bucket: 'beats' },
        ].filter(u => u.file !== null) as { key: 'master'|'demo'|'stems'|'cover', path: string, file: File, bucket: string }[];
        
        console.log('[SUBMIT] Starting sequential file uploads...');

        for (const up of uploads) {
            setUploadsState(prev => ({ 
              ...prev, 
              [up.key]: { 
                ...prev[up.key], 
                status: 'uploading', 
                progress: 0,
                stageMessage: 'Iniciando...'
              } 
            }));

            await uploadFileReal(up, (p, speed, uploadedSize, totalSize, timeLeft, stageMessage) => {
                setUploadsState(prev => {
                  const currentItem = prev[up.key];
                  const currentProgress = currentItem.progress || 0;
                  
                  // If p is -1, it's a reconnection retry event
                  if (p === -1) {
                    return {
                      ...prev,
                      [up.key]: {
                        ...currentItem,
                        progress: currentProgress, // hold high watermark
                        stageMessage: stageMessage || 'A restabelecer ligação...',
                        speed: 'A reconectar...',
                        timeLeft: 'A retomar...'
                      }
                    };
                  }

                  // Normal progress or catching up
                  const isPhysicalCatchUp = p < currentProgress;
                  
                  // When catching up, the visual progress remains at currentProgress, but we suffix the message to show action
                  let finalStageMessage = stageMessage || currentItem.stageMessage;
                  if (isPhysicalCatchUp) {
                    finalStageMessage = `A retomar do início... (físico: ${p}%)`;
                  }

                  return {
                    ...prev, 
                    [up.key]: { 
                      ...currentItem, 
                      progress: Math.max(currentProgress, p),
                      speed: isPhysicalCatchUp ? (speed || 'A ler...') : (speed || currentItem.speed),
                      uploadedSize: isPhysicalCatchUp ? (uploadedSize || currentItem.uploadedSize) : (uploadedSize || currentItem.uploadedSize),
                      totalSize: totalSize || currentItem.totalSize,
                      timeLeft: isPhysicalCatchUp ? `A recalcular... (${p}%)` : (timeLeft || currentItem.timeLeft),
                      stageMessage: finalStageMessage
                    } 
                  };
                });
            });

            successfullyUploaded.push({ bucket: up.bucket, path: up.path });

            setUploadsState(prev => ({ 
              ...prev, 
              [up.key]: { 
                ...prev[up.key], 
                status: 'completed', 
                progress: 100,
                stageMessage: 'Upload concluído'
              } 
            }));
            
            console.log(`[SUBMIT] Successfully uploaded ${up.key}`);
        }

        console.log('[SUBMIT] All uploads completed. Preparing database payload.');
        
        setIsUploading(false);
        setLoading(false);
        setProcessingFiles(false);
        setIsLoading(false); // also turn off loading so general loading overlay closes instantly if we want it to!
        
        const parsedBpm = parseInt(bpm, 10);
        const parsedBasic = parseFloat(prices.basic.replace(',', '.'));
        const parsedPremium = parseFloat(prices.premium.replace(',', '.') || '0');
        const parsedExclusive = parseFloat(prices.exclusive.replace(',', '.') || '0');

        let profileName = 'Produtor';
        try {
          const savedProfile = localStorage.getItem('producerProfile');
          if (savedProfile) {
            const parsedProfile = JSON.parse(savedProfile);
            if (parsedProfile && parsedProfile.artisticName) {
              profileName = parsedProfile.artisticName;
            }
          }
        } catch (e) {
          console.warn('Could not parse producer profile from localStorage:', e);
        }

        const finalArtName = profileName !== 'Produtor' ? profileName : (user?.user_metadata?.artistic_name || user?.user_metadata?.display_name || user?.email?.split('@')[0] || 'Produtor');

        const finalCoverPath = (uploads.find(u => u.key === 'cover') as any)?.serverUrl || coverPath;
        const finalMasterPath = (uploads.find(u => u.key === 'master') as any)?.serverUrl || masterPath;
        const finalDemoPath = (uploads.find(u => u.key === 'demo') as any)?.serverUrl || demoPath;
        const finalStemsPath = (uploads.find(u => u.key === 'stems') as any)?.serverUrl || stemsPath;

        const dbTags = [...tags];
        if (key) {
            dbTags.push(`_key:${key}`);
        } else {
            dbTags.push(`_key:C`);
        }
        if (scale) {
            dbTags.push(`_scale:${scale}`);
        } else {
            dbTags.push(`_scale:Maior`);
        }

        const insertPayload = {
            producer_id: user.id,
            title: title.trim(),
            bpm: isNaN(parsedBpm) ? null : parsedBpm,
            genre: genre || 'Outro',
            tags: dbTags.length > 0 ? dbTags : null, 
            price_basic: isNaN(parsedBasic) ? 0 : parsedBasic,
            price_premium: isNaN(parsedPremium) ? 0 : parsedPremium,
            price_exclusive: isNaN(parsedExclusive) ? 0 : parsedExclusive,
            cover_url: finalCoverPath,
            master_url: finalCoverPath, // fallback or set helper fields
            demo_url: finalDemoPath,
            stems_url: finalStemsPath,
            status: 'published',
            artist_name: finalArtName,
            category: 'marketplace'
        };

        // If we have a master URL we can write it properly
        if (finalMasterPath) {
            insertPayload.master_url = finalMasterPath;
        }

        if (mode === 'edit') {
            console.log('EDIT MODE: Active');
            console.log('BEAT ID:', activeBeatId);
            console.log('UPDATE PAYLOAD:', JSON.stringify(insertPayload, null, 2));
        }

        console.log('[DB] Attempting save with server API proxy:', JSON.stringify(insertPayload, null, 2));

        const saveResponse = await fetch('/api/beats/save', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            mode,
            activeBeatId,
            payload: insertPayload
          })
        });

        if (!saveResponse.ok) {
          const errData = await saveResponse.json().catch(() => ({}));
          throw new Error(`[Database] ${errData.error || 'Erro ao guardar batida no servidor.'}`);
        }

        const saveResult = await saveResponse.json();
        const data = saveResult.data;

        console.log('[SUBMIT] Database save successful:', data);

        // Submit Collab splits
        try {
            const savedBeat = data && data[0] ? data[0] : null;
            if (savedBeat && collaborators.length > 0) {
                console.log('[COLLABS] Submitting collab splits to backend...');
                await fetch(`/api/collabs/beat/${savedBeat.id}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ collaborators })
                });
                console.log('[COLLABS] Submitted splits successfully');
            }
        } catch (collabErr: any) {
            console.error('[COLLABS] Error posting collab splits:', collabErr.message);
        }
        
        // Register Social Activity (only for creation)
        if (mode !== 'edit') {
            try {
                const uploadedBeat = data && data[0] ? data[0] : null;
                if (uploadedBeat) {
                    const authorProf = JSON.parse(localStorage.getItem('user_profile') || '{}');
                    const pName = authorProf.artisticName || authorProf.artistic_name || authorProf.display_name || user?.user_metadata?.artistic_name || user?.email?.split('@')[0] || 'Produtor';
                    const pUsername = authorProf.username || user?.user_metadata?.username || user?.email?.split('@')[0]?.toLowerCase().replace(/\s+/g, '') || 'produtor';
                    const pAvatar = authorProf.avatarUrl || authorProf.avatar_url || user?.user_metadata?.avatar_url || null;

                    const urlResolver = getPublicUrl('beats', uploadedBeat.cover_url || '');
                    
                    await fetch('/api/activity/create', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            user_id: user?.id,
                            type: 'beat_upload',
                            actor_name: pName,
                            actor_username: pUsername,
                            actor_avatar: pAvatar,
                            target_id: uploadedBeat.id,
                            target_title: uploadedBeat.title,
                            target_cover: urlResolver,
                            metadata: {
                                genre: uploadedBeat.genre,
                                bpm: uploadedBeat.bpm
                            }
                        })
                    });
                }
            } catch (actErr) {
                console.warn('[SUBMIT] Silent error logging upload activity:', actErr);
            }
        }

        try {
            onSuccess();
        } catch (e) {
            console.warn('[SUBMIT] Error in parent onSuccess callback:', e);
        }
        onClose();
        
        if (mode !== 'edit') {
            setTimeout(() => {
                window.location.href = '/dashboard';
            }, 100);
        }
        
    } catch (err: any) {
      console.error(`[FATAL ERROR]`, err);
      setError('Erro ao publicar beat: ' + (err.message || String(err)));
      
      // Automatic Rollback Protection for Orphaning
      if (typeof successfullyUploaded !== 'undefined' && successfullyUploaded.length > 0) {
        console.warn(`[ROLLBACK EXECUTED] Beat publication failed after uploads. Cleaning up ${successfullyUploaded.length} uploaded files from Storage...`);
        const RollbackSupabase = getSupabase();
        if (RollbackSupabase) {
          for (const item of successfullyUploaded) {
            try {
              console.log(`[STORAGE AUDIT] [ROLLBACK EXECUTED] Removing uploaded orphan file: ${item.bucket} -> ${item.path}`);
              await RollbackSupabase.storage.from(item.bucket).remove([item.path]);
              console.log(`[STORAGE AUDIT] [ROLLBACK EXECUTED] Removed orphan successfully: ${item.path}`);
            } catch (rollbackErr) {
              console.error(`[STORAGE AUDIT] Rollback execution failed for ${item.bucket}/${item.path}:`, rollbackErr);
            }
          }
        }
      }
      
      setUploadsState(prev => ({
        ...prev,
        master: { ...prev.master, status: prev.master.file ? 'ready' : 'idle' },
        demo: { ...prev.demo, status: prev.demo.file ? 'ready' : 'idle' },
        stems: { ...prev.stems, status: prev.stems.file ? 'ready' : 'idle' },
        cover: { ...prev.cover, status: prev.cover.file ? 'ready' : 'idle' },
      }));
    } finally {
      setIsLoading(false);
      setIsUploading(false);
      setLoading(false);
      setProcessingFiles(false);
      isSubmittingRef.current = false;
    }
  };

  // Helper validation computed states for each step
  const step1Completeness = useMemo(() => {
    const missing = [];
    if (!isFileLoaded('cover')) missing.push('Arte de Capa');
    if (!isFileLoaded('master')) missing.push('Mix Masterizada (MP3/WAV)');
    if (!isFileLoaded('demo')) missing.push('Versão de Teste Demo');
    if (!isFileLoaded('stems')) missing.push('Ficheiros Trackouts (Stems ZIP)');
    return { complete: missing.length === 0, missing };
  }, [uploadsState, replacedFiles, mode, initialData]);

  const step2Completeness = useMemo(() => {
    const missing = [];
    if (!title.trim()) missing.push('Título do Beat');
    if (!bpm) missing.push('BPM (Batidas por Minuto)');
    if (!genre) missing.push('Gênero Principal');
    if (tags.length === 0) missing.push('Pelo menos 1 Tag');
    return { complete: missing.length === 0, missing };
  }, [title, bpm, genre, tags]);

  const step3Completeness = useMemo(() => {
    const missing = [];
    if (!prices.basic) missing.push('Preço da Licença Básica');
    return { complete: missing.length === 0, missing };
  }, [prices.basic]);

  const allUploadsComplete = useMemo(() => {
    return Object.values(uploadsState).every(upload => upload.status === 'completed' || upload.progress >= 100);
  }, [uploadsState]);

  console.log({
    isUploading,
    loading,
    processingFiles,
    uploadsState,
    allUploadsComplete
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/95 backdrop-blur-md p-4 overflow-y-auto overflow-x-hidden py-12 md:py-20 text-slate-100">
      <div className="bg-[#08080C] border border-white-5/5 border-white/5 rounded-[2.5rem] w-full max-w-5xl shadow-[0_32px_64px_-12px_rgba(0,0,0,0.9)] relative">
        
        {/* Hidden Inputs triggered securely */}
        <div className="hidden" aria-hidden="true">
          <input 
            id="cover-upload-input"
            type="file" 
            accept="image/*" 
            onChange={(e) => {
              if (e.target.files?.[0]) {
                validateAndSetCover(e.target.files[0]);
                e.target.value = ''; 
              }
            }} 
          />
          <input 
            id="master-upload-input"
            type="file" 
            accept=".mp3,.wav" 
            onChange={(e) => {
              if (e.target.files?.[0]) {
                handleFileChange('master', e.target.files[0]);
                e.target.value = '';
              }
            }} 
          />
          <input 
            id="demo-upload-input"
            type="file" 
            accept=".mp3,.wav" 
            onChange={(e) => {
              if (e.target.files?.[0]) {
                handleFileChange('demo', e.target.files[0]);
                e.target.value = '';
              }
            }} 
          />
          <input 
            id="stems-upload-input"
            type="file" 
            accept=".zip" 
            onChange={(e) => {
              if (e.target.files?.[0]) {
                handleFileChange('stems', e.target.files[0]);
                e.target.value = '';
              }
            }} 
          />
        </div>

        {/* Ambient Glow Orbs */}
        <div className="absolute -top-40 -left-40 w-[450px] h-[450px] bg-gradient-to-tr from-amber-500/10 via-amber-500/5 to-transparent rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute -bottom-40 -right-40 w-[450px] h-[450px] bg-gradient-to-br from-blue-500/10 via-amber-500/5 to-transparent rounded-full blur-[140px] pointer-events-none" />

        {/* Header */}
        <div className="p-6 md:p-8 border-b border-white/[0.04] bg-[#0A0A0E]/80 backdrop-blur-md flex justify-between items-center sticky top-0 z-30">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/10">
                <Music size={22} className="text-black" strokeWidth={2.5} />
              </div>
              <div>
                  <h2 className="text-xl md:text-2xl font-black text-white italic tracking-tight uppercase leading-none">
                    {mode === 'edit' ? 'Editar Beat' : 'Reduto de Publicação'}
                  </h2>
                  <p className="text-gray-500 text-[9px] font-black uppercase tracking-widest mt-1">
                    {mode === 'edit' ? 'Atualiza os dados do teu Beat' : 'Lança o teu Beat de nível Mundial'}
                  </p>
              </div>
            </div>
            <button 
              onClick={onClose} 
              disabled={isLoading}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white disabled:opacity-30 transition-all cursor-pointer"
            >
              <X size={20} />
            </button>
        </div>

        {/* Stepper Wizard Indicator */}
        <div className="bg-[#040406] px-6 md:px-8 py-5 border-b border-white/[0.03] flex items-center justify-between overflow-x-auto whitespace-nowrap custom-scrollbar">
          <div className="flex items-center justify-between w-full max-w-4xl mx-auto gap-2 md:gap-4">
            {STEPS.map((s, idx) => {
              const isActive = step === s.number;
              const isCompleted = step > s.number;
              return (
                <React.Fragment key={s.number}>
                  <button
                    type="button"
                    disabled={isLoading}
                    onClick={() => setStep(s.number)}
                    className="flex items-center gap-3 transition-opacity disabled:opacity-50 text-left outline-none cursor-pointer group"
                  >
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs transition-all duration-300 ${
                      isActive ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20 scale-105' : 
                      isCompleted ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' : 
                      'bg-white/[0.03] text-gray-500 border border-white/[0.04] group-hover:border-white/10'
                    }`}>
                      {isCompleted ? <Check size={14} strokeWidth={3} /> : s.number}
                    </div>
                    <div className="hidden sm:block">
                      <p className={`text-[10px] font-black uppercase tracking-wider leading-none ${isActive ? 'text-white' : 'text-gray-500 group-hover:text-gray-400'}`}>{s.name}</p>
                      <p className="text-[8px] text-gray-600 font-bold uppercase tracking-widest mt-1">{s.desc}</p>
                    </div>
                  </button>
                  {idx < STEPS.length - 1 && (
                    <div className={`flex-grow h-[1px] rounded-full min-w-[20px] max-w-[80px] transition-colors duration-300 ${
                      step > s.number ? 'bg-emerald-500/20' : 'bg-white/[0.03]'
                    }`} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Step Contents Container */}
        <div className="p-6 md:p-10 min-h-[480px] relative">
          
          {error && (
            <div className="bg-rose-500/10 text-rose-400 p-5 rounded-2xl border border-rose-500/20 flex items-start gap-4 mb-8 text-left">
              <AlertCircle size={20} className="my-0.5 shrink-0 text-rose-400" />
              <div className="flex-1 min-w-0">
                {error.startsWith('file_size_error:') ? (() => {
                  const parts = error.split(':');
                  const fileName = parts[1] || 'Ficheiro';
                  const currentMB = parts[2] || '0.0';
                  return (
                    <div>
                      <p className="text-xs font-black uppercase tracking-widest text-rose-400 mb-2">
                        Limite de Upload Excedido
                      </p>
                      <p className="text-xs font-bold text-slate-100 mb-3 leading-relaxed">
                        Este ficheiro <span className="text-rose-300">"{fileName}"</span> excede o limite máximo de 50MB permitido atualmente.
                      </p>
                      
                      <div className="bg-black/40 border border-white/5 rounded-xl p-3 mb-4 max-w-sm">
                        <div className="flex justify-between text-[10px] font-black uppercase tracking-wider text-gray-400 mb-1.5">
                          <span>Tamanho Atual</span>
                          <span>Limite Máximo</span>
                        </div>
                        <div className="flex justify-between items-baseline">
                          <span className="text-sm font-black text-rose-400">{currentMB}MB</span>
                          <span className="text-xs font-bold text-gray-500">/ 50MB</span>
                        </div>
                        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mt-2 border border-white/5">
                          <div className="h-full bg-rose-500 rounded-full" style={{ width: '100%' }} />
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-3">
                        <p className="text-[10px] font-black uppercase tracking-widest text-[#5865F2] mb-2">
                          Recomendações do Batukada:
                        </p>
                        <ul className="space-y-1.5 text-[11px] font-bold text-gray-400">
                          <li className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                            Utilizar ZIP comprimido com compressão máxima
                          </li>
                          <li className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                            Otimizar stems (converter de WAV 32-bit para 24-bit ou 16-bit)
                          </li>
                          <li className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                            Remover ficheiros desnecessários do ficheiro compactado
                          </li>
                        </ul>
                      </div>
                    </div>
                  );
                })() : (
                  <>
                    <p className="text-xs font-black uppercase tracking-wider mb-0.5">Falha de Validação</p>
                    <p className="text-xs font-medium text-rose-300/80 leading-relaxed">{error}</p>
                  </>
                )}
              </div>
            </div>
          )}

          {/* REAL TIME UPLOADING OVERLAY */}
          {isLoading && (
            <div className="absolute inset-0 bg-[#08080C]/98 backdrop-blur-md z-40 flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-300">
              <div className="relative mb-8">
                <span className="absolute inset-0 rounded-full bg-amber-500/10 scale-150 animate-ping duration-[3s]" />
                <div className="w-16 h-16 rounded-[1.5rem] bg-gradient-to-br from-[#5865F2]/20 to-amber-500/20 border border-[#5865F2]/30 flex items-center justify-center relative shadow-2xl">
                  <Upload className="text-amber-400 animate-bounce" size={24} />
                </div>
              </div>

              <h3 className="text-xl font-black text-white uppercase italic tracking-tight">Portal de Transferência Ativo</h3>
              <p className="text-gray-400 text-xs font-semibold tracking-wider max-w-sm mt-2 mb-8 leading-relaxed">
                Estamos a carregar e a processar os seus ficheiros de som na nossa infraestrutura descentralizada em tempo real. Não feche o navegador!
              </p>

              {/* Dynamic Progress List */}
              <div className="w-full max-w-md space-y-4">
                {[
                  { key: 'cover', icon: FileAudio, name: 'Arte da Capa' },
                  { key: 'master', icon: Headphones, name: 'Mix Masterizada (Áudio)' },
                  { key: 'demo', icon: Sparkles, name: 'Versão de Teste (Demo)' },
                  { key: 'stems', icon: FolderArchive, name: 'Ficheiros Trackouts (ZIP)' }
                ].map((item) => {
                  const state = uploadsState[item.key as 'master' | 'demo' | 'stems' | 'cover'];
                  const percent = state.progress;
                  const isUploading = state.status === 'uploading';
                  const isDone = state.status === 'completed';
                  return (
                    <div key={item.key} className="space-y-3.5 text-left bg-white/[0.01] border border-white/[0.04] p-5 rounded-[1.8rem] shadow-xl">
                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-wider">
                        <span className={`flex items-center gap-2 ${isDone ? 'text-emerald-400' : isUploading ? 'text-amber-400' : 'text-gray-500'}`}>
                          <item.icon size={14} className={isUploading ? "animate-pulse" : ""} />
                          {item.name}
                        </span>
                        <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black tracking-widest ${
                          isDone ? 'bg-emerald-500/10 text-emerald-400' : 
                          isUploading ? 'bg-amber-500/10 text-amber-500' : 
                          'bg-white/5 text-gray-500'
                        }`}>
                          {isDone ? 'COMPLETADO' : isUploading ? `${state.stageMessage || 'A ENVIAR'} ${percent}%` : 'EM ESPERA'}
                        </span>
                      </div>

                      {/* Display live upload details when uploading */}
                      {isUploading && (
                        <div className="grid grid-cols-2 gap-y-1.5 gap-x-4 text-[10px] font-mono text-gray-400 bg-black/30 p-2.5 rounded-xl border border-white/[0.03]">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Velocidade:</span> 
                            <span className="text-ash-50 font-semibold">{state.speed || '---'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Previsão:</span> 
                            <span className="text-ash-50 font-semibold">{state.timeLeft || 'A calcular...'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Enviado:</span> 
                            <span className="text-ash-50 font-semibold">{state.uploadedSize || '0 MB'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Tamanho:</span> 
                            <span className="text-ash-50 font-semibold">{state.totalSize || '---'}</span>
                          </div>
                        </div>
                      )}

                      {/* If done, show size */}
                      {isDone && state.totalSize && (
                        <p className="text-[10px] font-mono text-gray-500 mt-1">
                          Tamanho Final: <span className="text-emerald-400 font-black">{state.totalSize}</span>
                        </p>
                      )}

                      <div className="h-2 w-full bg-white/[0.02] border border-white/[0.04] rounded-full overflow-hidden relative">
                        <div 
                          className={`h-full transition-all duration-300 rounded-full ${
                            isDone ? 'bg-gradient-to-r from-emerald-500 to-teal-500 shadow-[0_0_12px_rgba(16,185,129,0.4)]' : 
                            isUploading ? 'bg-gradient-to-r from-[#5865F2] to-amber-500 shadow-[0_0_12px_rgba(88,101,242,0.4)] animate-pulse' : 
                            'bg-transparent'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 1: FILE MEDIA COMPONENT */}
          {step === 1 && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="space-y-8 animate-in fade-in"
            >
              <div className="text-center md:text-left">
                <h3 className="text-lg font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                  <Upload size={18} className="text-amber-500" />
                  Passo 1: Carregar Ficheiros-Chave
                </h3>
                <p className="text-gray-500 text-xs font-semibold mt-1">Carrega o material que compõe o teu beat. Todos os campos são obrigatórios.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Capa Upload Div (Left Span 5) */}
                <div className="md:col-span-5 space-y-4">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] block">
                    Arte da Capa (Imagem Quadradra 1:1) <span className="text-amber-500">*</span>
                  </label>
                  
                  <div 
                    onDragOver={(e) => handleDrag(e, 'cover', true)}
                    onDragLeave={(e) => handleDrag(e, 'cover', false)}
                    onDrop={(e) => handleDrop(e, 'cover')}
                    className={`relative aspect-square border-2 border-dashed rounded-[2rem] flex flex-col items-center justify-center transition-all overflow-hidden ${
                      coverPreviewUrl 
                        ? 'border-emerald-500/20 bg-emerald-500/[0.01]' 
                        : dragActive.cover 
                          ? 'border-amber-500 bg-amber-500/5' 
                          : 'border-white/5 hover:border-amber-500/30 bg-white/[0.01]'
                    }`}
                  >
                    {coverPreviewUrl ? (
                      <div className="relative w-full h-full group">
                        <img src={coverPreviewUrl} alt="Preview da Capa" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                          <label htmlFor="cover-upload-input" className="px-5 py-2.5 bg-white text-black text-[10px] font-black uppercase tracking-widest rounded-xl hover:scale-105 active:scale-95 transition-transform cursor-pointer">
                            Substituir Capa
                          </label>
                        </div>
                        
                        <button 
                          type="button"
                          onClick={() => removeFile('cover')}
                          className="absolute top-4 right-4 w-9 h-9 bg-rose-500 text-white rounded-xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all shadow-lg"
                        >
                          <Trash2 size={16} />
                        </button>

                        <div className="absolute bottom-4 left-4 bg-emerald-500/90 text-black text-[8px] font-black px-2.5 py-1 uppercase tracking-widest rounded-full flex items-center gap-1">
                          <Check size={10} strokeWidth={3} />
                          Arte Pronta
                        </div>
                      </div>
                    ) : (
                      <label htmlFor="cover-upload-input" className="flex flex-col items-center justify-center p-8 w-full h-full cursor-pointer text-center group">
                        <div className="w-14 h-14 rounded-2xl bg-white/[0.02] border border-white/[0.05] flex items-center justify-center group-hover:bg-amber-500 group-hover:text-[#0C0C12] transition-colors mb-4 text-gray-500">
                          <Upload size={22} className="group-hover:animate-bounce" />
                        </div>
                        <span className="text-xs font-black text-white uppercase tracking-wider">Carregar Capa</span>
                        <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest mt-2 max-w-[180px] leading-relaxed">
                          Arraste a sua arte JPEG/PNG quadrada aqui ou clique.
                        </span>
                      </label>
                    )}
                  </div>
                </div>

                {/* Audio Master/Demo/Stems (Right Span 7) */}
                <div className="md:col-span-7 space-y-5">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] block">
                    Ficheiros de Áudio Obrigatórios <span className="text-amber-500">*</span>
                  </label>

                  <div className="space-y-4">
                    {[
                      { 
                        key: 'master' as const, 
                        title: 'Mix Principal Masterizada (Áudio)', 
                        type: 'MP3 ou WAV sem tag', 
                        icon: Headphones,
                        desc: 'Ficheiro entregue ao cliente ao comprar qualquer uma das licenças de áudio.'
                      },
                      { 
                        key: 'demo' as const, 
                        title: 'Versão de Teste Demo (Mercado)', 
                        type: 'MP3 com Voice Tag opcional', 
                        icon: Flame,
                        desc: 'Ficheiro público usado para streaming e pré-escuta na página principal.'
                      },
                      { 
                        key: 'stems' as const, 
                        title: 'Trackouts Separados (Stems ZIP)', 
                        type: 'Ficheiro comprimido ZIP', 
                        icon: FolderArchive,
                        desc: 'Ficheiro obrigatório com as faixas separadas (bateria, guitarras, teclados) juntas.'
                      }
                    ].map((item) => {
                      const fileState = uploadsState[item.key];
                      const isDragActive = dragActive[item.key];
                      const isLoaded = isFileLoaded(item.key);

                      return (
                        <div 
                          key={item.key}
                          onDragOver={(e) => handleDrag(e, item.key, true)}
                          onDragLeave={(e) => handleDrag(e, item.key, false)}
                          onDrop={(e) => handleDrop(e, item.key)}
                          className={`relative border rounded-2xl p-4 transition-all ${
                            isLoaded 
                              ? 'bg-slate-900/[0.08] border-emerald-500/20' 
                              : isDragActive 
                                ? 'border-amber-500 bg-amber-500/[0.02]' 
                                : 'bg-white/[0.01] border-white/5 hover:border-white/10'
                          }`}
                        >
                          {isLoaded ? (
                            <div className="flex items-center justify-between gap-4">
                              <div className="flex items-center gap-3 overflow-hidden">
                                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                                  <Check size={18} strokeWidth={2.5} />
                                </div>
                                <div className="overflow-hidden">
                                  <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest leading-none">{item.title}</p>
                                  <p className="text-[11px] font-bold text-white uppercase truncate mt-1 max-w-[240px] md:max-w-xs">{getFileName(item.key)}</p>
                                  {fileState.file ? (
                                    <p className="text-[9px] text-[#5865F2] font-black tracking-widest uppercase mt-1">
                                      {(fileState.file.size / (1024 * 1024)).toFixed(1)}MB / 50MB
                                    </p>
                                  ) : (
                                    <p className="text-[10px] text-emerald-400 font-extrabold tracking-widest uppercase mt-1">
                                      Guardado no Servidor (Existente)
                                    </p>
                                  )}
                                  {item.key === 'demo' && demoPreviewUrl && (
                                    <div className="mt-2.5 flex items-center gap-2 bg-black/40 border border-white/5 rounded-xl p-2 max-w-[280px]">
                                      <audio src={demoPreviewUrl} controls className="w-full h-8 brightness-90 saturate-50 contrast-125" />
                                    </div>
                                  )}
                                </div>
                              </div>
                              
                              <button
                                type="button"
                                onClick={() => removeFile(item.key)}
                                className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500 hover:text-white flex items-center justify-center transition-colors shrink-0"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          ) : (
                            <label htmlFor={`${item.key}-upload-input`} className="flex items-start gap-4 cursor-pointer w-full group">
                              <div className="w-10 h-10 rounded-xl bg-white/[0.02] border border-white/[0.05] text-gray-400 group-hover:bg-amber-500 group-hover:text-black flex items-center justify-center transition-colors shrink-0">
                                <item.icon size={18} />
                              </div>
                              <div className="flex-grow pt-0.5">
                                <div className="flex justify-between items-center">
                                  <span className="text-[10px] font-black text-white uppercase tracking-wider group-hover:text-amber-400 transition-colors">{item.title}</span>
                                  <span className="text-[8px] font-black bg-white/5 text-gray-400 uppercase tracking-widest px-2 py-0.5 rounded border border-white/5">{item.type}</span>
                                </div>
                                <p className="text-[9px] text-gray-500 font-semibold leading-relaxed mt-1">{item.desc}</p>
                              </div>
                            </label>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            </motion.div>
          )}

          {/* STEP 2: METADATA INFORMATION */}
          {step === 2 && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="space-y-8 animate-in fade-in"
            >
              <div className="text-center md:text-left">
                <h3 className="text-lg font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                  <Activity size={18} className="text-amber-500" />
                  Passo 2: Metadados & Caracterização do Beat
                </h3>
                <p className="text-gray-500 text-xs font-semibold mt-1">Configura os metadados corretos para ajudar artistas a encontrar o teu beat mais facilmente.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Form Elements Left */}
                <div className="space-y-5">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                      Título Oficial <span className="text-amber-500">*</span>
                    </label>
                    <input 
                      type="text"
                      className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 text-sm font-bold text-white placeholder:text-gray-700 focus:border-amber-500/50 outline-none transition-all" 
                      placeholder="Ex: Alvorada de Benguela"
                      value={title} 
                      onChange={e => setTitle(e.target.value)} 
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                        BPM <span className="text-amber-500">*</span>
                      </label>
                      <input 
                        type="number"
                        className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 text-center text-sm font-black text-white focus:border-amber-500/50 outline-none transition-all" 
                        placeholder="120"
                        value={bpm} 
                        onChange={e => setBpm(e.target.value)} 
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                        Tom <span className="text-amber-500">*</span>
                      </label>
                      <select 
                        className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 text-center text-sm font-bold text-white focus:border-amber-500/50 outline-none cursor-pointer transition-all appearance-none" 
                        value={key} 
                        onChange={e => setKey(e.target.value)}
                      >
                        {['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'].map(k => <option key={k} value={k} className="bg-[#0B0B0F]">{k}</option>)}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                        Escala <span className="text-amber-500">*</span>
                      </label>
                      <select 
                        className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 text-center text-sm font-bold text-white focus:border-amber-500/50 outline-none cursor-pointer transition-all appearance-none" 
                        value={scale} 
                        onChange={e => setScale(e.target.value)}
                      >
                        {['Maior','Menor'].map(s => <option key={s} value={s} className="bg-[#0B0B0F]">{s}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] ml-1">
                      Género Principal <span className="text-amber-500">*</span>
                    </label>
                    <GenreSelect 
                      value={genre} 
                      onChange={setGenre} 
                      placeholder="Selecionar Gênero da Batida" 
                    />
                  </div>
                </div>

                {/* Tags section Right */}
                <div className="space-y-5 bg-white/[0.01] border border-white/[0.04] p-6 rounded-[2rem]">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">
                      Tags de Estilo do Beat <span className="text-amber-500">*</span>
                    </label>
                    <span className="text-[10px] font-black text-amber-500">{tags.length}/3 tags</span>
                  </div>

                  <div className="flex gap-2 p-1.5 bg-[#111116] border border-white/5 rounded-2xl">
                    <input 
                      type="text"
                      className="flex-grow bg-transparent p-3 text-xs font-bold text-white placeholder:text-gray-700 outline-none" 
                      placeholder={tags.length < 3 ? "Adicionar tag (máx. 3)..." : "Limite de tags atingido"} 
                      disabled={tags.length >= 3}
                      value={tagInput}
                      onChange={e => setTagInput(e.target.value)}
                      onKeyDown={(e) => { if(e.key === 'Enter') { e.preventDefault(); addTag(); } }}
                    />
                    <button 
                      type="button" 
                      onClick={() => addTag()} 
                      disabled={tags.length >= 3 || !tagInput.trim()}
                      className="bg-amber-500 text-black px-6 rounded-xl text-[10px] font-black uppercase tracking-widest disabled:opacity-20 transition-all active:scale-95 cursor-pointer shrink-0"
                    >
                      Gravar
                    </button>
                  </div>

                  {/* Active tags */}
                  <div className="flex flex-wrap gap-2 min-h-[40px]">
                    {tags.map((t, index) => (
                      <span key={index} className="flex items-center gap-2 text-[9px] font-black uppercase tracking-wider bg-amber-500/10 border border-amber-500/15 text-amber-400 pl-3.5 pr-2 py-1.5 rounded-xl">
                        {t}
                        <button 
                          type="button" 
                          onClick={() => setTags(tags.filter((_, i) => i !== index))}
                          className="w-5 h-5 rounded-md hover:bg-rose-500 hover:text-white flex items-center justify-center transition-colors"
                        >
                          <X size={10} />
                        </button>
                      </span>
                    ))}
                  </div>

                  {/* Suggested tags */}
                  <div className="pt-4 border-t border-white/[0.04]">
                    <span className="text-[9px] font-bold text-gray-600 uppercase tracking-widest block mb-2.5">Algumas sugestões:</span>
                    <div className="flex flex-wrap gap-2">
                      {SUGGESTED_TAGS.filter(t => !tags.includes(t)).slice(0, 8).map(t => (
                        <button
                          key={t}
                          type="button"
                          disabled={tags.length >= 3}
                          onClick={() => addTag(t)}
                          className="text-[9px] font-black uppercase tracking-widest px-3 py-2 rounded-xl border border-white/5 bg-white/[0.01] hover:border-amber-500/20 hover:text-amber-400 hover:bg-amber-500/[0.02] disabled:opacity-35 disabled:cursor-not-allowed transition-all cursor-pointer"
                        >
                          #{t}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

              </div>

              {/* COLABORADORES (SPLITS) SECTION */}
              <div className="mt-8 pt-8 border-t border-white/[0.04] space-y-6 text-left">
                <div>
                  <h4 className="text-sm font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                    <Users size={16} className="text-amber-500" />
                    Colaboradores (Collab Splits) - Opcional
                  </h4>
                  <p className="text-gray-500 text-xs font-semibold mt-1">
                    Pesquisa e adiciona co-produtores e divide as percentagens de ganhos (splits de 100% no total).
                  </p>
                </div>

                {/* Real-time Producer Search Field */}
                <div className="space-y-2 relative">
                  <label className="text-[9px] font-black text-gray-400 uppercase tracking-wider ml-1">Pesquisar Produtor (Nome Artístico / Display Name)</label>
                  <div className="relative">
                    <input
                      type="text"
                      className="w-full bg-[#0B0B0F] border border-white/10 rounded-xl p-3 text-xs font-bold text-white placeholder-gray-600 outline-none focus:border-amber-500/50"
                      placeholder="Começa a escrever para pesquisar... ex: Mar"
                      value={searchTerm}
                      onChange={(e) => {
                        console.log('INPUT CHANGED:', e.target.value);
                        setSearchTerm(e.target.value);
                      }}
                    />
                    {(() => {
                      const validProducers = producers.filter(
                        p =>
                          p.artistic_name?.trim() ||
                          p.display_name?.trim()
                      );

                      console.log('VALID PRODUCERS AFTER FILTER:', validProducers);

                      if (showDropdown && validProducers.length > 0) {
                        console.log('DROPDOWN JSX RENDERED');
                        console.log('DROPDOWN ITEMS:', validProducers);
                        return (
                          <div 
                            style={{
                              position: 'absolute',
                              top: '100%',
                              left: 0,
                              right: 0,
                              zIndex: 999999,
                              background: '#0E0E12',
                              border: '1px solid rgba(255,255,255,0.08)',
                              borderRadius: '12px',
                              boxShadow: '0 20px 40px rgba(0,0,0,0.6)'
                            }}
                            className="absolute left-0 right-0 mt-1.5 max-h-48 overflow-y-auto divide-y divide-white/5"
                          >
                            {validProducers.map((prod) => {
                              const producerName =
                                prod.artistic_name?.trim() ||
                                prod.display_name?.trim();

                              return (
                                <button
                                  key={prod.id}
                                  type="button"
                                  onClick={() => handleAddCollaborator(prod)}
                                  className="w-full text-left px-4 py-3 text-xs text-gray-300 hover:text-white hover:bg-white/[0.04] transition-all flex items-center justify-between font-bold"
                                >
                                  <div className="flex flex-col">
                                    <span className="text-white text-xs font-bold">{producerName}</span>
                                    <span className="text-[10px] text-gray-400 font-mono">@{prod.username || 'producer'}</span>
                                  </div>
                                </button>
                              );
                            })}
                          </div>
                        );
                      }
                      return null;
                    })()}
                  </div>
                </div>

                <div className="space-y-4">
                  {collaborators.map((collab, idx) => (
                    <div key={idx} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 bg-[#111116] p-4 rounded-2xl border border-white/5">
                      {/* Producer Display */}
                      <div className="flex-1 space-y-1">
                        <label className="text-[9px] font-black text-gray-500 uppercase tracking-wider ml-1">Produtor</label>
                        <div className="w-full bg-[#0B0B0F] border border-white/5 rounded-xl p-3 text-xs font-bold text-white/80">
                          {collab.artistic_name} {idx === 0 ? "(Principal)" : ""}
                        </div>
                      </div>

                      {/* Split Percentage */}
                      <div className="w-full sm:w-32 space-y-1">
                        <label className="text-[9px] font-black text-gray-500 uppercase tracking-wider text-center block">Partilha</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            className="w-full bg-[#0B0B0F] border border-white/5 rounded-xl p-3 text-center text-xs font-black text-white outline-none focus:border-amber-500/50"
                            placeholder="0"
                            value={collab.split_percentage}
                            onChange={(e) => {
                              const val = Math.min(100, Math.max(0, Number(e.target.value || 0)));
                              const copy = [...collaborators];
                              copy[idx] = { ...copy[idx], split_percentage: val };
                              setCollaborators(copy);
                              console.log('COLLABORATORS:', copy);
                            }}
                          />
                          <span className="text-xs font-bold text-gray-400">%</span>
                        </div>
                      </div>

                      {/* Delete */}
                      {idx > 0 && (
                        <button
                          type="button"
                          onClick={() => {
                            const updated = collaborators.filter((_, i) => i !== idx);
                            setCollaborators(updated);
                            console.log('COLLABORATORS:', updated);
                          }}
                          className="mt-4 sm:mt-5 p-2 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded-xl hover:bg-rose-500 hover:text-white transition cursor-pointer self-center"
                        >
                          <X size={14} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>

                {collaborators.length > 1 && (() => {
                  const totalPercent = collaborators.reduce((sum, c) => sum + Number(c.split_percentage || 0), 0);
                  return totalPercent !== 100 ? (
                    <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded-xl text-[11px] font-bold">
                      As percentagens dos colaboradores devem totalizar exatamente 100%. Total atual: {totalPercent}%
                    </div>
                  ) : (
                    <div className="p-3 bg-green-500/10 border border-green-500/20 text-green-400 rounded-xl text-[11px] font-bold">
                      ✓ Configuração de splits perfeitamente equilibrada e em conformidade! (100%)
                    </div>
                  );
                })()}

              </div>
            </motion.div>
          )}

          {/* STEP 3: LICENSING PLANS REDESIGN */}
          {step === 3 && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="space-y-8 animate-in fade-in"
            >
              <div className="text-center md:text-left">
                <h3 className="text-lg font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                  <Coins size={18} className="text-amber-500" />
                  Passo 3: Licenciamento & Preços de Venda
                </h3>
                <p className="text-gray-500 text-xs font-semibold mt-1">Configura o preço em Kwanzas (Kz) para cada tipo de licença de aquisição do seu beat.</p>
              </div>

              {/* Grid 3 licensing tier cards like subscriptions */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  {
                    key: 'basic' as const,
                    tag: 'BÁSCHA STANDARD',
                    title: 'Licença Básica',
                    desc: 'O ponto de partida para artistas em crescimento.',
                    accent: 'border-blue-500/20 text-blue-400 text-blue-500 shadow-blue-500/5',
                    features: [
                      'Entrega de ficheiro de Áudio MP3',
                      'Direitos limitados de rádio/shows',
                      'Até 100.000 transmissões áudio',
                      'Contrato padrão não-exclusivo'
                    ],
                    subtext: 'Preço base recomendado: ~10.000 Kz'
                  },
                  {
                    key: 'premium' as const,
                    tag: 'GOLD MASTER',
                    title: 'Licença Premium',
                    desc: 'A escolha mais popular para gravações profissionais.',
                    accent: 'border-violet-500/30 text-violet-400 bg-gradient-to-b from-violet-500/[0.03] to-transparent shadow-violet-500/5',
                    recommended: true,
                    features: [
                      'Ficheiros MP3 em WAV Premium',
                      'Trackouts (Stems) completos incluídos',
                      'Até 500.000 transmissões de streaming',
                      'Direitos estendidos para rádio comercial'
                    ],
                    subtext: 'Preço base recomendado: ~25.000 Kz'
                  },
                  {
                    key: 'exclusive' as const,
                    tag: 'BLACK DIAMOND UNLIMITED',
                    title: 'Licença Exclusiva',
                    desc: 'Posse total do material executado sem royalties.',
                    accent: 'border-amber-500/20 text-amber-400 bg-gradient-to-b from-amber-500/[0.03] to-transparent shadow-amber-500/5',
                    features: [
                      'Direitos definitivos, posse absoluta',
                      'Remoção automática do catálogo do site',
                      'Uso de rádio e transmissões ilimitadas',
                      'Transferência contratual de master'
                    ],
                    subtext: 'Valor de assinatura livre'
                  }
                ].map((tier) => {
                  return (
                    <div 
                      key={tier.key} 
                      className={`relative border rounded-[2rem] p-6 flex flex-col justify-between shadow-2xl transition-all hover:-translate-y-1 ${
                        tier.recommended 
                          ? 'border-violet-500/40 bg-zinc-950 shadow-[0_12px_44px_rgba(139,92,246,0.08)]' 
                          : 'border-white/5 bg-white/[0.01] hover:border-white/10'
                      }`}
                    >
                      {tier.recommended && (
                        <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-violet-600 text-[8px] font-black tracking-widest text-white uppercase shadow-lg shadow-violet-600/30">
                          Recomendado
                        </div>
                      )}

                      <div className="space-y-4">
                        <div className="flex justify-between items-start">
                          <span className="text-[8px] font-black text-gray-500 tracking-wider uppercase bg-white/5 px-2.5 py-1 rounded-md">{tier.tag}</span>
                          {tier.recommended && <Sparkles size={14} className="text-violet-400 animate-pulse" />}
                        </div>

                        <div>
                          <h4 className="text-md font-black text-white uppercase italic tracking-tight">{tier.title}</h4>
                          <p className="text-[10px] text-gray-500 mt-1 leading-relaxed">{tier.desc}</p>
                        </div>

                        <ul className="space-y-2 py-4 border-t border-b border-white/[0.04]">
                          {tier.features.map((f, i) => (
                            <li key={i} className="flex items-center gap-2 text-[10px] font-semibold text-gray-400">
                              <Check size={10} className="text-amber-500 shrink-0" strokeWidth={3} />
                              {f}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="pt-5 space-y-3">
                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest block pl-1">
                          Definir Valor (Kz) {tier.key === 'basic' && <span className="text-amber-500">*</span>}
                        </label>
                        <div className="relative">
                          <input 
                            type="number"
                            className="w-full bg-[#111116] border border-white/5 rounded-2xl p-4 pl-12 text-sm font-black text-white focus:border-amber-500/50 outline-none transition-all placeholder:text-gray-800" 
                            placeholder="Desativado"
                            value={prices[tier.key]} 
                            onChange={e => setPrices({...prices, [tier.key]: e.target.value})} 
                          />
                          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[11px] font-black text-gray-600">Kz</span>
                        </div>
                        <p className="text-[8px] text-gray-600 font-bold uppercase tracking-widest text-center mt-1">{tier.subtext}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Opções de Download Gratuito (Estilo BeatStars) */}
              <div className="mt-10 border-t border-white/[0.04] pt-8 space-y-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-500/10 text-amber-500 rounded-lg">
                    <Download size={18} />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white uppercase italic tracking-wider">Download Gratuito (Estilo BeatStars)</h4>
                    <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-widest mt-0.5">Disponibilize este beat gratuitamente em troca de engagement ou contacto do utilizador</p>
                  </div>
                </div>

                <div className="bg-white/[0.01] border border-white/5 rounded-[2rem] p-6 space-y-6">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <input 
                      type="checkbox"
                      checked={isFreeDownload}
                      onChange={(e) => {
                        setIsFreeDownload(e.target.checked);
                        if (!e.target.checked) {
                          setFreeDownloadRequiresFollow(false);
                          setFreeDownloadRequiresComment(false);
                          setFreeDownloadRequiresEmail(false);
                        }
                      }}
                      className="w-5 h-5 rounded border border-white/10 bg-black text-amber-500 focus:ring-0 cursor-pointer"
                    />
                    <div>
                      <span className="text-xs font-black text-white uppercase tracking-wider group-hover:text-amber-500 transition-colors">Permitir Download Gratuito</span>
                      <p className="text-[10px] text-gray-500 font-medium leading-relaxed mt-1">Os utilizadores poderão baixar o beat gratuitamente. (Será disponibilizado um arquivo MP3Tagged/Demo para download).</p>
                    </div>
                  </label>

                  {isFreeDownload && (
                    <div className="border-t border-white/[0.04] pt-6 space-y-4 pl-8">
                      <h5 className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Requisitos para Desbloquear Download</h5>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <label className="flex items-start gap-3 cursor-pointer bg-[#111116] border border-white/5 hover:border-amber-500/30 p-4 rounded-2xl transition-all select-none">
                          <input 
                            type="checkbox"
                            checked={freeDownloadRequiresFollow}
                            onChange={(e) => setFreeDownloadRequiresFollow(e.target.checked)}
                            className="w-4 h-4 rounded border border-white/10 bg-black text-amber-500 mt-0.5"
                          />
                          <div>
                            <span className="text-xs font-bold text-white block">Exigir Follow</span>
                            <span className="text-[8px] text-gray-500 font-black tracking-widest uppercase block mt-1">Seguir produtor</span>
                          </div>
                        </label>

                        <label className="flex items-start gap-3 cursor-pointer bg-[#111116] border border-white/5 hover:border-amber-500/30 p-4 rounded-2xl transition-all select-none">
                          <input 
                            type="checkbox"
                            checked={freeDownloadRequiresComment}
                            onChange={(e) => setFreeDownloadRequiresComment(e.target.checked)}
                            className="w-4 h-4 rounded border border-white/10 bg-black text-amber-500 mt-0.5"
                          />
                          <div>
                            <span className="text-xs font-bold text-white block">Exigir Comentário</span>
                            <span className="text-[8px] text-gray-500 font-black tracking-widest uppercase block mt-1">Fazer feedback</span>
                          </div>
                        </label>

                        <label className="flex items-start gap-3 cursor-pointer bg-[#111116] border border-white/5 hover:border-amber-500/30 p-4 rounded-2xl transition-all select-none">
                          <input 
                            type="checkbox"
                            checked={freeDownloadRequiresEmail}
                            onChange={(e) => setFreeDownloadRequiresEmail(e.target.checked)}
                            className="w-4 h-4 rounded border border-white/10 bg-black text-amber-500 mt-0.5"
                          />
                          <div>
                            <span className="text-xs font-bold text-white block">Exigir Email</span>
                            <span className="text-[8px] text-gray-500 font-black tracking-widest uppercase block mt-1">Fornecer Email</span>
                          </div>
                        </label>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 4: PREVIEW REVIEW & CONFIRM */}
          {step === 4 && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              className="space-y-8 animate-in fade-in"
            >
              <div className="text-center md:text-left">
                <h3 className="text-lg font-black text-white uppercase italic tracking-tight flex items-center gap-2">
                  <CheckCircle2 size={18} className="text-amber-500" />
                  Passo 4: Verificação Final & Publicação
                </h3>
                <p className="text-gray-500 text-xs font-semibold mt-1">Garante que todas as informações se encontram corretas antes de registar o teu beat.</p>
              </div>

              {/* Master verification and layout summary */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Column Left: Visual Mock Market Card (Span 5) */}
                <div className="md:col-span-5 space-y-4">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] block">
                    Visualização no Mercado (Pré-Visualização)
                  </label>

                  <div className="bg-[#12121A]/80 border border-white/5 rounded-[2.2rem] p-5 space-y-4 shadow-xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
                    
                    {/* Visual simulated beat card inside explore */}
                    <div className="aspect-square w-full rounded-2xl overflow-hidden relative bg-zinc-900 flex items-center justify-center">
                      {coverPreviewUrl ? (
                        <img src={coverPreviewUrl} alt="Capa" className="w-full h-full object-cover" />
                      ) : (
                        <Music size={48} className="text-gray-800" />
                      )}
                      
                      {/* Decorative fake play visualizer bar overlay */}
                      <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-md px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 border border-white/5 text-[9px] font-black uppercase text-amber-400 tracking-wider">
                        <Activity size={10} className="animate-pulse" />
                        {bpm || '120'} BPM
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-md font-black text-white truncate italic uppercase tracking-tight">{title || 'Título do seu Beat'}</h4>
                        <span className="text-[9px] font-black bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded uppercase">{genre || 'Gênero'}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-gray-500 font-bold uppercase tracking-wider">
                        <span>{user?.email?.split('@')[0] || 'Produtor'}</span>
                        <span>•</span>
                        <span className="text-amber-400">{key || 'C'}{scale || 'Maior'}</span>
                      </div>
                    </div>

                    {/* Fake sound wave element to show premium feel */}
                    <div className="flex items-end justify-between gap-1 h-8 px-1 overflow-hidden opacity-30 mt-3">
                      {Array.from({ length: 30 }).map((_, i) => {
                        const h = Math.floor(Math.sin(i * 0.4) * 12) + 16;
                        return (
                          <div 
                            key={i} 
                            className="bg-amber-500 flex-grow rounded-full transition-all duration-300"
                            style={{ height: `${h}px` }}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Column Right: Complete Summary of uploads (Span 7) */}
                <div className="md:col-span-7 space-y-6">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.25em] block">
                    Checklist de Distribuição Autorizada
                  </label>

                  <div className="space-y-4 bg-white/[0.01] border border-white/[0.04] p-6 rounded-[2.2rem]">
                    
                    {/* Media Files */}
                    <div className="space-y-3">
                      <span className="text-[9px] font-black text-gray-600 uppercase tracking-widest block mb-1">Uploads Regitados</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="flex items-center gap-2.5 bg-white/[0.01] border border-white/[0.03] p-3 rounded-xl text-[10px] font-bold">
                          <Check size={12} className="text-emerald-500 shrink-0" strokeWidth={3} />
                          <span className="text-gray-400 truncate">Mix Master: {getFileName('master')}</span>
                        </div>
                        <div className="flex items-center gap-2.5 bg-white/[0.01] border border-white/[0.03] p-3 rounded-xl text-[10px] font-bold">
                          <Check size={12} className="text-emerald-500 shrink-0" strokeWidth={3} />
                          <span className="text-gray-400 truncate">Demo MP3: {getFileName('demo')}</span>
                        </div>
                        <div className="flex items-center gap-2.5 bg-white/[0.01] border border-white/[0.03] p-3 rounded-xl text-[10px] font-bold">
                          <Check size={12} className="text-emerald-500 shrink-0" strokeWidth={3} />
                          <span className="text-gray-400 truncate">Stems ZIP: {getFileName('stems')}</span>
                        </div>
                        <div className="flex items-center gap-2.5 bg-white/[0.01] border border-white/[0.03] p-3 rounded-xl text-[10px] font-bold">
                          <Check size={12} className="text-emerald-500 shrink-0" strokeWidth={3} />
                          <span className="text-gray-400 truncate">Arte Capa: {getFileName('cover')}</span>
                        </div>
                      </div>
                    </div>

                    {/* Metadata summary */}
                    <div className="pt-4 border-t border-white/[0.04] space-y-2">
                      <span className="text-[9px] font-black text-gray-600 uppercase tracking-widest block mb-1">Atributos de Pesquisa</span>
                      <div className="flex flex-wrap gap-2">
                        <div className="bg-white/5 border border-white/5 px-3 py-1.5 rounded-lg text-[9px] font-bold uppercase text-slate-300">
                          GÊNERO: {genre}
                        </div>
                        <div className="bg-white/5 border border-white/5 px-3 py-1.5 rounded-lg text-[9px] font-bold uppercase text-slate-300">
                          BPM: {bpm}
                        </div>
                        <div className="bg-white/5 border border-white/5 px-3 py-1.5 rounded-lg text-[9px] font-bold uppercase text-slate-300">
                          TOM: {key} {scale}
                        </div>
                        {tags.map((t, idx) => (
                          <div key={idx} className="bg-amber-500/10 border border-amber-500/10 px-3 py-1.5 rounded-lg text-[9px] font-bold uppercase text-amber-400">
                            #{t}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* License Price summary */}
                    <div className="pt-4 border-t border-white/[0.04] space-y-2.5">
                      <span className="text-[9px] font-black text-gray-600 uppercase tracking-widest block mb-1">Preços de Licenciamento</span>
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center text-[10px] font-extrabold">
                          <span className="text-gray-500 uppercase">Licença Básica (MP3):</span>
                          <span className="text-white text-xs">{prices.basic ? `${prices.basic} Kz` : 'Indefinido'}</span>
                        </div>
                        <div className="flex justify-between items-center text-[10px] font-extrabold">
                          <span className="text-gray-500 uppercase">Licença Premium (WAV + Stems):</span>
                          <span className="text-white text-xs">{prices.premium ? `${prices.premium} Kz` : 'Não Oferecida'}</span>
                        </div>
                        <div className="flex justify-between items-center text-[10px] font-extrabold">
                          <span className="text-gray-500 uppercase">Licença Exclusiva (Contrato Total):</span>
                          <span className="text-white text-xs">{prices.exclusive ? `${prices.exclusive} Kz` : 'Não Oferecida'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Platform protection policy hint */}
                    <div className="pt-4 border-t border-white/[0.04] flex items-start gap-2.5 text-slate-400">
                      <Lock size={12} className="text-amber-500 shrink-0 mt-0.5" />
                      <p className="text-[8.5px] font-medium leading-relaxed uppercase tracking-wide">
                        Ao publicar, o seu beat ficará publicamente disponível no catálogo secundário sob as diretivas de serviço da plataforma. Receba pagementos automáticos direto no seu portfólio carteira.
                      </p>
                    </div>

                  </div>
                </div>

              </div>
            </motion.div>
          )}

        </div>

        {/* Footer Navigation bar */}
        <footer className="p-6 md:p-8 border-t border-white/[0.04] bg-[#0A0A0E]/80 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-4 sticky bottom-0 z-30">
          
          {/* Validation indicators or missing fields summary */}
          <div className="text-center sm:text-left">
            {step === 1 && !step1Completeness.complete && (
              <p className="text-[9px] font-bold text-amber-500/80 uppercase tracking-wider">
                Faltam: {step1Completeness.missing.join(', ')}
              </p>
            )}
            {step === 2 && !step2Completeness.complete && (
              <p className="text-[9px] font-bold text-amber-500/80 uppercase tracking-wider">
                Faltam: {step2Completeness.missing.join(', ')}
              </p>
            )}
            {step === 3 && !step3Completeness.complete && (
              <p className="text-[9px] font-bold text-amber-500/80 uppercase tracking-wider">
                Defina o preço da Licença Básica para continuar.
              </p>
            )}
            {step === 4 && (!step1Completeness.complete || !step2Completeness.complete || !step3Completeness.complete) && (
              <p className="text-[9px] font-bold text-rose-400 uppercase tracking-wider">
                Existem campos obrigatórios em falta noutros passos!
              </p>
            )}
            {((step === 1 && step1Completeness.complete) || 
              (step === 2 && step2Completeness.complete) || 
              (step === 3 && step3Completeness.complete)) && (
              <p className="text-[9px] font-bold text-emerald-400 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1">
                <Check size={11} strokeWidth={3} />
                Passo Validado & Completo
              </p>
            )}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto shrink-0 justify-end">
            
            {/* Voltar button */}
            {step > 1 && (
              <button 
                type="button"
                disabled={isLoading}
                onClick={() => setStep(prev => prev - 1)}
                className="w-1/2 sm:w-auto px-5 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-white/[0.04]"
              >
                <ChevronLeft size={14} strokeWidth={2.5} />
                Anterior
              </button>
            )}

            {/* Proximo / Submit button */}
            {step < 4 ? (
              <button 
                type="button"
                onClick={() => {
                  if (step === 2 && collaborators.length > 1) {
                    const sum = collaborators.reduce((acc, c) => acc + Number(c.split_percentage || 0), 0);
                    if (Math.abs(sum - 100) > 0.01) {
                      setError("As percentagens dos colaboradores devem totalizar 100%.");
                      alert("As percentagens dos colaboradores devem totalizar 100%.");
                      return;
                    }
                  }
                  setError(null);
                  setStep(prev => prev + 1);
                }}
                disabled={
                  (step === 1 && !step1Completeness.complete) || 
                  (step === 3 ? !step3Completeness.complete : false)
                }
                className="w-full sm:w-auto min-w-[130px] px-6 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest bg-white text-black hover:bg-amber-500 hover:text-black hover:scale-[1.02] disabled:opacity-30 disabled:pointer-events-none transition-all flex items-center justify-center gap-1.5 cursor-pointer ml-auto"
              >
                Próximo
                <ChevronRight size={14} strokeWidth={2.5} />
              </button>
            ) : (
              <button 
                type="button"
                onClick={handleSubmit} 
                disabled={isLoading || !step1Completeness.complete || !step2Completeness.complete || !step3Completeness.complete} 
                className="w-full sm:w-auto min-w-[200px] px-8 py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.14em] bg-amber-500 text-black hover:bg-amber-400 shadow-xl shadow-amber-500/15 hover:scale-[1.04] active:scale-95 disabled:opacity-30 disabled:pointer-events-none transition-all flex items-center justify-center gap-2 cursor-pointer ml-auto"
              >
                {mode === 'edit' ? 'Salvar Alterações' : 'Publicar Agora'}
                <Sparkles size={14} className="animate-pulse" />
              </button>
            )}

          </div>

        </footer>

      </div>
    </div>
  );
}
