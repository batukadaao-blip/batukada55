import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid,
  Cell
} from 'recharts';
import { 
  DollarSign, 
  TrendingUp, 
  Music, 
  Package, 
  Calendar, 
  User, 
  CheckCircle, 
  AlertCircle, 
  Clock,
  ArrowRight,
  TrendingDown,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { getSupabase, normalizeBeatId } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import InstagramLoader from '../../InstagramLoader';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#0B0B0B] border border-white/10 p-4 rounded-xl shadow-2xl backdrop-blur-xl">
        <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest mb-1">{label}</p>
        <p className="text-white text-lg font-black italic">
          {payload[0].value.toLocaleString()} Kz
        </p>
      </div>
    );
  }
  return null;
};

export default function Vendas() {
  const [loading, setLoading] = useState(true);
  const [salesItems, setSalesItems] = useState<any[]>([]);
  const [bestSellers, setBestSellers] = useState<any[]>([]);
  const [revenueData, setRevenueData] = useState<any[]>([]);
  const [salesStats, setSalesStats] = useState({
    totalSalesCount: 0,
    grossEarnings: 0,
    commissionPaid: 0,
    netEarnings: 0,
    averagePrice: 0,
    activeOrdersCount: 0
  });

  const supabase = getSupabase();
  const { user } = useAuth();
  const userId = user?.id;
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    const handleRefresh = () => {
      console.log('[REALTIME UPDATE] financialMetricsChanged event caught, refreshing sales dashboard...');
      setRefreshTrigger(prev => prev + 1);
    };

    window.addEventListener('financialMetricsChanged', handleRefresh);

    let bc: BroadcastChannel | null = null;
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        bc = new BroadcastChannel('financial_updates');
        bc.onmessage = (event) => {
          if (event.data === 'refresh') {
            console.log('[REALTIME UPDATE] BroadcastChannel financial_updates message caught, refreshing sales dashboard...');
            setRefreshTrigger(prev => prev + 1);
          }
        };
      } catch (err) {
        console.error('Error starting BroadcastChannel in Vendas:', err);
      }
    }

    return () => {
      window.removeEventListener('financialMetricsChanged', handleRefresh);
      if (bc) {
        bc.close();
      }
    };
  }, []);

  useEffect(() => {
    async function fetchSalesData() {
      if (!supabase || !userId) {
        setLoading(false);
        return;
      }

      console.time('VENDAS LOAD');
      setLoading(true);
      try {
        // 1. Fetch order items for this producer
        const { data: orderItems, error: itemsError } = await supabase
          .from('order_items')
          .select('id, price, order_id, created_at, beat_id')
          .eq('producer_id', userId)
          .order('created_at', { ascending: false });

        if (itemsError) throw itemsError;
        const items = orderItems || [];
        console.log('ORDER ITEMS:', orderItems);

        // 2. Fetch beats mapping in bulk to avoid complex joins
        const beatIds = Array.from(new Set(items.map((item: any) => item.beat_id).filter(Boolean)));
        console.log('BEAT IDS:', beatIds);

        let beatsData: any[] = [];
        if (beatIds.length > 0) {
          const { data, error: beatsError } = await supabase
            .from('beats')
            .select('id, title, image_url')
            .in('id', beatIds);
          if (!beatsError && data) {
            beatsData = data;
          }
        }
        console.log('BEATS FETCHED:', beatsData);

        const beatMap: Record<string, string> = {};
        const imageMap: Record<string, string> = {};
        beatsData.forEach((beat: any) => {
          const rawId = beat.id;
          const strId = String(rawId);
          const numId = Number(rawId);
          const normId = normalizeBeatId(rawId);

          beatMap[strId] = beat.title;
          beatMap[numId] = beat.title;
          beatMap[String(normId)] = beat.title;
          beatMap[Number(normId)] = beat.title;

          imageMap[strId] = beat.image_url || '';
          imageMap[numId] = beat.image_url || '';
          imageMap[String(normId)] = beat.image_url || '';
          imageMap[Number(normId)] = beat.image_url || '';
        });
        console.log('BEAT MAP:', beatMap);

        // 3. Extract and fetch details for related orders (only safe, existing columns)
        const orderIds = Array.from(new Set(items.map((item: any) => item.order_id).filter(Boolean)));
        let ordersMap: Record<string, any> = {};

        if (orderIds.length > 0) {
          const { data: ordersData, error: ordersError } = await supabase
            .from('orders')
            .select('id, status, customer_id, created_at, beat_title')
            .in('id', orderIds);

          if (!ordersError && ordersData) {
            // Resolve profiles for these buyers
            const buyerIds = Array.from(new Set(ordersData.map((o: any) => o.customer_id).filter(Boolean)));
            let profileMap: Record<string, any> = {};

            if (buyerIds.length > 0) {
              const { data: profilesData } = await supabase
                .from('profiles')
                .select('id, artistic_name, display_name, email')
                .in('id', buyerIds);
              if (profilesData) {
                profilesData.forEach((p: any) => {
                  profileMap[p.id] = p;
                });
              }
            }

            ordersData.forEach((o: any) => {
              const profile = o.customer_id ? profileMap[o.customer_id] : null;
              const name = profile 
                ? (profile.artistic_name || profile.display_name || profile.email) 
                : 'Anonymous Customer';
              ordersMap[o.id] = { ...o, customerName: name };
            });
          }
        }

        // 4. Normalize sales data with strict sanitization
        const normalizedSales = items.map((item: any) => {
          const order = ordersMap[item.order_id] || {};
          const status = (order.status || 'pending').toString();
          const price = parseFloat(item.price) || 0;
          
          console.log('RAW ITEM BEAT ID:', item.beat_id);
          console.log('LOOKUP TITLE:', beatMap[item.beat_id]);

          let resolvedTitle = beatMap[item.beat_id];
          if (!resolvedTitle && item.beat_id) {
            resolvedTitle = beatMap[String(item.beat_id)] || beatMap[Number(item.beat_id)];
            if (!resolvedTitle) {
              const normalizedItemBeatId = normalizeBeatId(item.beat_id);
              resolvedTitle = beatMap[String(normalizedItemBeatId)] || beatMap[Number(normalizedItemBeatId)];
            }
          }
          if (!resolvedTitle) {
            resolvedTitle = order.beat_title || 'Beat removido';
          }
          console.log('FINAL RESOLVED TITLE:', resolvedTitle);

          let beatImage = '';
          if (item.beat_id) {
            beatImage = imageMap[item.beat_id] || imageMap[String(item.beat_id)] || imageMap[Number(item.beat_id)] || '';
            if (!beatImage) {
              const normalizedItemBeatId = normalizeBeatId(item.beat_id);
              beatImage = imageMap[String(normalizedItemBeatId)] || imageMap[Number(normalizedItemBeatId)] || '';
            }
          }

          const customerName = order.customerName || 'Anonymous';
          
          const transactionObject = {
            id: item.id,
            beatTitle: resolvedTitle,
            resolvedTitle: resolvedTitle,
            beatImage,
            price,
            net: price * 0.9, // 10% platform commission
            created_at: item.created_at || order.created_at || new Date().toISOString(),
            status,
            customerName,
            orderId: item.order_id
          };
          console.log('FINAL TRANSACTION OBJECT:', transactionObject);
          return transactionObject;
        });

        console.log('FINAL SALES ARRAY:', normalizedSales);

        // 5. Calculate stats safely
        const paidSales = normalizedSales.filter((sale: any) => {
          const s = (sale.status || '').toString().toLowerCase();
          return ['paid', 'completed', 'concluido', 'sucesso'].includes(s);
        });
        const grossEarnings = paidSales.reduce((sum: number, sale: any) => sum + sale.price, 0);
        const netEarnings = grossEarnings * 0.9;
        const commissionPaid = grossEarnings * 0.1;
        const totalSalesCount = paidSales.length;
        const averagePrice = totalSalesCount > 0 ? (grossEarnings / totalSalesCount) : 0;
        const activeOrdersCount = normalizedSales.filter((sale: any) => {
          const s = (sale.status || '').toString().toLowerCase();
          return ['pending', 'waiting', 'waiting_confirmation', 'aguardando'].includes(s);
        }).length;

        setSalesStats({
          totalSalesCount,
          grossEarnings,
          commissionPaid,
          netEarnings,
          averagePrice,
          activeOrdersCount
        });

        setSalesItems(normalizedSales);

        // 6. Calculate best selling beats
        const beatSalesMap: Record<string, { title: string; image: string; salesCount: number; earnings: number }> = {};
        normalizedSales.forEach((sale: any) => {
          const s = (sale.status || '').toString().toLowerCase();
          if (['paid', 'completed', 'concluido', 'sucesso'].includes(s)) {
            if (!beatSalesMap[sale.beatTitle]) {
              beatSalesMap[sale.beatTitle] = {
                title: sale.beatTitle,
                image: sale.beatImage,
                salesCount: 0,
                earnings: 0
              };
            }
            beatSalesMap[sale.beatTitle].salesCount += 1;
            beatSalesMap[sale.beatTitle].earnings += sale.price;
          }
        });

        const sortedBestSellers = Object.values(beatSalesMap)
          .sort((a, b) => b.earnings - a.earnings)
          .slice(0, 5);
        setBestSellers(sortedBestSellers);

        // 7. Generate monthly revenue history (last 6 months)
        const last6Months: Record<string, number> = {};
        const monthNames = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        for (let i = 5; i >= 0; i--) {
          const date = new Date();
          date.setMonth(date.getMonth() - i);
          const mKey = `${monthNames[date.getMonth()]} ${date.getFullYear().toString().slice(-2)}`;
          last6Months[mKey] = 0;
        }

        paidSales.forEach((sale: any) => {
          try {
            const saleDate = new Date(sale.created_at);
            const mKey = `${monthNames[saleDate.getMonth()]} ${saleDate.getFullYear().toString().slice(-2)}`;
            if (last6Months[mKey] !== undefined) {
              last6Months[mKey] += sale.price;
            }
          } catch (e) {
            console.error('Error calculating monthly revenue partition:', e);
          }
        });

        const sortedRevenue = Object.entries(last6Months).map(([month, rev]) => ({
          month,
          revenue: rev
        }));
        setRevenueData(sortedRevenue);

      } catch (err) {
        console.error('Error in Vendas fetching:', err);
      } finally {
        setLoading(false);
        console.timeEnd('VENDAS LOAD');
      }
    }

    fetchSalesData();
  }, [userId, refreshTrigger]);

  const getStatusBadge = (status: string) => {
    const s = status.toLowerCase();
    if (['paid', 'completed', 'concluido', 'sucesso'].includes(s)) {
      return (
        <span className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-[#10B981] bg-[#10B981]/10 px-3 py-1.5 rounded-full">
          <CheckCircle size={10} /> Pago
        </span>
      );
    } else if (['pending', 'waiting', 'waiting_confirmation', 'aguardando'].includes(s)) {
      return (
        <span className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3 py-1.5 rounded-full animate-pulse">
          <Clock size={10} /> Pendente
        </span>
      );
    } else {
      return (
        <span className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-gray-400 bg-gray-400/10 px-3 py-1.5 rounded-full">
          <AlertCircle size={10} /> {status}
        </span>
      );
    }
  };

  if (loading) {
    return <InstagramLoader label="A carregar analítica de vendas..." />;
  }

  return (
    <div className="p-6 md:py-8 md:pr-10 md:pl-4 space-y-10 animate-in fade-in duration-700">
      <header>
        <h2 className="text-4xl font-black text-white italic tracking-tighter uppercase mb-2">
          Painel de <span className="text-amber-500">Vendas</span>
        </h2>
        <p className="text-gray-400 font-medium">Acompanha a faturação detalhada, licenças e encomendas dos teus beats.</p>
      </header>

      {/* Stats Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { 
            label: 'Vendas Confirmadas', 
            value: `${salesStats.totalSalesCount}`, 
            desc: `${salesStats.activeOrdersCount} encomendas pendentes`,
            icon: Music, 
            color: 'text-amber-500', 
            bg: 'from-amber-400/10 to-transparent' 
          },
          { 
            label: 'Lucro Líquido (90%)', 
            value: `${salesStats.netEarnings.toLocaleString('pt-AO')} Kz`, 
            desc: `Comissão: ${salesStats.commissionPaid.toLocaleString('pt-AO')} Kz`,
            icon: DollarSign, 
            color: 'text-emerald-500', 
            bg: 'from-emerald-400/10 to-transparent' 
          },
          { 
            label: 'Preço Médio / Venda', 
            value: `${salesStats.averagePrice.toLocaleString('pt-AO')} Kz`, 
            desc: 'Faturação por beat vendido',
            icon: TrendingUp, 
            color: 'text-blue-500', 
            bg: 'from-blue-400/10 to-transparent' 
          },
          { 
            label: 'Faturação Bruta', 
            value: `${salesStats.grossEarnings.toLocaleString('pt-AO')} Kz`, 
            desc: 'Faturação total consolidada',
            icon: Package, 
            color: 'text-rose-400', 
            bg: 'from-rose-400/10 to-transparent' 
          }
        ].map((item, i) => (
          <div key={i} className="relative group bg-[#050505] border border-white/5 p-6 rounded-xl overflow-hidden transition-all duration-300 hover:border-[#6366f1]/35">
            <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full blur-3xl opacity-10 bg-[#5865F2]/5`} />
            <div className="flex justify-between items-start mb-6">
              <div className={`p-3 rounded-2xl bg-white/5 ${item.color}`}>
                <item.icon size={22} />
              </div>
            </div>
            <div>
              <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em] mb-1.5">{item.label}</p>
              <p className="text-3xl font-black text-white italic tracking-tighter mb-1.5">{item.value}</p>
              <p className="text-xs text-gray-400 font-bold uppercase tracking-wide">{item.desc}</p>
            </div>
          </div>
        ))}
      </section>

      {/* Revenue & Top Selling Section */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Monthly Revenue Chart */}
        <div className="lg:col-span-2 bg-[#050505] border border-white/5 p-8 rounded-xl space-y-6 hover:border-[#6366f1]/35 transition-all duration-300">
          <div>
            <h3 className="text-lg font-black text-white uppercase tracking-widest italic">Análise de Receita</h3>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Evolução Mensal (Últimos 6 meses)</p>
          </div>

          <div className="h-[280px] w-full min-w-0 relative">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis 
                  dataKey="month" 
                  stroke="#ffffff20" 
                  fontSize={10} 
                  fontWeight={700}
                  tickLine={false}
                  axisLine={false}
                  dy={10}
                />
                <YAxis 
                  stroke="#ffffff20" 
                  fontSize={10} 
                  fontWeight={700}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip cursor={{fill: '#ffffff05'}} content={<CustomTooltip />} />
                <Bar 
                  dataKey="revenue" 
                  name="revenue"
                  fill="#f59e0b" 
                  radius={[8, 8, 0, 0]} 
                  barSize={36}
                >
                  {revenueData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === revenueData.length - 1 ? '#F59E0B' : '#3B82F6'} fillOpacity={0.8} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Selling Beats */}
        <div className="bg-[#050505] border border-white/5 p-8 rounded-xl space-y-6 hover:border-[#6366f1]/35 transition-all duration-300">
          <div>
            <h3 className="text-lg font-black text-white uppercase tracking-widest italic">Mais Vendidos</h3>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Beats líderes em faturação</p>
          </div>

          <div className="space-y-4">
            {bestSellers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-center gap-3">
                <img 
                  src="https://i.ibb.co/hF1MD85X/20260523-155411.png" 
                  className="w-10 h-10 object-contain filter grayscale opacity-40 hover:opacity-80 transition-opacity" 
                  referrerPolicy="no-referrer"
                  alt="Logo" 
                />
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest leading-relaxed">Nenhum beat vendido de momento</p>
              </div>
            ) : (
              bestSellers.map((beat, idx) => (
                <div key={idx} className="flex items-center justify-between p-3.5 bg-black/40 border border-white/5 rounded-2xl hover:border-white/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-gray-800 border border-white/5 flex items-center justify-center">
                      {beat.image ? (
                        <img src={beat.image} alt={beat.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <Music className="text-gray-500" size={16} />
                      )}
                      <div className="absolute top-1 left-1 bg-amber-500 text-black text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                        {idx + 1}
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-black text-white line-clamp-1">{beat.title}</p>
                      <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{beat.salesCount} {beat.salesCount === 1 ? 'venda' : 'vendas'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-black text-amber-500 italic">+{beat.earnings.toLocaleString('pt-AO')} Kz</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Detailed Orders & Customers List */}
      <section className="bg-[#050505] border border-white/5 p-8 rounded-xl space-y-6 hover:border-[#6366f1]/35 transition-all duration-300">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
          <div>
            <h3 className="text-xl font-black text-white uppercase tracking-widest italic">Historial de Transações</h3>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Registo em tempo real das vendas e encomendas</p>
          </div>
        </div>

        <div className="overflow-x-auto min-w-full">
          {salesItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center gap-4">
              <Sparkles size={40} className="text-gray-600 animate-pulse" />
              <div>
                <p className="text-sm text-white font-black uppercase tracking-widest mb-1">Ainda sem histórico de vendas</p>
                <p className="text-xs text-gray-500 font-medium">As tuas transações detalhadas aparecerão aqui assim que receberes a primeira encomenda.</p>
              </div>
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/5 pb-4">
                  <th className="py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest font-mono">Data</th>
                  <th className="py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest font-mono">Comprador</th>
                  <th className="py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest font-mono">Beat</th>
                  <th className="py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest font-mono">Receita Bruta</th>
                  <th className="py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest font-mono">Teu Lucro (90%)</th>
                  <th className="py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest font-mono text-right">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.03]">
                {salesItems.map((sale) => (
                  <tr key={sale.id} className="hover:bg-white/[0.01] transition-colors group">
                    <td className="py-4 text-xs font-semibold text-gray-400 font-mono">
                      {new Date(sale.created_at).toLocaleDateString('pt-AO', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <User size={13} className="text-gray-500" />
                        <span className="text-xs font-bold text-white max-w-[150px] truncate">{sale.customerName}</span>
                      </div>
                    </td>
                    <td className="py-4">
                      <div className="flex items-center gap-2.5">
                        {sale.beatImage ? (
                          <img src={sale.beatImage} className="w-7 h-7 rounded bg-gray-800 object-cover" alt="" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-7 h-7 rounded bg-white/5 flex items-center justify-center">
                            <Music size={12} className="text-gray-400" />
                          </div>
                        )}
                        <span className="text-xs font-black text-white group-hover:text-amber-500 transition-colors">{sale.resolvedTitle}</span>
                      </div>
                    </td>
                    <td className="py-4 text-xs font-semibold text-gray-400">
                      {sale.price.toLocaleString('pt-AO')} Kz
                    </td>
                    <td className="py-4 text-xs font-black text-emerald-500 italic">
                      {sale.net.toLocaleString('pt-AO')} Kz
                    </td>
                    <td className="py-4 text-right">
                      <div className="flex justify-end">
                        {getStatusBadge(sale.status)}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
}
