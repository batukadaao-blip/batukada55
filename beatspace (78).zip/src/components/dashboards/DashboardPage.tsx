import React from 'react';
import ProducerDashboardLayout from './producer/Layout';
import ArtistDashboardLayout from './artist/Layout';
import { useAuth } from '../../context/AuthContext';
import { Beat } from '../../types';

interface DashboardPageProps {
  beats: Beat[];
  handlePlay: (beat: Beat) => void;
  addToCart: (beat: Beat) => void;
  currentBeat: Beat | null;
  isPlaying: boolean;
  onSelectProducer: (producerName: string) => void;
  onSelectBeat?: (beat: Beat) => void;
}

export default function DashboardPage({ beats, handlePlay, addToCart, currentBeat, isPlaying, onSelectProducer, onSelectBeat }: DashboardPageProps) {
  const { profile, loading } = useAuth();

  React.useEffect(() => {
    console.log('[BOOT] Dashboard loaded');
  }, []);

  if (loading) {
    return (
      <div className="pt-20 min-h-screen bg-black flex items-center justify-center">
        <div className="text-zinc-500 font-bold text-xs uppercase tracking-widest animate-pulse">
          A carregar painel...
        </div>
      </div>
    );
  }

  // Use profile.role directly from profiles database as the absolute source of truth
  const activeRole = profile?.role || 'buyer';
  const isAdmin = activeRole === 'admin';
  const isProducer = activeRole === 'seller' || activeRole === 'producer' || isAdmin;

  console.log('DASHBOARD ROLE:', activeRole);
  console.log('IS PRODUCER:', isProducer);
  console.log('IS ADMIN:', isAdmin);
  console.log('RENDERING:', isProducer ? 'PRODUCER' : 'ARTIST');

  return (
    <div className="pt-20 min-h-screen">
      {isProducer ? (
        <ProducerDashboardLayout onSelectProducer={onSelectProducer} />
      ) : (
        <ArtistDashboardLayout 
          beats={beats}
          handlePlay={handlePlay}
          addToCart={addToCart}
          currentBeat={currentBeat}
          isPlaying={isPlaying}
          onSelectProducer={onSelectProducer}
          onSelectBeat={onSelectBeat}
        />
      )}
    </div>
  );
}
