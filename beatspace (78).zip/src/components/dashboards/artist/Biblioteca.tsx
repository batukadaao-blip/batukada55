import React, { useState, useEffect } from 'react';
import { 
  Music, 
  Package, 
  Search, 
  Download, 
  FileText, 
  Play, 
  Pause, 
  MoreVertical,
  Filter,
  Loader2,
  Sparkles,
  ShoppingBag,
  ShieldCheck,
  Lock
} from 'lucide-react';
import { motion } from 'motion/react';
import { getSupabase, getPublicUrl, getBeatSignedUrl } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import InstagramLoader from '../../InstagramLoader';

export default function Biblioteca() {
  const [activeTab, setActiveTab] = useState<'Tudo' | 'Beats' | 'Kits'>('Tudo');
  const [searchQuery, setSearchQuery] = useState('');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const { user } = useAuth();
  const supabase = getSupabase();

  useEffect(() => {
    async function fetchBiblioteca() {
      if (!supabase || !user) {
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        // Fetch purchased beats
        const { data: purchasedBeats, error: pbErr } = await supabase
          .from('purchased_beats')
          .select('*')
          .eq('customer_id', user.id);

        if (pbErr) throw pbErr;

        if (!purchasedBeats || purchasedBeats.length === 0) {
          setItems([]);
          setLoading(false);
          return;
        }

        const toValidIntId = (id: any): number => {
          if (!id) return 1;
          const strId = String(id).trim();
          const parsed = parseInt(strId, 10);
          if (!isNaN(parsed)) return parsed;
          const lastParts = strId.split('-');
          return parseInt(lastParts[lastParts.length - 1], 10) || 1;
        };

        const beatIds = purchasedBeats.map((pb: any) => toValidIntId(pb.beat_id)).filter(id => !isNaN(id));

        if (beatIds.length === 0) {
          setItems([]);
          setLoading(false);
          return;
        }

        // Fetch beat records
        const { data: beatsData, error: beatsErr } = await supabase
          .from('beats')
          .select('*')
          .in('id', beatIds);

        if (beatsErr) throw beatsErr;

        // Fetch producer profiles to get usernames
        const { data: profilesData } = await supabase.from('profiles').select('id, artistic_name, display_name');
        const profileMap = new Map((profilesData || []).map(p => [p.id, p.artistic_name || p.display_name]));

        // Fetch corresponding orders to restrict unconfirmed items
        const orderIds = purchasedBeats.map((pb: any) => pb.order_id).filter((id: any) => id !== null && id !== undefined);
        let ordersData: any[] = [];
        if (orderIds.length > 0) {
          const { data: oData, error: oErr } = await supabase
            .from('orders')
            .select('id, status')
            .in('id', orderIds);
          if (!oErr && oData) {
            ordersData = oData;
          }
        }

        const mappedItems = purchasedBeats.map((pb: any, idx: number) => {
          const numericId = toValidIntId(pb.beat_id);
          const beatDetail = beatsData?.find((b: any) => toValidIntId(b.id) === numericId);
          const matchedOrder = ordersData.find((o: any) => String(o.id) === String(pb.order_id));
          
          let producerName = 'Produtor';
          if (beatDetail) {
            producerName = profileMap.get(beatDetail.producer_id) || beatDetail.producer_name || beatDetail.artist_name || 'Produtor';
          }

          return {
            id: pb.id || `pb-${idx}`,
            beatId: pb.beat_id,
            title: beatDetail?.title || 'Instrumental',
            producer: producerName,
            type: beatDetail?.category && ['drum-kit', 'loop-kit', 'sample-pack'].includes(beatDetail.category) ? 'Kit' : 'Beat',
            license: pb.license_type || (pb.license_id === 1 ? 'Basic' : pb.license_id === 2 ? 'Premium' : 'Exclusive'),
            image: beatDetail?.cover_url ? getPublicUrl('beats', beatDetail.cover_url) : 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=500',
            date: pb.created_at ? new Date(pb.created_at).toLocaleDateString('pt-AO', { day: '2-digit', month: 'short', year: 'numeric' }) : 'Recente',
            audioUrl: beatDetail?.demo_url ? getPublicUrl('beats', beatDetail.demo_url) : '',
            orderStatus: matchedOrder?.status || 'pending'
          };
        });

        setItems(mappedItems);
      } catch (err) {
        console.error('Error fetching library:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchBiblioteca();
  }, [user, supabase]);

  const handleDownloadFile = async (item: any) => {
    const s = String(item.orderStatus || 'pending').toLowerCase();
    const canAccess = ['completed', 'paid', 'approved', 'confirmed'].includes(s);
    if (!canAccess) {
      alert("Acesso negado. Ficheiro protegido até confirmação do pagamento.");
      return;
    }

    if ((item.type === 'Beat' || item.type === 'Kit') && item.beatId) {
      const fileKey = (item.license?.toLowerCase() === 'premium' || item.license?.toLowerCase() === 'exclusive') ? 'stems' : 'master';
      try {
        const signedUrl = await getBeatSignedUrl(item.beatId, fileKey);
        if (signedUrl) {
          window.open(signedUrl, '_blank');
        } else {
          // fallback to 'master' which represents premium file/zip
          const fbUrl = await getBeatSignedUrl(item.beatId, 'master');
          if (fbUrl) {
            window.open(fbUrl, '_blank');
          } else {
            alert("Não foi possível gerar um link seguro para o ficheiro premium.");
          }
        }
      } catch (err) {
        console.error(err);
        alert("Erro ao preparar link seguro.");
      }
      return;
    }

    // Fallback for items without specific type/id
    if (!item.audioUrl) {
      alert("Nenhum ficheiro oficial correspondente gerado para download.");
      return;
    }
    const fullUrl = item.audioUrl.startsWith('http') ? item.audioUrl : getPublicUrl('beats', item.audioUrl);
    if (fullUrl) {
      window.open(fullUrl, '_blank');
    } else {
      alert("Erro ao resolver link de descarga.");
    }
  };

  const filteredItems = items.filter(item => {
    const matchesTab = activeTab === 'Tudo' || (activeTab === 'Beats' && item.type === 'Beat') || (activeTab === 'Kits' && item.type === 'Kit');
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || item.producer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  if (loading) {
    return (
      <div className="p-6 md:p-10 space-y-8 animate-in fade-in duration-700">
        <InstagramLoader label="A carregar a tua biblioteca musical..." />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 space-y-8 animate-in fade-in duration-700">
      <header className="flex flex-col gap-6">
        <div>
          <h2 className="text-4xl font-black text-white italic tracking-tighter uppercase">Minha <span className="text-blue-500">Biblioteca</span></h2>
          <p className="text-gray-400 font-medium">Todos os teus beats e kits adquiridos num só lugar.</p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-white/5 p-4 rounded-3xl border border-white/10">
          <div className="flex bg-black/40 p-1.5 rounded-2xl w-full md:w-auto">
            {['Tudo', 'Beats', 'Kits'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={`px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${
                  activeTab === tab ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-gray-500 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
            <input 
              type="text"
              placeholder="Procurar na colecção..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-black/40 border border-white/5 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:border-blue-500/50 transition-colors"
            />
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {filteredItems.map((item, i) => {
          const canAccess = ['completed', 'paid', 'approved', 'confirmed'].includes(String(item.orderStatus || 'pending').toLowerCase());

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className="group relative bg-white/5 border border-white/10 rounded-[2.5rem] overflow-hidden flex flex-col hover:border-white/20 transition-all font-sans"
            >
              {/* Image Section */}
              <div className="aspect-square relative overflow-hidden">
                <img 
                  src={item.image || undefined} 
                  alt={item.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                />
                
                {!canAccess ? (
                  <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center gap-2 text-center p-4 select-none">
                    <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/20 rounded-full flex items-center justify-center text-amber-500">
                      <Lock size={16} />
                    </div>
                    <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Acesso Restrito</span>
                    <span className="text-[8px] text-gray-400 font-bold uppercase tracking-wider block">Pagamento Pendente</span>
                  </div>
                ) : (
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                    <div className="flex gap-3">
                      {item.type === 'Beat' && (
                        <button 
                          onClick={() => setPlayingId(playingId === item.id ? null : item.id)}
                          className="w-12 h-12 rounded-full bg-blue-500 text-white flex items-center justify-center shadow-xl hover:scale-110 active:scale-95 transition-all cursor-pointer"
                        >
                          {playingId === item.id ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-1" />}
                        </button>
                      )}
                      <button 
                        onClick={() => handleDownloadFile(item)}
                        className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-xl hover:scale-110 active:scale-95 transition-all cursor-pointer"
                      >
                        <Download size={20} />
                      </button>
                    </div>
                  </div>
                )}
                
                <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                  <span className="text-[9px] font-black text-white italic uppercase tracking-widest">{item.license}</span>
                </div>
              </div>

              {/* Content Section */}
              <div className="p-6 space-y-4 flex-grow">
                <div>
                  <h4 className="text-lg font-black text-white uppercase tracking-tighter italic leading-tight">{item.title}</h4>
                  <p className="text-[10px] text-blue-500 font-bold uppercase tracking-[0.2em]">{item.producer}</p>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/5 mt-auto">
                  <div className="flex flex-col">
                     <span className="text-[8px] text-gray-500 font-black uppercase tracking-widest">Comprado em</span>
                     <span className="text-[10px] text-white font-bold">{item.date}</span>
                  </div>
                  {!canAccess ? (
                    <div className="p-2 text-amber-500/80" title="Protegido - Pagamento Pendente">
                      <Lock size={16} />
                    </div>
                  ) : (
                    <button 
                      onClick={() => handleDownloadFile(item)}
                      className="p-2 text-gray-500 hover:text-white transition-colors cursor-pointer"
                    >
                      <FileText size={18} />
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {items.length === 0 ? (
        <div className="relative overflow-hidden flex flex-col items-center justify-center py-20 px-6 bg-[#050505] border border-white/5 rounded-xl text-center max-w-3xl mx-auto">

          <div className="relative mb-6">
            <div className="w-20 h-20 rounded-[2rem] bg-white/[0.02] border border-white/5 flex items-center justify-center text-blue-500 shadow-xl">
              <ShoppingBag size={32} className="stroke-[1.5] animate-bounce" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center text-black border-2 border-[#040406]">
              <ShieldCheck size={12} fill="currentColor" />
            </div>
          </div>

          <span className="text-[10px] font-black uppercase tracking-[0.25em] text-blue-500 mb-2">A tua colecção comercial</span>
          <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter mb-3">
            Nenhum instrumental adquirido ainda
          </h3>
          <p className="text-gray-400 font-semibold mb-8 text-xs max-w-md leading-relaxed">
            Todas as tuas licenças ativas, masters em alta qualidade e pistas (stems) em formato WAV aparecerão protegidos aqui após a compra, prontos para download imediato.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-md mb-8 text-left">
            <div className="p-4 rounded-2xl bg-white/[0.01] border border-white/5 space-y-1">
              <span className="text-[9px] font-black text-blue-400 uppercase tracking-wider block">Garantia</span>
              <h4 className="text-xs font-black text-white uppercase tracking-tight">Donwload Instântaneo</h4>
              <p className="text-[9px] text-gray-500 font-medium leading-relaxed">Arquivos oficiais liberados logo após confirmação de pagamento.</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.01] border border-white/5 space-y-1">
              <span className="text-[9px] font-black text-amber-500 uppercase tracking-wider block">Legal</span>
              <h4 className="text-xs font-black text-white uppercase tracking-tight">Licença em PDF</h4>
              <p className="text-[9px] text-gray-500 font-medium leading-relaxed">Contrato digital completo que garante os teus direitos de distribuição.</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.01] border border-white/5 space-y-1">
              <span className="text-[9px] font-black text-emerald-400 uppercase tracking-wider block">Suporte</span>
              <h4 className="text-xs font-black text-white uppercase tracking-tight">Acesso Eterno</h4>
              <p className="text-[9px] text-gray-500 font-medium leading-relaxed">Ficheiros sempre guardados para novas sessões no teu estúdio.</p>
            </div>
          </div>

          <button 
            onClick={() => {
              localStorage.setItem('artist_dashboard_tab', 'Descoberta');
              window.location.reload();
            }}
            className="group relative flex items-center justify-center gap-3 bg-[#5865F2] hover:bg-[#4752C4] text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[11px] transition duration-300 transform hover:scale-[1.02] active:scale-95 shadow-xl shadow-[#5865F2]/10 border border-[#5865F2]/20 cursor-pointer"
          >
            <Sparkles size={16} fill="currentColor" />
            Explorar Trending Beats
          </button>
        </div>
      ) : filteredItems.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 rounded-[1.5rem] bg-white/5 flex items-center justify-center text-gray-500 mb-4">
                <Search size={28} />
            </div>
            <h3 className="text-lg font-black text-white uppercase italic">Nenhum item correspondente</h3>
            <p className="text-gray-500 font-bold text-xs uppercase tracking-widest mt-2">Tenta mudar ou limpar os termos do teu filtro de pesquisa.</p>
        </div>
      )}
    </div>
  );
}
