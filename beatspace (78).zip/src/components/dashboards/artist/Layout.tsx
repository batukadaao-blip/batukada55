import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Library, 
  Heart, 
  ShieldCheck, 
  Settings as SettingsIcon, 
  Moon, 
  Sun, 
  Music,
  Plus,
  MessageSquare,
  Sparkles,
  ListMusic,
  User
} from 'lucide-react';
import VisaoGeral from './VisaoGeral';
import Biblioteca from './Biblioteca';
import Favoritos from './Favoritos';
import MeuPerfil from './MeuPerfil';
import DiscoverySection from '../../DiscoverySection';
import PlaylistDetailsPage from '../../PlaylistDetailsPage';
import { useDarkMode } from '@/src/lib/useDarkMode';
import { Beat } from '../../../types';
import { useAuth } from '../../../context/AuthContext';
import { getSupabase } from '../../../lib/supabase';
import { mapDbToClient } from '../../../lib/profileMapper';

import Licencas from './Licencas';

interface ArtistDashboardLayoutProps {
  beats: Beat[];
  handlePlay: (beat: Beat) => void;
  addToCart: (beat: Beat) => void;
  currentBeat: Beat | null;
  isPlaying: boolean;
  onSelectProducer: (producerName: string) => void;
  onSelectBeat?: (beat: Beat) => void;
}

export default function ArtistDashboardLayout({ beats, handlePlay, addToCart, currentBeat, isPlaying, onSelectProducer, onSelectBeat }: ArtistDashboardLayoutProps) {
  const { user, profile: authProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('Visão Geral');
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [isDarkMode, toggleDarkMode] = useDarkMode();
  const profile = React.useMemo(() => {
    if (authProfile) {
      return mapDbToClient(authProfile as any);
    }
    
    return {
      artisticName: 'Artista Urbano',
      city: 'Luanda',
      phone: '+244 955 000 000',
      yearsExp: '3',
      bio: '',
      profilePhotoUrl: '',
      bannerPhotoUrl: '',
      socials: { ig: '', tw: '', tiktok: '', web: '' },
      username: ''
    };
  }, [authProfile]);

  // Instrument log of Layout profile as requested
  useEffect(() => {
    console.log("LAYOUT PROFILE OBJECT:", profile);
  }, [profile]);

  useEffect(() => {
    const tab = localStorage.getItem('artist_dashboard_tab');
    if (tab) {
      setActiveTab(tab);
      localStorage.removeItem('artist_dashboard_tab');
    }
  }, []);

  const navItems = [
    { name: 'Visão Geral', icon: LayoutDashboard },
    { name: 'Biblioteca', icon: Library },
    { name: 'Descoberta', icon: Sparkles },
    { name: 'Favoritos', icon: Heart },
    { name: 'Licenças Ativas', icon: ShieldCheck },
    { name: 'Meu Perfil', icon: User },
  ];

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-[#000000] text-white">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-e border-white/5 bg-[#000000] p-6 shrink-0 h-screen sticky top-0">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-white/[0.04] border border-white/[0.08]">
              <img 
                src="https://i.ibb.co/hF1MD85X/20260523-155411.png" 
                className="w-4 h-4 object-contain" 
                referrerPolicy="no-referrer"
                alt="Logo" 
              />
            </div>
            <div>
              <p className="text-xs font-bold tracking-tight text-white mb-0 leading-tight">Batukada</p>
              <p className="text-[9px] font-semibold text-zinc-500 uppercase tracking-widest leading-none">Artistas</p>
            </div>
          </div>
          <span className="text-[8px] font-semibold uppercase tracking-wider bg-white/5 border border-white/10 text-zinc-400 px-1.5 py-0.5 rounded">
            VIP
          </span>
        </div>

        {/* Small Session Info */}
        <div className="mb-6 p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-zinc-800 border border-white/10 flex items-center justify-center text-xs font-bold text-zinc-300 uppercase shrink-0">
            {profile.artisticName ? profile.artisticName.substring(0, 2).toUpperCase() : 'A'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-black pointer-events-none truncate text-white leading-tight mb-0.5">{profile.artisticName}</p>
            <p className="text-[9px] text-[#3b82f6] font-semibold tracking-wider uppercase leading-none">Membro verificado</p>
          </div>
        </div>

        <nav className="space-y-1 flex-1">
          {navItems.map((item) => (
            <button
              key={item.name}
              onClick={() => setActiveTab(item.name)}
              className={`flex items-center space-x-3 w-full px-3.5 py-2.5 cursor-pointer rounded-lg transition-all duration-150 group relative ${
                activeTab === item.name 
                  ? 'bg-white/[0.04] text-white font-semibold border-white/[0.08]' 
                  : 'text-zinc-400 hover:text-white hover:bg-white/[0.02]'
              }`}
            >
              {activeTab === item.name && (
                <div className="absolute left-0 top-2 bottom-2 w-1 rounded bg-[#3b82f6]" />
              )}
              <item.icon size={15} strokeWidth={activeTab === item.name ? 2.2 : 1.8} className={activeTab === item.name ? 'text-blue-400' : 'text-zinc-500 group-hover:text-white transition-colors'} />
              <span className={`text-[11px] tracking-wide font-medium ${activeTab === item.name ? 'text-white font-bold' : ''}`}>
                {item.name}
              </span>
            </button>
          ))}
        </nav>

        <div className="mt-auto pt-4 border-t border-white/5">
          <button onClick={toggleDarkMode} className="flex items-center space-x-2.5 px-3 py-2.5 cursor-pointer w-full text-zinc-400 hover:text-white rounded-lg hover:bg-white/[0.02] transition-colors">
              {isDarkMode ? <Sun size={15} /> : <Moon size={15} />}
              <span className="font-semibold text-[9px] tracking-wider uppercase">{isDarkMode ? 'Brilho' : 'Escuro'}</span>
          </button>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 bg-[#000000] h-full overflow-y-auto">
        {activeTab === 'Visão Geral' && <VisaoGeral userName={profile.artisticName} />}
        {activeTab === 'Biblioteca' && <Biblioteca />}
        {activeTab === 'Descoberta' && (
          <div className="p-6 md:p-10">
            {selectedPlaylistId ? (
              <PlaylistDetailsPage
                playlistId={selectedPlaylistId}
                beats={beats}
                onBack={() => setSelectedPlaylistId(null)}
                onPlay={handlePlay}
                isPlaying={isPlaying}
                currentBeat={currentBeat}
                onAddToCart={addToCart}
              />
            ) : (
              <DiscoverySection
                beats={beats}
                onPlay={handlePlay}
                isPlaying={isPlaying}
                currentBeat={currentBeat}
                onAddToCart={addToCart}
                onSelectBeat={onSelectBeat}
                onSelectPlaylist={(id) => setSelectedPlaylistId(id)}
              />
            )}
          </div>
        )}
        {activeTab === 'Favoritos' && (
          <Favoritos 
            handlePlay={handlePlay}
            addToCart={addToCart}
            currentBeat={currentBeat}
            isPlaying={isPlaying}
            onSelectProducer={onSelectProducer}
            onSelectBeat={onSelectBeat}
          />
        )}
        {activeTab === 'Licenças Ativas' && <Licencas />}
        {activeTab === 'Meu Perfil' && <MeuPerfil />}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full bg-[#000000]/95 border-t border-white/5 backdrop-blur-xl flex justify-around p-2 pb-6 z-50">
        {navItems.map((item) => (
            <button
                key={item.name}
                onClick={() => setActiveTab(item.name)}
                className={`flex flex-col items-center p-2 transition-all ${
                    activeTab === item.name ? 'text-blue-500' : 'text-gray-500'
                }`}
            >
                <item.icon size={20} strokeWidth={activeTab === item.name ? 2.5 : 2} />
                <span className="text-[9px] font-black uppercase tracking-widest mt-1.5">{item.name}</span>
            </button>
        ))}
      </nav>
    </div>
  );
}
