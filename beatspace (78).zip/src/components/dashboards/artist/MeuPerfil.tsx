import React, { useState, useEffect, useRef } from 'react';
import { 
  User, Sparkles, MapPin, Calendar, AtSign, AlignLeft, 
  Camera, Upload, Save, Loader2, CheckCircle, AlertCircle, Edit3, ArrowLeft, ShieldCheck, Globe,
  Terminal, ShieldAlert, Database, AlertTriangle
} from 'lucide-react';
import { getSupabase, getPublicUrl } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';

const ANGOLA_LOCATIONS = [
  "Bengo",
  "Benguela",
  "Bié",
  "Cabinda",
  "Quando",
  "Cuando Cubango",
  "Cuanza Norte",
  "Cuanza Sul",
  "Cunene",
  "Huambo",
  "Huíla",
  "Icolo e Bengo",
  "Luanda",
  "Lunda Norte",
  "Lunda Sul",
  "Malanje",
  "Moxico",
  "Moxico Leste",
  "Namibe",
  "Uíge",
  "Zaire"
];

const getInitials = (name: string) => {
  if (!name) return 'AU';
  const cleanName = name.trim();
  if (!cleanName) return 'AU';
  const parts = cleanName.split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
  }
  return cleanName.substring(0, Math.min(2, cleanName.length)).toUpperCase();
};

export default function MeuPerfil() {
  const { user, profile, refreshProfile, setProfile } = useAuth();

  // EXTREMAMENTE DETALHADO: COMPROVAÇÃO DE ORIGEM DO ESTADO
  console.log("==================== [DIAGNÓSTICO COMPLETO MEUPERFIL] ====================");
  console.log("MEUPERFIL PROFILE SOURCE:", profile);
  console.log("1. VALORES DOS CAMPOS DIRETAMENTE DO OBJETO PROFILE:");
  console.log("   - profile.id :", profile?.id);
  console.log("   - profile.username (snake_case) :", (profile as any)?.username);
  console.log("   - profile.username (camelCase fallback) :", (profile as any)?.username);
  console.log("   - profile.artistic_name (snake_case) :", (profile as any)?.artistic_name);
  console.log("   - profile.artisticName (camelCase) :", (profile as any)?.artisticName);
  console.log("   - profile.display_name (snake_case) :", (profile as any)?.display_name);
  console.log("   - profile.displayName (camelCase) :", (profile as any)?.displayName);
  
  console.log("2. VALORES DAS VARIÁVEIS DE ESTADO LOCAIS (useState):");
  // Como são declaradas abaixo, vamos logar no useEffect ou render correspondente, mas mostramos os valores lidos da fonte.
  console.log("   - Árvore de Fluxo: Layout -> MeuPerfil");
  console.log("   - Layout não passa props ao MeuPerfil!");
  console.log("   - Renderização no Layout: <MeuPerfil />");
  console.log("   - Isto significa que o MeuPerfil obtém o perfil DIRETAMENTE de AuthContext (useAuth())");
  console.log("=========================================================================");

  // MUST match the requested telemetry exact format:
  console.log("-----------------------------------------");
  console.log("MeuPerfil está a renderizar:");
  console.log("profile.id =", profile?.id || 'null');
  console.log("MeuPerfil está a renderizar:");
  console.log("username =", (profile as any)?.username || 'null');
  console.log("MeuPerfil está a renderizar:");
  console.log("artistic_name =", ((profile as any)?.artistic_name || (profile as any)?.display_name) || 'null');
  console.log("-----------------------------------------");

  const [isEditing, setIsEditing] = useState(false);
  
  // Loaded State
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [location, setLocation] = useState('Luanda, Angola');
  const [avatarUrl, setAvatarUrl] = useState('');
  
  // Form/Input Control Refs
  const avatarInputRef = useRef<HTMLInputElement>(null);
  
  // UI Statuses
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'err' } | null>(null);
  
  // Angola location select dropdown state
  const [provinceSearch, setProvinceSearch] = useState('');
  const [isProvinceSelectOpen, setIsProvinceSelectOpen] = useState(false);
  
  // Username validation state
  // 'empty' | 'invalid' | 'checking' | 'available' | 'taken' | 'error' | 'unchanged'
  const [usernameStatus, setUsernameStatus] = useState<'empty' | 'invalid' | 'checking' | 'available' | 'taken' | 'error' | 'unchanged'>('unchanged');

  // Real-time Database Transaction Audit State
  const [auditInfo, setAuditInfo] = useState<{
    status: 'idle' | 'running' | 'success' | 'warn_rls' | 'error';
    timestamp: string;
    currentUserEmail: string;
    currentUserID: string;
    targetTable: string;
    whereClause: string;
    beforeState: {
      display_name: string;
      username: string;
      avatar_url: string;
      bio: string;
      location: string;
    };
    payloadSent: any;
    httpStatus: number;
    httpStatusText: string;
    rowsAffected: number;
    returnedData: any;
    dbStateAfter: any;
    matchingFields: {
      display_name: boolean;
      username: boolean;
      avatar_url: boolean;
      city: boolean;
      bio: boolean;
    };
    errorMessage: string;
  } | null>(null);

  // Load and populate fields on mount
  useEffect(() => {
    const runAbsoluteProofDiagnostics = async () => {
      if (!user) return;
      const supabase = getSupabase();
      if (!supabase) return;

      console.log("=========================================");
      console.log("🔍 [PROVA ABSOLUTA] REQUISITANDO DADOS:");
      console.log("AUTH PROFILE RAW:", profile);

      try {
        // Querying exactly what the user requested: avatar_url, banner_url (if exists as column), display_name, artistic_name, username
        // We select "*" to be safe and avoid column-not-exist failures for banner_url, then print them as a post-query projection.
        const { data: freshDbData, error: freshDbError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();

        if (freshDbError) {
          console.error("DATABASE PROFILE ERROR:", freshDbError);
        } else if (freshDbData) {
          console.log("DATABASE PROFILE SELECTION OUTPUT:");
          console.log({
            avatar_url: freshDbData.avatar_url,
            display_name: freshDbData.display_name,
            artistic_name: freshDbData.artistic_name,
            username: freshDbData.username,
            phone_metadata: freshDbData.phone
          });
          
          console.log("--- RESULTADO DOS VALORES QUE IRÃO PARA O FORMULÁRIO ---");
          console.log("DATABASE PROFILE VALUE FOR AVATAR:", freshDbData.avatar_url);
        } else {
          console.warn("Nenhum registo de perfil encontrado no Supabase para o ID:", user.id);
        }
      } catch (err) {
        console.error("Erro ao rodar diagnóstico absoluto:", err);
      }
      console.log("=========================================");
    };

    runAbsoluteProofDiagnostics();

    if (profile) {
      setDisplayName(profile.display_name || profile.artistic_name || 'Artista Urbano');
      setUsername(profile.username || '');
      
      // Support phone-packed bio extraction for robust client sync
      let parsedBio = '';
      if (profile.phone && profile.phone.startsWith('{')) {
        try {
          const parsed = JSON.parse(profile.phone);
          parsedBio = parsed.bio || '';
        } catch (e) {
          console.error("Bio JSON parse error in MeuPerfil mount:", e);
        }
      }
      setBio(profile.bio || parsedBio || '');
      
      setLocation(profile.city || 'Luanda, Angola');
      setAvatarUrl(profile.avatar_url || '');
      setIsLoading(false);
    }
  }, [profile]);

  // Instrument log of MeuPerfil profile as requested
  useEffect(() => {
    console.log('RENDER AVATAR SOURCE:', avatarUrl);
    console.log('PROFILE RAW OBJECT:', profile);
    console.log("BIO AUTHCONTEXT VALUE:", profile?.bio);
  }, [avatarUrl, profile]);

  // Outside click listener for custom location dropdown
  useEffect(() => {
    if (!isProvinceSelectOpen) return;
    const handleOutsideClick = (e: MouseEvent) => {
      const container = document.getElementById('province-dropdown-container');
      if (container && !container.contains(e.target as Node)) {
        setIsProvinceSelectOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [isProvinceSelectOpen]);

  // Validation checking on username input change
  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.toLowerCase().replace(/\s+/g, '').replace(/[^a-z0-9_]/g, '');
    setUsername(rawValue);
    
    const initialClean = (profile?.username || '').replace(/^@/, '').toLowerCase().trim();
    if (rawValue === initialClean) {
      setUsernameStatus('unchanged');
      return;
    }

    if (!rawValue) {
      setUsernameStatus('empty');
      return;
    }

    if (rawValue.length < 3) {
      setUsernameStatus('invalid');
      return;
    }

    triggerUniqueUsernameCheck(rawValue);
  };

  // Debounced/called uniqueness check
  const checkTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const triggerUniqueUsernameCheck = (name: string) => {
    if (checkTimeoutRef.current) clearTimeout(checkTimeoutRef.current);
    
    setUsernameStatus('checking');
    checkTimeoutRef.current = setTimeout(async () => {
      try {
        const supabase = getSupabase();
        if (!supabase) return;
        
        const { data, error } = await supabase
          .from('profiles')
          .select('id')
          .eq('username', name)
          .not('id', 'eq', user?.id)
          .maybeSingle();

        if (error) throw error;
        
        if (data) {
          setUsernameStatus('taken');
        } else {
          setUsernameStatus('available');
        }
      } catch (err) {
        console.error('Uniqueness assessment failed:', err);
        setUsernameStatus('error');
      }
    }, 500);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar') => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (!file.type.startsWith('image/')) {
      alert('Carrega uma imagem válida (PNG, JPG ou WEBP).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('Tamanho máximo excedido. Reduz para menos de 5MB.');
      return;
    }

    setUploadingAvatar(true);

    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Supabase indisponível.');

      const cleanFilename = `${user.id}/${type}_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
      let targetUrl = '';
      let uploadError = null;

      try {
        const { error } = await supabase.storage
          .from('avatars')
          .upload(cleanFilename, file, {
            cacheControl: '3600',
            upsert: true
          });
        uploadError = error;
        if (!uploadError) {
          targetUrl = getPublicUrl('avatars', cleanFilename);
        }
      } catch (directErr) {
        uploadError = directErr;
      }

      // Fallback via server-side proxy upload if direct fails
      if (uploadError) {
        console.warn('[MEU PERFIL] Storage upload direct failed, trying proxy...', uploadError);
        try {
          const base64Data = await new Promise<string>((resolve, reject) => {
            const r = new FileReader();
            r.onloadend = () => resolve(r.result as string);
            r.onerror = reject;
            r.readAsDataURL(file);
          });

          const { data: { session } } = await supabase.auth.getSession();
          const token = session?.access_token;

          const response = await fetch('/api/storage/upload', {
            method: 'POST',
            headers: { 
              'Content-Type': 'application/json',
              ...(token ? { 'Authorization': `Bearer ${token}` } : {})
            },
            body: JSON.stringify({
              base64Data,
              bucket: 'avatars',
              path: cleanFilename,
              contentType: file.type || 'application/octet-stream'
            })
          });

          if (!response.ok) {
            const errDetails = await response.json().catch(() => ({}));
            throw new Error(errDetails.error || `HTTP ${response.status}`);
          }

          const responseData = await response.json();
          targetUrl = responseData.fileUrl;
        } catch (proxyErr: any) {
          throw new Error(proxyErr.message || 'Falha ao processar imagem no servidor.');
        }
      }

      setAvatarUrl(targetUrl);
      setNotification({ message: 'Foto de perfil carregada com sucesso!', type: 'success' });

    } catch (err: any) {
      console.error('[UPLOAD ERROR]', err);
      setNotification({ message: 'Erro ao carregar ficheiro: ' + err.message, type: 'err' });
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleSave = async () => {
    // Audit telemetry check
    console.log("BIO BEFORE SAVE:", bio);

    if (!user) {
      console.error("[MEU PERFIL] Save aborted: user not authenticated in standard AuthContext.");
      return;
    }
    
    if (!displayName.trim()) {
      setNotification({ message: 'O Nome de Exibição é obrigatório.', type: 'err' });
      return;
    }

    if (usernameStatus === 'taken') {
      setNotification({ message: 'Este Nome de Utilizador já está registado por outro artista.', type: 'err' });
      return;
    }

    if (usernameStatus === 'invalid') {
      setNotification({ message: 'Nome de Utilizador demasiado curto ou inválido.', type: 'err' });
      return;
    }

    setIsSaving(true);

    const checkSupabase = getSupabase();
    const sessionTokenExists = !!(checkSupabase as any)?.auth?.session?.access_token;
    
    // 1. CAPTURE BEFORE STATE
    const stateAntes = {
      display_name: profile?.display_name || profile?.artistic_name || '',
      username: profile?.username || '',
      avatar_url: profile?.avatar_url || '',
      bio: profile?.bio || '',
      location: profile?.city || ''
    };

    console.log("====================================================");
    console.log("🚨 [MÉTRICA AUDITORIA] ANTES DO UPDATE:");
    console.log(" - ID do Usuário do Contexto:", user.id);
    console.log(" - ID no DB (Query Condition WHERE): profiles.id = '" + user.id + "'");
    console.log(" - Campo 'username' ANTES:", stateAntes.username);
    console.log(" - Campo 'display_name' (artistic_name) ANTES:", stateAntes.display_name);
    console.log(" - Campo 'avatar_url' ANTES:", stateAntes.avatar_url);
    console.log(" - Campo 'bio' ANTES:", stateAntes.bio);
    console.log(" - Campo 'location' (city) ANTES:", stateAntes.location);
    console.log("====================================================");

    // Initial audit reactive state
    const currentTimestamp = new Date().toISOString();
    const tempAudit: any = {
      status: 'running',
      timestamp: currentTimestamp,
      currentUserEmail: user.email || 'N/D',
      currentUserID: user.id,
      targetTable: 'profiles',
      whereClause: `id = "${user.id}"`,
      beforeState: stateAntes,
      payloadSent: null,
      httpStatus: 0,
      httpStatusText: '',
      rowsAffected: 0,
      returnedData: null,
      dbStateAfter: null,
      matchingFields: {
        display_name: false,
        username: false,
        avatar_url: false,
        city: false,
        bio: false
      },
      errorMessage: ''
    };
    setAuditInfo(tempAudit);

    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Conexão ao Supabase falhou (Cliente está null).');

      // Pack string metadata
      const packedMetadata = JSON.stringify({
        phone: profile?.phone && profile.phone.startsWith('{') ? JSON.parse(profile.phone).phone : (profile?.phone || ''),
        bio: bio,
        instagram_url: profile?.phone && profile.phone.startsWith('{') ? JSON.parse(profile.phone).instagram_url : '',
        youtube_url: profile?.phone && profile.phone.startsWith('{') ? JSON.parse(profile.phone).youtube_url : '',
        twitter_url: profile?.phone && profile.phone.startsWith('{') ? JSON.parse(profile.phone).twitter_url : '',
        website_url: profile?.phone && profile.phone.startsWith('{') ? JSON.parse(profile.phone).website_url : '',
        genres: profile?.phone && profile.phone.startsWith('{') ? JSON.parse(profile.phone).genres : [],
        years_exp: profile?.phone && profile.phone.startsWith('{') ? JSON.parse(profile.phone).years_exp : '3'
      });

      const updatePayload: any = {
        username: username.trim(),
        artistic_name: displayName.trim(),
        display_name: displayName.trim(),
        avatar_url: avatarUrl,
        city: location,
        bio: bio,
        phone: packedMetadata,
        updated_at: new Date().toISOString()
      };

      console.log("BIO UPDATE PAYLOAD:", updatePayload);

      tempAudit.payloadSent = updatePayload;

      console.log("👉 [MÉTRICA AUDITORIA] PAYLOAD ENVIADO PARA UPDATE:", JSON.stringify(updatePayload, null, 2));

      // Execute UPDATE
      let { data: updateData, error: updateError, status: updateStatus, statusText } = await supabase
        .from('profiles')
        .update(updatePayload)
        .eq('id', user.id)
        .select();

      tempAudit.httpStatus = updateStatus;
      tempAudit.httpStatusText = statusText || 'OK';
      tempAudit.returnedData = updateData;

      console.log("🔍 [MÉTRICA AUDITORIA] RESULTADO DO UPDATE SUPABASE:", { 
        status: updateStatus, 
        statusText, 
        error: updateError, 
        rowsReturned: updateData ? updateData.length : 0,
        data: updateData 
      });

      // Self-healing check for schema mismatch on 'bio'
      if (updateError && (updateError.message?.includes('bio') || updateError.message?.includes('schema cache') || updateError.code === 'PGRST204')) {
        console.warn("⚠️ [MÉTRICA AUDITORIA] Coluna 'bio' falhou no cache do schema. A tentar novamente removendo coluna bio...");
        delete updatePayload.bio;
        tempAudit.payloadSent = updatePayload;
        
        const retryRes = await supabase
          .from('profiles')
          .update(updatePayload)
          .eq('id', user.id)
          .select();
          
        updateError = retryRes.error;
        updateData = retryRes.data;
        tempAudit.httpStatus = retryRes.status;
        tempAudit.httpStatusText = retryRes.statusText || 'OK';
        tempAudit.returnedData = updateData;
        console.log("💡 [MÉTRICA AUDITORIA] RESULTADO RETRY UPDATE SUPABASE:", { 
          status: retryRes.status, 
          error: updateError, 
          rowsReturned: updateData ? updateData.length : 0 
        });
      }

      if (updateError) {
        console.error("❌ [MÉTRICA AUDITORIA] ERRO ENCONTRADO NO UPDATE:", updateError);
        tempAudit.status = 'error';
        tempAudit.errorMessage = updateError.message || JSON.stringify(updateError);
        setAuditInfo({ ...tempAudit });
        throw updateError;
      }

      const rowsCount = updateData ? updateData.length : 0;
      tempAudit.rowsAffected = rowsCount;

      // Supabase special RLS check logic: when httpStatus is successful but returned row count is 0
      if (rowsCount === 0) {
        console.error("⛔ [MÉTRICA AUDITORIA] SINTOMA RLS DETECTADO: UPDATE executado mas 0 linhas foram afetadas.");
        tempAudit.status = 'warn_rls';
        tempAudit.errorMessage = "Causo: 0 linhas afetadas no update. Isso ocorre tipicamente quando as políticas de RLS (Row Level Security) não conferem permissões de UPDATE ao usuário autenticado para seu próprio UID, ou se a linha não existe na tabela 'profiles'.";
        
        // Let's run a select to confirm context exists
        const { data: selectContextCheck } = await supabase
          .from('profiles')
          .select('id')
          .eq('id', user.id)
          .maybeSingle();
        
        console.log("ℹ️ [MÉTRICA AUDITORIA] RLS Verificar existência da linha no DB: ", selectContextCheck ? "EXISTE" : "NÃO EXISTE");
        setAuditInfo({ ...tempAudit });
        setNotification({ 
          message: 'Falha de gravação RLS: 0 linhas afetadas pelo teu update.', 
          type: 'err' 
        });
        setIsSaving(false);
        return;
      }

      // 2. RUN INDEPENDENT SELECT CONFIRMATION FOR ABSOLUTE PROOF
      console.log("🔄 [MÉTRICA AUDITORIA] EXECUTANDO SELECT DE CONFIGURAÇÃO PÓS-UPDATE...");
      
      // Target exact requested print output:
      console.log("=========================================");
      console.log("1. USER ID AUTENTICADO:", user.id);
      console.log("2. PROFILE ID SENDING UPDATE:", profile?.id || 'null');
      console.log("3. EXECUTANDO:");
      console.log("SELECT id, display_name, artistic_name, username FROM profiles WHERE id = '" + user.id + "'");

      const { data: selectCheck, error: selectError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      console.log("BIO SELECT RESULT:", selectCheck);

      if (selectError) {
        console.error("❌ [MÉTRICA AUDITORIA] Falha no SELECT de comprovação de integridade:", selectError);
        tempAudit.status = 'error';
        tempAudit.errorMessage = "Erro no SELECT imediato pós-update: " + selectError.message;
        setAuditInfo({ ...tempAudit });
        throw selectError;
      }

      console.log("4. RESULTADO REAL DA QUERIED TABLE:");
      if (selectCheck) {
        console.log({
          id: selectCheck.id,
          display_name: selectCheck.display_name,
          artistic_name: selectCheck.artistic_name,
          username: selectCheck.username
        });
      } else {
        console.log("Nenhum registo encontrado.");
      }
      console.log("=========================================");

      tempAudit.dbStateAfter = selectCheck;
      console.log("📊 [MÉTRICA AUDITORIA] DADOS REAIS LIDOS DA TABELA profiles APÓS UPDATE:", selectCheck);

      if (!selectCheck) {
        console.error("❌ [MÉTRICA AUDITORIA] Linha de perfil vazia no SELECT pós-update!");
        tempAudit.status = 'error';
        tempAudit.errorMessage = "Erro: A linha de perfil foi lida como null após o update.";
        setAuditInfo({ ...tempAudit });
        throw new Error("Não foi possível carregar o teu perfil do banco após alteração.");
      }

      // 3. COMPARE BEFORE AND AFTER DETAILED FIELDS
      const hasBioColumn = selectCheck.hasOwnProperty('bio');
      const hasCityColumn = selectCheck.hasOwnProperty('city');
      
      const matchDetails = {
        display_name: selectCheck.display_name === displayName.trim() || selectCheck.artistic_name === displayName.trim(),
        username: selectCheck.username === username.trim(),
        avatar_url: selectCheck.avatar_url === avatarUrl,
        city: selectCheck.city === location,
        bio: !hasBioColumn ? true : selectCheck.bio === bio
      };

      tempAudit.matchingFields = matchDetails;

      console.log("====================================================");
      console.log("🚨 [MÉTRICA AUDITORIA] DEPOIS DO UPDATE (SELEÇÃO DIRETA DO BANCO):");
      console.log(" - Campo 'username' AGORA:", selectCheck.username, " (Corresponde?: " + matchDetails.username + ")");
      console.log(" - Campo 'display_name' (artistic_name) AGORA:", selectCheck.display_name, " (Corresponde?: " + matchDetails.display_name + ")");
      console.log(" - Campo 'avatar_url' AGORA:", selectCheck.avatar_url, " (Corresponde?: " + matchDetails.avatar_url + ")");
      console.log(" - Campo 'bio' AGORA:", selectCheck.bio, " (Corresponde?: " + matchDetails.bio + ")");
      console.log(" - Campo 'location' (city) AGORA:", selectCheck.city, " (Corresponde?: " + matchDetails.city + ")");
      console.log("====================================================");

      // Invalidate frontend local storage cache
      localStorage.removeItem('artistProfile');
      localStorage.removeItem('producerProfile');
      localStorage.removeItem('user_profile');

      // Unpack bio from phone JSON field if direct bio property is empty/null/missing
      const finalSelectCheck = selectCheck ? { ...selectCheck } : null;
      if (finalSelectCheck && finalSelectCheck.phone && finalSelectCheck.phone.startsWith('{')) {
        try {
          const parsed = JSON.parse(finalSelectCheck.phone);
          if (parsed && parsed.bio && !finalSelectCheck.bio) {
            (finalSelectCheck as any).bio = parsed.bio;
          }
        } catch (e) {}
      }

      // Set fresh profile from SELECT immediately to AuthContext
      if (setProfile) {
        console.log("UPDATE CORRECTION: Assigning fresh profile to AuthContext dynamically...", finalSelectCheck);
        setProfile(finalSelectCheck as any);
      }

      if (refreshProfile) {
        console.log("🔋 [MÉTRICA AUDITORIA] Sincronizando contexto de autenticação AuthContext...");
        await refreshProfile();
      }

      tempAudit.status = 'success';
      setAuditInfo({ ...tempAudit });

      setNotification({ message: 'O teu perfil foi persistido e sincronizado com sucesso!', type: 'success' });
      setIsEditing(false);
      setUsernameStatus('unchanged');

      window.dispatchEvent(new CustomEvent('profileUpdated'));
      window.dispatchEvent(new Event('auth_state_change'));

    } catch (err: any) {
      console.error('💥 [MÉTRICA AUDITORIA] EXCEÇÃO CRÍTICA ENCONTRADA:', err);
      tempAudit.status = 'error';
      tempAudit.errorMessage = err.message || JSON.stringify(err);
      setAuditInfo({ ...tempAudit });
      setNotification({ message: 'Erro do servidor ao gravar perfil: ' + err.message, type: 'err' });
    } finally {
      setIsSaving(false);
    }
  };

  // Safe format join date helper
  const getFormattedJoinDate = () => {
    if (profile?.created_at) {
      try {
        const date = new Date(profile.created_at);
        const mName = date.toLocaleDateString('pt-AO', { month: 'long' });
        return `${mName.charAt(0).toUpperCase() + mName.slice(1)} de ${date.getFullYear()}`;
      } catch (err) {
        return 'Janeiro de 2024';
      }
    }
    return 'Janeiro de 2024';
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
        <Loader2 className="animate-spin text-blue-500" size={36} />
        <p className="text-zinc-500 text-xs font-mono uppercase tracking-widest">A carregar informações do utilizador...</p>
      </div>
    );
  }

  // Log the render value of the Bio for the telemetry request
  console.log("BIO RENDER VALUE:", bio);

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6 relative pb-24">
      
      {/* Dynamic Pop Action Toast */}
      {notification && (
        <div 
          onClick={() => setNotification(null)}
          className={`fixed top-24 right-4 md:right-8 z-50 p-4 rounded-xl shadow-xl flex items-center gap-3 border animate-in fade-in slide-in-from-top-4 duration-300 cursor-pointer ${
            notification.type === 'success' 
              ? 'bg-emerald-950/95 text-emerald-300 border-emerald-500/20' 
              : 'bg-rose-950/95 text-rose-300 border-rose-500/20'
          }`}
        >
          {notification.type === 'success' ? <CheckCircle size={18} /> : <AlertCircle size={18} />}
          <span className="text-xs font-semibold leading-normal">{notification.message}</span>
        </div>
      )}

      {/* Profile Header Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter flex items-center gap-2">
            <User className="text-emerald-500" size={24} />
            {isEditing ? 'Editar Perfil' : 'Meu Perfil'}
          </h2>
          <p className="text-zinc-400 text-xs mt-1">Gere a tua identidade pública e presença oficial na plataforma Batukada.</p>
        </div>

        <button 
          onClick={() => {
            setIsEditing(!isEditing);
            setUsernameStatus('unchanged');
          }}
          className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 cursor-pointer transition-all active:scale-[0.98] ${
            isEditing 
              ? 'bg-zinc-800 hover:bg-zinc-700 text-white border border-white/5' 
              : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-500/15'
          }`}
        >
          {isEditing ? (
            <>
              <ArrowLeft size={13} /> Voltar ao Perfil
            </>
          ) : (
            <>
              <Edit3 size={13} /> Editar Meu Perfil
            </>
          )}
        </button>
      </div>

      {/* HIGH FIDELITY PROFILE PREVIEW INTERFACE (isEditing = false) */}
      {!isEditing ? (
        <div className="space-y-6">
          
          {/* Centered Profile Card without banner */}
          <div className="relative rounded-[2rem] overflow-hidden border border-white/5 bg-zinc-950 p-8 md:p-12 shadow-2xl flex flex-col items-center justify-center text-center">
            {/* Subtle premium ambient background glow inside */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.03),transparent_60%)] pointer-events-none" />
            <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.005)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.005)_1px,transparent_1px)] bg-[size:32px_32px] opacity-20 pointer-events-none" />

            {/* Profile image border wrapper - Centered */}
            <div className="w-32 h-32 md:w-36 md:h-36 rounded-full overflow-hidden p-1 bg-black border-2 border-emerald-500/80 shadow-[0_0_20px_rgba(16,185,129,0.15)] shrink-0 flex items-center justify-center relative z-10">
              {avatarUrl ? (
                <img 
                  src={avatarUrl} 
                  className="w-full h-full object-cover rounded-full" 
                  referrerPolicy="no-referrer"
                  alt="Avatar" 
                />
              ) : (
                <div className="w-full h-full rounded-full bg-gradient-to-br from-[#0c0c14] via-zinc-900 to-zinc-950 border border-white/5 flex flex-col items-center justify-center text-center select-none">
                  <span className="text-3xl md:text-4xl font-extrabold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-200">
                    {getInitials(displayName)}
                  </span>
                  <span className="text-[7px] font-mono tracking-widest text-emerald-500 font-bold uppercase mt-1">BATUKADA ARTIST</span>
                </div>
              )}
            </div>

            {/* Identity labels container */}
            <div className="space-y-4 mt-6 relative z-10 w-full max-w-md">
              <div className="flex flex-col items-center gap-1">
                <h1 className="text-2xl md:text-3xl font-black text-white italic tracking-tighter leading-none mb-1">
                  {displayName}
                </h1>
                <span className="text-indigo-400 font-bold font-mono text-sm tracking-wide">
                  @{username || displayName.toLowerCase().replace(/\s+/g, '')}
                </span>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 text-xs font-mono text-zinc-400 pt-1">
                <span className="flex items-center gap-1.5 bg-white/[0.02] border border-white/5 px-3 py-1.5 rounded-xl">
                  <MapPin size={12} className="text-zinc-500" />
                  <span>{location}</span>
                </span>

                <span className="flex items-center gap-1.5 bg-white/[0.02] border border-white/5 px-3 py-1.5 rounded-xl">
                  <Calendar size={12} className="text-zinc-500" />
                  <span>{getFormattedJoinDate()}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Biography presentation module */}
          <div className="bg-white/[0.01] border border-white/5 rounded-[2rem] p-6 md:p-8 space-y-6">
            <div className="flex items-center gap-3 border-b border-white/5 pb-4">
              <AlignLeft className="text-emerald-400" size={18} />
              <h3 className="text-sm font-black uppercase tracking-wider text-white">Sobre Mim (Apresentação)</h3>
            </div>

            <p className="text-zinc-300 leading-relaxed text-sm whitespace-pre-line">
              {bio ? bio : 'Este utilizador ainda não adicionou uma biografia. Carrega no botão "Editar Meu Perfil" acima para adicionares e personalizares o teu cartão de apresentação público.'}
            </p>
          </div>

        </div>
      ) : (
        /* COMPREHENSIVE EDITING FORMS MODULE (isEditing = true) */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column: Image Identity Panel (Span 1) */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Avatar upload center */}
            <div className="bg-white/[0.01] border border-white/5 p-6 rounded-[2rem] text-center space-y-4">
              <p className="text-[10px] font-black uppercase tracking-widest text-zinc-505">Foto de Perfil</p>
              
              <div className="relative w-28 h-28 mx-auto rounded-full p-0.5 border-2 border-dashed border-emerald-500/40 bg-zinc-950 flex items-center justify-center group overflow-hidden">
                {avatarUrl ? (
                  <img 
                    src={avatarUrl} 
                    className="w-full h-full object-cover rounded-full" 
                    referrerPolicy="no-referrer"
                    alt="Avatar Preview" 
                  />
                ) : (
                  <div className="w-full h-full rounded-full bg-gradient-to-br from-[#0c0c14] via-zinc-900 to-zinc-950 flex flex-col items-center justify-center text-center select-none">
                    <span className="text-2xl font-black text-emerald-400">
                      {getInitials(displayName)}
                    </span>
                  </div>
                )}
                
                {/* Loader overlay */}
                {uploadingAvatar && (
                  <div className="absolute inset-0 bg-black/75 flex items-center justify-center z-10 rounded-full">
                    <Loader2 className="animate-spin text-emerald-400" size={18} />
                  </div>
                )}
                
                {/* Trigger hover edit layer */}
                <button 
                  onClick={() => avatarInputRef.current?.click()}
                  className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white transition-opacity duration-300 cursor-pointer rounded-full"
                >
                  <Camera size={16} />
                  <span className="text-[9px] font-mono uppercase tracking-wider mt-1.5">Alterar</span>
                </button>
              </div>

              <input 
                type="file" 
                ref={avatarInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={(e) => handleFileUpload(e, 'avatar')} 
              />
              
              <button 
                onClick={() => avatarInputRef.current?.click()}
                className="w-full border border-white/5 hover:bg-white/5 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider text-zinc-300 hover:text-white transition-all cursor-pointer"
              >
                Carregar Nova Imagem
              </button>
            </div>

          </div>

          {/* Right Column: Information form fields (Span 2) */}
          <div className="lg:col-span-2 space-y-6">
            
            <div className="bg-white/[0.01] border border-white/5 p-6 md:p-8 rounded-[2rem] space-y-6">
              
              {/* Display Name input */}
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 block mb-2">
                  Nome de Exibição / Artístico
                </label>
                <input 
                  type="text" 
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Ex: Jay Marshal Artist"
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs text-white placeholder-zinc-600 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 outline-none transition-all font-semibold"
                />
              </div>

              {/* Unique Username Input with Live Verification Ring */}
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 block mb-2">
                  Nome de Utilizador único (Username)
                </label>
                <div className="relative">
                  <div className="absolute left-3.5 top-[13.5px] text-zinc-500 flex items-center justify-center font-bold text-xs">
                    @
                  </div>
                  
                  <input 
                    type="text" 
                    value={username}
                    onChange={handleUsernameChange}
                    placeholder="Ex: artist_name"
                    className="w-full bg-[#06060A] border border-white/5 rounded-xl py-3.5 pl-8 pr-12 text-xs text-white placeholder-zinc-600 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 outline-none transition-all font-mono font-bold"
                  />

                  {/* Visual Status Indicator Circle inside input */}
                  <div className="absolute right-3.5 top-3 flex items-center justify-center">
                    {usernameStatus === 'checking' && (
                      <Loader2 className="animate-spin text-blue-400" size={14} />
                    )}
                    {usernameStatus === 'available' && (
                      <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.7)]" title="Disponível!" />
                    )}
                    {usernameStatus === 'taken' && (
                      <span className="flex h-2.5 w-2.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(239,68,68,0.7)]" title="Indisponível!" />
                    )}
                    {usernameStatus === 'invalid' && (
                      <span className="flex h-2.5 w-2.5 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.7)]" title="Inválido!" />
                    )}
                  </div>
                </div>

                {/* Subtext explanation for uniqueness checks */}
                <div className="mt-2 flex items-center justify-between text-[10px] font-mono">
                  {usernameStatus === 'checking' && (
                    <span className="text-blue-400">A validar nome na base de dados...</span>
                  )}
                  {usernameStatus === 'available' && (
                    <span className="text-emerald-400 font-bold">✓ Username livre e disponível!</span>
                  )}
                  {usernameStatus === 'taken' && (
                    <span className="text-rose-400 font-bold">✗ Este username já se encontra registado.</span>
                  )}
                  {usernameStatus === 'invalid' && (
                    <span className="text-amber-500">Mínimo de 3 caracteres (algarismos, letras ou underscores).</span>
                  )}
                  {usernameStatus === 'unchanged' && (
                    <span className="text-zinc-500">O teu username atual permanente</span>
                  )}
                  {usernameStatus === 'empty' && (
                    <span className="text-zinc-600">Por favor, escreve um nome de utilizador único.</span>
                  )}
                </div>
              </div>

              {/* Custom Province Selector Dropdown layout */}
              <div id="province-dropdown-container" className="relative">
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 block mb-2">
                  Localização / Província
                </label>
                
                <div className="relative">
                  <MapPin className="absolute left-3.5 top-[14px] text-zinc-600" size={14} />
                  
                  <button 
                    type="button" 
                    onClick={() => setIsProvinceSelectOpen(!isProvinceSelectOpen)}
                    className="w-full bg-[#06060A] border border-white/5 rounded-xl py-3.5 pl-10 pr-10 text-zinc-200 text-xs font-semibold text-left outline-none transition-all hover:bg-white/[0.02]"
                  >
                    {location || 'Selecionar Localização'}
                  </button>

                  <div className="absolute right-3.5 top-[14px] pointer-events-none text-zinc-500">
                    <svg className={`w-4 h-4 transition-transform duration-200 ${isProvinceSelectOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>

                  {isProvinceSelectOpen && (
                    <div className="absolute left-0 right-0 mt-2 bg-[#0c0c14] border border-white/10 rounded-xl overflow-hidden shadow-2xl z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                      <div className="p-2 border-b border-white/5">
                        <input 
                          type="text" 
                          value={provinceSearch}
                          onChange={(e) => setProvinceSearch(e.target.value)}
                          placeholder="Pesquisar província..."
                          onClick={(e) => e.stopPropagation()}
                          className="w-full bg-white/[0.03] border border-white/5 rounded-lg py-2 px-3 text-xs text-white focus:border-emerald-500 outline-none transition-all"
                        />
                      </div>

                      <div className="max-h-40 overflow-y-auto divide-y divide-white/[0.02]">
                        {ANGOLA_LOCATIONS.filter(item => item.toLowerCase().includes(provinceSearch.toLowerCase())).length === 0 ? (
                          <div className="p-3 text-xs text-zinc-500 text-center">Nenhuma província encontrada</div>
                        ) : (
                          ANGOLA_LOCATIONS.filter(item => item.toLowerCase().includes(provinceSearch.toLowerCase())).map(prov => {
                            const formatted = `${prov}, Angola`;
                            const active = location === formatted;
                            return (
                              <button
                                key={prov}
                                type="button"
                                onClick={() => {
                                  setLocation(formatted);
                                  setIsProvinceSelectOpen(false);
                                  setProvinceSearch('');
                                }}
                                className={`w-full text-left px-4 py-2.5 text-xs hover:bg-white/[0.03] transition-colors flex items-center justify-between ${
                                  active ? 'text-emerald-400 font-bold bg-emerald-500/5' : 'text-zinc-300'
                                }`}
                              >
                                <span>{formatted}</span>
                                {active && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_6px_rgba(16,185,129,0.7)]" />}
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Bio area */}
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 block mb-2">
                  Biografia do Artista (Apresentação Básica)
                </label>
                <textarea 
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Escreve um pouco sobre ti, influências musicais, géneros preferidos, parcerias..."
                  rows={4}
                  className="w-full bg-[#06060A] border border-white/5 rounded-xl p-3.5 text-xs text-zinc-200 placeholder-zinc-600 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 outline-none transition-all leading-relaxed whitespace-pre"
                />
              </div>

              {/* Action buttons */}
              <div className="flex justify-end gap-3 pt-4 border-t border-white/5">
                <button 
                  type="button" 
                  onClick={() => setIsEditing(false)}
                  className="px-6 py-3 border border-white/5 rounded-xl text-xs font-black uppercase tracking-wide hover:bg-white/[0.03] transition-colors cursor-pointer text-zinc-400 hover:text-white"
                >
                  Cancelar
                </button>

                <button 
                  type="button" 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="bg-emerald-500 hover:bg-emerald-400 text-black px-8 py-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-500/10 disabled:opacity-55 hover:scale-[1.01] active:scale-[0.99]"
                >
                  {isSaving ? (
                    <>
                      <Loader2 size={13} className="animate-spin" /> A guardar...
                    </>
                  ) : (
                    <>
                      <Save size={13} /> Guardar Alterações
                    </>
                  )}
                </button>
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
}
