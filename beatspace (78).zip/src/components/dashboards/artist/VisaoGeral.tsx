import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Package, 
  DollarSign, 
  Layout, 
  ArrowUpRight,
  Clock,
  Play,
  Music
} from 'lucide-react';
import { motion } from 'motion/react';
import { getSupabase } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import InstagramLoader from '../../InstagramLoader';
import OnboardingElegante from '../../OnboardingElegante';

export default function VisaoGeral({ userName }: { userName: string }) {
  const [loading, setLoading] = useState(true);
  const [compras, setCompras] = useState<any[]>([]);
  const [stats, setStats] = useState({
    beatsCount: 0,
    kitsCount: 0,
    totalSpent: 0,
    activeProjects: 3
  });

  const { user } = useAuth();
  const supabase = getSupabase();

  useEffect(() => {
    async function loadArtistData() {
      if (!supabase || !user) {
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        // 1. Fetch purchased_beats separately
        const { data: purchasedBeatsRaw, error: pbErr } = await supabase
          .from('purchased_beats')
          .select('*')
          .eq('customer_id', user.id);

        if (pbErr) {
          console.error("Error fetching licensed beats dashboard:", pbErr);
        }

        const purchasedBeats = purchasedBeatsRaw || [];

        // 2. Fetch orders to sum total spend
        const { data: ordersData, error: ordersErr } = await supabase
          .from('orders')
          .select('id, total_price')
          .eq('buyer_id', user.id);

        if (ordersErr) {
          console.error("Error fetching orders dashboard:", ordersErr);
        }

        const activeOrders = ordersData || [];
        const sumSpent = activeOrders.reduce((acc: number, o: any) => acc + (parseFloat(o.total_price) || 0), 0);

        // 3. Fetch related beat titles
        const toValidIntId = (id: any): number => {
          if (!id) return 1;
          const strId = String(id).trim();
          const parsed = parseInt(strId, 10);
          if (!isNaN(parsed)) return parsed;
          const lastParts = strId.split('-');
          return parseInt(lastParts[lastParts.length - 1], 10) || 1;
        };

        const beatIds = Array.from(new Set(purchasedBeats.map((pb: any) => toValidIntId(pb.beat_id))));

        let beats: any[] = [];
        if (beatIds.length > 0) {
          const { data: beatsData } = await supabase
            .from('beats')
            .select('id, title, producer_id, price_basic, price_premium, price_exclusive')
            .in('id', beatIds);
          if (beatsData) beats = beatsData;
        }

        const { data: profilesData } = await supabase.from('profiles').select('id, artistic_name, display_name');
        const profileMap = new Map((profilesData || []).map(p => [p.id, p.artistic_name || p.display_name]));

        // Load statistics
        setStats({
          beatsCount: purchasedBeats.length,
          kitsCount: 0, 
          totalSpent: sumSpent,
          activeProjects: 3
        });

        // Map recent history
        const mappedHistory = purchasedBeats.map((item: any, idx: number) => {
          const numericBeatId = toValidIntId(item.beat_id);
          const matchedBeat = beats.find((b: any) => toValidIntId(b.id) === numericBeatId);
          const producerName = matchedBeat ? profileMap.get(matchedBeat.producer_id) || matchedBeat.producer_name || 'Produtor' : 'Produtor';
          
          let computedPrice = 0;
          if (matchedBeat) {
            const licType = String(item.license_type || '').toLowerCase();
            if (licType.includes('exclusive')) {
              computedPrice = matchedBeat.price_exclusive || 0;
            } else if (licType.includes('premium')) {
              computedPrice = matchedBeat.price_premium || 0;
            } else {
              computedPrice = matchedBeat.price_basic || 0;
            }
          }

          return {
            id: item.id || `hist-${idx}`,
            title: matchedBeat?.title || 'Instrumental',
            producer: producerName,
            date: item.created_at ? new Date(item.created_at).toLocaleDateString('pt-AO', { day: '2-digit', month: 'short' }) : 'Recente',
            price: computedPrice > 0 ? `${computedPrice.toLocaleString()} Kz` : 'Adquirido',
            type: 'Beat'
          };
        }).slice(0, 4);

        setCompras(mappedHistory);
      } catch (err) {
        console.error("Dashboard exception:", err);
      } finally {
        setLoading(false);
      }
    }

    loadArtistData();
  }, [supabase, user]);

  const metricas = [
    { label: 'Beats Comprados', value: stats.beatsCount.toString(), icon: Music, color: 'blue' },
    { label: 'Kits Comprados', value: stats.kitsCount.toString(), icon: Package, color: 'amber' },
    { label: 'Gasto Total', value: `${stats.totalSpent.toLocaleString()} Kz`, icon: DollarSign, color: 'emerald' },
    { label: 'Projetos Ativos', value: stats.activeProjects.toString(), icon: Layout, color: 'purple' },
  ];

  if (loading) {
    return (
      <div className="p-6 md:p-10 space-y-10">
        <InstagramLoader label="A carregar o teu resumo artístico..." />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 space-y-8 animate-in fade-in duration-300 min-h-screen bg-[#000000] text-white font-sans">
      {/* Premium Breadcrumb and Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-white/[0.04]">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-wider text-zinc-500">
            <span>Área de Artista</span>
            <span className="text-zinc-700">/</span>
            <span className="text-zinc-300">Visão Geral</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">Painel Criativo</h1>
        </div>
        <div className="text-right text-zinc-500 text-[10px] font-mono">
          Nível de Membro: <span className="text-zinc-300 font-bold uppercase text-[9px] px-2 py-0.5 bg-white/5 border border-white/10 rounded-full">Artista VIP</span>
        </div>
      </div>

      <header className="relative bg-[#050505] border border-white/[0.06] p-6 md:p-8 rounded-xl overflow-hidden hover:border-white/10 transition-all duration-150">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-xl md:text-2xl font-semibold text-white tracking-tight mb-1">
              Bem-vindo, <span className="text-white font-bold">{userName}</span>
            </h2>
            <p className="text-xs text-zinc-400">Aqui está o sumário profissional do teu percurso e compras no Batukada.</p>
          </div>
          <div className="flex items-center gap-2 bg-white/[0.04] border border-white/10 text-zinc-300 text-[9px] font-medium tracking-tight uppercase tracking-wider px-3 py-1 rounded-md">
            Conta Ativa
          </div>
        </div>
      </header>

      {/* Onboarding Guide */}
      <OnboardingElegante role="artist" />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {metricas.map((m, i) => (
          <motion.div 
            key={m.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.15, delay: i * 0.02 }}
            className="group relative bg-[#050505] border border-white/[0.06] p-5 rounded-xl overflow-hidden hover:border-white/10 transition-all duration-150"
          >
            <div className="absolute top-0 right-0 w-16 h-16 bg-white/[0.01] rounded-bl-full pointer-events-none transition-all duration-300 group-hover:scale-150 group-hover:bg-white/[0.02]" />
            <div className="relative flex flex-col justify-between h-full space-y-4">
              <div className="flex justify-between items-start">
                <span className="text-zinc-400 text-[10px] font-bold uppercase tracking-wider">{m.label}</span>
                <div className="p-2 rounded-lg bg-zinc-800 border border-white/[0.05] text-zinc-400 group-hover:text-white transition-colors">
                  <m.icon size={13} />
                </div>
              </div>
              <div>
                <p className="text-lg md:text-xl font-extrabold text-white tracking-tight mb-0.5">{m.value}</p>
                <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-wider">Métrica Oficial</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Purchases */}
        <div className="lg:col-span-2 space-y-4 bg-[#050505] border border-white/[0.06] p-5 md:p-6 rounded-xl hover:border-white/10 transition-all duration-150">
          <div className="flex items-center justify-between pb-2 border-b border-white/[0.04]">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Últimas Compras</h3>
              <p className="text-[10px] text-zinc-500 mt-0.5">Instrumentais licenciados recientemente</p>
            </div>
            <button className="text-[10px] font-black text-[#6366f1] uppercase tracking-widest hover:text-white transition-colors cursor-pointer">Ver Tudo</button>
          </div>
          <div className="space-y-3 pt-2">
            {compras.length === 0 ? (
               <div className="flex flex-col items-center justify-center p-8 bg-white/[0.01] border border-dashed border-white/[0.05] rounded-xl text-center py-10">
                 <Music size={20} className="text-zinc-600 mb-2" />
                 <p className="font-bold text-white text-xs">Ainda sem compras</p>
                 <p className="text-zinc-500 text-[11px] max-w-[280px] mx-auto mt-1">
                   Os teus instrumentais e sound kits adquiridos aparecerão aqui depois de encomendados.
                 </p>
               </div>
            ) : (
              compras.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3.5 bg-white/[0.02] border border-white/[0.03] hover:border-white/[0.08] hover:bg-white/[0.03] rounded-xl group transition-all">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-zinc-800 border border-white/[0.04] flex items-center justify-center text-zinc-400 group-hover:bg-blue-500 group-hover:text-white transition-colors">
                      {item.type === 'Beat' ? <Music size={15} /> : <Package size={15} />}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white group-hover:text-blue-400 transition-colors uppercase italic">{item.title}</h4>
                      <p className="text-[10px] text-zinc-500 font-medium">{item.producer}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold text-white">{item.price}</p>
                    <p className="text-[10px] text-zinc-500 font-medium">{item.date}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Quick Actions / Activity */}
        <div className="space-y-6">
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Acesso Rápido</h3>
            <div className="grid gap-3">
              <button className="p-4 bg-[#6366f1] hover:bg-[#5254e2] text-white rounded-xl font-bold text-xs transition-all text-left flex justify-between items-center group cursor-pointer duration-150">
                Explorar Novos Beats
                <div className="w-6 h-6 rounded-lg bg-white/15 flex items-center justify-center group-hover:translate-x-0.5 transition-transform">
                  <Play size={10} fill="currentColor" />
                </div>
              </button>
              <button className="p-4 bg-transparent border border-white/[0.08] text-white rounded-xl font-bold text-xs hover:bg-white/[0.04] transition-all text-left flex justify-between items-center group cursor-pointer duration-150">
                Minha Biblioteca
                <Clock size={15} className="text-zinc-500 group-hover:text-white transition-colors" />
              </button>
            </div>
          </div>

          <div className="p-5 bg-[#050505] border border-white/[0.06] rounded-xl hover:border-white/10 transition-all duration-150">
              <h4 className="text-xs font-extrabold text-white uppercase tracking-wider mb-1">Beat em Destaque</h4>
              <p className="text-[10px] text-zinc-500 font-medium mb-3">Sugerido para o teu style</p>
              <div className="aspect-square rounded-xl bg-white/5 overflow-hidden mb-4 group relative cursor-pointer">
                <img 
                   src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&q=80" 
                   alt="Featured" 
                   loading="lazy"
                   decoding="async"
                   className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play size={24} className="text-white" />
                </div>
              </div>
              <h5 className="text-xs font-bold text-white uppercase italic">Vibe Tropical</h5>
              <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider mt-0.5">Kandimba Beats</p>
          </div>
        </div>
      </div>
    </div>
  );
}
