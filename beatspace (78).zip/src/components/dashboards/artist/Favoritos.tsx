import React, { useState, useEffect } from 'react';
import { Heart } from 'lucide-react';
import { motion } from 'motion/react';
import { getSupabase, getPublicUrl } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import { Beat } from '../../../types';
import BeatCard from '../../BeatCard';
import { playService } from '../../../lib/playService';

interface FavoritosProps {
  handlePlay: (beat: Beat) => void;
  addToCart: (beat: Beat) => void;
  currentBeat: Beat | null;
  isPlaying: boolean;
  onSelectProducer: (producerName: string) => void;
  onSelectBeat?: (beat: Beat) => void;
}

export default function Favoritos({ handlePlay, addToCart, currentBeat, isPlaying, onSelectProducer, onSelectBeat }: FavoritosProps) {
  const [favorites, setFavorites] = useState<Beat[]>([]);
  const { user } = useAuth();
  const supabase = getSupabase();

  useEffect(() => {
    if (!user || !supabase) return;

    const fetchFavorites = async () => {
      // 1. Fetch favorite beat IDs
      const { data: favoritesData, error: favError } = await supabase
        .from('favorites')
        .select('beat_id')
        .eq('user_id', user.id);

      if (favError) {
        console.error('Error fetching favorites:', favError);
        return;
      }
      
      if (!favoritesData || favoritesData.length === 0) {
        console.log('No favorites found for user', user.id);
        setFavorites([]);
        return;
      }

      // Convert stored beat UUIDs back to numeric IDs if they match our padding scheme
      const queryIds = favoritesData.map(f => {
        if (f.beat_id.startsWith('00000000-0000-0000-0000-')) {
          return Number(f.beat_id.split('-')[4].replace(/^0+/, ''));
        }
        return Number(f.beat_id);
      }).filter(id => !isNaN(id));

      if (queryIds.length === 0) {
        setFavorites([]);
        return;
      }
      
      // 2. Fetch beat details using numeric IDs
      const { data: beatsDataRaw, error: beatsError } = await supabase
        .from('beats')
        .select('id, producer_id, title, type, category, bpm, genre, tags, price_basic, price_premium, price_exclusive, cover_url, demo_url, status, artist_name, producer_name, is_free_download, free_download_requires_follow, free_download_requires_comment, free_download_requires_email, free_download_count, plays_count, created_at, updated_at, key, scale, featured, featured_at, featured_priority')
        .in('id', queryIds);

      const beatsData = beatsDataRaw as any[] | null;

      if (beatsError) {
        console.error('Error fetching beat details:', beatsError);
        return;
      }

      if (!beatsData) return;

      // 3. Fetch producer names
      const { data: profilesData } = await supabase.from('profiles').select('id, display_name');
      const profileMap = new Map((profilesData || []).map(p => [p.id, p.display_name]));

      // Map beats to complete beat objects that include public URLs and structured license price arrays
      const mappedBeats = beatsData.map(b => {
        let producerName = profileMap.get(b.producer_id) || b.producer_name || b.artist_name || 'Produtor';
        if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producerName)) {
          producerName = 'Produtor';
        }

        let extractedKey = b.key;
        let extractedScale = b.scale;
        if (b.tags && Array.isArray(b.tags)) {
          const kt = b.tags.find((t: string) => t.startsWith('_key:'));
          if (kt) extractedKey = kt.split(':')[1];
          const st = b.tags.find((t: string) => t.startsWith('_scale:'));
          if (st) extractedScale = st.split(':')[1];
        }
        const cleanTags = b.tags ? b.tags.filter((t: string) => !t.startsWith('_key:') && !t.startsWith('_scale:')) : [];

        return {
          id: b.id,
          title: b.title,
          producer: producerName,
          producer_name: producerName,
          producer_id: b.producer_id,
          genre: b.genre,
          tags: cleanTags,
          price: {
            basic: b.price_basic || 0,
            premium: b.price_premium || 0,
            exclusive: b.price_exclusive || 0
          },
          image: b.cover_url ? getPublicUrl('beats', b.cover_url) : '',
          audioUrl: b.demo_url ? getPublicUrl('beats', b.demo_url) : '',
          bpm: b.bpm || 0,
          type: b.type || 'beat',
          category: b.category,
          plays_count: playService.getPlayCount(b.id, b.plays_count || 0),
          created_at: b.created_at,
          key: extractedKey || 'C',
          scale: extractedScale || 'Maior'
        };
      });

      setFavorites(mappedBeats);
    };

    fetchFavorites();
  }, [user, supabase]);

  // Handle immediate visual cleanup when dynamic favoriteStatusChanged events are received
  useEffect(() => {
    const handleFavoriteChanged = (e: Event) => {
      const customEvent = e as CustomEvent<{ beatId: string | number; isFavorited: boolean }>;
      if (customEvent.detail && !customEvent.detail.isFavorited) {
        setFavorites(prev => prev.filter(b => String(b.id) !== String(customEvent.detail.beatId)));
      }
    };

    window.addEventListener('favoriteStatusChanged', handleFavoriteChanged);
    return () => {
      window.removeEventListener('favoriteStatusChanged', handleFavoriteChanged);
    };
  }, []);

  return (
    <div className="p-6 md:p-10 space-y-10 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-4xl font-black text-white italic tracking-tighter uppercase">Meus <span className="text-red-500">Favoritos</span></h2>
          <p className="text-gray-400 font-medium">Beats que guardaste para mais tarde.</p>
        </div>
      </header>

      {favorites.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {favorites.map((beat, i) => (
            <motion.div
              key={beat.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <BeatCard 
                beat={beat}
                isPlaying={currentBeat?.id === beat.id && isPlaying}
                onPlay={handlePlay}
                onAddToCart={addToCart}
                onSelectProducer={onSelectProducer}
                onSelectBeat={onSelectBeat}
              />
            </motion.div>
          ))}
        </div>
      ) : (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center py-20 text-center space-y-6 bg-white/[0.02] rounded-[3rem] border border-white/5"
        >
          <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center text-rose-500 shadow-xl shadow-rose-500/10">
            <Heart size={32} fill="currentColor" />
          </div>
          <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">Sem favoritos ainda</h3>
          <p className="text-gray-500 font-medium max-w-sm">Explora o marketplace e guarda os teus beats favoritos para ouvi-los e comprá-los mais tarde.</p>
        </motion.div>
      )}
    </div>
  );
}
