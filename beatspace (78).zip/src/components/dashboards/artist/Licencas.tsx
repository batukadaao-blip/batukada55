import React, { useState, useEffect } from 'react';
import { ShieldCheck, User, Clock, ExternalLink, Download, FileText, Music, Lock } from 'lucide-react';
import { motion } from 'motion/react';
import { getSupabase, getPublicUrl, getBeatSignedUrl } from '@/src/lib/supabase';
import { useAuth } from '@/src/context/AuthContext';
import { jsPDF } from 'jspdf';
import { generateLicensePDF } from '@/src/lib/licenseTemplates';
import InstagramLoader from '../../InstagramLoader';

const toValidUuid = (id: any): string => {
  if (!id) return '00000000-0000-0000-0000-000000000000';
  const strId = String(id).trim();
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (uuidRegex.test(strId)) {
    return strId;
  }
  
  if (/^\d+$/.test(strId)) {
    const padded = strId.padStart(12, '0');
    return `00000000-0000-0000-0000-${padded}`;
  }
  
  let hex = '';
  for (let i = 0; i < strId.length; i++) {
    const code = strId.charCodeAt(i);
    hex += (code % 16).toString(16);
  }
  
  const cleanHex = hex.toLowerCase().replace(/[^0-9a-f]/g, '0').padStart(32, '0').substring(0, 32);
  return `${cleanHex.substring(0, 8)}-${cleanHex.substring(8, 12)}-${cleanHex.substring(12, 16)}-${cleanHex.substring(16, 20)}-${cleanHex.substring(20, 32)}`;
};

const toValidIntId = (id: any): number => {
  if (!id) return 1;
  const strId = String(id).trim();
  const parsed = parseInt(strId, 10);
  if (!isNaN(parsed)) {
    return parsed;
  }
  const lastParts = strId.split('-');
  const lastPart = lastParts[lastParts.length - 1];
  const parsedLast = parseInt(lastPart, 10);
  if (!isNaN(parsedLast)) {
    return parsedLast;
  }
  return 1;
};

export default function Licencas() {
  const [purchases, setPurchases] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = getSupabase();
  const { user } = useAuth();

  useEffect(() => {
    fetchLicenses();
  }, [supabase, user]);

  async function fetchLicenses() {
    if (!supabase || !user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const authUser = user;

      // 1. Fetch purchased_beats separately
      const { data: purchasedBeatsRaw, error: pbErr } = await supabase
        .from('purchased_beats')
        .select('*')
        .eq('customer_id', user.id);

      if (pbErr) {
        console.error("Error fetching licensed beats database call:", pbErr);
      }

      const purchasedBeats = purchasedBeatsRaw || [];

      // REQUIRED LOG: AFTER purchased_beats fetch
      console.log(
        'PURCHASED BEATS FETCH:',
        purchasedBeats
      );

      // Collect IDs for independent fetching
      const beatIds = purchasedBeats.map((pb: any) => pb.beat_id).filter((id: any) => id !== null && id !== undefined);
      const orderIds = purchasedBeats.map((pb: any) => pb.order_id).filter((id: any) => id !== null && id !== undefined);
      const licenseIds = purchasedBeats.map((pb: any) => pb.license_id).filter((id: any) => id !== null && id !== undefined);

      const intBeatIds = Array.from(new Set(beatIds.map((id: any) => toValidIntId(id))));

      // 2. Fetch beats
      let beats: any[] = [];
      if (intBeatIds.length > 0) {
        const { data: beatsData, error: beatsErr } = await supabase
          .from('beats')
          .select('*')
          .in('id', intBeatIds);
        if (beatsErr) {
          console.error("Error fetching beats independently:", beatsErr);
        }
        if (beatsData) {
          beats = beatsData;
        }
      }
      console.log('FETCHED BEATS FULL:', JSON.stringify(beats, null, 2));

      // 2.1 Fetch producer profiles
      const producerIds = Array.from(new Set(beats.map((b: any) => b.producer_id).filter((id: any) => id !== null && id !== undefined)));
      let producerProfiles: any[] = [];
      if (producerIds.length > 0) {
        try {
          const { data: profilesData, error: profilesErr } = await supabase
            .from('profiles')
            .select('id, artistic_name, display_name')
            .in('id', producerIds);
          if (profilesErr) {
            console.error("Error fetching producer profiles:", profilesErr);
          }
          if (profilesData) {
            producerProfiles = profilesData;
          }
        } catch (e) {
          console.error("Profiles fetch exception:", e);
        }
      }

      // Construct a robust beatMap mapping by string id, integer id, and padded uuid key
      const beatMap: Record<string, any> = {};
      beats.forEach((b: any) => {
        const intId = toValidIntId(b.id);
        beatMap[String(b.id)] = b;
        beatMap[String(intId)] = b;
        const padded = String(intId).padStart(12, '0');
        beatMap[`00000000-0000-0000-0000-${padded}`] = b;
      });
      console.log('BEAT MAP FULL:', JSON.stringify(beatMap, null, 2));

      // REQUIRED LOGS
      console.log(
        'PURCHASED BEAT IDS:',
        purchasedBeats.map(pb => pb.beat_id)
      );

      console.log(
        'FETCHED BEATS:',
        beats
      );

      console.log(
        'BEAT MAP:',
        beatMap
      );

      const firstPb = purchasedBeats[0];
      if (firstPb) {
        console.log(
          'MAPPING TEST:',
          firstPb.beat_id,
          beatMap[firstPb.beat_id]
        );
      } else {
        console.log(
          'MAPPING TEST:',
          null,
          null
        );
      }

      // 3. Fetch orders
      let orders: any[] = [];
      if (orderIds.length > 0) {
        const { data: ordersData, error: ordersErr } = await supabase
          .from('orders')
          .select('*')
          .in('id', orderIds);
        if (ordersErr) {
          console.error("Error fetching orders independently:", ordersErr);
        }
        if (ordersData) {
          orders = ordersData;
        }
      }

      // 4. Fetch licenses
      let licensesTableData: any[] = [];
      if (licenseIds.length > 0) {
        try {
          const { data: licData, error: licErr } = await supabase
            .from('licenses')
            .select('*')
            .in('id', licenseIds);
          if (licErr) {
            console.warn("Licenses table select issue:", licErr);
          }
          if (licData) {
            licensesTableData = licData;
          }
        } catch (licEx) {
          console.warn("Licenses table fetch exception ignored:", licEx);
        }
      }

      // 5. Relational mapping in-memory
      const mappedLicenses = purchasedBeats.map((pbItem: any) => {
        console.log('CURRENT PURCHASED BEAT:', pbItem);
        console.log('CURRENT LOOKUP ID:', pbItem.beat_id);
        console.log('LOOKUP RESULT:', beatMap[pbItem.beat_id]);

        const pbBeatId = pbItem.beat_id;
        const matchedBeat = beatMap[String(pbBeatId)] || 
                            beatMap[String(toValidIntId(pbBeatId))] || 
                            beats.find((b: any) => toValidIntId(b.id) === toValidIntId(pbBeatId)) || 
                            null;
        const matchedOrder = orders.find((o: any) => String(o.id) === String(pbItem.order_id)) || null;
        const matchedLicense = licensesTableData.find((l: any) => String(l.id) === String(pbItem.license_id)) || null;

        return {
          ...pbItem,
          beats: {
            ...matchedBeat,
            producer_profile: producerProfiles.find((p: any) => p.id === matchedBeat?.producer_id)
          },
          orders: matchedOrder,
          license: matchedLicense,
          license_type: pbItem.license_type || matchedLicense?.name || (pbItem.license_id === 1 ? 'basic' : pbItem.license_id === 2 ? 'premium' : 'exclusive')
        };
      });

      // REQUIRED LOG: AFTER relational mapping
      console.log(
        'FINAL LICENSE OBJECTS:',
        JSON.stringify(mappedLicenses, null, 2)
      );

      // Removed filter: const licenses = mappedLicenses.filter((p: any) => p.orders?.status === 'paid');
      const licenses = mappedLicenses;

      // REQUIRED LOG: BEFORE render
      console.log(
        'FINAL LICENSES:',
        licenses
      );

      // Also log authUser for completeness as required in previous steps
      console.log(
        'AUTH USER ID:',
        authUser?.id
      );

      console.log(
        'PURCHASED_BEATS RAW:',
        purchasedBeats
      );

      console.log(
        'PURCHASED_BEATS COUNT:',
        purchasedBeats?.length
      );

      console.log(
        'LICENSE QUERY RESULT:',
        licenses
      );

      setPurchases(licenses);
    } catch (err) {
      console.error("Exception fetching active licenses:", err);
    } finally {
      setLoading(false);
    }
  }

  const generateLicenseFile = (beatTitle: string, licenseType: string, buyerName: string, orderId: string, date: string, producerName: string, bpm?: string | number, genre?: string, price?: string) => {
    const doc = new jsPDF();
    generateLicensePDF(doc, {
      beatTitle,
      licenseType,
      buyerName,
      producerName,
      orderId,
      date,
      bpm,
      genre,
      price
    });
  };

  async function handleDownloadBeat(p: any) {
    if (!supabase) return;
    const status = String(p.orders?.status || 'pending').toLowerCase();
    const canAccess = ['completed', 'paid', 'approved', 'confirmed'].includes(status);
    if (!canAccess) {
      alert("Acesso negado. Ficheiro protegido até confirmação do pagamento.");
      return;
    }

    const beat = p.beats;
    if (!beat) {
      alert("Metadados do instrumental em falta.");
      return;
    }

    const fileKey = (p.license_type === 'premium' || p.license_type === 'exclusive' || p.license_id === 2 || p.license_id === 3) && beat.stems_url 
      ? 'stems' 
      : 'master';
      
    try {
      const signedUrl = await getBeatSignedUrl(beat.id, fileKey);
      if (signedUrl) {
        window.open(signedUrl, '_blank');
      } else {
        const fallbackUrl = await getBeatSignedUrl(beat.id, 'master');
        if (fallbackUrl) {
          window.open(fallbackUrl, '_blank');
        } else {
          alert("Não foi possível gerar um link seguro temporário para download. Contacte o suporte.");
        }
      }
    } catch (err) {
      console.error(err);
      alert("Falha ao processar descarga de segurança.");
    }
  }

  function handleDownloadLicense(p: any) {
    const status = String(p.orders?.status || 'pending').toLowerCase();
    const canAccess = ['completed', 'paid', 'approved', 'confirmed'].includes(status);
    if (!canAccess) {
      alert("Acesso negado. Contrato protegido até confirmação do pagamento.");
      return;
    }

    try {
      const beatTitle = p.beats?.title || 'Beat';
      const licenseType = p.license_type || (p.license_id === 1 ? 'basic' : p.license_id === 2 ? 'premium' : 'exclusive');
      const buyerName = user?.user_metadata?.full_name || user?.email || 'Artista';
      const orderId = p.order_id || 'N/A';
      const purchaseDate = p.created_at ? new Date(p.created_at).toLocaleDateString() : new Date().toLocaleDateString();
      const producerName = p.beats?.producer_profile?.artistic_name || p.beats?.producer_profile?.display_name || p.beats?.producer_name || p.beats?.producer || 'Produtor Autorizado';
      
      const bpm = p.beats?.bpm || '120';
      const genre = p.beats?.genre || 'Afro House / Semba / Kuduro';
      const priceVal = p.price_paid ? `${p.price_paid.toLocaleString('pt-AO')} Kz` : p.beats?.price ? `${p.beats.price.toLocaleString('pt-AO')} Kz` : 'N/A';

      generateLicenseFile(beatTitle, licenseType, buyerName, orderId, purchaseDate, producerName, bpm, genre, priceVal);
    } catch (err) {
      console.error("Error creating license file:", err);
      alert("Erro ao descarregar a licença.");
    }
  }

  return (
    <div className="p-6 md:p-10 space-y-10 animate-in fade-in duration-700">
      <header>
        <h2 className="text-4xl font-black text-white italic uppercase tracking-tighter">
          Licenças <span className="text-blue-500">Activas</span>
        </h2>
        <p className="text-gray-400 font-medium">Controlo total sobre os teus direitos de uso.</p>
      </header>

      {loading ? (
        <InstagramLoader label="A carregar o seu portfólio de licenças..." />
      ) : purchases.length === 0 ? (
        <div className="bg-[#0B0B0B] border border-white/5 rounded-[2rem] p-12 text-center text-gray-400 space-y-4">
          <Lock className="w-12 h-12 text-gray-600 mx-auto" />
          <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">Nenhuma Licença Ativa</h3>
          <p className="text-sm text-gray-500 font-bold max-w-md mx-auto">
            Assim que os teus pagamentos forem confirmados pelo administrador, as tuas licenças compradas aparecerão aqui prontas para download imediato.
          </p>
        </div>
      ) : (
        <div className="bg-gradient-to-b from-[#0B0B0C] to-[#040405] border border-white/5 rounded-[2.5rem] p-6 shadow-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/[0.04]">
                  <th className="px-6 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Beat Instrumental</th>
                  <th className="px-6 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Produtor</th>
                  <th className="px-6 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Tipo Licença</th>
                  <th className="px-6 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Data</th>
                  <th className="px-6 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Estado</th>
                  <th className="px-6 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Modo Pagamento</th>
                  <th className="px-6 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest text-center">Acções</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.03]">
                {purchases.map((p) => {
                  if (!p.beats) {
                    return null;
                  }

                  const ord = p.orders || {
                    status: 'paid',
                    payment_method: 'paypal',
                    amount: p.price_paid || 25000
                  };

                  const beatTitle = p.beats?.title || 'Obra sem nome';
                  const producerName = p.beats?.producer_profile?.artistic_name || p.beats?.producer_profile?.display_name || p.beats?.producer_name || p.beats?.producer || 'Produtor Autorizado';
                  const purchaseDate = p.created_at ? new Date(p.created_at).toLocaleDateString() : 'N/A';
                  const licenseType = p.license_type || (p.license_id === 1 ? 'Básica' : p.license_id === 2 ? 'Premium' : 'Exclusive');

                  const renderStatusBadge = (status: string) => {
                    const s = String(status).toLowerCase();
                    if (s === 'paid' || s === 'completed' || s === 'approved') {
                      return (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-sm">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          Pago
                        </span>
                      );
                    }
                    if (s === 'pending' || s === 'waiting_confirmation' || s === 'waiting') {
                      return (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-amber-500/10 text-amber-500 border border-amber-500/20 shadow-sm">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                          Pendente
                        </span>
                      );
                    }
                    if (s === 'cancelled' || s === 'canceled') {
                      return (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-red-500/10 text-red-400 border border-red-500/20 shadow-sm">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                          Cancelado
                        </span>
                      );
                    }
                    if (s === 'refunded') {
                      return (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-blue-500/10 text-blue-400 border border-blue-500/20 shadow-sm">
                          <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                          Reembolsado
                        </span>
                      );
                    }
                    return (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-gray-500/10 text-gray-400 border border-gray-500/20">
                        Pendente
                      </span>
                    );
                  };

                  const renderPaymentMethod = (order: any) => {
                    let method = String(order?.payment_method || 'paypal').toLowerCase();
                    if (method.includes('paypal') || method.includes('pp')) {
                      return (
                        <span className="text-[10px] text-gray-400 font-extrabold uppercase bg-white/[0.02] border border-white/5 py-1 px-2.5 rounded-xl">
                          PayPal Premium 💳
                        </span>
                      );
                    }
                    return (
                      <span className="text-[10px] text-gray-400 font-extrabold uppercase bg-white/[0.02] border border-white/5 py-1 px-2.5 rounded-xl">
                        Multicaixa / Transf 🏦
                      </span>
                    );
                  };

                  return (
                    <tr key={p.id} className="group hover:bg-white/[0.01] transition-all duration-300">
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-xl overflow-hidden bg-white/5 border border-white/5 flex items-center justify-center text-gray-500 relative shrink-0 group-hover:scale-105 transition-transform duration-300">
                            {p.beats?.cover_url ? (
                              <img
                                src={getPublicUrl('beats', p.beats.cover_url) || undefined}
                                alt={beatTitle}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <Music size={18} />
                            )}
                          </div>
                          <div>
                            <span className="text-sm font-black text-white uppercase italic tracking-tighter leading-none block group-hover:text-blue-400 transition-colors">
                              {beatTitle}
                            </span>
                            <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest block mt-0.5">
                              ID: {String(p.id).substring(0, 8)}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5 text-xs text-gray-400 font-black uppercase tracking-widest">
                        {producerName}
                      </td>
                      <td className="px-6 py-5">
                        <span
                          className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
                            licenseType.toLowerCase().includes('premium')
                              ? 'bg-amber-500/10 text-amber-500 border border-amber-500/10'
                              : licenseType.toLowerCase().includes('exclusive')
                              ? 'bg-red-500/10 text-red-500 border border-red-500/10'
                              : 'bg-blue-500/10 text-blue-500 border border-blue-500/10'
                          }`}
                        >
                          {licenseType}
                        </span>
                      </td>
                      <td className="px-6 py-5 text-xs text-gray-500 font-bold">{purchaseDate}</td>
                      <td className="px-6 py-5">
                        {renderStatusBadge(ord.status)}
                      </td>
                      <td className="px-6 py-5">
                        {renderPaymentMethod(ord)}
                      </td>
                      <td className="px-6 py-5 text-center font-bold">
                        <div className="flex items-center gap-2.5 justify-center">
                          {!['completed', 'paid', 'approved', 'confirmed'].includes(String(ord.status || 'pending').toLowerCase()) ? (
                            <div className="flex items-center gap-1.5 justify-center px-4 py-2 bg-amber-500/5 border border-amber-500/10 text-[10px] text-amber-500 font-extrabold uppercase tracking-widest rounded-2xl select-none">
                              <Lock size={12} className="shrink-0" /> Restrito
                            </div>
                          ) : (
                            <>
                              <button
                                onClick={() => handleDownloadLicense(p)}
                                title="Descarregar Contrato de Licença"
                                className="p-3 bg-white/[0.03] border border-white/5 rounded-2xl text-gray-400 hover:text-white hover:bg-white/10 active:scale-95 transition-all duration-300 cursor-pointer"
                              >
                                <FileText size={15} />
                              </button>
                              <button
                                onClick={() => handleDownloadBeat(p)}
                                title="Descarregar Beat (Áudio)"
                                className="p-3 bg-blue-600/10 border border-blue-500/10 rounded-2xl text-blue-400 hover:text-white hover:bg-blue-600 active:scale-95 transition-all duration-300 cursor-pointer shadow-sm"
                              >
                                <Download size={15} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Info Card */}
      <div className="p-8 bg-blue-600/5 border border-blue-600/20 rounded-3xl flex items-start gap-6">
        <div className="p-3 bg-blue-600/10 text-blue-500 rounded-2xl">
          <ShieldCheck size={24} />
        </div>
        <div>
          <h4 className="text-sm font-black text-white uppercase tracking-widest mb-2">Informação Jurídica</h4>
          <p className="text-xs text-gray-500 font-bold leading-relaxed max-w-2xl">
            As licenças compradas na nossa plataforma garantem-te o direito legal de usar as obras conforme os termos de cada nível. Em caso de dúvidas sobre monetização ou direitos de autor, consulta o nosso Centro de Ajuda.
          </p>
        </div>
      </div>
    </div>
  );
}
