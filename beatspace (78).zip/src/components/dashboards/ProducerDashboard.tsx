import React from 'react';

export default function ProducerDashboard() {
  return (
    <div className="p-8">
      <h2 className="text-3xl font-black text-white mb-6">Dashboard de Produtor</h2>
      <p className="text-gray-400">Aqui podes gerir os teus beats, ver vendas e estatísticas.</p>
      {/* Add producer specific functionality here */}
    </div>
  );
}
