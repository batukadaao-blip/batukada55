import React, { useState, useEffect, useRef } from 'react';
import { Beat } from '../types';
import { 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  Volume2, 
  VolumeX,
  Heart, 
  ShoppingCart, 
  ListMusic, 
  Maximize2,
  Repeat,
  Shuffle,
  ChevronUp,
  X,
  MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { trackAnalyticsEvent } from '../lib/analytics';
import { playService } from '../lib/playService';

interface PlayerProps {
  currentBeat: Beat | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
  audioElement?: HTMLAudioElement;
  onClose?: () => void;
  globalBeats?: Beat[];
  onPlayBeat?: (beat: Beat) => void;
}

export default function Player({ 
  currentBeat, 
  isPlaying, 
  onTogglePlay, 
  audioElement, 
  onClose,
  globalBeats = [],
  onPlayBeat
}: PlayerProps) {
  const { user, profile } = useAuth();
  const [volume, setVolume] = useState(() => {
    try {
      const stored = localStorage.getItem('beatangola_player_volume');
      return stored ? parseFloat(stored) : 0.8;
    } catch {
      return 0.8;
    }
  });
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  
  // Custom states for Queue, History, Repeat & Shuffle
  const [isRepeat, setIsRepeat] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [queue, setQueue] = useState<Beat[]>([]);
  const [recentlyPlayed, setRecentlyPlayed] = useState<Beat[]>([]);

  // Timeline hovering tooltips
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverX, setHoverX] = useState<number>(0);
  const [bufferedEnd, setBufferedEnd] = useState<number>(0);

  // Real Plays Tracking state, locks, and refs (Section 1, 5, 6, 10, 12)
  const [playTracked, setPlayTracked] = useState(false);
  const playTrackedRef = useRef(false);
  const lastTrackedBeatIdRef = useRef<string | null>(null);
  const lastTimeRef = useRef(0);
  const accumulatedPlayTimeRef = useRef(0);

  // Sync active beat shifts and reset play tracking locks
  useEffect(() => {
    if (currentBeat) {
      if (lastTrackedBeatIdRef.current !== currentBeat.id) {
        // Clear the session play lock on the old beat in playService if we shift songs
        if (lastTrackedBeatIdRef.current) {
          playService.clearSessionLock(lastTrackedBeatIdRef.current);
        }
        playTrackedRef.current = false;
        setPlayTracked(false);
        lastTimeRef.current = 0;
        accumulatedPlayTimeRef.current = 0;
        lastTrackedBeatIdRef.current = currentBeat.id;
        console.log(`[PLAYER RESET] Cleaned plays tracker locks for: ${currentBeat.title}`);
      }
    }
  }, [currentBeat]);

  const registerPlay = async () => {
    if (!currentBeat || playTrackedRef.current) return;

    // Lock local ref immediately to prevent race conditions during request flight
    playTrackedRef.current = true;
    setPlayTracked(true);

    try {
      const result = await playService.trackPlay(
        currentBeat.id,
        audioElement?.currentTime || 8,
        user?.id || null,
        currentBeat.title
      );

      if (result.success && result.plays_count !== undefined) {
        // Dispatch global event so App.tsx can update its global state and currentBeat.
        window.dispatchEvent(new CustomEvent('beatPlayTracked', { 
          detail: { beatId: currentBeat.id, playsCount: result.plays_count } 
        }));
      }
    } catch (err) {
      console.warn('[PLAYER] Error tracking play with playService:', err);
    }
  };

  // Stable continuous play timer tracking
  const playTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (playTimerRef.current) {
      clearTimeout(playTimerRef.current);
      playTimerRef.current = null;
    }

    if (currentBeat && isPlaying && !playTrackedRef.current) {
      console.log(`[PLAY TIMER] Scheduled play count in 8 seconds of continuous playback for: ${currentBeat.title}`);
      playTimerRef.current = setTimeout(async () => {
        console.log(`[PLAY TIMER] 8 seconds threshold met. Registering play securely.`);
        await registerPlay();
      }, 8000);
    }

    return () => {
      if (playTimerRef.current) {
        clearTimeout(playTimerRef.current);
        playTimerRef.current = null;
      }
    };
  }, [currentBeat, isPlaying]);

  // Load recently played list from local cache
  useEffect(() => {
    try {
      const stored = localStorage.getItem('beatangola_recently_played_list');
      if (stored) {
        setRecentlyPlayed(JSON.parse(stored));
      }
    } catch (e) {
      console.warn('Could not load recently played list:', e);
    }
  }, []);

  // Sync active beat shifts with recently played list
  useEffect(() => {
    if (!currentBeat) return;
    setRecentlyPlayed(prev => {
      const filtered = prev.filter(b => b.id !== currentBeat.id);
      const updated = [currentBeat, ...filtered].slice(0, 20);
      try {
        localStorage.setItem('beatangola_recently_played_list', JSON.stringify(updated));
      } catch (e) {
        console.warn('Could not track played history:', e);
      }
      return updated;
    });
  }, [currentBeat]);

  // Queue Global Event Listeners (loose-coupling queue controller)
  useEffect(() => {
    const handleAddToQueue = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && customEvent.detail.beat) {
        const beatToAdd = customEvent.detail.beat as Beat;
        setQueue(prev => {
          if (prev.some(b => b.id === beatToAdd.id)) return prev;
          return [...prev, beatToAdd];
        });
        
        // Dispatches global dynamic UI notification
        const playBtn = document.getElementById('music-queue-btn');
        if (playBtn) {
          playBtn.classList.add('animate-bounce');
          setTimeout(() => playBtn.classList.remove('animate-bounce'), 1000);
        }
      }
    };

    const handleReplaceQueue = (e: Event) => {
      const customEvent = e as CustomEvent<{ beats: Beat[]; playFirst?: boolean }>;
      if (customEvent.detail && customEvent.detail.beats) {
        const beatsList = customEvent.detail.beats;
        if (beatsList.length > 0) {
          if (customEvent.detail.playFirst) {
            const first = beatsList[0];
            const remaining = beatsList.slice(1);
            setQueue(remaining);
            if (onPlayBeat) {
              onPlayBeat(first);
            }
          } else {
            setQueue(beatsList);
          }
        }
      }
    };

    window.addEventListener('addToPlayerQueue', handleAddToQueue);
    window.addEventListener('replacePlayerQueue', handleReplaceQueue);
    return () => {
      window.removeEventListener('addToPlayerQueue', handleAddToQueue);
      window.removeEventListener('replacePlayerQueue', handleReplaceQueue);
    };
  }, [onPlayBeat]);

  // --- SoundCloud Comments Phase 2 Custom States ---
  const [comments, setComments] = useState<any[]>([]);
  const [isCommentingPopupOpen, setIsCommentingPopupOpen] = useState(false);
  const [capturedTime, setCapturedTime] = useState<number>(0);
  const [popupCommentText, setPopupCommentText] = useState('');
  const [isSubmittingPopupComment, setIsSubmittingPopupComment] = useState(false);

  // Fetch comments for current playing beat
  useEffect(() => {
    if (!currentBeat?.id) {
      setComments([]);
      return;
    }
    const fetchCurrentBeatComments = async () => {
      try {
        const res = await fetch(`/api/comments/${currentBeat.id}`);
        const data = await res.json();
        if (data.success && data.comments) {
          setComments(data.comments);
        }
      } catch (e) {
        console.warn("Error fetching playbeat comments in player:", e);
      }
    };
    fetchCurrentBeatComments();
  }, [currentBeat?.id]);

  // Synchronize new comments posted from details page or elsewhere
  useEffect(() => {
    const handleNewCommentEvent = (e: CustomEvent) => {
      const newComment = e.detail;
      if (newComment && currentBeat && String(newComment.beat_id) === String(currentBeat.id)) {
        setComments(prev => {
          if (prev.some(c => c.id === newComment.id)) return prev;
          return [newComment, ...prev];
        });
      }
    };
    window.addEventListener('new_comment_received' as any, handleNewCommentEvent);
    return () => {
      window.removeEventListener('new_comment_received' as any, handleNewCommentEvent);
    };
  }, [currentBeat?.id]);

  // Auto Scroll Sync (Section 9 foundation: Dispatch pulse)
  useEffect(() => {
    if (!comments.length || !isPlaying || !audioElement) return;
    const threshold = 1.0; // match comments within 1.0s window
    const activeComment = comments.find(c => c.timestamp_seconds !== null && Math.abs(c.timestamp_seconds - currentTime) < threshold);
    if (activeComment) {
      window.dispatchEvent(new CustomEvent('active_comment_pulse', { detail: { id: activeComment.id, timestamp: activeComment.timestamp_seconds } }));
    }
  }, [currentTime, comments, isPlaying]);

  const handleMarkerSeek = (seconds: number) => {
    if (!audioElement) return;
    audioElement.currentTime = seconds;
    setCurrentTime(seconds);
    // ensure continued reproduction
    if (audioElement.paused) {
      audioElement.play().catch(err => console.warn("Failed to play on seek:", err));
    }
  };

  const startCommentingAtCurrentTime = () => {
    if (!user) {
      window.dispatchEvent(new CustomEvent('show_toast', {
        detail: {
          message: 'Faz login para comentares em momentos específicos.',
          type: 'error',
          title: 'Necessário Login'
        }
      }));
      return;
    }
    if (!audioElement) return;
    setCapturedTime(Math.round(audioElement.currentTime));
    setPopupCommentText('');
    setIsCommentingPopupOpen(true);
  };

  const handlePostPopupComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!popupCommentText.trim() || !user || !currentBeat) return;
    setIsSubmittingPopupComment(true);
    try {
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          beat_id: currentBeat.id,
          user_id: user.id,
          content: popupCommentText.trim(),
          timestamp_seconds: capturedTime
        })
      });
      const data = await response.json();
      if (data.success && data.comment) {
        setComments((prev) => [data.comment, ...prev]);
        setIsCommentingPopupOpen(false);
        setPopupCommentText('');
        // Dispatch to sync any listeners like BeatDetailsPage comments list
        window.dispatchEvent(new CustomEvent('new_comment_received', { detail: data.comment }));
        window.dispatchEvent(new CustomEvent('show_toast', {
          detail: {
            message: 'Comentário com timestamp publicado com sucesso!',
            type: 'success',
            title: 'Batukada Premium'
          }
        }));
      } else {
        window.dispatchEvent(new CustomEvent('show_toast', {
          detail: { message: data.error || 'Erro ao publicar comentário', type: 'error' }
        }));
      }
    } catch (err) {
      console.error('Error posting popup comment:', err);
    } finally {
      setIsSubmittingPopupComment(false);
    }
  };

  // Keyboard Shortcuts (Phase 8 bindings - Input Field Protected)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const active = document.activeElement;
      if (
        active && (
          active.tagName === 'INPUT' || 
          active.tagName === 'TEXTAREA' || 
          active.hasAttribute('contenteditable') ||
          (active as HTMLElement).isContentEditable
        )
      ) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        onTogglePlay();
      } else if (e.code === 'ArrowLeft') {
        if (!audioElement) return;
        e.preventDefault();
        const prev = Math.max(0, audioElement.currentTime - 10);
        audioElement.currentTime = prev;
        setCurrentTime(prev);
      } else if (e.code === 'ArrowRight') {
        if (!audioElement) return;
        e.preventDefault();
        const next = Math.min(duration, audioElement.currentTime + 10);
        audioElement.currentTime = next;
        setCurrentTime(next);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [audioElement, onTogglePlay, duration]);

  // Sync internal track position with audio element
  useEffect(() => {
    if (!audioElement) return;

    const updateTime = () => {
      setCurrentTime(audioElement.currentTime);
    };
    const updateDuration = () => {
      setDuration(audioElement.duration || 0);
    };
    const updateBuffer = () => {
      if (audioElement.buffered.length > 0) {
        const curTime = audioElement.currentTime;
        let end = 0;
        for (let i = 0; i < audioElement.buffered.length; i++) {
          const bStart = audioElement.buffered.start(i);
          const bEnd = audioElement.buffered.end(i);
          if (bStart <= curTime && bEnd >= curTime) {
            end = bEnd;
            break;
          }
        }
        setBufferedEnd(end);
      }
    };

    audioElement.addEventListener('timeupdate', updateTime);
    audioElement.addEventListener('loadedmetadata', updateDuration);
    audioElement.addEventListener('progress', updateBuffer);

    return () => {
      audioElement.removeEventListener('timeupdate', updateTime);
      audioElement.removeEventListener('loadedmetadata', updateDuration);
      audioElement.removeEventListener('progress', updateBuffer);
    };
  }, [audioElement, currentBeat]);

  // Audio elements volume alignment
  useEffect(() => {
    if (audioElement) {
      audioElement.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted, audioElement]);

  // Autoplay next track on end (Phase 3 and stability requirements)
  useEffect(() => {
    if (!audioElement) return;

    const handleEnded = () => {
      console.log('[AUTOPLAY NEXT] Activating sequence loop...');
      playNext();
    };

    audioElement.addEventListener('ended', handleEnded);
    return () => {
      audioElement.removeEventListener('ended', handleEnded);
    };
  }, [audioElement, queue, globalBeats, isRepeat, isShuffle, currentBeat]);

  // Queue and sequential navigation control loop
  const playNext = () => {
    if (queue.length > 0) {
      const nextInQueue = queue[0];
      setQueue(prev => prev.slice(1));
      if (onPlayBeat) {
        onPlayBeat(nextInQueue);
      }
      return;
    }

    if (globalBeats.length > 0) {
      if (isShuffle) {
        const otherBeats = globalBeats.filter(b => b.id !== currentBeat?.id);
        const randomBeat = otherBeats.length > 0
          ? otherBeats[Math.floor(Math.random() * otherBeats.length)]
          : globalBeats[0];
        if (onPlayBeat) onPlayBeat(randomBeat);
      } else {
        const currentIndex = globalBeats.findIndex(b => b.id === currentBeat?.id);
        if (currentIndex !== -1 && currentIndex < globalBeats.length - 1) {
          if (onPlayBeat) onPlayBeat(globalBeats[currentIndex + 1]);
        } else if (isRepeat) {
          if (onPlayBeat) onPlayBeat(globalBeats[0]);
        } else if (audioElement) {
          audioElement.currentTime = 0;
          setCurrentTime(0);
        }
      }
    }
  };

  const playPrevious = () => {
    if (globalBeats.length > 0) {
      if (isShuffle) {
        const otherBeats = globalBeats.filter(b => b.id !== currentBeat?.id);
        const randomBeat = otherBeats.length > 0
          ? otherBeats[Math.floor(Math.random() * otherBeats.length)]
          : globalBeats[0];
        if (onPlayBeat) onPlayBeat(randomBeat);
      } else {
        const currentIndex = globalBeats.findIndex(b => b.id === currentBeat?.id);
        if (currentIndex > 0) {
          if (onPlayBeat) onPlayBeat(globalBeats[currentIndex - 1]);
        } else if (isRepeat) {
          if (onPlayBeat) onPlayBeat(globalBeats[globalBeats.length - 1]);
        } else if (audioElement) {
          audioElement.currentTime = 0;
          setCurrentTime(0);
        }
      }
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time) || !isFinite(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // Drag Seek handlers (Phase 2 timelines)
  const handleProgressBarMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const pct = Math.max(0, Math.min(1, x / rect.width));
    setHoverX(x);
    setHoverTime(pct * duration);
  };

  const handleProgressBarMouseLeave = () => {
    setHoverTime(null);
  };

  const handleProgressBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!audioElement || duration === 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const pct = Math.max(0, Math.min(1, x / rect.width));
    audioElement.currentTime = pct * duration;
    setCurrentTime(pct * duration);
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  // Render elegant idle state if no beat is actively loaded
  if (!currentBeat) {
    if (user) {
      const userRole = profile?.role || user?.user_metadata?.account_type || user?.user_metadata?.role || '';
      const isArtist = userRole === 'artist' || userRole === 'buyer' || userRole === 'buy';
      if (!isArtist) {
        return null;
      }
    }
    return (
      <>
        <AnimatePresence>
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="fixed bottom-0 left-0 right-0 z-50 px-4 pb-4 pointer-events-none"
          >
            <div className="max-w-7xl mx-auto pointer-events-auto">
              <div className="relative group/player">
                <div className="bg-[#09090d]/85 backdrop-blur-2xl border border-white/10 rounded-[2rem] p-3 md:px-6 h-20 flex items-center justify-between shadow-[0_15px_40px_rgba(0,0,0,0.8)] overflow-hidden">
                  <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-amber-500/20 to-transparent" />
                  
                  {/* Left info label */}
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="relative w-11 h-11 rounded-full bg-white/5 flex items-center justify-center text-gray-400 border border-white/5 flex-shrink-0">
                      <Play className="ml-0.5" size={16} />
                      <span className="absolute -inset-1 bg-amber-500/10 blur-xl rounded-full animate-pulse opacity-40" />
                    </div>
                    <div className="overflow-hidden">
                      <h4 className="text-white font-black italic uppercase tracking-tighter text-xs md:text-sm truncate">Pronto para criar o teu som?</h4>
                      <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest hidden sm:block truncate mt-0.5">Selecione uma batida ou explore as tendências</p>
                    </div>
                  </div>

                  {/* Right interactive choices */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {globalBeats.length > 0 && (
                      <button 
                        onClick={() => {
                          const randomIndex = Math.floor(Math.random() * globalBeats.length);
                          if (onPlayBeat) onPlayBeat(globalBeats[randomIndex]);
                        }}
                        className="bg-amber-500 hover:bg-amber-400 text-black px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-md shadow-amber-500/10 active:scale-95"
                      >
                        Surpreenda-me 🔥
                      </button>
                    )}
                    
                    <button 
                      onClick={() => setIsQueueOpen(true)}
                      className="p-2 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:border-amber-500/30 transition-all text-xs flex items-center gap-1.5"
                      title="Historial de Reprodução"
                    >
                      <ListMusic size={14} />
                      <span className="text-[9px] font-black uppercase tracking-widest hidden md:inline">Historial</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Floating Sidebar Panels when empty */}
        <AnimatePresence>
          {isQueueOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsQueueOpen(false)}
                className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
              />
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                className="fixed right-0 top-0 bottom-24 w-full sm:w-[400px] bg-[#0B0B0B]/95 backdrop-blur-2xl border-l border-white/5 z-[55] flex flex-col p-6 shadow-2xl overflow-hidden rounded-l-[2rem]"
              >
                <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-6">
                  <div className="flex items-center gap-2">
                    <ListMusic className="text-amber-500" size={20} />
                    <h3 className="text-lg font-black uppercase tracking-widest text-white italic">Fila & Historial</h3>
                  </div>
                  <button onClick={() => setIsQueueOpen(false)} className="p-1.5 rounded-full bg-white/5 text-gray-400 hover:text-rose-500 transition-colors cursor-pointer"><X size={16} /></button>
                </div>

                <div className="flex-grow overflow-y-auto space-y-6 scrollbar-none">
                  <div>
                    <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-3">Últimas Batidas Ouvidas</h4>
                    {recentlyPlayed.length > 0 ? (
                      <div className="space-y-2">
                        {recentlyPlayed.map((beat, i) => (
                          <div key={beat.id + '-hist-' + i} className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/[0.02] border border-transparent hover:border-white/5 transition-all">
                            <img src={beat.image || undefined} className="w-8 h-8 rounded-lg object-cover" alt="" />
                            <div className="flex-grow min-w-0">
                              <button 
                                onClick={() => {
                                  if (onPlayBeat) onPlayBeat(beat);
                                  setIsQueueOpen(false);
                                }}
                                className="text-left text-xs font-bold text-gray-300 hover:text-amber-500 truncate block w-full uppercase tracking-wider"
                              >
                                {beat.title}
                              </button>
                              <p className="text-[10px] font-semibold text-gray-500 truncate">{beat.producer}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[10px] font-bold text-gray-600 italic">Historial vazio. Inicia a reprodução de um ritmo para começar!</p>
                    )}
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </>
    );
  }

  return (
    <>
      <AnimatePresence>
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="fixed bottom-0 left-0 right-0 z-50 px-4 pb-4 pointer-events-none"
        >
          <div className="max-w-7xl mx-auto pointer-events-auto">
            {/* Main Player Bar */}
            <div className="relative group/player">
              
              {/* Premium Floating flat container */}
              <div className="bg-[#0c0c0e]/95 backdrop-blur-xl border border-white/10 rounded-xl p-3 md:px-5 h-20 flex items-center justify-between shadow-2xl overflow-hidden">
                
                {/* Thin top divider line */}
                <div className="absolute top-0 left-0 right-0 h-[1px] bg-white/5" />

                {/* Left Side: Solid cover artwork & labels */}
                <div className="flex items-center gap-3.5 w-[35%] md:w-[30%] min-w-0">
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    className="relative flex-shrink-0 group/cover cursor-pointer"
                    onClick={() => setIsExpanded(!isExpanded)}
                  >
                    {/* Modern semi-rounded cover artwork (Spotify / SoundCloud style) */}
                    <div className="relative w-12 h-12 rounded-md overflow-hidden border border-white/5 shadow-lg bg-[#121212]">
                      <img 
                        src={currentBeat.image || undefined} 
                        alt={currentBeat.title} 
                        className="w-full h-full object-cover rounded-md" 
                      />
                    </div>
                    {/* Hover expand indicator overlays */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/cover:opacity-100 transition-opacity flex items-center justify-center rounded-md">
                      <ChevronUp className={`text-white transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} size={14} />
                    </div>
                  </motion.div>
                  <div className="overflow-hidden text-left">
                    <h4 
                      onClick={() => setIsExpanded(true)}
                      className="text-white font-bold tracking-tight truncate leading-tight text-sm cursor-pointer hover:text-[#5865F2] transition-colors"
                    >
                      {currentBeat.title}
                    </h4>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <p className="text-gray-400 text-[10px] md:text-xs font-medium tracking-wide truncate">{currentBeat.producer}</p>
                      {currentBeat.genre && (
                        <span className="bg-[#5865F2]/10 text-[#5865F2] text-[8px] font-bold px-1.5 py-0.5 rounded uppercase hidden sm:inline-block border border-[#5865F2]/20">{currentBeat.genre}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Center: Playback controller controls & timeline progress */}
                <div className="hidden md:flex flex-col items-center gap-1 flex-grow max-w-[40%] px-4">
                  <div className="flex items-center gap-6">
                    <button 
                      onClick={() => setIsShuffle(!isShuffle)}
                      className={`transition-colors p-1 relative ${isShuffle ? 'text-[#5865F2]' : 'text-gray-500 hover:text-white'}`}
                      title="Shuffle"
                    >
                      <Shuffle size={14} />
                      {isShuffle && <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 bg-[#5865F2] rounded-full" />}
                    </button>
                    <button 
                      onClick={playPrevious}
                      className="text-gray-400 hover:text-white transition-colors active:scale-95 p-1 cursor-pointer"
                      title="Anterior"
                    >
                      <SkipBack size={18} />
                    </button>
                    
                    <motion.button 
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={onTogglePlay} 
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${isPlaying ? 'bg-[#5865F2] text-white shadow-md' : 'bg-white text-black shadow-sm'}`}
                    >
                      {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
                    </motion.button>
                    
                    <button 
                      onClick={playNext}
                      className="text-gray-400 hover:text-white transition-colors active:scale-95 p-1 cursor-pointer"
                      title="Seguinte"
                    >
                      <SkipForward size={18} />
                    </button>
                    <button 
                      onClick={() => setIsRepeat(!isRepeat)}
                      className={`transition-colors p-1 relative ${isRepeat ? 'text-[#5865F2]' : 'text-gray-500 hover:text-white'}`}
                      title="Repeat Track"
                    >
                      <Repeat size={14} />
                      {isRepeat && <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 bg-[#5865F2] rounded-full" />}
                    </button>
                  </div>

                  {/* Clean HTML5 Interactive Progress Timeline (Phase 2) */}
                  <div className="w-full flex items-center gap-3 select-none">
                    <span className="text-[10px] font-black text-gray-500 font-mono w-8 text-right">{formatTime(currentTime)}</span>
                    <div 
                      className="relative flex-grow h-4 flex items-center cursor-pointer group/progress"
                      onMouseMove={handleProgressBarMouseMove}
                      onMouseLeave={handleProgressBarMouseLeave}
                      onClick={handleProgressBarClick}
                    >
                      {/* Background base track */}
                      <div className="absolute inset-x-0 h-1 rounded-full bg-white/10 transition-all group-hover/progress:h-1.5" />
                      
                      {/* Buffer bar segment */}
                      <div 
                        className="absolute left-0 h-1 rounded-full bg-white/15 transition-all group-hover/progress:h-1.5 duration-300 pointer-events-none" 
                        style={{ width: `${duration > 0 ? (bufferedEnd / duration) * 100 : 0}%` }}
                      />
                      
                      {/* Played progression segment */}
                      <div 
                        className="absolute left-0 h-1 rounded-full bg-[#5865F2] group-hover/progress:h-1.5 transition-all duration-75 pointer-events-none shadow-[0_0_8px_rgba(88,101,242,0.3)]" 
                        style={{ width: `${progress}%` }}
                      />
                      
                      {/* Circle Handle thumb toggle */}
                      <div 
                        className="absolute w-2.5 h-2.5 bg-white rounded-full opacity-0 group-hover/progress:opacity-100 transition-opacity -ml-1.25 shadow-md border border-[#5865F2]"
                        style={{ left: `${progress}%` }}
                      />

                      {/* Comment Markers (SoundCloud Style Phase 2) */}
                      {duration > 0 && comments?.filter(c => c.timestamp_seconds !== null && c.timestamp_seconds !== undefined).map((c) => {
                        const markerPct = (c.timestamp_seconds / duration) * 100;
                        if (markerPct < 0 || markerPct > 100) return null;
                        return (
                          <div
                            key={c.id}
                            className="group/marker absolute w-1.5 h-1.5 rounded-full bg-amber-400 border border-black/50 hover:bg-white hover:scale-130 transition-all shadow-[0_0_6px_rgba(255,191,0,0.85)] z-20 cursor-pointer animate-fade-in"
                            style={{ left: `${markerPct}%`, transform: 'translateX(-50%)' }}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMarkerSeek(c.timestamp_seconds);
                            }}
                          >
                            {/* Hover Tooltip (Premium Dark) */}
                            <div className="absolute bottom-5 left-1/2 -translate-x-1/2 bg-[#0A0A0E]/95 backdrop-blur-md border border-purple-500/35 text-white p-2 text-[10px] min-w-[155px] max-w-[220px] rounded-xl shadow-[0_8px_30px_rgb(0,0,0,0.9)] opacity-0 pointer-events-none group-hover/marker:opacity-100 transition-all duration-150 z-30 flex flex-col gap-1 translate-y-1 group-hover/marker:translate-y-0 text-left">
                              <div className="flex items-center justify-between gap-1 border-b border-white/5 pb-1 mb-0.5">
                                <span className="text-amber-400 font-extrabold text-[9px] truncate">@{c.author_username || c.username || 'user'}</span>
                                <span className="font-mono font-black text-[9px] text-amber-300">
                                  {formatTime(c.timestamp_seconds)}
                                </span>
                              </div>
                              <p className="font-sans font-medium text-neutral-300 leading-normal line-clamp-2">{c.content}</p>
                            </div>
                          </div>
                        );
                      })}

                      {/* Tooltip Hover position */}
                      {hoverTime !== null && (
                        <div 
                          className="absolute bottom-5 -translate-x-1/2 bg-[#0B0B0B] border border-white/5 text-[9px] font-bold text-white px-2 py-0.5 rounded shadow-xl pointers-events-none"
                          style={{ left: hoverX }}
                        >
                          {formatTime(hoverTime)}
                        </div>
                      )}
                    </div>
                    <span className="text-[10px] font-black text-gray-500 font-mono w-8">{formatTime(duration)}</span>
                    <button
                      onClick={startCommentingAtCurrentTime}
                      className="p-1 px-1.5 text-gray-500 hover:text-amber-500 hover:bg-white/5 rounded-lg transition-all flex items-center gap-1 active:scale-90"
                      title="Comentar neste momento"
                    >
                      <MessageSquare size={13} className="text-amber-500 fill-amber-500/10" />
                      <span className="text-[8px] font-black uppercase tracking-widest hidden md:inline-block">Comentar</span>
                    </button>
                  </div>
                  </div>

                {/* Right Side: Action Utilities & Enqueue Toggle (44px mobile touch optimization targets) */}
                <div className="flex items-center justify-end gap-2 md:gap-3 w-[50%] md:w-[30%]">
                  
                  {/* Play Pause Trigger on Mobile (large targets) */}
                  <div className="md:hidden flex items-center gap-2 pr-1">
                    <button 
                      onClick={playPrevious}
                      className="p-2.5 text-gray-400 hover:text-white active:scale-90"
                    >
                      <SkipBack size={18} />
                    </button>
                    <button 
                      onClick={onTogglePlay} 
                      className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center shadow-md"
                    >
                      {isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
                    </button>
                    <button 
                      onClick={playNext}
                      className="p-2.5 text-gray-400 hover:text-white active:scale-90"
                    >
                      <SkipForward size={18} />
                    </button>
                  </div>

                  <motion.button 
                    whileTap={{ scale: 0.8 }}
                    onClick={() => setIsLiked(!isLiked)}
                    className={`p-2 rounded-full hover:bg-white/5 transition-colors ${isLiked ? 'text-rose-500' : 'text-gray-500 hover:text-white'}`}
                  >
                    <Heart size={18} fill={isLiked ? 'currentColor' : 'none'} />
                  </motion.button>

                  {/* List / Queue Toggle */}
                  <button 
                    id="music-queue-btn"
                    onClick={() => setIsQueueOpen(!isQueueOpen)}
                    className={`p-2 rounded-full transition-colors relative ${isQueueOpen ? 'text-amber-500 bg-white/5' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}
                    title="Ver Fila de Reprodução"
                  >
                    <ListMusic size={18} />
                    {queue.length > 0 && (
                      <span className="absolute top-1 right-1 w-2 h-2 bg-amber-500 rounded-full" />
                    )}
                  </button>

                  <button 
                    onClick={() => {
                      window.dispatchEvent(new CustomEvent('showAddToPlaylist', { detail: { beat: currentBeat } }));
                    }}
                    className="p-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-full transition-colors hidden sm:inline-block"
                    title="Adicionar à Playlist"
                  >
                    <Repeat size={14} className="opacity-0 absolute pointer-events-none" /> {/* hidden spacer help */}
                    <span className="text-[9px] font-black uppercase tracking-widest block text-gray-500 hover:text-white">Add</span>
                  </button>

                  <div className="hidden lg:flex items-center gap-2 group/volume">
                    <button onClick={() => setIsMuted(!isMuted)} className="p-2 text-gray-500 hover:text-white transition-colors">
                      {isMuted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
                    </button>
                    <div className="w-16 h-1 bg-white/10 rounded-full relative group-hover/volume:h-1.5 transition-all">
                      <input 
                        type="range" 
                        min="0" 
                        max="1" 
                        step="0.01"
                        value={isMuted ? 0 : volume}
                        onChange={(e) => {
                          const v = parseFloat(e.target.value);
                          setVolume(v);
                          setIsMuted(false);
                          try {
                            localStorage.setItem('beatangola_player_volume', String(v));
                          } catch {}
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                      />
                      <div 
                        className="absolute top-0 left-0 h-full bg-amber-500 rounded-full transition-all" 
                        style={{ width: `${(isMuted ? 0 : volume) * 100}%` }} 
                      />
                    </div>
                  </div>

                  <button 
                    onClick={() => setIsExpanded(!isExpanded)}
                    className="p-2 text-gray-500 hover:text-white transition-colors hidden sm:block"
                    title="Expandir Layout"
                  >
                    <Maximize2 size={16} />
                  </button>

                  <button 
                    className="p-2 text-gray-500 hover:text-rose-500 transition-colors"
                    onClick={() => {
                      if (onClose) onClose();
                    }}
                    title="Fechar"
                  >
                    <div className="w-5 h-5 flex items-center justify-center rounded-full bg-white/5 hover:bg-rose-500/15 transition-colors">
                      <X size={10} />
                    </div>
                  </button>
                </div>
              </div>
              
              {/* Mobile top slim Timeline (high visibility, Phase 7 gestures) */}
              <div className="md:hidden absolute top-0 left-6 right-6 h-[2px] bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-500" 
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Expanded Playback Overlay (Spotify Cinematic style Layout, Phase 10 details) */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-between p-6 md:p-12 overflow-y-auto"
          >
            {/* Soft Ambient color splash */}
            <div className="absolute inset-0 z-0">
              <img src={currentBeat.image || undefined} alt="" className="w-full h-full object-cover opacity-12 blur-[120px] scale-125" />
              <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/90 to-black" />
            </div>

            {/* Premium Dynamic Title indicator */}
            <div className="relative z-10 w-full max-w-7xl flex items-center justify-between">
              <span className="text-xs font-black text-gray-500 tracking-[0.3em] uppercase italic">Batukada Premium Player</span>
              <button 
                onClick={() => setIsExpanded(false)}
                className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/10 hover:border-white/20 transition-all cursor-pointer"
                title="Fechar"
              >
                <ChevronUp className="rotate-180" size={24} />
              </button>
            </div>

            {/* Core Artwork & metadata content container */}
            <div className="relative z-10 max-w-5xl w-full grid grid-cols-1 md:grid-cols-2 gap-12 items-center my-auto">
              
              {/* Cover Experience art (Phase 10) */}
              <div className="flex justify-center">
                <motion.div 
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.1 }}
                  whileHover={{ scale: 1.03 }}
                  className="relative w-full max-w-[360px] aspect-square rounded-[2rem] overflow-hidden shadow-[0_30px_60px_rgba(0,0,0,0.85)] border border-white/10 group"
                >
                  <img src={currentBeat.image || undefined} alt={currentBeat.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </motion.div>
              </div>

              {/* Title, genre and interactive descriptors */}
              <div className="space-y-6 text-center md:text-left">
                <div>
                  <motion.div 
                    initial={{ y: 15, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="flex flex-wrap gap-2 justify-center md:justify-start mb-3"
                  >
                    <span className="px-3.5 py-1 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-full text-[10px] font-black uppercase tracking-widest">
                      {currentBeat.genre || 'RITMO'}
                    </span>
                    <span className="px-3.5 py-1 bg-white/5 text-gray-300 border border-white/10 rounded-full text-[10px] font-black uppercase tracking-widest">
                      {currentBeat.bpm || 120} BPM
                    </span>
                  </motion.div>
                  <motion.h1 
                    initial={{ y: 15, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="text-4xl md:text-5xl lg:text-6xl font-black text-white italic uppercase tracking-tighter leading-none mb-3"
                  >
                    {currentBeat.title}
                  </motion.h1>
                  <motion.p 
                    initial={{ y: 15, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="text-lg md:text-xl font-bold text-gray-400 uppercase tracking-widest"
                  >
                    PRODUTO POR <span className="text-amber-500">{currentBeat.producer}</span>
                  </motion.p>
                </div>

                {/* Subtext info */}
                <motion.p 
                  initial={{ y: 15, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="text-gray-500 text-xs md:text-sm font-semibold leading-relaxed max-w-md mx-auto md:mx-0"
                >
                  Este ritmo de alta fidelidade está disponível para licenciamento profissional na BATUKADA. Utiliza e cria o teu próximo grande sucesso comercial de forma segura.
                </motion.p>

                {/* Main purchase operations */}
                <motion.div 
                  initial={{ y: 15, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="flex flex-wrap gap-3 justify-center md:justify-start pt-2"
                >
                  <button className="bg-amber-500 hover:bg-amber-400 text-black px-8 py-3.5 rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-amber-500/10 hover:scale-[1.03] transition-all">
                    Licenciar Beat
                  </button>
                  <button 
                    onClick={() => {
                      window.dispatchEvent(new CustomEvent('showAddToPlaylist', { detail: { beat: currentBeat } }));
                    }}
                    className="bg-white/5 hover:bg-white/10 border border-white/10 text-white px-6 py-3.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all hover:scale-[1.03]"
                  >
                    Adicionar à Playlist
                  </button>
                </motion.div>
              </div>
            </div>

            {/* Bottom Controls area */}
            <div className="relative z-10 w-full max-w-4xl flex flex-col gap-4 border-t border-white/5 pt-6 mt-6">
              
              {/* Detailed seek progress bar */}
              <div className="w-full flex items-center gap-4">
                <span className="text-xs font-black text-gray-500 font-mono w-10 text-right">{formatTime(currentTime)}</span>
                <div 
                  className="relative flex-grow h-6 flex items-center cursor-pointer group/progress-exp"
                  onMouseMove={handleProgressBarMouseMove}
                  onMouseLeave={handleProgressBarMouseLeave}
                  onClick={handleProgressBarClick}
                >
                  <div className="absolute inset-x-0 h-1.5 rounded-full bg-white/10 group-hover/progress-exp:h-2" />
                  <div 
                    className="absolute left-0 h-1.5 rounded-full bg-white/15 duration-300 pointer-events-none group-hover/progress-exp:h-2" 
                    style={{ width: `${duration > 0 ? (bufferedEnd / duration) * 100 : 0}%` }}
                  />
                  <div 
                    className="absolute left-0 h-1.5 rounded-full bg-amber-500 pointer-events-none group-hover/progress-exp:h-2 shadow-[0_0_10px_rgba(245,158,11,0.5)]" 
                    style={{ width: `${progress}%` }}
                  />
                  <div 
                    className="absolute w-3 h-3 bg-white rounded-full opacity-100 -ml-1.5 border border-amber-500"
                    style={{ left: `${progress}%` }}
                  />

                  {/* Comment Markers for expanded view */}
                  {duration > 0 && comments?.filter(c => c.timestamp_seconds !== null && c.timestamp_seconds !== undefined).map((c) => {
                    const markerPct = (c.timestamp_seconds / duration) * 100;
                    if (markerPct < 0 || markerPct > 100) return null;
                    return (
                      <div
                        key={c.id}
                        className="group/marker absolute w-2 h-2 rounded-full bg-amber-400 border border-black hover:bg-white hover:scale-130 transition-all shadow-[0_0_8px_rgba(255,191,0,0.9)] z-20 cursor-pointer animate-fade-in"
                        style={{ left: `${markerPct}%`, transform: 'translateX(-50%)' }}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMarkerSeek(c.timestamp_seconds);
                        }}
                      >
                        {/* Hover Tooltip (Premium Dark for expanded) */}
                        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-[#0A0A0E]/95 backdrop-blur-md border border-purple-500/35 text-white p-2.5 text-[10px] min-w-[165px] max-w-[245px] rounded-xl shadow-[0_8px_30px_rgb(0,0,0,0.9)] opacity-0 pointer-events-none group-hover/marker:opacity-100 transition-all duration-150 z-30 flex flex-col gap-1 translate-y-1 group-hover/marker:translate-y-0 text-left">
                          <div className="flex items-center justify-between gap-1 border-b border-white/5 pb-1 mb-0.5">
                            <span className="text-amber-400 font-extrabold text-[9px] truncate">@{c.author_username || c.username || 'user'}</span>
                            <span className="font-mono font-black text-[9px] text-amber-300">
                              {formatTime(c.timestamp_seconds)}
                            </span>
                          </div>
                          <p className="font-sans font-medium text-neutral-300 leading-normal line-clamp-2">{c.content}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <span className="text-xs font-black text-gray-500 font-mono w-10">{formatTime(duration)}</span>
              </div>

              {/* Centered comment at current time button for expanded player */}
              <div className="w-full flex items-center justify-center -mt-2">
                <button
                  onClick={startCommentingAtCurrentTime}
                  className="px-5 py-2 hover:bg-amber-500 hover:text-black border border-amber-500/30 text-amber-500 hover:shadow-[0_0_15px_rgba(245,158,11,0.25)] rounded-full text-[10px] font-black uppercase tracking-widest transition-all hover:scale-[1.03] flex items-center gap-1.5 active:scale-95"
                  type="button"
                >
                  <MessageSquare size={14} className="text-amber-500 animate-pulse fill-amber-500/10" />
                  Comentar aos {formatTime(currentTime)}
                </button>
              </div>

              {/* Bottom Play buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <button onClick={() => setIsShuffle(!isShuffle)} className={`p-2 transition-colors ${isShuffle ? 'text-amber-500' : 'text-gray-500 hover:text-white'}`} title="Shuffle"><Shuffle size={18} /></button>
                  <button onClick={playPrevious} className="p-2 text-gray-400 hover:text-white transition-colors"><SkipBack size={22} /></button>
                </div>

                <button 
                  onClick={onTogglePlay} 
                  className="w-16 h-16 rounded-full bg-amber-500 text-black flex items-center justify-center shadow-2xl hover:bg-amber-400 hover:scale-105 transition-all"
                >
                  {isPlaying ? <Pause size={28} fill="currentColor" /> : <Play size={28} fill="currentColor" className="ml-1" />}
                </button>

                <div className="flex items-center gap-4">
                  <button onClick={playNext} className="p-2 text-gray-400 hover:text-white transition-colors"><SkipForward size={22} /></button>
                  <button onClick={() => setIsRepeat(!isRepeat)} className={`p-2 transition-colors ${isRepeat ? 'text-amber-500' : 'text-gray-500 hover:text-white'}`} title="Repeat Track"><Repeat size={18} /></button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating interactive Sidebar panels when playing */}
      <AnimatePresence>
        {isQueueOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsQueueOpen(false)}
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed right-0 top-0 bottom-24 w-full sm:w-[400px] bg-[#000000]/95 backdrop-blur-2xl border-l border-white/[0.04] z-[55] flex flex-col p-6 shadow-2xl overflow-hidden rounded-l-[2rem]"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <ListMusic className="text-amber-500" size={20} />
                  <h3 className="text-lg font-black uppercase tracking-widest text-white italic">Fila de Reprodução</h3>
                </div>
                <button onClick={() => setIsQueueOpen(false)} className="p-1.5 rounded-full bg-white/5 text-gray-400 hover:text-rose-500 transition-colors cursor-pointer"><X size={16} /></button>
              </div>

              <div className="flex-grow overflow-y-auto space-y-6 scrollbar-none">
                <div>
                  <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-3">A Tocar Agora</h4>
                  <div className="flex items-center gap-3 p-2.5 rounded-xl bg-white/5 border border-white/10 animate-fade-in">
                    <img src={currentBeat.image || undefined} className="w-10 h-10 rounded-lg object-cover" alt="" />
                    <div className="flex-grow min-w-0">
                      <p className="text-xs font-black text-amber-500 uppercase tracking-wider truncate">{currentBeat.title}</p>
                      <p className="text-[10px] font-bold text-gray-400 truncate">{currentBeat.producer}</p>
                    </div>
                    {/* Animated visualizer pulse bars */}
                    <div className="flex gap-0.5 items-end h-3 px-2">
                      <span className="w-0.5 bg-amber-500 animate-pulse h-full" />
                      <span className="w-0.5 bg-amber-500 animate-pulse h-3/4 [animation-delay:0.2s]" />
                      <span className="w-0.5 bg-amber-500 animate-pulse h-1/2 [animation-delay:0.4s]" />
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Seguintes Fila ({queue.length})</h4>
                    {queue.length > 0 && (
                      <button onClick={() => setQueue([])} className="text-[9px] font-black text-rose-500 hover:underline">Limpar Fila</button>
                    )}
                  </div>

                  {queue.length > 0 ? (
                    <div className="space-y-2">
                      {queue.map((beat, i) => (
                        <div key={beat.id + '-' + i} className="group/item flex items-center gap-3 p-2 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-white/5 transition-all">
                          <img src={beat.image || undefined} className="w-8 h-8 rounded-lg object-cover" alt="" />
                          <div className="flex-grow min-w-0">
                            <button 
                              onClick={() => {
                                if (onPlayBeat) {
                                  onPlayBeat(beat);
                                  setQueue(prev => prev.slice(i + 1));
                                }
                              }}
                              className="text-left text-xs font-bold text-white hover:text-amber-500 truncate block w-full uppercase tracking-wider"
                            >
                              {beat.title}
                            </button>
                            <p className="text-[10px] font-semibold text-gray-500 truncate">{beat.producer}</p>
                          </div>
                          <button 
                            onClick={() => setQueue(prev => prev.filter((_, idx) => idx !== i))}
                            className="opacity-0 group-hover/item:opacity-100 p-1 text-gray-500 hover:text-rose-500 transition-all rounded-full hover:bg-white/5"
                          >
                            <X size={12} />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-4 text-center border border-dashed border-white/5 rounded-xl">
                      <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">A fila está vazia</p>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-3">Historial Recente ({recentlyPlayed.length})</h4>
                  {recentlyPlayed.length > 0 ? (
                    <div className="space-y-2 max-h-[180px] overflow-y-auto">
                      {recentlyPlayed.map((beat, i) => (
                        <div key={beat.id + '-hist-' + i} className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/[0.02] transition-all">
                          <img src={beat.image || undefined} className="w-8 h-8 rounded-lg object-cover" alt="" />
                          <div className="flex-grow min-w-0">
                            <button 
                              onClick={() => {
                                if (onPlayBeat) onPlayBeat(beat);
                              }}
                              className="text-left text-xs font-bold text-gray-300 hover:text-amber-500 truncate block w-full uppercase tracking-wider"
                            >
                              {beat.title}
                            </button>
                            <p className="text-[10px] font-semibold text-gray-500 truncate">{beat.producer}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[10px] font-bold text-gray-500 italic">Nenhum historial.</p>
                  )}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* SoundCloud Floating commenting popup form (Phase 2) */}
      <AnimatePresence>
        {isCommentingPopupOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed bottom-28 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-4"
          >
            <form 
              onSubmit={handlePostPopupComment}
              className="bg-[#09090D]/95 backdrop-blur-2xl border border-white/10 rounded-[1.5rem] p-4 shadow-[0_20px_50px_rgba(0,0,0,0.9)] flex flex-col gap-3"
            >
              <div className="flex items-center justify-between border-b border-white/5 pb-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                  <h5 className="text-[11px] font-black uppercase tracking-widest text-white">
                    Comentar em <span className="text-amber-400 font-mono">[{formatTime(capturedTime)}]</span>
                  </h5>
                </div>
                <button 
                  type="button" 
                  onClick={() => setIsCommentingPopupOpen(false)}
                  className="text-gray-500 hover:text-white transition-colors p-1"
                >
                  <X size={14} />
                </button>
              </div>

              <div className="relative">
                <input
                  type="text"
                  value={popupCommentText}
                  onChange={(e) => setPopupCommentText(e.target.value)}
                  maxLength={200}
                  placeholder="Escreve o teu comentário musical..."
                  className="w-full bg-white/5 border border-white/10 hover:border-white/20 focus:border-amber-500/40 rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-500 outline-none transition-all font-medium pr-10"
                  autoFocus
                  required
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-mono text-gray-500 font-bold">
                  {200 - popupCommentText.length}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCommentingPopupOpen(false)}
                  className="px-3 py-1.5 rounded-lg text-gray-400 hover:text-white text-[10px] font-bold uppercase transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingPopupComment || !popupCommentText.trim()}
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black rounded-lg text-[10px] font-black uppercase tracking-wider transition-all shadow-[0_0_12px_rgba(245,158,11,0.2)] flex items-center gap-1 cursor-pointer"
                >
                  {isSubmittingPopupComment ? 'A enviar...' : 'Publicar 🔥'}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
