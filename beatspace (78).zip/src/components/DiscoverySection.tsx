import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { playlistStore, Playlist } from '../lib/playlistStore';
import { Beat } from '../types';
import { Play, Pause, Disc, Heart, FolderHeart, Sparkles, TrendingUp, Music, Headphones, Volume2, Plus, ArrowRight, Library, ListMusic, Globe, Lock } from 'lucide-react';
import { motion } from 'motion/react';
import { useToast } from '../context/ToastContext';

interface DiscoverySectionProps {
  beats: Beat[];
  onPlay: (beat: Beat) => void;
  isPlaying: boolean;
  currentBeat: Beat | null;
  onAddToCart?: (beat: Beat) => void;
  onSelectBeat?: (beat: Beat) => void;
  onSelectPlaylist: (playlistId: string) => void;
}

export default function DiscoverySection({
  beats,
  onPlay,
  isPlaying,
  currentBeat,
  onAddToCart,
  onSelectBeat,
  onSelectPlaylist
}: DiscoverySectionProps) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [discoveryData, setDiscoveryData] = useState<{
    trendingNow: Beat[];
    mostPlayed: Beat[];
    newUploads: Beat[];
    recommended: Beat[];
    basedOnLikes: Beat[];
  } | null>(null);

  const [recentlyPlayed, setRecentlyPlayed] = useState<Beat[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'playlists' | 'smart' | 'history'>('all');

  useEffect(() => {
    loadDiscovery();
    window.addEventListener('playlistUpdated', loadDiscovery);
    window.addEventListener('favoriteStatusChanged', loadDiscovery);
    // Listen to play events to dynamically update "recently played" tab in real-time
    const handleTrackPlayed = () => {
      loadRecentlyPlayed();
    };
    window.addEventListener('beatPlayed', handleTrackPlayed);

    return () => {
      window.removeEventListener('playlistUpdated', loadDiscovery);
      window.removeEventListener('favoriteStatusChanged', loadDiscovery);
      window.removeEventListener('beatPlayed', handleTrackPlayed);
    };
  }, [beats, user]);

  const loadRecentlyPlayed = () => {
    const historicalIds = playlistStore.getRecentlyPlayed();
    const historicalBeats = historicalIds
      .map(id => beats.find(b => String(b.id) === String(id)))
      .filter(Boolean) as Beat[];
    setRecentlyPlayed(historicalBeats);
  };

  const loadDiscovery = async () => {
    loadRecentlyPlayed();

    // Load recommendations
    const recommendations = await playlistStore.getSmartDiscovery(beats, user?.id);
    setDiscoveryData(recommendations);

    // Load playlists if user logged in
    if (user) {
      const uPlaylists = await playlistStore.fetchPlaylists(user.id);
      setPlaylists(uPlaylists);
    }
  };

  const triggerAddPlaylist = () => {
    // Dispatch fake beat to trigger create workflow cleanly through our global modal
    if (!user) {
      showToast('Inicia sessão para criares as tuas playlists!', 'info', 'Autenticação');
      window.dispatchEvent(new CustomEvent('openAuthModal'));
      return;
    }
    const fakeBeat = beats[0] || { id: 'temp' };
    window.dispatchEvent(new CustomEvent('showAddToPlaylist', { detail: { beat: fakeBeat } }));
  };

  const handlePlaylistPlay = (pl: Playlist, e: React.MouseEvent) => {
    e.stopPropagation();
    const plBeats = beats.filter(b => pl.beat_ids?.includes(String(b.id)));
    if (plBeats.length === 0) {
      showToast('Esta playlist ainda está vazia.', 'info', 'Sem Músicas');
      return;
    }
    onPlay(plBeats[0]);
  };

  const isPlaylistActive = (pl: Playlist) => {
    if (!currentBeat) return false;
    return isPlaying && pl.beat_ids?.includes(String(currentBeat.id));
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      
      {/* Banner / Title Header */}
      <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#0B0B0F] via-[#12121A] to-[#0A0713] border border-white/5 p-8 md:p-12 shadow-2xl">
        <div className="absolute top-1/2 left-1/2 w-[350px] h-[350px] -translate-x-1/2 -translate-y-1/2 bg-[#5865F2]/5 blur-[120px] rounded-full -z-10 animate-pulse pointer-events-none" />
        <div className="max-w-2xl space-y-3.5">
          <div className="flex items-center gap-2">
            <span className="p-1 px-2.5 rounded-full bg-[#5865F2]/10 border border-[#5865F2]/20 text-[8px] font-black text-[#5865F2] tracking-widest uppercase flex items-center gap-1">
              <Sparkles size={10} className="animate-spin" style={{ animationDuration: '6s' }} /> Discovery Hub
            </span>
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Premium</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-black italic text-white tracking-tight leading-none uppercase">
            Sente o Ritmo, <span className="text-purple-400">Encontra a Tua Batida</span>
          </h1>
          <p className="text-gray-400 text-sm font-semibold max-w-xl pr-4">
            Explora playlists reais partilhadas pela nossa comunidade e deixa que o motor inteligente do Batukada recomende os sons ideais para os teus projetos.
          </p>
        </div>
      </div>

      {/* Primary Discovery Tabs filter */}
      <div className="flex items-center justify-between border-b border-white/5 pb-2 overflow-x-auto whitespace-nowrap scrollbar-none gap-2">
        <div className="flex items-center gap-2 md:gap-3.5">
          {[
            { id: 'all', name: 'Explorar Tudo', icon: Library },
            { id: 'playlists', name: 'As Minhas Playlists', icon: ListMusic },
            { id: 'smart', name: 'Recomendações IA', icon: Sparkles },
            { id: 'history', name: 'Histórico Recente', icon: Headphones }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-[10px] uppercase font-black tracking-widest border transition-all cursor-pointer ${
                  activeTab === tab.id 
                    ? 'bg-amber-500 border-amber-500 text-black font-black shadow-lg shadow-amber-500/10'
                    : 'bg-white/5 border-white/5 text-gray-400 hover:text-white hover:bg-white/10'
                }`}
              >
                <Icon size={12} />
                {tab.name}
              </button>
            );
          })}
        </div>

        {activeTab === 'playlists' && (
          <button
            onClick={triggerAddPlaylist}
            className="px-4 py-2.5 rounded-xl bg-purple-600/15 border border-purple-500/20 hover:bg-purple-600/25 text-purple-400 text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 transition-all text-right shrink-0"
          >
            <Plus size={12} />
            Nova Playlist
          </button>
        )}
      </div>

      {/* RENDERS TABS */}

      {/* 2. PLAYLISTS TAB VIEW */}
      {activeTab === 'playlists' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black tracking-widest text-[#F59E0B] uppercase italic">Playlists de {user?.email?.split('@')[0] || 'Produtor'}</h3>
          </div>

          {!user ? (
            <div className="py-14 text-center border border-dashed border-white/5 rounded-3xl bg-white/[0.01]">
              <Lock size={36} className="text-gray-600 mx-auto mb-3 opacity-40 animate-pulse" />
              <p className="text-sm font-bold text-gray-300">Organiza as tuas próprias playlists!</p>
              <p className="text-xs text-gray-500 mt-1 mb-4">Inicia sessão para criar, editar e partilhar as tuas coleções musicais.</p>
              <button
                onClick={() => window.dispatchEvent(new CustomEvent('openAuthModal'))}
                className="bg-amber-500 text-black px-6 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider"
              >
                Entrar / Criar Conta
              </button>
            </div>
          ) : playlists.length === 0 ? (
            <div className="relative overflow-hidden py-16 px-6 text-center bg-gradient-to-b from-[#09090F] to-[#040406] border border-white/[0.04] rounded-[2rem] shadow-xl max-w-2xl mx-auto">
              {/* Decorative Subtle Flowing Amber/Orange lights */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-amber-500/[0.03] rounded-full blur-[60px] pointer-events-none" />

              <div className="w-16 h-16 rounded-[1.5rem] bg-white/[0.01] border border-white/5 flex items-center justify-center text-amber-500 mx-auto mb-5 shadow-lg">
                <Disc size={28} className="animate-spin" style={{ animationDuration: '6s' }} />
              </div>

              <span className="text-[9px] font-black uppercase tracking-[0.25em] text-amber-500 mb-1.5 block">A tua curadoria musical</span>
              <h3 className="text-xl font-black text-white italic uppercase tracking-tighter mb-2">Sem coleções pessoais ainda</h3>
              <p className="text-gray-400 font-medium text-xs max-w-md mx-auto leading-relaxed mb-6">
                Monta as tuas próprias coleções de beats favoritas para organizar sessões no teu estúdio, comparar sonoridades ou preparar a tua próxima grande aquisição com total facilidade.
              </p>

              <div className="inline-flex flex-col sm:flex-row items-center gap-2.5 p-4 rounded-2xl bg-white/[0.01] border border-white/5 text-left max-w-md mx-auto">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider leading-relaxed">
                  Para começar, clica no botão <span className="text-white">"Adicionar à Playlist"</span> ou <span className="text-white">"+"</span> presente nos cartões de beats em todo o site.
                </p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
              {playlists.map(pl => {
                const isActive = isPlaylistActive(pl);
                const plBeats = beats.filter(b => pl.beat_ids?.includes(String(b.id)));
                const plCover = plBeats[0]?.image || 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300';
                
                return (
                  <div
                    key={pl.id}
                    onClick={() => onSelectPlaylist(pl.id)}
                    className="p-4 rounded-3xl bg-white/[0.02] border border-white/5 hover:border-white/10 hover:bg-white/[0.04] transition-all duration-300 cursor-pointer text-left group flex flex-col justify-between h-72 relative"
                  >
                    <div className="space-y-3.5">
                      {/* Cover box */}
                      <div className="aspect-square rounded-2xl overflow-hidden bg-white/5 border border-white/10 relative shadow-lg">
                        <img src={plCover} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        
                        {/* Status tag */}
                        <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded bg-black/75 backdrop-blur-md text-[8px] font-black uppercase tracking-widest border border-white/5">
                          {pl.is_public ? <Globe size={8} className="text-emerald-400" /> : <Lock size={8} className="text-amber-500" />}
                          {pl.is_public ? 'Pública' : 'Privada'}
                        </div>

                        {/* Hover play overlay */}
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button
                            onClick={(e) => handlePlaylistPlay(pl, e)}
                            className="w-10 h-10 rounded-full bg-amber-500 text-black flex items-center justify-center shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-all duration-300"
                          >
                            {isActive ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
                          </button>
                        </div>
                      </div>

                      {/* Info Text */}
                      <div className="min-w-0">
                        <h4 className="font-extrabold text-white text-sm truncate">{pl.title}</h4>
                        <p className="text-[10px] text-gray-500 font-semibold truncate mt-0.5 leading-relaxed">
                          {pl.description || "Coleção de beats organizada."}
                        </p>
                      </div>
                    </div>

                    {/* Metadata Footer */}
                    <div className="flex items-center justify-between text-[10px] text-gray-500 border-t border-white/5 pt-3 mt-3">
                      <span className="font-bold flex items-center gap-1.5"><ListMusic size={12} className="text-purple-400" /> {pl.beat_ids?.length || 0} Beats</span>
                      <span className="text-[9px] uppercase font-black text-[#5865F2] tracking-wider group-hover:underline flex items-center gap-0.5">Ver <ArrowRight size={10} /></span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 4. HISTORY TAB VIEW */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black tracking-widest text-[#F59E0B] uppercase italic">Recentemente Tocadas (“Recentemente Ouvidas”)</h3>
          </div>

          {recentlyPlayed.length === 0 ? (
            <div className="py-16 text-center border border-dashed border-white/5 rounded-3xl bg-white/[0.01]">
              <Headphones size={36} className="text-gray-600 mx-auto mb-2.5 opacity-30" />
              <p className="text-xs font-bold text-gray-400">Nenhum som reproduzido ainda.</p>
              <p className="text-[10px] text-gray-500 mt-1">Reproduz faixas no catálogo para que fiquem salvas recentemente!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {recentlyPlayed.map((beat) => {
                const isActive = isPlaying && currentBeat?.id === beat.id;
                return (
                  <div
                    key={beat.id}
                    onClick={() => onSelectBeat?.(beat)}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-white/[0.01] hover:bg-white/[0.04] border border-white/5 hover:border-white/10 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-white/5 border border-white/10 shrink-0">
                        <img src={beat.image || undefined} alt="" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onPlay(beat);
                            }}
                            className="p-2 bg-amber-500 rounded-full text-black hover:scale-110 active:scale-95 transition"
                          >
                            {isActive ? <Pause size={12} fill="currentColor" /> : <Play size={12} fill="currentColor" className="ml-0.5" />}
                          </button>
                        </div>
                      </div>
                      <div className="min-w-0 text-left">
                        <h4 className={`font-extrabold text-sm truncate ${isActive ? 'text-amber-500 font-extrabold' : 'text-white'}`}>{beat.title}</h4>
                        <p className="text-[10px] font-black tracking-wider text-[#F59E0B] mt-0.5 uppercase">{beat.producer}</p>
                      </div>
                    </div>

                    {!(beat.type === 'kit' || (beat.category && (beat.category.toLowerCase().includes('kit') || beat.category.toLowerCase().includes('pack')))) ? (
                      <span className="text-[10px] font-black text-gray-500 font-mono pr-2">{beat.bpm} BPM</span>
                    ) : (
                      <span className="text-[10px] font-black text-blue-400 font-mono pr-2 uppercase italic tracking-wider">{beat.category || 'KIT'}</span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 3. RECOMENDAÇÕES/SMART IA TAB VIEW */}
      {activeTab === 'smart' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black tracking-widest text-[#F59E0B] uppercase italic flex items-center gap-1.5">
              <Sparkles size={14} className="text-purple-400" /> Recomendado para Você ("Recommendation Engine")
            </h3>
          </div>

          {!discoveryData ? (
            <div className="py-14 text-center">
              <Disc className="mx-auto text-gray-700 animate-spin" size={32} />
            </div>
          ) : (
            <div className="space-y-8">
              {/* Based on likes */}
              <div className="space-y-4">
                <h4 className="text-[10px] font-black uppercase text-gray-500 tracking-wider">Baseado nos teus Likes & Gêneros</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {discoveryData.basedOnLikes.map(b => (
                    <div 
                      key={b.id}
                      onClick={() => onSelectBeat?.(b)}
                      className="flex items-center justify-between p-3.5 rounded-2xl bg-[#09090D] border border-white/5 hover:border-white/10 transition-colors cursor-pointer group hover:shadow-md"
                    >
                      <div className="flex items-center gap-3.5 min-w-0 text-left">
                        <img src={b.image || undefined} alt="" className="w-11 h-11 rounded-xl object-cover border border-white/10 shrink-0" />
                        <div className="min-w-0">
                          <h5 className="font-extrabold text-sm text-white truncate">{b.title}</h5>
                          <p className="text-[9px] font-black text-amber-500 uppercase tracking-wider mt-0.5">{b.producer}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="px-2 py-1 rounded bg-white/5 text-[8px] font-black text-gray-500 uppercase tracking-wider">{b.genre || 'Beat'}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onPlay(b);
                          }}
                          className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-amber-500 hover:text-black transition-colors"
                        >
                          {isPlaying && currentBeat?.id === b.id ? <Pause size={14} /> : <Play size={14} className="ml-0.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended For You grid */}
              <div className="space-y-4">
                <h4 className="text-[10px] font-black uppercase text-gray-500 tracking-wider">Recomendados do Momento</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {discoveryData.recommended.map(b => (
                    <div 
                      key={b.id}
                      onClick={() => onSelectBeat?.(b)}
                      className="flex items-center justify-between p-3.5 rounded-2xl bg-[#09090D] border border-white/5 hover:border-white/10 transition-colors cursor-pointer group hover:shadow-md"
                    >
                      <div className="flex items-center gap-3.5 min-w-0 text-left">
                        <img src={b.image || undefined} alt="" className="w-11 h-11 rounded-xl object-cover border border-white/10 shrink-0" />
                        <div className="min-w-0">
                          <h5 className="font-extrabold text-sm text-white truncate">{b.title}</h5>
                          <p className="text-[9px] font-black text-amber-500 uppercase tracking-wider mt-0.5">{b.producer}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="px-2 py-1 rounded bg-white/5 text-[8px] font-black text-gray-500 uppercase tracking-wider">{b.genre || 'Beat'}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onPlay(b);
                          }}
                          className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-amber-500 hover:text-black transition-colors"
                        >
                          {isPlaying && currentBeat?.id === b.id ? <Pause size={14} /> : <Play size={14} className="ml-0.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 1. DISCOVERY ALL HUB */}
      {activeTab === 'all' && (
        <div className="space-y-12">

          {/* CONTINUE LISTENING / "CONTINUE OUVINDO" (if active or recently played has tracks) */}
          {recentlyPlayed.length > 0 && (
            <div className="p-6 md:p-8 rounded-[28px] bg-gradient-to-r from-purple-900/10 via-white/[0.01] to-transparent border border-white/5 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4 text-left">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#5865F2] to-amber-500 p-[1.5px] shrink-0">
                  <div className="w-full h-full rounded-[14px] overflow-hidden bg-[#0A0A0E]">
                    <img src={recentlyPlayed[0].image || undefined} alt="" className="w-full h-full object-cover animate-pulse" />
                  </div>
                </div>
                <div className="space-y-1">
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/10 text-[8px] font-black text-amber-500 uppercase tracking-widest">CONTINUE LISTENING</span>
                  <h3 className="font-black text-white text-lg tracking-tight leading-none pt-0.5">{recentlyPlayed[0].title}</h3>
                  <p className="text-xs text-gray-400 font-semibold">{recentlyPlayed[0].producer}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 shrink-0 w-full md:w-auto">
                {/* Dynamic resume controller */}
                <button
                  onClick={() => onPlay(recentlyPlayed[0])}
                  className="w-full md:w-auto px-8 py-3.5 rounded-2xl bg-white hover:bg-amber-500 hover:text-black text-black font-black uppercase text-[10px] tracking-widest transition-all scale-100 active:scale-95 flex items-center justify-center gap-2 text-center"
                >
                  {isPlaying && currentBeat?.id === recentlyPlayed[0].id ? (
                    <>
                      <Pause size={14} fill="currentColor" /> Pausar Beat
                    </>
                  ) : (
                    <>
                      <Play size={14} fill="currentColor" className="ml-0.5" /> Continuar a Ouvir
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* TRENDING NOW & AUTOMATIC SMART SECTIONS */}
          {!discoveryData ? (
            <div className="py-14 text-center">
              <Disc className="mx-auto text-gray-700 animate-spin" size={32} />
            </div>
          ) : (
            <>
              {/* Row 1: Trending Agora */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black tracking-widest text-[#F59E0B] uppercase italic flex items-center gap-1.5"><TrendingUp size={14} /> Trending Agora</h3>
                  <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Performance Global</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                  {discoveryData.trendingNow.map(b => {
                    const isActive = isPlaying && currentBeat?.id === b.id;
                    return (
                      <div
                        key={b.id}
                        onClick={() => onSelectBeat?.(b)}
                        className="p-3.5 rounded-2xl bg-[#09090D] border border-white/5 hover:border-white/10 hover:-translate-y-1 transition-all duration-300 cursor-pointer relative group flex flex-col justify-between text-left aspect-[4/5]"
                      >
                        <div className="relative aspect-square rounded-xl overflow-hidden bg-white/5 border border-white/5">
                          <img src={b.image || undefined} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="" />
                          <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onPlay(b);
                              }}
                              className="w-9 h-9 rounded-full bg-amber-500 text-black flex items-center justify-center shadow-md scale-95 group-hover:scale-100 transition-transform"
                            >
                              {isActive ? <Pause size={14} /> : <Play size={14} className="ml-0.5" />}
                            </button>
                          </div>
                        </div>
                        <div className="min-w-0 pt-3">
                          <h4 className={`font-extrabold text-xs truncate leading-none ${isActive ? 'text-amber-500' : 'text-white'}`}>{b.title}</h4>
                          <p className="text-[9px] font-bold text-gray-500 truncate mt-0.5 leading-none uppercase">{b.producer}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Row 2: Mais Tocadas */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black tracking-widest text-purple-400 uppercase italic flex items-center gap-1.5"><Headphones size={14} /> Mais Tocadas</h3>
                  <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Estreias Populares</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                  {discoveryData.mostPlayed.map(b => {
                    const isActive = isPlaying && currentBeat?.id === b.id;
                    return (
                      <div
                        key={b.id}
                        onClick={() => onSelectBeat?.(b)}
                        className="p-3.5 rounded-2xl bg-[#09090D] border border-white/5 hover:border-white/10 hover:-translate-y-1 transition-all duration-300 cursor-pointer relative group flex flex-col justify-between text-left aspect-[4/5]"
                      >
                        <div className="relative aspect-square rounded-xl overflow-hidden bg-white/5 border border-white/5">
                          <img src={b.image || undefined} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="" />
                          <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onPlay(b);
                              }}
                              className="w-9 h-9 rounded-full bg-amber-500 text-black flex items-center justify-center shadow-md scale-95 group-hover:scale-100 transition-transform"
                            >
                              {isActive ? <Pause size={14} /> : <Play size={14} className="ml-0.5" />}
                            </button>
                          </div>
                        </div>
                        <div className="min-w-0 pt-3">
                          <h4 className={`font-extrabold text-xs truncate leading-none ${isActive ? 'text-amber-500' : 'text-white'}`}>{b.title}</h4>
                          <p className="text-[9px] font-bold text-gray-500 truncate mt-0.5 leading-none uppercase">{b.producer}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Row 3: Novos Uploads */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black tracking-widest text-blue-400 uppercase italic flex items-center gap-1.5"><Music size={14} /> Novos Lançamentos</h3>
                  <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Últimos uploads</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                  {discoveryData.newUploads.map(b => {
                    const isActive = isPlaying && currentBeat?.id === b.id;
                    return (
                      <div
                        key={b.id}
                        onClick={() => onSelectBeat?.(b)}
                        className="p-3.5 rounded-2xl bg-[#09090D] border border-white/5 hover:border-white/10 hover:-translate-y-1 transition-all duration-300 cursor-pointer relative group flex flex-col justify-between text-left aspect-[4/5]"
                      >
                        <div className="relative aspect-square rounded-xl overflow-hidden bg-white/5 border border-white/5">
                          <img src={b.image || undefined} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="" />
                          <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onPlay(b);
                              }}
                              className="w-9 h-9 rounded-full bg-amber-500 text-black flex items-center justify-center shadow-md scale-95 group-hover:scale-100 transition-transform"
                            >
                              {isActive ? <Pause size={14} /> : <Play size={14} className="ml-0.5" />}
                            </button>
                          </div>
                        </div>
                        <div className="min-w-0 pt-3">
                          <h4 className={`font-extrabold text-xs truncate leading-none ${isActive ? 'text-amber-500' : 'text-white'}`}>{b.title}</h4>
                          <p className="text-[9px] font-bold text-gray-500 truncate mt-0.5 leading-none uppercase">{b.producer}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}

        </div>
      )}

    </div>
  );
}
