import React, { useState, useEffect, useCallback } from 'react';
import { 
  ArrowLeft, Play, Users, MessageSquare, Share2, Search, 
  Music, Lock, MapPin, 
  Instagram, Youtube, Music2, Headphones, Download, 
  TrendingUp, Star, Filter, Heart, ShoppingBag,
  MoreVertical, ChevronRight, Pause, ShoppingCart, Settings, Globe, Twitter, Mail, FileText, Flag, ShieldCheck, Package, Award,
  CreditCard, Zap, Sparkles
} from 'lucide-react';
import VerifiedBadge from './VerifiedBadge';
import { Producer, Beat } from '../types';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { adminStore } from '../lib/adminStore';
import { calculatePremiumProducerStats, getBadgeDetails } from '../lib/rankingSystem';
import { motion, AnimatePresence } from 'motion/react';
import { getSupabase, getPublicUrl } from '../lib/supabase';
import { playlistStore, Playlist } from '../lib/playlistStore';
import { followService } from '../lib/followService';
import EditProfileModal from './EditProfileModal';
import SocialActivityFeed from './SocialActivityFeed';

interface Props {
  producer: Producer;
  beats: Beat[];
  onBack: () => void;
  onPlay: (beat: Beat) => void;
  isPlaying: boolean;
  currentBeat: Beat | null;
  onOpenAuth: (mode: 'login' | 'signup') => void;
  onMessage: (recipientId: string) => void;
  onAddToCart?: (beat: Beat) => void;
  onUpdateProducer?: (updated: Producer) => void;
  onSelectBeat?: (beat: Beat) => void;
  onBackDashboard?: () => void;
}

type TabType = 'beats' | 'kits' | 'playlists' | 'activity';

export default function ProducerProfilePage({ 
  producer, 
  beats, 
  onBack,
  onBackDashboard,
  onPlay, 
  isPlaying, 
  currentBeat, 
  onOpenAuth, 
  onMessage,
  onAddToCart,
  onUpdateProducer,
  onSelectBeat
}: Props) {
  console.log("PROFILE DATA", producer);
  const { user } = useAuth();
  const [producerState, setProducerState] = useState<Producer>(producer);
  const isOwner = user && user.id === producerState.id;
  const isClientProfile = producerState.role === 'client' || (producerState as any).role === 'buyer' || (producerState as any).role === 'artist';
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDocsOpen, setIsDocsOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState<'copyright' | 'spam' | 'inappropriate' | 'scam' | 'stolen_beat' | 'other'>('spam');
  const [reportDetails, setReportDetails] = useState('');

  useEffect(() => {
    const isCurrentUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producerState.id);
    const isNewUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producer.id);
    
    if (isCurrentUUID && !isNewUUID) {
      setProducerState(prev => ({
        ...producer,
        id: prev.id // preserve the real UUID id
      }));
    } else {
      setProducerState(producer);
    }
  }, [producer]);

  // Record profile views to the analytics tracking engine
  useEffect(() => {
    if (!producerState.id || isOwner) return;
    try {
      import('@/src/lib/analytics').then(m => {
        m.trackAnalyticsEvent('profile_visit', {
          producerId: producerState.id,
          userId: user?.id || undefined
        });
      });
    } catch (err) {
      console.error("[ANALYTICS] Profile visit tracking error:", err);
    }
  }, [producerState.id, isOwner, user?.id]);

  const producerBeats = beats.filter(b => (b.producer_id === producerState.id || b.producer === producerState.name) && b.type !== 'kit');
  const producerKits = beats.filter(b => (b.producer_id === producerState.id || b.producer === producerState.name) && b.type === 'kit');
  
  const { showToast } = useToast();

  const handleSendReport = () => {
    adminStore.addReport({
      reporter_id: user?.id || 'anon-visitor',
      reporter_name: user?.user_metadata?.full_name || user?.user_metadata?.artistic_name || user?.email?.split('@')[0] || 'Utilizador Anónimo',
      target_id: producerState.id,
      target_type: 'profile',
      target_name: `Perfil: ${producerState.name}`,
      reason: reportReason,
      details: reportDetails
    });
    
    setIsReportModalOpen(false);
    setReportDetails('');
    showToast('A tua denúncia foi registada e será analisada pela moderação.', 'success', 'Denúncia do Perfil');
  };
  const [activeTab, setActiveTab] = useState<TabType>('beats');
  const [isFollowing, setIsFollowing] = useState(false);
  const [isFollowLoading, setIsFollowLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [scrolled, setScrolled] = useState(false);

  const [realStats, setRealStats] = useState({
    followers: 0,
    beats: 0,
    kits: 0,
    likes: 0,
    sales: 0
  });
  const [isLoadingStats, setIsLoadingStats] = useState(true);

  // Check real following status from server
  useEffect(() => {
    const fetchLatestProfile = async () => {
      const supabase = getSupabase();
      if (!supabase || !producerState.id) {
        console.log('fetchLatestProfile: missing supabase or producerState.id', { hasSupabase: !!supabase, id: producerState?.id });
        return;
      }
      try {
        const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producerState.id);
        console.log('fetchLatestProfile starting...', { id: producerState.id, isUUID, currentStateName: producerState.name });
        
        const makeQuery = async (selectStr: string) => {
          let queryData = null;
          let queryError: any = null;
          if (isUUID) {
            const res = await supabase
              .from('profiles')
              .select(selectStr)
              .eq('id', producerState.id)
              .maybeSingle();
            queryData = res.data;
            queryError = res.error;
          } else {
            const cleanName = (producerState.name || '').trim();
            const resArtistic = await supabase
              .from('profiles')
              .select(selectStr)
              .ilike('artistic_name', cleanName)
              .maybeSingle();

            if (resArtistic.data) {
              queryData = resArtistic.data;
              queryError = resArtistic.error;
            } else {
              const resUsername = await supabase
                .from('profiles')
                .select(selectStr)
                .ilike('username', cleanName.replace(/^@/, ''))
                .maybeSingle();

              if (resUsername.data) {
                queryData = resUsername.data;
                queryError = resUsername.error;
              } else {
                const resDisplay = await supabase
                  .from('profiles')
                  .select(selectStr)
                  .ilike('display_name', cleanName)
                  .maybeSingle();
                queryData = resDisplay.data;
                queryError = resDisplay.error;
              }
            }
          }
          return { data: queryData, error: queryError };
        };

        let selectStr = 'id, username, artistic_name, display_name, avatar_url, city, is_verified, bio, phone, role, created_at';
        let { data, error } = await makeQuery(selectStr);

        if (error && (error.message?.includes('bio') || error.message?.includes('schema cache') || error.hint?.includes('bio') || error.code === 'PGRST204')) {
          console.warn("Retrying fetchLatestProfile query without 'bio' column...");
          selectStr = 'id, username, artistic_name, display_name, avatar_url, city, is_verified, phone, role, created_at';
          const retryRes = await makeQuery(selectStr);
          data = retryRes.data;
          error = retryRes.error;
        }

        console.log('fetchLatestProfile result data:', data, 'error:', error);
        
        if (error) {
          console.error("fetchLatestProfile error response from Supabase:", error);
        }
        
        if (data && !error) {
          console.log('fetchLatestProfile MATCHED profile row successfully. DB username value is:', data.username);
          
          let parsedBio = data.bio || '';
          let parsedBanner = '';
          let parsedSocials: any = {};
          let parsedGenres = [];
          
          if (data.phone && data.phone.startsWith('{')) {
            try {
              const ext = JSON.parse(data.phone);
              if (!parsedBio) {
                parsedBio = ext.bio || '';
              }
              parsedBanner = ext.banner_url || '';
              parsedSocials = {
                instagram: ext.instagram_url || '',
                youtube: ext.youtube_url || '',
                twitter: ext.twitter_url || '',
                web: ext.website_url || ''
              };
              parsedGenres = ext.genres || [];
            } catch (e) {
              console.error('Failed to parse phone JSON in fetchLatestProfile:', e);
            }
          }

          setProducerState(prev => {
            let formattedIntroDate = prev.joinDate;
            if (data.created_at) {
              try {
                const dt = new Date(data.created_at);
                const mName = dt.toLocaleDateString('pt-AO', { month: 'long' });
                formattedIntroDate = `${mName.charAt(0).toUpperCase() + mName.slice(1)} de ${dt.getFullYear()}`;
              } catch (e) {
                console.error("Join date parse error", e);
              }
            }
            const updated = {
              ...prev,
              id: data.id || prev.id,
              username: data.username || prev.username,
              name: data.artistic_name || data.display_name || prev.name,
              avatar: data.avatar_url || prev.avatar,
              location: data.city || prev.location,
              isVerified: data.is_verified === true,
              bio: parsedBio,
              banner: parsedBanner || prev.banner,
              socials: Object.keys(parsedSocials).length > 0 ? parsedSocials : prev.socials,
              genres: parsedGenres.length > 0 ? parsedGenres : prev.genres,
              role: data.role || (prev as any).role,
              joinDate: formattedIntroDate
            };
            console.log('Updating producerState with latest DB field values:', updated);
            return updated;
          });
        } else if (!data && !error) {
          console.warn('fetchLatestProfile did not find any matching row for term:', producerState.name);
        }
      } catch (err) {
        console.error('fetchLatestProfile caught an exception:', err);
      }
    };
    fetchLatestProfile();
  }, [producerState.id, producerState.name]);

  // Check real following status from server & keep synchronized with global cache events
  useEffect(() => {
    let active = true;
    
    const checkFollowStatus = async () => {
      if (!user || !producerState.id) return;
      
      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producerState.id);
      if (!isUUID) {
        console.log("[FOLLOW STATUS CHECK] Skipping check because ID is not yet a UUID:", producerState.id);
        return;
      }
      
      console.log("[FOLLOW STATUS CHECK] Central checking follow status for User:", user.id, "Producer:", producerState.id);
      try {
        const isFollow = await followService.checkIsFollowing(user.id, producerState.id);
        if (active) {
          console.log("[FOLLOW STATUS CHECK] Central returned:", isFollow);
          console.log('FOLLOW QUERY RESULT:', isFollow);
          console.log('IS FOLLOWING COMPUTED:', isFollow);
          setIsFollowing(isFollow);
        }
      } catch (err) {
        console.warn("[FOLLOW STATUS CHECK] Central check failed:", err);
      }
    };
    
    checkFollowStatus();

    // Sincronização em tempo real entre componentes e estados globais
    const handleGlobalFollowChange = (e: any) => {
      if (e.detail && e.detail.followerId === user?.id && e.detail.followingId === producerState.id) {
        console.log("[FOLLOW GLOBAL CHANGE EVENT] Synchronizing status for producer:", producerState.id, "to:", e.detail.isFollowing);
        setIsFollowing(e.detail.isFollowing);
        fetchRealStats(); // re-fetch stats to trigger counter increase/decrease in real time safely
      }
    };

    window.addEventListener('followStatusChanged', handleGlobalFollowChange);

    return () => {
      active = false;
      window.removeEventListener('followStatusChanged', handleGlobalFollowChange);
    };
  }, [user, producerState.id]);

  const fetchRealStats = useCallback(async () => {
    setIsLoadingStats(true);
    const supabase = getSupabase();
    const producerIdToUse = producerState.id || producer.id;
    if (!supabase) {
      setRealStats({
        followers: 0,
        beats: producerBeats.length,
        kits: producerKits.length,
        likes: 0,
        sales: 0
      });
      setIsLoadingStats(false);
      return;
    }

    const isProducerUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producerIdToUse);
    if (!isProducerUUID) {
      setRealStats({
        followers: 0,
        beats: producerBeats.length,
        kits: producerKits.length,
        likes: 0,
        sales: 0
      });
      setIsLoadingStats(false);
      return;
    }

    try {
      // 1. Fetch count of followers directly from Supabase (Source of Truth)
      let followersCount = 0;
      const { count: followersRes, error: fErr } = await supabase
        .from("followers")
        .select("*", { count: "exact", head: true })
        .eq("following_id", producerIdToUse);
      
      if (!fErr && followersRes !== null) {
        followersCount = followersRes;
        console.log('FOLLOW COUNT SOURCE: Direct Supabase "followers" table');
        console.log(`FOLLOW DATABASE RESULT: ${followersCount}`);
      } else {
        // fallback to server endpoint
        try {
          const statsRes = await fetch(`/api/social/stats/${producerIdToUse}`);
          if (statsRes.ok) {
            const serverStats = await statsRes.json();
            followersCount = serverStats.followers || 0;
            console.log('FOLLOW COUNT SOURCE: Server API /api/social/stats');
            console.log(`FOLLOW FALLBACK RESULT: ${followersCount}`);
          }
        } catch (apiErr) {
          console.warn("API fallback stats query failed:", apiErr);
        }
      }

      // 2. Fetch real stats of likes/plays via API
      let likesCount = 0;
      try {
        const statsRes = await fetch(`/api/social/stats/${producerIdToUse}`);
        if (statsRes.ok) {
          const serverStats = await statsRes.json();
          likesCount = serverStats.likes_count || 0;
        }
      } catch (err) {
        console.warn("Could not fetch full social stats:", err);
      }

      // 3. Fetch real sales count from order_items
      let salesCount = 0;
      const { count: itemSalesCountVal, error: salesErr } = await supabase
        .from('order_items')
        .select('*', { count: 'exact', head: true })
        .eq('producer_id', producerIdToUse);
      
      if (!salesErr && itemSalesCountVal !== null) {
        salesCount = itemSalesCountVal;
      }

      // 4. Fetch real temporal timeline of play_events to compute growth and weekly/monthly velocity metrics
      let weeklyGrowth = 0;
      let monthlyPlaysGrowth = 0;
      try {
        const { data: peEvents } = await supabase
          .from('play_events')
          .select('created_at')
          .eq('producer_id', producerIdToUse);
        
        if (peEvents && peEvents.length > 0) {
          const totalPeCount = peEvents.length;
          const nowMs = Date.now();
          const sevenDaysAgo = nowMs - 7 * 24 * 3600 * 1000;
          const thirtyDaysAgo = nowMs - 30 * 24 * 3600 * 1000;
          
          const weeklyRealPlays = peEvents.filter(pe => new Date(pe.created_at).getTime() > sevenDaysAgo).length;
          const monthlyRealPlays = peEvents.filter(pe => new Date(pe.created_at).getTime() > thirtyDaysAgo).length;
          
          const prevWeekly = totalPeCount - weeklyRealPlays;
          const prevMonthly = totalPeCount - monthlyRealPlays;
          
          if (prevWeekly > 0) {
            weeklyGrowth = +((weeklyRealPlays / prevWeekly) * 100).toFixed(1);
          } else if (weeklyRealPlays > 0) {
            weeklyGrowth = 100.0;
          }
          
          if (prevMonthly > 0) {
            monthlyPlaysGrowth = +((monthlyRealPlays / prevMonthly) * 100).toFixed(1);
          } else if (monthlyRealPlays > 0) {
            monthlyPlaysGrowth = 100.0;
          }
        }
      } catch (growthErr) {
        console.warn('Error calculating real growth:', growthErr);
      }

      // 5. Fetch top playlist by finding references in playlist_beats junction table
      let topPlaylistTitle = 'Nenhuma Playlist';
      let computedPlaylistCount = 0;
      try {
        const producerBeatIds = producerBeats.map(b => b.id);
        if (producerBeatIds.length > 0) {
          const { data: pbs } = await supabase
            .from('playlist_beats')
            .select('playlist_id')
            .in('beat_id', producerBeatIds);
          
          if (pbs && pbs.length > 0) {
            computedPlaylistCount = new Set(pbs.map(pb => pb.playlist_id)).size;
            const counts: { [key: string]: number } = {};
            pbs.forEach(pb => {
              counts[pb.playlist_id] = (counts[pb.playlist_id] || 0) + 1;
            });
            let bestPlId = '';
            let maxCount = 0;
            Object.entries(counts).forEach(([id, count]) => {
              if (count > maxCount) {
                maxCount = count;
                bestPlId = id;
              }
            });
            if (bestPlId) {
              const { data: pl } = await supabase
                .from('playlists')
                .select('title')
                .eq('id', bestPlId)
                .maybeSingle();
              if (pl) {
                topPlaylistTitle = pl.title;
              }
            }
          }
        }
      } catch (plErr) {
        console.warn('Error fetching playlist title:', plErr);
      }

      setProducerState(prev => ({
        ...prev,
        salesCount,
        topPlaylistTitle,
        weeklyGrowth,
        monthlyPlaysGrowth,
        playlistCount: computedPlaylistCount
      }));

      setRealStats({
        followers: followersCount,
        beats: producerBeats.length,
        kits: producerKits.length,
        likes: likesCount,
        sales: salesCount
      });
    } catch (err: any) {
      console.warn('Real profile stats currently unavailable:', err?.message || err);
      setRealStats({
        followers: 0,
        beats: producerBeats.length,
        kits: producerKits.length,
        likes: 0,
        sales: 0
      });
    } finally {
      setIsLoadingStats(false);
    }
  }, [producerState.id, producer.id, producerBeats.length, producerKits.length]);

  useEffect(() => {
    fetchRealStats();
  }, [fetchRealStats]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleFollow = async () => {
    if (!user) {
      onOpenAuth('signup');
      return;
    }

    if (user.id === producerState.id) {
      showToast('Não podes seguir a ti próprio!', 'error', 'Erro');
      return;
    }
    
    console.log('FOLLOW CLICKED');
    console.log('FOLLOW TARGET ID:', producerState.id);
    
    setIsFollowLoading(true);
    const newFollowingState = !isFollowing;
    const followerName = user.user_metadata?.username || user.user_metadata?.artistic_name || user.email?.split('@')[0] || 'Um utilizador';
    
    try {
      let result = false;
      if (newFollowingState) {
        result = await followService.follow(user.id, producerState.id, followerName);
        console.log('FOLLOW INSERT RESULT:', result);
        setIsFollowing(true);
        showToast(`Agora segues @${producerState.name}!`, 'success', 'Seguindo');
        
        try {
          import('@/src/lib/analytics').then(m => {
            m.trackAnalyticsEvent('follow', {
              producerId: producerState.id,
              userId: user?.id || undefined
            });
          });
        } catch (err) {
          console.error("[ANALYTICS] Follow tracking error:", err);
        }
      } else {
        result = await followService.unfollow(user.id, producerState.id);
        console.log('FOLLOW UNFOLLOW RESULT:', result);
        setIsFollowing(false);
        showToast(`Deixaste de seguir @${producerState.name}.`, 'info', 'Unfollow');
      }
      
      // Instantly load real follower count
      await fetchRealStats();
    } catch (err) {
      console.error('Error toggling follow relation:', err);
      showToast('Ocorreu um erro ao processar a relação de follow.', 'error', 'Falha');
      // Rollback status
      setIsFollowing(isFollowing);
    } finally {
      setIsFollowLoading(false);
    }
  };

  const filteredBeats = producerBeats.filter(b => b.title.toLowerCase().includes(searchQuery.toLowerCase()));

  const [userPlaylists, setUserPlaylists] = useState<Playlist[]>([]);

  useEffect(() => {
    const loadProfilePlaylists = async () => {
      try {
        const idToQuery = producerState?.id || producer?.id;
        if (!idToQuery) return;
        const allPlaylists = await playlistStore.fetchPlaylists(idToQuery);
        // Filter for playlists that are either owned by this profile, or are public
        const filtered = allPlaylists.filter(p => p.user_id === idToQuery || p.is_public);
        setUserPlaylists(filtered);
      } catch (e) {
        console.warn('Silent skip loading user profile playlists:', e);
      }
    };
    loadProfilePlaylists();
  }, [producerState.id, producer.id]);

  const tabs: { id: TabType, label: string }[] = [
    { id: 'beats', label: 'Beats' },
    { id: 'kits', label: 'Kits d\'Áudio' },
    { id: 'playlists', label: 'Playlists' },
    { id: 'activity', label: 'Atividade' },
  ];

  console.log('PRODUCER PROFILE PAGE RENDER - Current producerState:', producerState);
  console.log('PROFILE OBJECT:', producerState);

  const profile = producerState;
  
  console.log('PROFILE:', profile);

  const getFormattedUsername = (name: string, username?: string) => {
    if (username) return username;
    return (name || '').toLowerCase().replace(/\s+/g, '').replace(/^@/, '');
  };

  return (
    <div className="relative min-h-screen bg-[#000000] text-gray-200 transition-all duration-300">
      {/* Dynamic Background Effects - subtle and high-end */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-orange-500/5 blur-[150px] rounded-full" />
        <div className="absolute bottom-[-15%] left-[-15%] w-[500px] h-[500px] bg-blue-500/5 blur-[130px] rounded-full" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-6 md:py-8 space-y-6">
        {/* Navigation Header */}
        <motion.button 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={isOwner && onBackDashboard ? onBackDashboard : onBack} 
          className="flex items-center gap-2 text-gray-400 hover:text-white transition-all group px-3 py-1.5 rounded-full hover:bg-white/5 w-fit text-sm"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          <span className="font-semibold tracking-tight">{isOwner ? 'Voltar para Dashboard' : 'Voltar'}</span>
        </motion.button>

        {/* Compact, Stylized Producer Profile Header (No Banner Clutter) */}
        <div className="relative rounded-[2.5rem] border border-white/[0.05] bg-[#000000] shadow-2xl p-6 md:p-10 overflow-hidden group">
          {/* Accent Glowing Light Leak */}
          <div className="absolute top-0 right-0 w-[400px] h-[300px] bg-indigo-600/[0.04] blur-[100px] rounded-full pointer-events-none -translate-y-1/2 translate-x-1/3 group-hover:bg-indigo-600/[0.06] transition-colors duration-700" />
          <div className="absolute bottom-0 left-0 w-[300px] h-[200px] bg-orange-650/[0.03] blur-[80px] rounded-full pointer-events-none translate-y-1/2 -translate-x-1/4" />

          <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Column: Avatar & Producer Main Identity details (col-span-8) */}
            <div className="lg:col-span-8 flex flex-col md:flex-row items-center md:items-start gap-8 text-center md:text-left">
              {/* Avatar with premium styling or fallback */}
              <div className="relative shrink-0 group/avatar">
                <div className="absolute -inset-1.5 bg-gradient-to-tr from-indigo-500 via-purple-500 to-orange-500 rounded-full blur-md opacity-25 group-hover/avatar:opacity-45 transition-opacity duration-500" />
                {(() => {
                  const hasCustomAvatar = !!producerState.avatar && producerState.avatar.trim() !== '';
                  const initials = producerState.name
                    ? producerState.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
                    : 'P';
                  return hasCustomAvatar ? (
                    <img 
                      src={(producerState.avatar.startsWith('http') ? producerState.avatar : getPublicUrl('avatars', producerState.avatar)) || undefined} 
                      alt={producerState.name} 
                      className="relative w-24 h-24 md:w-28 md:h-28 rounded-full object-cover border-2 border-[#000000] shadow-2xl transition-transform duration-500 group-hover/avatar:scale-102"
                    />
                  ) : (
                    <div className="relative w-24 h-24 md:w-28 md:h-28 rounded-full bg-gradient-to-br from-[#12121D] to-[#25253A] border border-indigo-500/20 flex items-center justify-center text-white font-black text-xl tracking-wide uppercase shadow-2xl">
                      {initials}
                    </div>
                  );
                })()}
              </div>
 
              {/* Identity Information Details */}
              <div className="space-y-4 min-w-0 flex-1">
                <div className="space-y-2">
                  <div className="flex flex-row flex-wrap items-center justify-center md:justify-start gap-3">
                    <h1 className="text-3xl md:text-4xl font-black text-white italic uppercase tracking-tighter leading-none">
                      {producerState.name}
                    </h1>
                    {(producerState.isVerified || (producerState as any).is_verified) && (
                      <div className="flex items-center gap-2">
                        <div className="scale-110 flex items-center justify-center mt-0.5">
                          <VerifiedBadge size="lg" />
                        </div>
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border font-mono bg-[#5865F2]/10 text-[#5865F2] border-[#5865F2]/20 shadow-md">
                          VERIFIED
                        </span>
                      </div>
                    )}
                    {(() => {
                      const role = (producerState.role || '').toLowerCase();
                      if (role === 'admin') {
                        return (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border font-mono bg-[#5865F2]/10 text-blue-400 border-[#5865F2]/20 shadow-md">
                            ADMIN
                          </span>
                        );
                      } else if (role !== 'client' && role !== 'buyer' && role !== 'artist') {
                        const premium = calculatePremiumProducerStats(producerState, beats);
                        const badgeDetails = getBadgeDetails(premium.badge);
                        if (!badgeDetails || premium.badge === 'verified') return null;
                        return (
                          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border font-mono ${badgeDetails.labelColor} shadow-md`}>
                            {badgeDetails.label}
                          </span>
                        );
                      }
                      return null;
                    })()}
                  </div>
 
                  {/* RENDER USERNAME BELOW NAME AND ABOVE BIO WITH BULLETPROOF FALLBACK */}
                  <p className="text-xs text-indigo-400 font-mono tracking-wider lowercase block text-center md:text-left leading-none">
                    @{profile?.username || (profile?.name || '').toLowerCase().replace(/\s+/g, '').replace(/^@/, '')}
                  </p>
 
                  {profile?.bio && (
                    <p className="text-gray-300 leading-relaxed max-w-2xl text-center md:text-left text-xs md:text-sm font-medium">
                      {profile.bio}
                    </p>
                  )}
                </div>
 
                {/* Location metadata ONLY (Calendar and tagline completely removed) */}
                <div className="flex flex-wrap justify-center md:justify-start items-center gap-2 text-[10px] text-gray-400">
                  <div className="flex items-center gap-1.5 bg-white/[0.02] border border-white/5 px-3 py-1.5 rounded-xl font-bold uppercase tracking-wider text-[10px]">
                    <MapPin size={12} className="text-orange-500" />
                    <span>{producerState.location || 'Luanda, AO'}</span>
                  </div>
                </div>
 
                {/* Social Channel Links in the Identity Area */}
                <div className="flex justify-center md:justify-start items-center gap-2 pt-1">
                  {producerState.socials?.instagram && (
                    <a href={producerState.socials.instagram} target="_blank" rel="noreferrer" className="w-9 h-9 rounded-xl bg-white/[0.02] hover:bg-[#E1306C]/10 hover:text-[#E1306C] border border-white/5 flex items-center justify-center text-gray-400 transition-all hover:scale-105 hover:border-[#E1306C]/30 shadow-md">
                      <Instagram size={15} />
                    </a>
                  )}
                  {producerState.socials?.youtube && (
                    <a href={producerState.socials.youtube} target="_blank" rel="noreferrer" className="w-9 h-9 rounded-xl bg-white/[0.02] hover:bg-[#FF0000]/10 hover:text-[#FF0000] border border-white/5 flex items-center justify-center text-gray-400 transition-all hover:scale-105 hover:border-[#FF0000]/30 shadow-md">
                      <Youtube size={15} />
                    </a>
                  )}
                  {producerState.socials?.twitter && (
                    <a href={producerState.socials.twitter} target="_blank" rel="noreferrer" className="w-9 h-9 rounded-xl bg-white/[0.02] hover:bg-[#1DA1F2]/10 hover:text-[#1DA1F2] border border-white/5 flex items-center justify-center text-gray-400 transition-all hover:scale-105 hover:border-[#1DA1F2]/30 shadow-md">
                      <Twitter size={15} />
                    </a>
                  )}
                  {producerState.socials?.web && (
                    <a href={producerState.socials.web} target="_blank" rel="noreferrer" className="w-9 h-9 rounded-xl bg-white/[0.02] hover:bg-orange-500/10 hover:text-orange-500 border border-white/5 flex items-center justify-center text-gray-400 transition-all hover:scale-105 hover:border-orange-500/30 shadow-md">
                      <Globe size={15} />
                    </a>
                  )}
                </div>
              </div>
            </div>
 
            {/* Right Column: CTA Actions & Airbit style Stats Summary counts (col-span-4) */}
            <div className="lg:col-span-4 flex flex-col gap-5 items-center lg:items-end w-full">
              
              {/* Stats summary strip layout with Airbit density design - Hidden for clients */}
              {!isClientProfile && (
                <div className="grid grid-cols-3 gap-2 w-full max-w-sm">
                  {[
                    { label: 'Seguidores', value: realStats.followers, icon: Users, color: 'text-orange-500', bg: 'hover:border-orange-500/20' },
                    { label: 'Beats', value: realStats.beats, icon: Music, color: 'text-indigo-400', bg: 'hover:border-indigo-500/20' },
                    { label: 'Likes', value: realStats.likes, icon: Heart, color: 'text-rose-400', bg: 'hover:border-rose-500/20' }
                  ].map((stat, sIdx) => (
                    <div key={sIdx} className={`bg-white/[0.01] border border-white/5 rounded-2xl p-4 text-center flex flex-col items-center justify-center hover:bg-white/[0.03] transition-all duration-300 ${stat.bg} shadow-md`}>
                      <stat.icon size={15} className={`${stat.color} mb-1.5`} />
                      <span className="text-lg font-black text-white font-mono leading-none tracking-tight">
                        {isLoadingStats ? '...' : stat.value}
                      </span>
                      <span className="text-[9px] font-black uppercase text-gray-500 tracking-wider mt-1.5 block">{stat.label}</span>
                    </div>
                  ))}
                </div>
              )}
 
              {/* Primary Action Button Bar */}
              <div className="flex items-center gap-2 w-full max-w-sm">
                {user && user.id === producerState.id ? (
                  <button 
                    onClick={() => setIsEditModalOpen(true)}
                    className="w-full bg-white/5 hover:bg-neutral-800 text-white border border-white/10 hover:border-white/15 font-bold h-10 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-[0.98]"
                  >
                    <Settings size={13} /> Editar Perfil
                  </button>
                ) : (
                  <>
                    <button 
                      onClick={handleFollow}
                      disabled={isFollowLoading}
                      className={`min-w-[120px] px-4 flex items-center justify-center gap-1.5 overflow-hidden whitespace-nowrap h-10 rounded-lg font-bold uppercase tracking-wider text-xs transition-all cursor-pointer active:scale-[0.98] ${
                        isFollowing 
                          ? 'bg-transparent text-white border border-white/20 hover:border-white/40' 
                          : 'bg-[#5865F2] text-white hover:bg-[#4752C4]'
                      } disabled:opacity-50`}
                    >
                      {isFollowLoading ? (
                        <div className="w-3.5 h-3.5 rounded-full border-2 border-current border-t-transparent animate-spin shrink-0" />
                      ) : isFollowing ? (
                        'Seguindo'
                      ) : (
                        <><Users size={12} className="shrink-0" /> Seguir</>
                      )}
                    </button>
 
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log("[MESSAGE BUTTON CLICK] Primary MESSAGE button triggered inside ProducerProfilePage.", { producerId: producer.id, userAuthenticated: !!user });
                        if (user) {
                          onMessage(producer.id);
                        } else {
                          onOpenAuth('login');
                        }
                      }}
                      className="min-w-[120px] px-4 flex items-center justify-center gap-1.5 overflow-hidden whitespace-nowrap h-10 bg-white/5 border border-white/10 text-gray-200 hover:text-white rounded-lg hover:bg-neutral-800 transition-all cursor-pointer active:scale-[0.98] text-xs font-bold uppercase tracking-wider"
                      title="Enviar mensagem"
                    >
                      <MessageSquare size={13} className="shrink-0" /> Message
                    </button>
                  </>
                )}
 
                <button 
                  onClick={() => {
                    const usernamePart = producerState.username || producerState.name.toLowerCase().replace(/\s+/g, '');
                    const url = window.location.origin + `/@${usernamePart}`;
                    navigator.clipboard.writeText(url);
                    showToast('Link do perfil copiado com sucesso!', 'success', 'Partilhar');
                  }}
                  className="w-10 h-10 bg-white/5 border border-white/10 text-gray-300 hover:text-white rounded-lg hover:bg-neutral-800 transition-all flex items-center justify-center cursor-pointer active:scale-[0.98]" 
                  title="Partilhar Perfil"
                >
                  <Share2 size={13} />
                </button>
 
                {!isOwner && (
                  <button 
                    onClick={() => setIsReportModalOpen(true)}
                    className="w-10 h-10 bg-red-950/10 border border-red-900/10 text-red-400/80 hover:text-red-300 rounded-lg hover:bg-red-900/10 transition-all flex items-center justify-center cursor-pointer active:scale-[0.98]" 
                    title="Denunciar Perfil"
                  >
                    <Flag size={13} />
                  </button>
                )}
              </div>
            </div>
 
          </div>


        </div>

        {/* Tabs System & Content */}
        {isClientProfile ? (
          <div className="bg-white/[0.01] border border-white/5 rounded-[2rem] p-8 max-w-4xl mx-auto space-y-6">
            <div className="flex items-center gap-3 border-b border-white/5 pb-4">
              <Sparkles className="text-emerald-400" size={20} />
              <h3 className="text-lg font-black italic uppercase tracking-tighter text-white">Identidade do Utilizador</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div className="space-y-4 bg-white/[0.01] border border-white/5 p-6 rounded-2xl">
                <div>
                  <p className="text-[10px] uppercase font-black tracking-widest text-gray-500">Nome de Exibição / Artístico</p>
                  <p className="text-white font-bold text-base mt-1">{producerState.name}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-black tracking-widest text-gray-500">Nome de Utilizador (Username)</p>
                  <p className="text-indigo-400 font-bold font-mono text-base mt-1">@{getFormattedUsername(producerState.name, producerState.username)}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-black tracking-widest text-gray-500">Membro Desde</p>
                  <p className="text-gray-300 font-semibold mt-1">{producerState.joinDate || 'Janeiro de 2024'}</p>
                </div>
              </div>

              <div className="space-y-4 bg-white/[0.01] border border-white/5 p-6 rounded-2xl">
                <div>
                  <p className="text-[10px] uppercase font-black tracking-widest text-gray-500">Biografia / Apresentação</p>
                  <p className="text-gray-300 font-medium leading-relaxed mt-1 text-xs">
                    {producerState.bio || 'Este utilizador não adicionou uma biografia ainda.'}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-black tracking-widest text-gray-500">Localização</p>
                  <p className="text-gray-300 font-bold mt-1 text-xs">{producerState.location || 'Luanda, Angola'}</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
          {/* Compact visual Tab Line */}
          <div className="flex border-b border-white/5 overflow-x-auto scrollbar-none gap-2 pb-0.5">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative px-4 py-3 text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === tab.id 
                    ? 'text-orange-500 font-extrabold' 
                    : 'text-gray-500 hover:text-gray-300'
                }`}
              >
                {activeTab === tab.id && (
                  <motion.div 
                    layoutId="activeTabUnderline"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500"
                  />
                )}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          <div className="min-h-[400px]">
            <AnimatePresence mode="wait">
              {activeTab === 'beats' && (
                <motion.div 
                  key="beats"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-4"
                >
                  {/* Search and Filters Strip */}
                  <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-white/[0.02] border border-white/5 p-3 rounded-2xl">
                    <div className="relative w-full md:max-w-md group">
                      <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-orange-500 transition-colors" size={16} />
                      <input 
                        type="text" 
                        placeholder="Pesquisar instrumentais deste produtor..." 
                        className="w-full bg-[#000000]/50 border border-white/5 rounded-xl py-2 pl-10 pr-4 text-xs text-white focus:outline-none focus:border-orange-500/50 focus:bg-[#000000] transition-all"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className="text-[10px] font-black uppercase text-gray-500 tracking-widest">{filteredBeats.length} obras</span>
                    </div>
                  </div>

                  {/* HIGH-DENSITY TRACKLIST / BEATS TABLE */}
                  {filteredBeats.length === 0 ? (
                    <div className="text-center p-12 bg-white/[0.01] border border-dashed border-white/5 rounded-2xl text-gray-500 text-sm">
                      Nenhum beat encontrado para a sua pesquisa.
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      {/* Desktop Table Header */}
                      <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-2.5 border-b border-white/5 text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                        <div className="col-span-1 text-center">#</div>
                        <div className="col-span-5">Título / Género</div>
                        <div className="col-span-2 text-center">Ritmo</div>
                        <div className="col-span-2 text-center">Valor Inicial</div>
                        <div className="col-span-2 text-right">Adquirir</div>
                      </div>

                      {/* Rows Grid */}
                      {filteredBeats.map((beat, idx) => {
                        const isCurrent = currentBeat?.id === beat.id;
                        const isActive = isCurrent && isPlaying;
                        
                        return (
                          <div 
                            key={beat.id}
                            onClick={() => onSelectBeat?.(beat)}
                            className="group/row flex flex-col md:grid md:grid-cols-12 md:items-center gap-3 p-4 md:px-6 md:py-2.5 bg-white/[0.01] hover:bg-white/[0.03] border border-white/[0.03] hover:border-white/10 rounded-2xl transition-all duration-200 cursor-pointer"
                          >
                            {/* Desktop Row Play Button */}
                            <div className="col-span-1 hidden md:flex items-center justify-center">
                              <button 
                                onClick={(e) => { e.stopPropagation(); onPlay(beat); }}
                                className="w-8 h-8 rounded-full bg-white/5 group-hover/row:bg-orange-600 group-hover/row:text-white hover:scale-105 transition-all text-gray-400 flex items-center justify-center cursor-pointer"
                              >
                                {isActive ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
                              </button>
                            </div>

                            {/* Cover & Description column */}
                            <div className="col-span-5 flex items-center gap-4">
                              {/* Thumbnail artwork */}
                              <div className="relative w-11 h-11 rounded-lg overflow-hidden bg-white/5 shrink-0 border border-white/5">
                                <img src={beat.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=100'} alt="" className="w-full h-full object-cover" />
                                <div className={`absolute inset-0 bg-black/60 flex items-center justify-center transition-opacity duration-200 ${isActive ? 'opacity-100' : 'opacity-0 group-hover/row:opacity-100'}`}>
                                  <button 
                                    onClick={(e) => { e.stopPropagation(); onPlay(beat); }}
                                    className="text-white hover:text-orange-500 hover:scale-110 transition-transform cursor-pointer"
                                  >
                                    {isActive ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
                                  </button>
                                </div>
                              </div>
                              
                              <div className="min-w-0 flex-grow">
                                <h4 className="text-sm font-bold text-white group-hover/row:text-orange-500 transition-colors truncate">
                                  {beat.title}
                                </h4>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className="text-[10px] font-black uppercase text-gray-500 tracking-wider">
                                    {beat.genre}
                                  </span>
                                  <span className="text-[10px] font-mono text-gray-500 md:hidden">
                                    • {beat.bpm} BPM
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* BPM rhythm column - desktop */}
                            <div className="col-span-2 hidden md:block text-center text-xs font-mono text-gray-400">
                              {beat.bpm} BPM
                            </div>

                            {/* Price initial value */}
                            <div className="col-span-2 flex items-center justify-between md:justify-center">
                              <span className="text-[10px] uppercase font-bold text-gray-500 md:hidden">Preço</span>
                              <span className="text-sm font-extrabold text-white">
                                {beat.price.basic.toLocaleString()} Kz
                              </span>
                            </div>

                            {/* Buying actions */}
                            <div className="col-span-2 flex items-center justify-between md:justify-end gap-2.5 mt-2 md:mt-0 pt-3 md:pt-0 border-t border-white/5 md:border-0 w-full md:w-auto">
                              <span className="text-[10px] uppercase font-bold text-gray-500 md:hidden">Opções</span>
                              
                              <div className="flex items-center gap-2">
                                {user?.id !== producerState.id && (
                                  <>
                                    <button 
                                      onClick={(e) => { e.stopPropagation(); }}
                                      className="p-2 text-gray-500 hover:text-rose-500 transition-colors"
                                    >
                                      <Heart size={14} />
                                    </button>

                                    {onAddToCart && (
                                      <button 
                                        onClick={(e) => { e.stopPropagation(); onAddToCart(beat); }}
                                        className="p-2 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-all cursor-pointer"
                                        title="Registar no Carrinho"
                                      >
                                        <ShoppingCart size={14} />
                                      </button>
                                    )}

                                    <button 
                                      onClick={(e) => { e.stopPropagation(); if (onSelectBeat) { onSelectBeat(beat); } else { window.dispatchEvent(new CustomEvent('showCheckout', { detail: beat })); } }}
                                      className="bg-orange-600 hover:bg-orange-500 text-white font-bold px-3.5 py-1.5 rounded-lg text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer shadow-lg shadow-orange-600/10 hover:-translate-y-0.5 active:scale-95"
                                    >
                                      Comprar
                                    </button>
                                  </>
                                )}
                                {user?.id === producerState.id && (
                                  <span className="text-[10px] uppercase font-black text-gray-600 tracking-wider">
                                    Conteúdo seu
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </motion.div>
              )}
              {activeTab === 'kits' && (
                <motion.div 
                  key="kits"
                  initial={{ opacity: 0, scale: 0.99 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="w-full"
                >
                  {producerKits.length === 0 ? (
                    <div className="text-center p-12 bg-white/[0.01] border border-dashed border-white/5 rounded-2xl text-gray-500 text-sm">
                      Nenhum kit de áudio disponível de momento.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {producerKits.map((kit) => (
                        <div key={kit.id} className="flex gap-4 bg-white/[0.01] border border-white/5 p-4 rounded-2xl hover:bg-[#000000] transition-all group">
                          <div className="w-24 h-24 rounded-xl overflow-hidden border border-white/5 shrink-0 relative">
                            <img src={kit.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=400&auto=format&fit=crop'} alt={kit.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                            <div className="absolute top-1.5 left-1.5 bg-black/75 text-[8px] text-orange-500 font-bold px-1.5 py-0.5 rounded uppercase border border-white/10">
                              {kit.genre || 'KIT'}
                            </div>
                          </div>
                          <div className="flex-grow flex flex-col justify-between py-1">
                            <div>
                              <p className="text-[9px] font-bold text-orange-500 uppercase tracking-widest">{kit.category || 'Sound Kit'}</p>
                              <h4 className="text-sm font-bold text-white mt-1 leading-tight">{kit.title}</h4>
                              <div className="flex items-center gap-3 text-xs font-medium text-gray-500 mt-1">
                                <span className="flex items-center gap-1"><Package size={12} className="text-gray-500" /> Ficheiro ZIP/RAR</span>
                              </div>
                            </div>
                            <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/[0.02]">
                              <span className="text-xs font-bold text-white">
                                {kit.is_free_download ? (
                                  <span className="text-amber-500 uppercase tracking-wider font-extrabold">GRÁTIS</span>
                                ) : (
                                  `${(kit.price?.basic || 0).toLocaleString()} Kz`
                                )}
                              </span>
                              {kit.is_free_download ? (
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const downloadUrl = kit.demo_url || kit.master_url || kit.audioUrl;
                                    if (downloadUrl) {
                                      const a = document.createElement('a');
                                      a.href = downloadUrl;
                                      a.download = `${kit.title || 'SoundKit'}.zip`;
                                      a.target = '_blank';
                                      document.body.appendChild(a);
                                      a.click();
                                      document.body.removeChild(a);
                                    } else {
                                      window.dispatchEvent(new CustomEvent('showCheckout', { detail: kit }));
                                    }
                                  }}
                                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold px-3 py-1.5 rounded-lg text-[10px] uppercase tracking-wider transition-all duration-200 active:scale-95 cursor-pointer flex items-center gap-1.5 hover:shadow-[0_0_12px_rgba(79,70,229,0.3)]"
                                >
                                  <Download size={11} className="text-white" />
                                  <span>Download</span>
                                </button>
                              ) : (
                                <button 
                                  onClick={() => window.dispatchEvent(new CustomEvent('showCheckout', { detail: kit }))}
                                  className="bg-white hover:bg-gray-100 text-black font-bold px-4 py-1.5 rounded-lg text-[10px] uppercase tracking-wider transition-transform active:scale-95 cursor-pointer"
                                >
                                  Adquirir
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
              {activeTab === 'playlists' && (
                <motion.div 
                  key="playlists"
                  initial={{ opacity: 0, scale: 0.99 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.99 }}
                  className="w-full"
                >
                  {userPlaylists.length === 0 ? (
                    <div className="text-center p-12 bg-white/[0.01] border border-dashed border-white/5 rounded-[2rem] text-gray-500 text-sm flex flex-col items-center justify-center space-y-4">
                      <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-gray-400">
                        <Headphones size={24} />
                      </div>
                      <h4 className="text-base font-black text-white italic uppercase tracking-tighter">Nenhuma playlist pública</h4>
                      <p className="max-w-xs text-xs font-semibold text-gray-400 leading-normal">
                        Este utilizador ainda não criou playlists ou definiu-as como públicas nas suas definições.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {userPlaylists.map((playlist) => {
                        const coverUrl = playlist.cover_image || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=450";
                        const playlistBeats = beats.filter(b => (playlist.beat_ids || []).map(String).includes(String(b.id)));
                        const tracksCount = playlist.beat_ids?.length || 0;
                        
                        return (
                          <div 
                            key={playlist.id} 
                            className="bg-white/[0.01] border border-white/5 rounded-3xl p-5 hover:bg-[#000000] transition-all group flex flex-col justify-between"
                          >
                            <div className="space-y-4">
                              <div className="aspect-square w-full rounded-2xl overflow-hidden relative border border-white/5 bg-black/40">
                                <img src={coverUrl} alt={playlist.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                  <button
                                    onClick={() => {
                                      if (playlistBeats.length > 0) {
                                        onPlay(playlistBeats[0]);
                                      }
                                    }}
                                    className="w-12 h-12 rounded-full bg-orange-500 text-black flex items-center justify-center hover:scale-110 active:scale-90 transition-all shadow-lg cursor-pointer"
                                  >
                                    <Play size={20} fill="currentColor" className="ml-0.5" />
                                  </button>
                                </div>
                              </div>
                              
                              <div>
                                <div className="flex items-center justify-between gap-2">
                                  <h4 className="text-sm font-black text-white uppercase italic tracking-tight truncate">{playlist.title}</h4>
                                  <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${playlist.is_public ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-white/5 text-gray-400 border border-white/10'}`}>
                                    {playlist.is_public ? 'Pública' : 'Privada'}
                                  </span>
                                </div>
                                <p className="text-xs text-gray-500 mt-1 line-clamp-2">{playlist.description || "Sem descrição disponível."}</p>
                              </div>
                            </div>

                            <div className="flex items-center justify-between pt-4 mt-4 border-t border-white/[0.02] text-[9px] font-black uppercase text-gray-500 tracking-wider">
                              <span>{tracksCount} {tracksCount === 1 ? 'Beat' : 'Beats'}</span>
                              <span className="flex items-center gap-1">
                                <Headphones size={10} className="text-orange-500" />
                                {(playlist.beat_ids?.length || 0) * 8 + 12} ouvintes
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </motion.div>
              )}
              {activeTab === 'activity' && (
                <motion.div
                  key="activity"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="max-w-2xl mx-auto"
                >
                  <SocialActivityFeed username={producerState.username} showTitle={false} />
                </motion.div>
              )}
              </AnimatePresence>
            </div>
          </div>
        )}
      </div>

      {/* Floating Action Bar (Visible when scrolled) */}
      <AnimatePresence>
        {scrolled && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 px-5 py-3 bg-black/70 backdrop-blur-md border border-white/10 rounded-2xl shadow-xl flex items-center gap-4"
          >
            <div className="flex items-center gap-2.5 pr-4 border-r border-white/10">
              {producerState.avatar && producerState.avatar.trim() !== '' ? (
                <img 
                  src={(producerState.avatar.startsWith('http') ? producerState.avatar : getPublicUrl('avatars', producerState.avatar)) || undefined} 
                  alt="" 
                  className="w-8 h-8 rounded-full object-cover border border-white/10" 
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#12121D] to-[#25253A] border border-indigo-500/20 flex items-center justify-center text-white font-black text-[9px] uppercase">
                  {producerState.name ? producerState.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'P'}
                </div>
              )}
              <span className="text-xs font-bold text-white whitespace-nowrap">{producerState.name}</span>
            </div>
            <div className="flex gap-2">
              {user && user.id === producerState.id ? (
                <button 
                  onClick={() => setIsEditModalOpen(true)}
                  className="px-3 py-1 bg-white/5 border border-white/10 hover:bg-neutral-800 text-white rounded font-bold text-[10px] uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1"
                >
                  <Settings size={11} /> Editar Perfil
                </button>
              ) : (
                <>
                  <button 
                    onClick={handleFollow}
                    disabled={isFollowLoading}
                    className={`px-3.5 py-1.5 rounded font-bold text-[9px] uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1 min-w-[70px] ${
                      isFollowing 
                        ? 'bg-transparent text-white border border-white/20 hover:border-white/35' 
                        : 'bg-[#5865F2] text-white hover:bg-[#4752C4]'
                    } disabled:opacity-50`}
                  >
                    {isFollowLoading ? (
                      <div className="w-2.5 h-2.5 rounded-full border-2 border-current border-t-transparent animate-spin shrink-0" />
                    ) : isFollowing ? (
                      'Seguindo'
                    ) : (
                      'Seguir'
                    )}
                  </button>
                  <button 
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      console.log("[MESSAGE BUTTON FLOAT CLICK] Floating MESSAGE button triggered inside ProducerProfilePage.", { producerId: producer.id, userAuthenticated: !!user });
                      if (user) {
                        onMessage(producer.id);
                      } else {
                        onOpenAuth('login');
                      }
                    }}
                    className="p-1.5 bg-white/5 border border-white/10 text-white hover:bg-neutral-800 rounded flex items-center justify-center cursor-pointer transition-colors"
                  >
                    <MessageSquare size={12} />
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <EditProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        producer={producerState}
        onSaveSuccess={(updated) => {
          setProducerState(updated);
          if (onUpdateProducer) {
            onUpdateProducer(updated);
          }
        }}
      />

      {/* Report Profile Modal */}
      {isReportModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-in fade-in duration-250">
          <div className="bg-gray-950 border border-white/10 rounded-[2rem] w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-6 border-b border-white/5 bg-gradient-to-r from-red-600/10 to-transparent">
              <div className="flex items-center gap-2.5">
                <Flag className="text-red-500 shrink-0" size={20} />
                <h3 className="text-lg font-black italic uppercase tracking-tighter text-white">
                  Denunciar Produtor
                </h3>
              </div>
              <p className="text-xs text-gray-400 mt-1">Denuncia comportamentos impróprios ou violações de autoria.</p>
            </div>

            <div className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase text-gray-500 tracking-widest">Motivo da Denúncia</label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value as any)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-xs text-white uppercase font-black tracking-widest outline-none focus:border-red-500/50 cursor-pointer"
                >
                  <option value="copyright">Violação de Direitos Autorais</option>
                  <option value="stolen_beat">Beat Roubado / Plágio</option>
                  <option value="spam">Spam / Flood / Fraude</option>
                  <option value="inappropriate">Conteúdo Inadequado / Ofensas</option>
                  <option value="scam">Burla / Esquema Técnico</option>
                  <option value="other">Outro Motivo</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase text-gray-500 tracking-widest">Detalhes Adicionais</label>
                <textarea
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="Explica detalhadamente a violação ou o cenário. Os admins da plataforma usarão esta justificação."
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-xs text-white placeholder:text-gray-650 outline-none focus:border-red-500/50 h-24 resize-none font-medium leading-relaxed"
                />
              </div>
            </div>

            <div className="p-6 bg-white/[0.01] border-t border-white/5 flex gap-2 justify-end">
              <button
                onClick={() => { setIsReportModalOpen(false); setReportDetails(''); }}
                className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-[#E6E6E6] hover:bg-white/5 rounded-lg border border-white/10"
              >
                Voltar
              </button>
              <button
                onClick={handleSendReport}
                disabled={!reportDetails.trim()}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 disabled:opacity-50 disabled:hover:bg-red-600 text-white font-bold uppercase tracking-widest text-[10px] rounded-lg shadow-md shadow-red-900/20 max-w-fit active:scale-95 transition-all text-center flex items-center justify-center cursor-pointer"
              >
                Enviar Denúncia
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
