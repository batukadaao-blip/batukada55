import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Play, 
  Pause, 
  ShoppingCart, 
  Heart, 
  Activity, 
  Globe, 
  Zap, 
  Flame, 
  TrendingUp, 
  ArrowRight, 
  Award, 
  Sparkles, 
  Star, 
  Users, 
  Music, 
  Calendar,
  Check
} from 'lucide-react';
import { Beat } from '../types';
import MarketplaceKitCard from './MarketplaceKitCard';
import VerifiedBadge from './VerifiedBadge';
import { getSupabase } from '../lib/supabase';

interface FeaturedBeatsProps {
  beats: Beat[];
  currentBeat: Beat | null;
  isPlaying: boolean;
  onPlay: (beat: Beat) => void;
  onAddToCart: (beat: Beat) => void;
  onSelectProducer: (producerName: string) => void;
  onViewAll: () => void;
  onSelectBeat?: (beat: Beat) => void;
}

const PremiumBeatCard = React.memo(({ 
  beat, 
  isPlaying, 
  onPlay, 
  onAddToCart, 
  onSelectProducer,
  onSelectBeat
}: { 
  beat: Beat; 
  isPlaying: boolean; 
  onPlay: (beat: Beat) => void; 
  onAddToCart: (beat: Beat) => void; 
  onSelectProducer: (producerName: string) => void;
  onSelectBeat?: (beat: Beat) => void;
}) => {
  // Pull local-storage editorial configs if available
  const config = (() => {
    try {
      const stored = localStorage.getItem(`batukada_editorial_config_beat_${beat.id}`);
      if (stored) return JSON.parse(stored);
    } catch (e) {}
    return { priority: beat.featured_priority || 0, campaign: 'None' };
  })();

  const priorityVal = beat.featured_priority || config.priority || 0;

  // Curation Badge selection
  let badgeLabel = '';
  let badgeColor = '';
  if (priorityVal === 100) {
    badgeLabel = 'CURATOR HERO';
    badgeColor = 'from-red-600 to-orange-600';
  } else if (priorityVal === 80) {
    badgeLabel = 'TRENDING NOW';
    badgeColor = 'from-orange-500 to-yellow-500';
  } else if (priorityVal === 50) {
    badgeLabel = 'EDITOR SPEC';
    badgeColor = 'from-blue-600 to-purple-600';
  } else {
    badgeLabel = beat.score && beat.score > 100 ? 'HOT SELLER' : 'NEW HIT';
    badgeColor = 'from-[#5865F2] to-blue-500';
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      onClick={() => onSelectBeat?.(beat)}
      className="group relative cursor-pointer"
    >
      <div className="relative bg-[#0c0c12]/65 border border-white/[0.04] rounded-2xl p-4 h-full flex flex-col shadow-lg overflow-hidden transition-all hover:bg-[#12121c]/90 hover:border-white/[0.08]">
        {/* Cover Artwork Area */}
        <div className="relative aspect-square rounded-xl overflow-hidden mb-4 group/cover bg-[#07070a]">
          <img 
            src={(beat.image && beat.image.trim() !== '') ? beat.image : 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400'} 
            alt={beat.title} 
            className="object-cover w-full h-full transition-transform duration-700 group-hover/cover:scale-105"
            referrerPolicy="no-referrer"
          />
          
          {/* Advanced Premium Curated Badge */}
          <div className="absolute top-3 left-3 z-10 flex items-center gap-1 px-2 py-0.5 rounded bg-[#5865F2] shadow-md">
            <Zap size={9} className="text-white" />
            <span className="text-[9px] font-bold text-white tracking-tight">{badgeLabel}</span>
          </div>

          {/* Overlay actions */}
          <div className="absolute inset-0 bg-black/50 md:opacity-0 md:group-hover/cover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <button 
              onClick={(e) => { e.stopPropagation(); onPlay(beat); }}
              className="w-12 h-12 rounded-full bg-[#5865F2] text-white flex items-center justify-center shadow-md transform scale-95 transition-all hover:scale-105"
            >
              {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} className="translate-x-0.5" fill="currentColor" />}
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col p-0.5">
          <div className="flex justify-between items-start mb-1.5">
            <div className="overflow-hidden w-full">
              <h3 className="text-sm font-bold text-white leading-tight tracking-tight group-hover:text-[#5865F2] transition-colors truncate">{beat.title}</h3>
              <button 
                onClick={(e) => { e.stopPropagation(); onSelectProducer(beat.producer_username || beat.producer_name || beat.producer || 'Unknown Producer'); }}
                className="text-gray-400 text-xs hover:text-white transition-colors block text-left truncate mt-0.5"
              >
                @{beat.producer_username || beat.producer_name || beat.producer || 'Unknown Producer'}
              </button>
            </div>
          </div>

          {/* Tags / Info */}
          <div className="flex flex-wrap gap-1 mt-1 mb-3">
            <span className="px-2 py-0.5 rounded bg-white/5 text-[9px] font-medium text-gray-400">
              {beat.genre}
            </span>
            {!(beat.type === 'kit' || (beat.category && (beat.category.toLowerCase().includes('kit') || beat.category.toLowerCase().includes('pack')))) ? (
              <span className="px-2 py-0.5 rounded bg-white/5 text-[9px] font-medium text-gray-500">
                {beat.bpm} BPM
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded bg-blue-500/10 text-[9px] font-medium text-blue-400">
                {beat.category || 'KIT'}
              </span>
            )}
            {priorityVal >= 80 && (
              <span className="px-2 py-0.5 rounded bg-rose-500/10 text-[9px] font-semibold text-rose-400 flex items-center gap-1">
                <Flame size={8} /> Popular
              </span>
            )}
          </div>

          {/* Waveform Micro UI */}
          <div className="hidden md:flex items-end gap-0.5 h-5 mb-4 opacity-15 group-hover:opacity-60 transition-opacity">
            {Array.from({ length: 28 }).map((_, i) => (
              <motion.div
                key={i}
                animate={isPlaying ? { height: [3, Math.random() * 15 + 3, 3] } : { height: 3 }}
                transition={{ repeat: Infinity, duration: 1 + Math.random(), ease: "easeInOut" }}
                className={`flex-1 rounded-full ${isPlaying ? 'bg-[#5865F2]' : 'bg-gray-600'}`}
                style={{ height: '3px' }}
              />
            ))}
          </div>

          {/* Bottom Call to Action */}
          <div className="mt-auto pt-2.5 border-t border-white/[0.04] flex items-center justify-between gap-2">
            <div className="flex flex-col">
              <span className="text-[9px] text-gray-500 leading-none mb-0.5">
                {beat.is_free_download || beat.price?.basic === 0 ? 'Download' : 'Licença Simples'}
              </span>
              <span className="text-sm font-bold text-white tracking-tight">
                {beat.is_free_download || beat.price?.basic === 0 || beat.price?.basic === null || beat.price?.basic === undefined ? (
                  <span className="text-emerald-400 font-extrabold text-xs uppercase tracking-wider">GRÁTIS</span>
                ) : (
                  <>
                    {beat.price.basic.toLocaleString()}{' '}
                    <span className="text-[10px] text-[#5865F2] font-semibold">Kz</span>
                  </>
                )}
              </span>
            </div>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                if (onSelectBeat) {
                  onSelectBeat(beat);
                } else {
                  onAddToCart(beat);
                }
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/5 border border-white/5 hover:bg-[#5865F2] hover:border-[#5865F2] hover:text-white transition-all group/buy"
            >
              <ShoppingCart size={12} className="group-hover/buy:scale-105 transition-transform text-white" />
              <span className="text-[10px] font-bold text-white">{onSelectBeat ? 'Ver' : 'Adicionar'}</span>
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
});

export default function FeaturedBeats({ 
  beats, 
  currentBeat, 
  isPlaying, 
  onPlay, 
  onAddToCart, 
  onSelectProducer,
  onViewAll,
  onSelectBeat
}: FeaturedBeatsProps) {
  const [producers, setProducers] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'trending' | 'editors_choice' | 'producers' | 'kits' | 'new_releases' | 'campaigns'>('trending');
  const [activeCampaign, setActiveCampaign] = useState<string>('Trap Angola Week');

  useEffect(() => {
    const fetchProducers = async () => {
      const supabase = getSupabase();
      if (!supabase) return;
      try {
        const { data: profiles } = await supabase.from('profiles').select('*');
        const { data: dbBeatsData } = await supabase.from('beats').select('id, producer_id, title, category, bpm, genre, tags, price_basic, price_premium, price_exclusive, cover_url, demo_url, status, artist_name, plays_count, created_at, updated_at, featured, featured_at, featured_priority');
        const dbBeats = dbBeatsData as any[] | null;
        if (profiles) {
          const processed = profiles.map(p => {
            const config = (() => {
              try {
                const stored = localStorage.getItem(`batukada_editorial_config_producer_${p.id}`);
                if (stored) return JSON.parse(stored);
              } catch (e) {}
              return { priority: p.featured_priority || 0, campaign: 'None' };
            })();

            const userBeats = (dbBeats || []).filter(b => b.producer_id === p.id);

            return {
              ...p,
              total_beats: userBeats.length,
              featured: p.featured === true || config.priority > 0,
              featured_priority: p.featured_priority || config.priority || 0,
              campaign: p.campaign || config.campaign || 'None'
            };
          }).filter(p => {
            const totalBeats = p.total_beats || 0;

            // 1. Must have at least 1 beat published
            if (totalBeats === 0) {
              return false;
            }

            // 2. Must not be empty account
            const displayName = (p.display_name || p.artistic_name || p.full_name || '').trim();
            const username = p.username || '';
            if (!displayName && !username) {
              return false;
            }

            // 3. Must not have email name
            const mainName = p.artistic_name || p.display_name || p.full_name || p.username || '';
            const hasEmailName = mainName.includes('@') || username.includes('@');
            if (hasEmailName) {
              return false;
            }

            return true;
          });
          setProducers(processed);
        }
      } catch (e) {
        console.warn("Could not fetch profiles inside FeaturedBeats, starting offline pool:", e);
      }
    };
    fetchProducers();
  }, [activeTab]);

  // CATEGORY SORTING AUTOMATION
  const now = new Date();

  // 1. Trending (automatic algorithms based on score + active high curators)
  const getTrendScore = (b: Beat) => {
    const scoreVal = b.score || 0;
    const config = (() => {
      try {
        const stored = localStorage.getItem(`batukada_editorial_config_beat_${b.id}`);
        if (stored) return JSON.parse(stored);
      } catch (e) {}
      return { priority: b.featured_priority || 0 };
    })();
    const priorityVal = b.featured_priority || config.priority || 0;
    const priorityPremiumWeight = priorityVal >= 80 ? 400 : priorityVal * 3;
    return scoreVal + priorityPremiumWeight;
  };
  
  const trendingBeats = [...beats]
    .filter(b => b.type !== 'kit')
    .sort((a, b) => getTrendScore(b) - getTrendScore(a));

  // 2. Editor's Choice (curated by priority between 20 & 100)
  const editorsChoiceBeats = beats.filter(b => {
    const config = (() => {
      try {
        const stored = localStorage.getItem(`batukada_editorial_config_beat_${b.id}`);
        if (stored) return JSON.parse(stored);
      } catch (e) {}
      return { priority: b.featured_priority || 0 };
    })();
    const priorityVal = b.featured_priority || config.priority || 0;
    return b.featured === true && priorityVal > 0 && priorityVal < 100;
  });
  
  const finalEditorsChoice = editorsChoiceBeats.length >= 3 
    ? editorsChoiceBeats 
    : [...beats].filter(b => b.type !== 'kit').slice(0, 8);

  // 3. Soundkits
  const soundkits = beats.filter(b => 
    b.type === 'kit' || b.category?.toLowerCase().includes('kit') || b.category?.toLowerCase().includes('pack')
  );

  // 4. New Releases (by timestamp)
  const newReleases = [...beats].sort((a, b) => {
    return new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime();
  });

  // 5. Campaigns
  const campaignBeats = beats.filter(b => {
    const config = (() => {
      try {
        const stored = localStorage.getItem(`batukada_editorial_config_beat_${b.id}`);
        if (stored) return JSON.parse(stored);
      } catch (e) {}
      return { campaign: (b as any).campaign || 'None' };
    })();
    return config.campaign === activeCampaign;
  });

  // Filter producers based on priority
  const trendingProducers = [...producers].sort((a, b) => {
    return (b.featured_priority || 0) - (a.featured_priority || 0);
  });

  return (
    <section className="relative py-8 md:py-12 overflow-hidden">
      {/* Background Ambient Orbs to build Depth */}
      <div className="absolute inset-x-0 bottom-0 bg-[radial-gradient(ellipse_at_center,_rgba(88,101,242,0.03),_transparent_40%)] -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div className="space-y-2 text-center md:text-left">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#5865F2]/10 border border-[#5865F2]/15 mx-auto md:mx-0"
            >
              <Sparkles size={11} className="text-[#5865F2]" />
              <span className="text-[10px] font-bold text-[#5865F2] tracking-wider uppercase">Destaques editoriais</span>
            </motion.div>
            
            <motion.h2
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-2xl md:text-3xl font-black text-white tracking-tight"
            >
              Curadoria Premium
            </motion.h2>
            
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-gray-400 max-w-lg font-medium text-xs leading-relaxed"
            >
              Acesso instantâneo a parcerias editoriais oficiais, tendências geradas de forma autónoma, novos talentos e campanhas exclusivas da Batukada.
            </motion.p>
          </div>

          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={onViewAll}
            className="flex items-center justify-center gap-1.5 px-4 py-2 rounded bg-white/5 border border-white/10 text-white text-xs font-semibold hover:bg-neutral-800 transition-all group shrink-0"
          >
            Ver Catálogo
            <ArrowRight size={13} className="group-hover:translate-x-0.5 transition-transform text-[#5865F2]" />
          </motion.button>
        </div>

        {/* Dynamic Navigation Tabs (Editorial System) */}
        <div className="flex overflow-x-auto pb-3 mb-8 gap-1.5 no-scrollbar border-b border-white/[0.04] select-none">
          <button
            onClick={() => setActiveTab('trending')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold shrink-0 transition-all flex items-center gap-2 ${
              activeTab === 'trending' 
                ? 'bg-[#5865F2] text-white' 
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Flame size={13} />
            Trending Now
          </button>
          <button
            onClick={() => setActiveTab('editors_choice')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold shrink-0 transition-all flex items-center gap-2 ${
              activeTab === 'editors_choice' 
                ? 'bg-[#5865F2] text-white' 
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Star size={13} />
            Escolha do Editor
          </button>
          <button
            onClick={() => setActiveTab('producers')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold shrink-0 transition-all flex items-center gap-2 ${
              activeTab === 'producers' 
                ? 'bg-[#5865F2] text-white' 
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Users size={13} />
            Produtores em Destaque
          </button>
          <button
            onClick={() => setActiveTab('kits')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold shrink-0 transition-all flex items-center gap-2 ${
              activeTab === 'kits' 
                ? 'bg-[#5865F2] text-white' 
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Music size={13} />
            Kits & Loops
          </button>
          <button
            onClick={() => setActiveTab('new_releases')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold shrink-0 transition-all flex items-center gap-2 ${
              activeTab === 'new_releases' 
                ? 'bg-[#5865F2] text-white' 
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Calendar size={13} />
            Novos Sons
          </button>
          <button
            onClick={() => setActiveTab('campaigns')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold shrink-0 transition-all flex items-center gap-2 ${
              activeTab === 'campaigns' 
                ? 'bg-[#5865F2] text-white' 
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <Award size={13} />
            Campanhas Activas
          </button>
        </div>

        {/* Campaign sub-selector buttons if campaign segment is active */}
        {activeTab === 'campaigns' && (
          <div className="flex flex-wrap gap-1.5 mb-6 bg-black/45 border border-white/[0.04] p-1.5 rounded-xl inline-flex">
            {['Trap Angola Week', 'Afro House Rising', 'Kuduro Essentials', 'Producer Spotlight'].map(campaignName => (
              <button
                key={campaignName}
                onClick={() => setActiveCampaign(campaignName)}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all ${
                  activeCampaign === campaignName 
                    ? 'bg-[#5865F2]/20 text-[#5865F2]' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {campaignName}
              </button>
            ))}
          </div>
        )}

        {/* Visual Content renders depending on active curation category */}
        {activeTab === 'trending' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {trendingBeats.slice(0, 8).map((beat) => (
              <PremiumBeatCard
                key={`trending-${beat.id}`}
                beat={beat}
                isPlaying={currentBeat?.id === beat.id && isPlaying}
                onPlay={onPlay}
                onAddToCart={onAddToCart}
                onSelectProducer={onSelectProducer}
                onSelectBeat={onSelectBeat}
              />
            ))}
            {trendingBeats.length === 0 && (
              <div className="col-span-full border border-dashed border-white/10 rounded-3xl p-16 text-center text-gray-500">
                <Flame size={32} className="mx-auto text-gray-600 mb-4" />
                <p className="font-bold text-xs uppercase tracking-wider text-gray-400">Nenhum som em tendência no momento.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'editors_choice' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {finalEditorsChoice.slice(0, 8).map((beat) => (
              <PremiumBeatCard
                key={`editors-${beat.id}`}
                beat={beat}
                isPlaying={currentBeat?.id === beat.id && isPlaying}
                onPlay={onPlay}
                onAddToCart={onAddToCart}
                onSelectProducer={onSelectProducer}
                onSelectBeat={onSelectBeat}
              />
            ))}
          </div>
        )}

        {activeTab === 'kits' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {soundkits.slice(0, 8).map((kit) => (
              <MarketplaceKitCard
                key={`kit-${kit.id}`}
                kit={kit}
                onAddToCart={onAddToCart}
                onSelectProducer={onSelectProducer}
                onSelectBeat={onSelectBeat}
              />
            ))}
            {soundkits.length === 0 && (
              <div className="col-span-full border border-dashed border-white/10 rounded-3xl p-16 text-center text-gray-500">
                <Music size={32} className="mx-auto text-gray-600 mb-4" />
                <p className="font-bold text-xs uppercase tracking-wider text-gray-400">Nenhum soundkit ou drumkit editado em destaque ainda.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'new_releases' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {newReleases.slice(0, 8).map((beat) => (
              <PremiumBeatCard
                key={`new-${beat.id}`}
                beat={beat}
                isPlaying={currentBeat?.id === beat.id && isPlaying}
                onPlay={onPlay}
                onAddToCart={onAddToCart}
                onSelectProducer={onSelectProducer}
                onSelectBeat={onSelectBeat}
              />
            ))}
          </div>
        )}

        {activeTab === 'producers' && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-6">
            {trendingProducers.slice(0, 8).map((prod) => {
              const name = prod.artistic_name || prod.display_name || prod.full_name || prod.username || 'Produtor Oficial';
              const username = prod.username || name.toLowerCase().replace(/\s/g, '');
              const initials = name.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase() || 'P';

              return (
                <motion.div
                  key={`prod-${prod.id}`}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  onClick={() => onSelectProducer(username)}
                  className="bg-[#0c0c12]/80 border border-white/[0.04] p-5 text-center flex flex-col justify-between items-center w-full rounded-2xl hover:bg-[#12121a] hover:border-white/[0.08] transition-all duration-150 cursor-pointer group select-none relative min-h-[220px]"
                >
                  {/* Subtle dynamic priority tag */}
                  {(prod.featured_priority >= 80) && (
                    <div className="absolute top-2.5 right-2.5 z-10 select-none flex items-center px-1.5 py-0.5 rounded bg-[#5865F2]/10 border border-[#5865F2]/20 text-[7px] font-bold text-gray-300 uppercase tracking-wider">
                      VIP
                    </div>
                  )}

                  {/* High end round avatar */}
                  <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden mb-3.5 border border-white/[0.06] group-hover:border-[#5865F2]/40 transition-all duration-150 bg-[#070709] shrink-0">
                    {prod.avatar_url && prod.avatar_url.trim() !== '' ? (
                      <img src={prod.avatar_url} alt={name} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-full h-full bg-neutral-900 text-gray-400 font-bold text-sm flex items-center justify-center">
                        {initials}
                      </div>
                    )}
                  </div>

                  {/* Name and Same-line Verified Badge */}
                  <div className="flex flex-col items-center w-full min-w-0 flex-1 justify-center">
                    <div className="flex items-center gap-1 justify-center w-full px-1">
                      <h3 className="text-xs sm:text-sm font-extrabold text-white truncate max-w-full text-center group-hover:text-[#5865F2] transition-colors leading-tight">
                        {name}
                      </h3>
                      {(prod.is_verified || prod.isVerified) && (
                        <VerifiedBadge size="sm" />
                      )}
                    </div>

                    {/* username */}
                    <p className="text-[10px] text-gray-500 text-center font-medium lowercase tracking-tight mt-0.5 truncate w-full px-1">@{username}</p>

                    {/* Discrete stats and location - BeatStars style */}
                    <div className="mt-3 flex items-center gap-1.5 bg-white/[0.02] border border-white/[0.04] px-2 py-0.5 rounded text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                      <span>{prod.total_beats || 0} BEATS</span>
                      <span className="text-gray-650">•</span>
                      <span className="text-gray-500 max-w-[70px] truncate">{prod.location || prod.city || 'Luanda'}</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
            {trendingProducers.length === 0 && (
              <div className="col-span-full border border-dashed border-white/10 rounded-2xl p-16 text-center text-gray-500">
                <Users size={24} className="mx-auto text-gray-600 mb-4" />
                <p className="font-bold text-xs uppercase tracking-wider text-gray-400">Nenhum produtor curado em destaque ainda.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'campaigns' && (
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {campaignBeats.map((beat) => (
                <PremiumBeatCard
                  key={`campaign-${beat.id}`}
                  beat={beat}
                  isPlaying={currentBeat?.id === beat.id && isPlaying}
                  onPlay={onPlay}
                  onAddToCart={onAddToCart}
                  onSelectProducer={onSelectProducer}
                  onSelectBeat={onSelectBeat}
                />
              ))}
            </div>
            {campaignBeats.length === 0 && (
              <div className="border border-dashed border-yellow-500/20 bg-yellow-500/[0.02] rounded-3xl p-12 text-center max-w-xl mx-auto space-y-3">
                <Award size={36} className="mx-auto text-yellow-500/80 animate-pulse" />
                <h4 className="font-bold text-white uppercase italic tracking-tight text-sm">Pronta para Curation!</h4>
                <p className="text-xs text-gray-400">Sem beats vinculados a esta campanha neste momento. Atribua beats a "{activeCampaign}" no painel administrativo e eles aparecerão em destaque aqui instantaneamente!</p>
              </div>
            )}
          </div>
        )}

        {/* Bottom Campaign Promotion Banner */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 md:mt-24 p-0.5 rounded-[2rem] md:rounded-3xl bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-blue-600/20 border border-white/5 backdrop-blur-xl"
        >
          <div className="bg-[#0B0B0F]/40 rounded-[1.9rem] md:rounded-[22px] py-10 md:py-12 px-6 md:px-8 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
              <div className="w-16 h-16 rounded-2xl bg-[#5865F2] flex items-center justify-center shadow-xl shadow-[#5865F2]/20 md:animate-bounce">
                <Zap className="text-white" size={32} />
              </div>
              <div>
                <h3 className="text-xl md:text-2xl font-black text-white italic uppercase tracking-tight mb-2">Queres o teu som em destaque?</h3>
                <p className="text-gray-400 text-sm max-w-md">Os subscritores e produtores com portfólio completo têm canais prioritários para curadoria editorial. Fala com a nossa equipa para solicitar audiência.</p>
              </div>
            </div>
            <button className="w-full md:w-auto px-8 py-4 rounded-2xl bg-white text-black font-black uppercase tracking-widest text-[10px] md:text-xs hover:scale-105 active:scale-95 transition-all shadow-2xl">
              Registar no Spotlight
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
