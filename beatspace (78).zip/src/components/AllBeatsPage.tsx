
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Search, 
  Filter, 
  ArrowLeft, 
  ChevronDown, 
  SlidersHorizontal, 
  Activity, 
  DollarSign, 
  Music, 
  TrendingUp, 
  Clock, 
  Award,
  Zap,
  X,
  Plus,
  Loader2,
  Users,
  Disc,
  ListMusic
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Beat, Producer } from '../types';
import BeatCard from './BeatCard';
import MarketplaceKitCard from './MarketplaceKitCard';
import VerifiedBadge from './VerifiedBadge';
import { getSupabase, getPublicUrl } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { playlistStore, Playlist } from '../lib/playlistStore';
import { playService } from '../lib/playService';

function FiltersContent({ 
  selectedGenre, 
  setSelectedGenre, 
  genres, 
  bpmRange, 
  setBpmRange, 
  priceRange, 
  setPriceRange,
  selectedKey,
  setSelectedKey,
  selectedScale,
  setSelectedScale,
  isFreeDownloadOnly,
  setIsFreeDownloadOnly,
  isFeaturedOnly,
  setIsFeaturedOnly,
  activeTab
}: any) {
  const isKit = activeTab === 'Kits' || activeTab === '🥁 Kits' || activeTab === 'Drum Kits' || activeTab === 'Loop Kits';
  const isPlaylist = activeTab === 'Playlists' || activeTab === '💿 Playlists';

  const KEYS = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const SCALES = ['Maior', 'Menor'];

  return (
    <div className="space-y-10">
      {/* Genre Filter */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-black text-xs uppercase tracking-widest italic">Gênero</h3>
          {selectedGenre && (
            <button onClick={() => setSelectedGenre(null)} className="text-amber-500 text-[10px] font-black uppercase hover:underline">Limpar</button>
          )}
        </div>
        <div className="max-h-[260px] overflow-y-auto pr-1 [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:bg-white/10 [&::-webkit-scrollbar-thumb]:rounded-full hover:[&::-webkit-scrollbar-thumb]:bg-amber-500/30">
          <div className="grid grid-cols-2 gap-2">
            {genres.map((genre: string) => (
              <button
                key={genre}
                onClick={() => setSelectedGenre(genre === selectedGenre ? null : genre)}
                className={`px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-center border ${selectedGenre === genre ? 'bg-amber-500 border-amber-500 text-black' : 'bg-white/5 border-white/10 text-gray-500 hover:text-white hover:border-white/20'}`}
              >
                {genre}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Hide bpm, key, scale for kits and playlists */}
      {!isKit && !isPlaylist && (
        <>
          {/* BPM Filter */}
          <div className="space-y-6">
            <h3 className="text-white font-black text-xs uppercase tracking-widest italic">Ritmo (BPM)</h3>
            <div className="space-y-4">
              <div className="flex justify-between text-[10px] font-black text-gray-400 uppercase italic">
                <span>{bpmRange[0]} BPM</span>
                <span>{bpmRange[1]} BPM</span>
              </div>
              <input 
                type="range" 
                min="80" 
                max="200" 
                value={bpmRange[1]}
                onChange={(e) => setBpmRange([80, parseInt(e.target.value)])}
                className="w-full accent-amber-500"
              />
            </div>
          </div>

          {/* Key Filter */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-black text-xs uppercase tracking-widest italic">Tom (Key)</h3>
              {selectedKey && (
                <button onClick={() => setSelectedKey(null)} className="text-amber-500 text-[10px] font-black uppercase hover:underline">Limpar</button>
              )}
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {KEYS.map((k) => (
                <button
                  key={k}
                  onClick={() => setSelectedKey(k === selectedKey ? null : k)}
                  className={`py-1.5 rounded-lg text-[9px] font-black transition-all text-center border ${selectedKey === k ? 'bg-amber-500 border-amber-500 text-black' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white hover:border-white/20'}`}
                >
                  {k}
                </button>
              ))}
            </div>
          </div>

          {/* Scale Filter */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-black text-xs uppercase tracking-widest italic">Escala</h3>
              {selectedScale && (
                <button onClick={() => setSelectedScale(null)} className="text-amber-500 text-[10px] font-black uppercase hover:underline">Limpar</button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2">
              {SCALES.map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedScale(s === selectedScale ? null : s)}
                  className={`px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-center border ${selectedScale === s ? 'bg-amber-500 border-amber-500 text-black' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white hover:border-white/20'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Price Filter */}
      {!isPlaylist && (
        <div className="space-y-6">
          <h3 className="text-white font-black text-xs uppercase tracking-widest italic">Preço Máximo</h3>
          <div className="space-y-4">
            <div className="flex justify-between text-[10px] font-black text-gray-400 uppercase italic">
              <span>0 Kz</span>
              <span>{priceRange[1].toLocaleString()} Kz</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="500000" 
              step="5000"
              value={priceRange[1]}
              onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
              className="w-full accent-amber-500"
            />
          </div>
        </div>
      )}

      {/* Toggle Options */}
      <div className="space-y-6">
        <h3 className="text-white font-black text-xs uppercase tracking-widest italic">Opções de Descoberta</h3>
        <div className="flex flex-col gap-3">
          <label className="flex items-center gap-3 group cursor-pointer">
            <input 
              type="checkbox" 
              checked={isFreeDownloadOnly}
              onChange={(e) => setIsFreeDownloadOnly(e.target.checked)}
              className="sr-only"
            />
            <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${isFreeDownloadOnly ? 'bg-amber-500 border-amber-500' : 'bg-white/5 border-white/10 group-hover:border-amber-500'}`}>
              <Plus size={12} className={`text-black transition-transform ${isFreeDownloadOnly ? 'scale-100' : 'scale-0'}`} />
            </div>
            <span className="text-[10px] font-black uppercase text-gray-500 group-hover:text-white transition-colors tracking-widest">Downloads Grátis</span>
          </label>

          <label className="flex items-center gap-3 group cursor-pointer">
            <input 
              type="checkbox" 
              checked={isFeaturedOnly}
              onChange={(e) => setIsFeaturedOnly(e.target.checked)}
              className="sr-only"
            />
            <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${isFeaturedOnly ? 'bg-amber-500 border-amber-500' : 'bg-white/5 border-white/10 group-hover:border-amber-500'}`}>
              <Plus size={12} className={`text-black transition-transform ${isFeaturedOnly ? 'scale-100' : 'scale-0'}`} />
            </div>
            <span className="text-[10px] font-black uppercase text-gray-500 group-hover:text-white transition-colors tracking-widest">Apenas Destaques</span>
          </label>
        </div>
      </div>
    </div>
  );
}

interface AllBeatsPageProps {
  beats?: Beat[];
  producers?: Producer[];
  handlePlay: (beat: Beat) => void;
  addToCart: (beat: Beat) => void;
  currentBeat: Beat | null;
  isPlaying: boolean;
  onBack: () => void;
  onSelectProducer: (producerName: string) => void;
  onSelectBeat?: (beat: Beat) => void;
  onSelectPlaylist?: (playlistId: string) => void;
}

const ALL_GENRES = [
  "Afro Beat",
  "Afro House",
  "Afro Trap",
  "Afro Soul",
  "Amapiano",
  "Kuduro",
  "Trap",
  "Drill",
  "Boom Bap",
  "Hip Hop",
  "Rap",
  "Lo-Fi",
  "Lo-Fi Jazz",
  "R&B",
  "Soul",
  "Pop",
  "Pop Trap",
  "Dancehall",
  "Reggaeton",
  "Gospel",
  "House",
  "Deep House",
  "Tech House",
  "EDM",
  "Funk",
  "Funk Brasileiro",
  "Jersey Club",
  "Kompa",
  "Kizomba",
  "Semba",
  "Zouk",
  "Ghetto Zouk",
  "Jazz",
  "Piano",
  "Acoustic",
  "Instrumental",
  "Cinematic",
  "Orchestral",
  "Melodic",
  "Sad",
  "Chill",
  "Ambient",
  "Detroit",
  "UK Drill",
  "Plug",
  "Rage",
  "Cloud Rap",
  "Experimental",
  "Outro"
];

export default function AllBeatsPage({ 
  beats,
  producers,
  handlePlay, 
  addToCart, 
  currentBeat, 
  isPlaying, 
  onBack, 
  onSelectProducer,
  onSelectBeat,
  onSelectPlaylist
}: AllBeatsPageProps) {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('q') || '';
    }
    return '';
  });
  const [selectedGenre, setSelectedGenre] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const genreParam = params.get('genre');
      if (genreParam) {
        const found = ALL_GENRES.find(g => {
          const normG = g.toLowerCase().replace(/[^a-z0-9]/g, '');
          const normP = genreParam.toLowerCase().replace(/[^a-z0-9]/g, '');
          return normG === normP || g.toLowerCase() === genreParam.toLowerCase();
        });
        return found || genreParam;
      }
    }
    return null;
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (selectedGenre) {
        params.set('genre', selectedGenre.toLowerCase());
      } else {
        params.delete('genre');
      }
      if (searchQuery) {
        params.set('q', searchQuery);
      } else {
        params.delete('q');
      }
      const newSearch = params.toString();
      const cleanUrl = newSearch ? `${window.location.pathname}?${newSearch}` : window.location.pathname;
      window.history.pushState({}, '', cleanUrl);
    }
  }, [selectedGenre, searchQuery]);

  useEffect(() => {
    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      const genreParam = params.get('genre');
      if (genreParam) {
        const found = ALL_GENRES.find(g => {
          const normG = g.toLowerCase().replace(/[^a-z0-9]/g, '');
          const normP = genreParam.toLowerCase().replace(/[^a-z0-9]/g, '');
          return normG === normP || g.toLowerCase() === genreParam.toLowerCase();
        });
        setSelectedGenre(found || genreParam);
      } else {
        setSelectedGenre(null);
      }

      const qParam = params.get('q') || '';
      setSearchQuery(qParam);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);
  const [sortBy, setSortBy] = useState('trending');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500000]);
  const [bpmRange, setBpmRange] = useState<[number, number]>([80, 200]);
  const [isFilterOpen, setIsFilterOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('Beats');
  
  const [page, setPage] = useState(1);
  const itemsPerPage = 12;
  const loaderRef = useRef<HTMLDivElement>(null);

  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [selectedScale, setSelectedScale] = useState<string | null>(null);
  const [isFreeDownloadOnly, setIsFreeDownloadOnly] = useState(false);
  const [isFeaturedOnly, setIsFeaturedOnly] = useState(false);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState('');

  // 300ms Search Debounce
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchQuery]);

  // Search History State & Persistence
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('batukada_search_history');
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      return [];
    }
  });

  const addToSearchHistory = (query: string) => {
    const trimmed = query.trim();
    if (!trimmed) return;

    // Track professional analytics search_performed event
    try {
      import('@/src/lib/analytics').then(m => {
        m.trackAnalyticsEvent('search_performed', {
          userId: user?.id || undefined,
          metadata: { query: trimmed }
        });
      });
    } catch (err) {
      console.error("[ANALYTICS] Search performance tracking error:", err);
    }

    setSearchHistory(prev => {
      const updated = [trimmed, ...prev.filter(q => q.toLowerCase() !== trimmed.toLowerCase())].slice(0, 5);
      localStorage.setItem('batukada_search_history', JSON.stringify(updated));
      return updated;
    });
  };

  const removeFromSearchHistory = (query: string) => {
    setSearchHistory(prev => {
      const updated = prev.filter(q => q !== query);
      localStorage.setItem('batukada_search_history', JSON.stringify(updated));
      return updated;
    });
  };

  const clearSearchHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem('batukada_search_history');
  };

  const genres = ALL_GENRES;
  const categories = ['Beats', 'Produtores', 'Kits', 'Playlists'];
  const sortOptions = [
    { label: 'Trending', value: 'trending', icon: TrendingUp },
    { label: 'Mais Tocados', value: 'popular', icon: Activity },
    { label: 'Mais Recentes', value: 'newest', icon: Clock },
    { label: 'Preço: Baixo', value: 'price_low', icon: ArrowLeft }, 
    { label: 'Preço: Alto', value: 'price_high', icon: Award }
  ];

  const [beatsData, setBeatsData] = useState<Beat[]>(beats || []);

  useEffect(() => {
    if (beats) {
      setBeatsData(beats);
    }
  }, [beats]);

  // Load Playlists
  useEffect(() => {
    async function loadPlaylists() {
      try {
        const data = await playlistStore.fetchPlaylists(user?.id || '');
        setPlaylists(data || []);
      } catch (err) {
        console.warn('Failed loading playlists for search page:', err);
      }
    }
    loadPlaylists();
  }, [user]);

  useEffect(() => {
    async function loadBeats() {
      const supabase = getSupabase();
      if (!supabase) return;
      
      try {
        const { data: beatsDataRaw, error: beatsError } = await supabase.from('beats').select('id, producer_id, title, category, bpm, genre, tags, price_basic, price_premium, price_exclusive, cover_url, demo_url, status, artist_name, plays_count, created_at, updated_at, featured, featured_at, featured_priority');
        const beatsData = beatsDataRaw as any[] | null;
        const { data: profilesData } = await supabase.from('profiles').select('id, display_name, artistic_name, username, avatar_url');
        const profileMap = new Map((profilesData || []).map(p => [p.id, {
          name: p.artistic_name || p.display_name || 'Produtor',
          username: p.username || '',
          avatar_url: p.avatar_url || ''
        }]));
        
        if (beatsError) {
            console.error('AllBeatsPage: error fetching beats', beatsError);
        } else {
            // Fetch auxiliary data for trending/popular score calculations safely
            let orderItems: any[] = [];
            let orders: any[] = [];
            let favorites: any[] = [];

            try {
              const { data: oItems } = await supabase.from('order_items').select('beat_id, order_id');
              if (oItems) orderItems = oItems;
            } catch (e) {
              console.warn('Could not fetch order_items for ranking:', e);
            }

            try {
              const { data: ords } = await supabase.from('orders').select('id, created_at');
              if (ords) orders = ords;
            } catch (e) {
              console.warn('Could not fetch orders for ranking:', e);
            }

            try {
              const { data: favs } = await supabase.from('favorites').select('beat_id');
              if (favs) favorites = favs;
            } catch (e) {
              console.warn('Could not fetch favorites for ranking:', e);
            }

            // Get local interaction stats from localStorage
            let localPlays: any[] = [];
            let localCartAdds: any[] = [];
            try {
              const storedPlays = localStorage.getItem('beatangola_beat_plays');
              if (storedPlays) localPlays = JSON.parse(storedPlays);
            } catch (e) {}
            try {
              const storedAdds = localStorage.getItem('beatangola_cart_additions');
              if (storedAdds) localCartAdds = JSON.parse(storedAdds);
            } catch (e) {}

            const now = Date.now();
            const orderDateMap = new Map(orders.map(o => [o.id, new Date(o.created_at).getTime()]));

            const mapped = (beatsData || []).map(b => {
                const profileInfo = profileMap.get(b.producer_id);
                let producerName = typeof profileInfo === 'object' && profileInfo !== null ? profileInfo.name : (b.producer_name || b.artist_name || 'Produtor');
                const producerUsername = typeof profileInfo === 'object' && profileInfo !== null ? profileInfo.username : '';
                const producerAvatarUrl = typeof profileInfo === 'object' && profileInfo !== null ? profileInfo.avatar_url : '';
                if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producerName)) {
                  producerName = 'Produtor';
                }

                // 1. Likes/Favorites score: +10 points per favorite
                const beatFavsCount = favorites.filter(f => {
                  const fId = String(f.beat_id);
                  const bId = String(b.id);
                  if (fId === bId) return true;
                  if (fId.startsWith('00000000-0000-0000-0000-')) {
                    const cleaned = fId.split('-')[4].replace(/^0+/, '');
                    return cleaned === bId;
                  }
                  return false;
                }).length;
                const likesScore = beatFavsCount * 10;

                // 2. Sales Score: +30 points per sale. Recent weighting: +20 for last 7d, +10 for last 30d
                const beatSales = orderItems.filter(item => item.beat_id === b.id || item.beat_id === Number(b.id));
                let salesScore = beatSales.length * 30;
                beatSales.forEach(sale => {
                  const ordTime = orderDateMap.get(sale.order_id);
                  if (ordTime) {
                    const ageMs = now - ordTime;
                    if (ageMs <= 7 * 24 * 3600 * 1000) {
                      salesScore += 20;
                    } else if (ageMs <= 30 * 24 * 3600 * 1000) {
                      salesScore += 10;
                    }
                  }
                });

                // 3. Play Score: +5 points for within 7 days, +1 point for older plays
                const beatPlays = localPlays.filter(play => play.id === b.id);
                let playScore = 0;
                beatPlays.forEach(play => {
                  const time = play.playedAt || play.time || 0;
                  if (now - time <= 7 * 24 * 3600 * 1000) {
                    playScore += 5;
                  } else {
                    playScore += 1;
                  }
                });

                // 4. Cart Additions Score: +15 points for within 7 days, +5 points for older additions
                const beatAdds = localCartAdds.filter(add => add.id === b.id);
                let cartScore = 0;
                beatAdds.forEach(add => {
                  const time = add.addedAt || add.time || 0;
                  if (now - time <= 7 * 24 * 3600 * 1000) {
                    cartScore += 15;
                  } else {
                    cartScore += 5;
                  }
                });

                // 5. Upload Recency / Freshness Score:
                let recencyScore = 0;
                const uploadTime = b.created_at ? new Date(b.created_at).getTime() : 0;
                if (uploadTime > 0) {
                  const ageDays = (now - uploadTime) / (24 * 3600 * 1000);
                  if (ageDays <= 3) {
                    recencyScore += 40;
                  } else if (ageDays <= 7) {
                    recencyScore += 25;
                  } else if (ageDays <= 30) {
                    recencyScore += 10;
                  }
                }

                const totalScore = likesScore + salesScore + playScore + cartScore + recencyScore;
                
                let extractedKey = b.key;
                let extractedScale = b.scale;
                if (b.tags && Array.isArray(b.tags)) {
                  const kt = b.tags.find((t: string) => t.startsWith('_key:'));
                  if (kt) extractedKey = kt.split(':')[1];
                  const st = b.tags.find((t: string) => t.startsWith('_scale:'));
                  if (st) extractedScale = st.split(':')[1];
                }
                const cleanTags = b.tags ? b.tags.filter((t: string) => !t.startsWith('_key:') && !t.startsWith('_scale:')) : [];

                return {
                    id: b.id,
                    title: b.title,
                    producer: producerName,
                    producer_name: producerName,
                    producer_id: b.producer_id,
                    producer_username: producerUsername,
                    producer_avatar: producerAvatarUrl || '',
                    genre: b.genre,
                    price: {
                        basic: b.price_basic || 0,
                        premium: b.price_premium || 0,
                        exclusive: b.price_exclusive || 0
                    },
                    is_free_download: b.is_free_download || b.price_basic === 0 || b.price_basic === null || b.price_basic === undefined,
                    demo_url: b.demo_url ? (b.demo_url.startsWith('http') ? b.demo_url : getPublicUrl('beats', b.demo_url)) : '',
                    master_url: b.master_url ? (b.master_url.startsWith('http') ? b.master_url : getPublicUrl('beats', b.master_url)) : '',
                    image: b.cover_url ? (b.cover_url.startsWith('http') ? b.cover_url : getPublicUrl('beats', b.cover_url)) : '',
                    audioUrl: b.master_url ? (b.master_url.startsWith('http') ? b.master_url : getPublicUrl('beats', b.master_url)) : '',
                    bpm: b.bpm || 0,
                    type: b.category && (
                      b.category === 'Drum Kit' || 
                      b.category === 'Loop Kit' || 
                      b.category === 'drum-kit' || 
                      b.category === 'loop-kit' || 
                      b.category === 'sample-pack' || 
                      b.category.toLowerCase().includes('kit') || 
                      b.category.toLowerCase().includes('pack')
                    ) ? 'kit' : (b.type || 'beat'),
                    category: b.category,
                    plays_count: playService.getPlayCount(b.id, b.plays_count || 0),
                    created_at: b.created_at,
                    score: totalScore,
                    key: extractedKey || 'C',
                    scale: extractedScale || 'Maior',
                    tags: cleanTags,
                    featured: b.featured || false
                };
            });
            setBeatsData(mapped);
        }
      } catch (err) {
        console.error("AllBeatsPage: Failed to load catalog beats elegantly:", err);
      }
    }
    loadBeats();
  }, []);

  const allItems = useMemo(() => beatsData, [beatsData]);

  const filteredBeats = useMemo(() => {
    return allItems
      .filter(item => {
        // Search criteria using debounced query
        const matchesSearch = debouncedSearchQuery === '' || 
          item.title.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) || 
          item.producer.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) || 
          (item.genre && item.genre.toLowerCase().includes(debouncedSearchQuery.toLowerCase())) ||
          ((item as any).tags && (item as any).tags.some((t: string) => t.toLowerCase().includes(debouncedSearchQuery.toLowerCase())));
        
        // Genre criteria
        const matchesGenre = selectedGenre === null || (() => {
          if (!item.genre) return false;
          const ig = item.genre.toLowerCase().replace(/[^a-z0-9]/g, '');
          const sg = selectedGenre.toLowerCase().replace(/[^a-z0-9]/g, '');
          return ig === sg || item.genre.toLowerCase() === selectedGenre.toLowerCase();
        })();

        // Price criteria
        const matchesPrice = item.price.basic <= priceRange[1] && item.price.basic >= priceRange[0];

        // Key, Scale and BPM criteria (beats only, bypassed for kits)
        const isKit = item.type === 'kit' || (item.category && item.category.toLowerCase().includes('kit'));
        const matchesBpm = isKit ? true : (item.bpm <= bpmRange[1] && item.bpm >= bpmRange[0]);
        const matchesKey = isKit ? true : (selectedKey === null || item.key === selectedKey);
        const matchesScale = isKit ? true : (selectedScale === null || item.scale === selectedScale);

        // Discovery options criteria
        const matchesFreeDownload = !isFreeDownloadOnly || item.is_free_download;
        const matchesFeatured = !isFeaturedOnly || item.featured;

        // Tab criteria
        const matchesTab = 
          (activeTab === 'Beats' || activeTab === '🎵 Beats') ? (item.type === 'beat' || !item.type) :
          (activeTab === 'Drum Kits' || activeTab === 'Loop Kits' || activeTab === '🥁 Kits' || activeTab === 'Kits') ? (item.type === 'kit') :
          false;

        return matchesSearch && matchesGenre && matchesPrice && matchesBpm && matchesKey && matchesScale && matchesFreeDownload && matchesFeatured && matchesTab;
      })
      .sort((a, b) => {
        if (sortBy === 'price_low') return a.price.basic - b.price.basic;
        if (sortBy === 'price_high') return b.price.basic - a.price.basic;
        if (sortBy === 'popular' || sortBy === 'trending') {
          return (b.score || 0) - (a.score || 0);
        }
        if (sortBy === 'newest') {
          const timeA = a.created_at ? new Date(a.created_at).getTime() : 0;
          const timeB = b.created_at ? new Date(b.created_at).getTime() : 0;
          return timeB - timeA;
        }
        return 0;
      });
  }, [debouncedSearchQuery, selectedGenre, sortBy, priceRange, bpmRange, selectedKey, selectedScale, isFreeDownloadOnly, isFeaturedOnly, activeTab, allItems]);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearchQuery, selectedGenre, sortBy, priceRange, bpmRange, selectedKey, selectedScale, isFreeDownloadOnly, isFeaturedOnly, activeTab]);

  const visibleBeats = useMemo(() => {
    return filteredBeats.slice(0, page * itemsPerPage);
  }, [filteredBeats, page]);

  const filteredProducers = useMemo(() => {
    if (!producers) return [];
    const baseProducers = !debouncedSearchQuery 
      ? producers 
      : producers.filter(p => 
          p.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase().trim()) || 
          (p.username && p.username.toLowerCase().includes(debouncedSearchQuery.toLowerCase().trim())) ||
          (p.location && p.location.toLowerCase().includes(debouncedSearchQuery.toLowerCase().trim()))
        );

    // Sort producers strictly by totalBeats DESC, then score DESC
    return [...baseProducers].sort((a, b) => {
      const aBeats = a.totalBeats || (a as any).total_beats || 0;
      const bBeats = b.totalBeats || (b as any).total_beats || 0;
      if (bBeats !== aBeats) {
        return bBeats - aBeats;
      }
      return (b.score || 0) - (a.score || 0);
    });
  }, [producers, debouncedSearchQuery]);

  const visibleProducers = useMemo(() => {
    return filteredProducers.slice(0, page * itemsPerPage);
  }, [filteredProducers, page]);

  const filteredPlaylists = useMemo(() => {
    if (!playlists) return [];
    if (!debouncedSearchQuery) return playlists;
    const query = debouncedSearchQuery.toLowerCase().trim();
    return playlists.filter(pl => 
      pl.title.toLowerCase().includes(query) || 
      (pl.description && pl.description.toLowerCase().includes(query))
    );
  }, [playlists, debouncedSearchQuery]);

  const visiblePlaylists = useMemo(() => {
    return filteredPlaylists.slice(0, page * itemsPerPage);
  }, [filteredPlaylists, page]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        let totalItems = filteredBeats.length;
        if (activeTab === '👑 Produtores' || activeTab === 'Produtores') {
          totalItems = filteredProducers.length;
        } else if (activeTab === '💿 Playlists' || activeTab === 'Playlists') {
          totalItems = filteredPlaylists.length;
        }
        if (entries[0].isIntersecting && page * itemsPerPage < totalItems) {
          setPage(prev => prev + 1);
        }
      },
      { threshold: 0.1, rootMargin: '200px' }
    );

    if (loaderRef.current) {
      observer.observe(loaderRef.current);
    }

    return () => observer.disconnect();
  }, [filteredBeats.length, filteredProducers.length, filteredPlaylists.length, page, activeTab]);

  const isProducerTab = activeTab === '👑 Produtores' || activeTab === 'Produtores';
  const isPlaylistTab = activeTab === '💿 Playlists' || activeTab === 'Playlists';

  return (
    <div className="min-h-screen bg-[#000000] pb-32">
      {/* Premium Header Section */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-amber-500/10 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          {!user && (
            <motion.button 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={onBack} 
              className="group flex items-center gap-2 text-gray-500 hover:text-white transition-colors mb-10 mb-8"
            >
              <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-black transition-all">
                <ArrowLeft size={16} />
              </div>
              <span className="text-xs font-black uppercase tracking-widest italic group-hover:translate-x-1 transition-transform">Voltar ao Início</span>
            </motion.button>
          )}

          <div className="max-w-4xl">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-8xl font-black text-white italic uppercase tracking-tighter leading-none mb-6"
            >
              Explorar <span className="text-amber-500">Marketplace</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-gray-400 text-base md:text-xl font-medium uppercase tracking-widest opacity-60 mb-12"
            >
              Descubra beats, produtores e kits incríveis da maior plataforma de Angola.
            </motion.p>
          </div>

          {/* Advanced Search Bar with Form-Submit Interaction */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="relative max-w-3xl group"
          >
            <div className="absolute inset-0 bg-amber-500/10 blur-2xl opacity-0 group-focus-within:opacity-100 transition-opacity animate-pulse" />
            <form onSubmit={(e) => { e.preventDefault(); addToSearchHistory(searchQuery); }} className="relative flex items-center bg-[#0d0d12]/60 border border-white/10 p-1.5 md:p-2 rounded-[2rem] md:rounded-[2.5rem] backdrop-blur-2xl group-focus-within:border-amber-500/50 transition-all shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
              <div className="pl-4 md:pl-6 pr-2 md:pr-4 text-gray-500 group-focus-within:text-amber-500 transition-colors">
                <Search className="w-5 h-5 md:w-6 md:h-6" />
              </div>
              <input 
                type="text" 
                placeholder="Pesquisar beats, produtores ou kits..." 
                className="w-full bg-transparent border-none outline-none text-white font-bold py-3 md:py-4 text-sm md:text-lg placeholder-gray-600 focus:ring-0"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button type="submit" className="bg-amber-500 text-black px-5 md:px-8 py-3 md:py-4 rounded-[1.5rem] md:rounded-[2rem] font-black uppercase tracking-widest text-[10px] md:text-sm hover:bg-amber-400 transition-all shadow-lg shadow-amber-500/20 active:scale-95">
                Procurar
              </button>
            </form>
          </motion.div>

          {/* Search History & Trending Suggs */}
          <div className="mt-8 space-y-4 max-w-3xl">
            {searchHistory.length > 0 && (
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest mr-1">Histórico:</span>
                {searchHistory.map((hist) => (
                  <div key={hist} className="flex items-center gap-1.5 pl-3 pr-2 py-1 rounded-full bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:border-white/20 transition-all">
                    <button 
                      type="button"
                      onClick={() => setSearchQuery(hist)}
                      className="text-[10px] font-bold uppercase tracking-widest text-left"
                    >
                      {hist}
                    </button>
                    <button 
                      type="button" 
                      onClick={() => removeFromSearchHistory(hist)}
                      className="text-gray-500 hover:text-red-400 p-0.5 rounded-full transition-colors"
                    >
                      <X size={10} />
                    </button>
                  </div>
                ))}
                <button 
                  onClick={clearSearchHistory}
                  className="text-amber-500/80 hover:text-amber-500 text-[9px] font-black uppercase tracking-widest transition-colors hover:underline ml-1"
                >
                  Limpar
                </button>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest mr-1">Destaques:</span>
              {[
                { label: '🔥 Trap Angola', val: 'Trap' },
                { label: '🔥 Afro House', val: 'Afro House' },
                { label: '🔥 Drill', val: 'Drill' },
                { label: '🔥 Loops', val: 'Loop' },
                { label: '🔥 R&B', val: 'R&B' }
              ].map((tag) => (
                <button 
                  key={tag.label}
                  onClick={() => {
                    setSearchQuery(tag.val);
                    addToSearchHistory(tag.val);
                  }}
                  className="px-3.5 py-1.5 rounded-full bg-[#111116] border border-white/5 text-[#888894] hover:text-white hover:border-amber-500/40 text-[10px] font-bold uppercase tracking-widest transition-all shadow-sm"
                >
                  {tag.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Sections */}
      <section className="max-w-7xl mx-auto px-6">
        {/* Category Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-6 mb-12 border-b border-white/5 animate-fade-in">
          <div className="flex gap-8">
            {categories.map((cat) => {
              const renderIcon = () => {
                switch(cat) {
                  case 'Beats':
                    return <Music size={14} />;
                  case 'Produtores':
                    return <Users size={14} />;
                  case 'Kits':
                    return <Disc size={14} />;
                  case 'Playlists':
                    return <ListMusic size={14} />;
                  default:
                    return null;
                }
              };

              return (
                <button 
                  key={cat}
                  onClick={() => setActiveTab(cat)}
                  className={`relative pb-6 text-sm font-black uppercase tracking-[0.2em] transition-all flex items-center gap-2.5 ${activeTab === cat ? 'text-white' : 'text-gray-600 hover:text-gray-400'}`}
                >
                  {renderIcon()}
                  <span>{cat}</span>
                  {activeTab === cat && (
                    <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-1 bg-amber-500 rounded-full" />
                  )}
                </button>
              );
            })}
          </div>

          {!isProducerTab && !isPlaylistTab && (
            <div className="flex items-center gap-4 pb-6">
              <div className="hidden md:flex items-center gap-2 bg-white/5 rounded-xl border border-white/10 p-1">
                {sortOptions.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setSortBy(opt.value)}
                    title={opt.label}
                    className={`p-2 rounded-lg transition-all ${sortBy === opt.value ? 'bg-amber-500 text-black' : 'text-gray-500 hover:text-white'}`}
                  >
                    <opt.icon size={16} />
                  </button>
                ))}
              </div>
              
              <button 
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl border transition-all font-black uppercase tracking-widest text-[10px] ${isFilterOpen ? 'bg-amber-500 border-amber-500 text-black' : 'bg-white/5 border-white/10 text-white'}`}
              >
                <SlidersHorizontal size={14} />
                {isFilterOpen ? 'Fechar Filtros' : 'Filtros'}
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-col lg:flex-row gap-12 items-start">
          {/* Filters Sidebar - Desktop */}
          {!isProducerTab && !isPlaylistTab && isFilterOpen && (
            <div className="hidden lg:block w-72 space-y-10 sticky top-24">
              <FiltersContent 
                selectedGenre={selectedGenre}
                setSelectedGenre={setSelectedGenre}
                genres={genres}
                bpmRange={bpmRange}
                setBpmRange={setBpmRange}
                priceRange={priceRange}
                setPriceRange={setPriceRange}
                selectedKey={selectedKey}
                setSelectedKey={setSelectedKey}
                selectedScale={selectedScale}
                setSelectedScale={setSelectedScale}
                isFreeDownloadOnly={isFreeDownloadOnly}
                setIsFreeDownloadOnly={setIsFreeDownloadOnly}
                isFeaturedOnly={isFeaturedOnly}
                setIsFeaturedOnly={setIsFeaturedOnly}
                activeTab={activeTab}
              />
            </div>
          )}

          {/* Mobile Filter Drawer */}
          <AnimatePresence>
            {!isProducerTab && !isPlaylistTab && isFilterOpen && (
              <div className="lg:hidden">
                {/* Backdrop */}
                <motion.div 
                   initial={{ opacity: 0 }}
                   animate={{ opacity: 1 }}
                   exit={{ opacity: 0 }}
                   onClick={() => setIsFilterOpen(false)}
                   className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm"
                />
                {/* Drawer */}
                <motion.div 
                  initial={{ y: '100%' }}
                  animate={{ y: 0 }}
                  exit={{ y: '100%' }}
                  transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                  className="fixed bottom-0 left-0 right-0 z-[120] bg-[#0B0B0B] border-t border-white/5 rounded-t-[3rem] p-8 pb-12 max-h-[85vh] overflow-y-auto shadow-[0_-20px_50px_rgba(0,0,0,0.5)]"
                >
                  <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/5">
                     <div className="flex items-center gap-3">
                       <SlidersHorizontal size={20} className="text-amber-500" />
                       <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter">Filtros</h2>
                     </div>
                     <button 
                       onClick={() => setIsFilterOpen(false)}
                       className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white"
                     >
                        <X size={20} />
                     </button>
                  </div>
                  
                  <div className="mb-8">
                    <FiltersContent 
                      selectedGenre={selectedGenre}
                      setSelectedGenre={setSelectedGenre}
                      genres={genres}
                      bpmRange={bpmRange}
                      setBpmRange={setBpmRange}
                      priceRange={priceRange}
                      setPriceRange={setPriceRange}
                      selectedKey={selectedKey}
                      setSelectedKey={setSelectedKey}
                      selectedScale={selectedScale}
                      setSelectedScale={setSelectedScale}
                      isFreeDownloadOnly={isFreeDownloadOnly}
                      setIsFreeDownloadOnly={setIsFreeDownloadOnly}
                      isFeaturedOnly={isFeaturedOnly}
                      setIsFeaturedOnly={setIsFeaturedOnly}
                      activeTab={activeTab}
                    />
                  </div>

                  <button 
                    onClick={() => setIsFilterOpen(false)}
                    className="w-full py-5 bg-amber-500 text-black font-black uppercase tracking-widest text-xs rounded-2xl shadow-xl shadow-amber-500/20 active:scale-95 transition-all"
                  >
                    Aplicar Filtros
                  </button>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* Results Grid Area */}
          <div className="flex-grow space-y-12 w-full">
            {/* Active Filters Display */}
            {isProducerTab || isPlaylistTab ? (
              searchQuery && (
                <div className="flex flex-wrap gap-2 items-center">
                  <span className="text-[10px] font-black text-gray-600 uppercase tracking-widest mr-2">Filtros Ativos:</span>
                  <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest border border-white/10">
                    Busca: {searchQuery}
                    <X size={12} className="cursor-pointer" onClick={() => setSearchQuery('')} />
                  </span>
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="text-amber-500 text-[10px] font-black uppercase tracking-widest ml-2 hover:underline"
                  >
                    Limpar
                  </button>
                </div>
              )
            ) : (
              (selectedGenre || searchQuery || priceRange[1] < 500000 || selectedKey || selectedScale || isFreeDownloadOnly || isFeaturedOnly) && (
                <div className="flex flex-wrap gap-2 items-center">
                  <span className="text-[10px] font-black text-gray-600 uppercase tracking-widest mr-2">Filtros Ativos:</span>
                  {selectedGenre && (
                    <span className="flex items-center gap-2 bg-amber-500 px-3 py-1 rounded-full text-black text-[10px] font-black uppercase tracking-widest">
                      {selectedGenre}
                      <X size={12} className="cursor-pointer" onClick={() => setSelectedGenre(null)} />
                    </span>
                  )}
                  {searchQuery && (
                    <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest border border-white/10">
                      Busca: {searchQuery}
                      <X size={12} className="cursor-pointer" onClick={() => setSearchQuery('')} />
                    </span>
                  )}
                  {priceRange[1] < 500000 && (
                    <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest border border-white/10">
                      Até {priceRange[1].toLocaleString()} Kz
                      <X size={12} className="cursor-pointer" onClick={() => setPriceRange([0, 500000])} />
                    </span>
                  )}
                  {selectedKey && (
                    <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest border border-white/10">
                      Tom: {selectedKey}
                      <X size={12} className="cursor-pointer" onClick={() => setSelectedKey(null)} />
                    </span>
                  )}
                  {selectedScale && (
                    <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest border border-white/10">
                      Escala: {selectedScale}
                      <X size={12} className="cursor-pointer" onClick={() => setSelectedScale(null)} />
                    </span>
                  )}
                  {isFreeDownloadOnly && (
                    <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest border border-white/10">
                      Grátis
                      <X size={12} className="cursor-pointer" onClick={() => setIsFreeDownloadOnly(false)} />
                    </span>
                  )}
                  {isFeaturedOnly && (
                    <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest border border-white/10">
                      Em Destaque
                      <X size={12} className="cursor-pointer" onClick={() => setIsFeaturedOnly(false)} />
                    </span>
                  )}
                  <button 
                    onClick={() => {
                      setSelectedGenre(null);
                      setSearchQuery('');
                      setPriceRange([0, 500000]);
                      setBpmRange([80, 200]);
                      setSelectedKey(null);
                      setSelectedScale(null);
                      setIsFreeDownloadOnly(false);
                      setIsFeaturedOnly(false);
                    }}
                    className="text-amber-500 text-[10px] font-black uppercase tracking-widest ml-2 hover:underline"
                  >
                    Limpar Todos
                  </button>
                </div>
              )
            )}

            {/* Results Grid */}
            {isProducerTab ? (
              visibleProducers.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {visibleProducers.map((producer, i) => {
                    const hasCustomAvatar = producer.avatar && 
                      !producer.avatar.includes('photo-1516280440614-37939bbacd81') && 
                      !producer.avatar.includes('placeholder') && 
                      !producer.avatar.includes('default');
                    const initials = producer.name
                      ? producer.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
                      : 'P';
                    return (
                      <motion.div
                        key={producer.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: (i % 12) * 0.04 }}
                        whileHover={{ y: -4 }}
                        onClick={() => onSelectProducer(producer.username || producer.name)}
                        className="bg-[#0c0c12]/80 border border-white/[0.04] rounded-2xl p-5 text-center flex flex-col justify-between items-center hover:bg-[#12121a] hover:border-white/[0.08] transition-all duration-150 cursor-pointer group min-h-[260px]"
                      >
                        <div className="relative w-20 h-20 mx-auto rounded-full overflow-hidden border border-white/[0.06] bg-[#070709] shrink-0">
                          {hasCustomAvatar ? (
                            <img 
                              src={producer.avatar} 
                              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" 
                              referrerPolicy="no-referrer" 
                              alt={producer.name}
                            />
                          ) : (
                            <div className="w-full h-full bg-neutral-900 flex items-center justify-center text-gray-400 font-bold text-sm uppercase">
                              {initials}
                            </div>
                          )}
                        </div>

                        <div className="flex-grow flex flex-col justify-center w-full mt-3">
                          <div className="flex items-center gap-1 justify-center w-full px-1">
                            <h4 className="text-white font-extrabold text-sm truncate leading-tight group-hover:text-[#5865F2] transition-colors">{producer.name}</h4>
                            {(producer.isVerified || (producer as any).is_verified) && (
                              <VerifiedBadge size="sm" />
                            )}
                          </div>
                          {producer.username ? (
                            <p className="text-[10px] text-gray-500 font-medium lowercase tracking-tight mt-0.5 truncate w-full px-1">@{producer.username}</p>
                          ) : (
                            <div className="h-4" />
                          )}
                          <div className="flex flex-col items-center justify-center gap-0.5 mt-2.5">
                            <p className="text-gray-400 text-[10px] font-bold uppercase tracking-wider">
                              {producer.totalBeats} {producer.totalBeats === 1 ? 'Beat' : 'Beats'}
                            </p>
                            <p className="text-emerald-400 text-[9px] font-bold uppercase tracking-wider mt-0.5">
                              {producer.totalPlays || 0} plays reais
                            </p>
                          </div>
                        </div>

                        <button className="w-full py-1.5 rounded bg-white/5 border border-white/10 text-white text-[10px] font-bold uppercase tracking-wider hover:bg-[#5865F2] hover:border-[#5865F2] transition-all mt-4 cursor-pointer">Ver Perfil</button>
                      </motion.div>
                    );
                  })}
                </div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center py-20 text-center space-y-6 bg-white/[0.02] rounded-[3rem] border border-white/5 w-full"
                >
                  <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center text-gray-600 mb-4 scale-150 opacity-20 animate-pulse">
                    <Search size={48} />
                  </div>
                  <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">
                    Nenhum produtor encontrado
                  </h3>
                  <p className="text-gray-500 font-semibold max-w-sm">Tente ajustar a sua pesquisa para encontrar o produtor que procura.</p>
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="bg-amber-500 text-black px-8 py-3 rounded-full font-black uppercase tracking-widest text-[10px] hover:bg-amber-400 transition-all shadow-lg active:scale-95"
                  >
                    Limpar Pesquisa
                  </button>
                </motion.div>
              )
            ) : isPlaylistTab ? (
              visiblePlaylists.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 w-full">
                  {visiblePlaylists.map((playlist, i) => (
                    <motion.div
                      key={playlist.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: (i % 12) * 0.05 }}
                      whileHover={{ y: -8, scale: 1.02 }}
                      onClick={() => onSelectPlaylist && onSelectPlaylist(playlist.id)}
                      className="bg-[#0b0b0f]/60 border border-white/[0.06] backdrop-blur-md rounded-[2rem] p-5 hover:border-amber-500/50 hover:shadow-[0_0_30px_rgba(245,158,11,0.1)] transition-all duration-300 cursor-pointer group flex flex-col justify-between min-h-[280px]"
                    >
                      <div className="relative w-full aspect-square bg-[#111116] rounded-xl overflow-hidden mb-4 border border-white/5 flex items-center justify-center">
                        {playlist.cover_image ? (
                          <img src={playlist.cover_image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={playlist.title} />
                        ) : (
                          <div className="flex flex-col items-center justify-center text-gray-600 gap-2">
                            <Music size={40} className="opacity-40" />
                            <span className="text-[9px] font-black uppercase tracking-widest italic opacity-40">Batukada Playlist</span>
                          </div>
                        )}
                        <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm px-2.5 py-1 rounded-full text-white text-[9px] font-black uppercase tracking-widest italic border border-white/5">
                          {playlist.beat_ids?.length || 0} ritmos
                        </div>
                      </div>
                      <div className="flex-grow space-y-1">
                        <h4 className="text-white font-black text-sm uppercase tracking-widest italic truncate group-hover:text-amber-500 transition-colors">{playlist.title}</h4>
                        <p className="text-[10px] text-gray-500 line-clamp-2 md:line-clamp-3 leading-relaxed font-bold mt-1 mb-2">{playlist.description || 'Uma curadoria especial de ritmos de Angola.'}</p>
                      </div>
                      <button className="w-full py-2.5 rounded-xl bg-amber-500 text-black text-[10px] font-black uppercase tracking-widest hover:bg-amber-400 transition-all shadow-md shadow-amber-500/10 mt-2">Ouvir Playlist</button>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center py-20 text-center space-y-6 bg-white/[0.02] rounded-[3rem] border border-white/5 w-full"
                >
                  <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center text-gray-600 mb-4 scale-150 opacity-20 animate-pulse">
                    <Music size={48} />
                  </div>
                  <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">
                    Nenhuma playlist encontrada
                  </h3>
                  <p className="text-gray-500 font-semibold max-w-sm">Tente redefinir a sua pesquisa para descobrir novas playlists.</p>
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="bg-amber-500 text-black px-8 py-3 rounded-full font-black uppercase tracking-widest text-[10px] hover:bg-amber-400 transition-all shadow-lg active:scale-95"
                  >
                    Limpar Pesquisa
                  </button>
                </motion.div>
              )
            ) : (
              visibleBeats.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {visibleBeats.map((beat, i) => (
                    <motion.div
                      key={beat.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: (i % 12) * 0.05 }}
                    >
                      {beat.type === 'kit' ? (
                        <MarketplaceKitCard 
                          kit={beat}
                          onAddToCart={addToCart}
                          onSelectProducer={onSelectProducer}
                          onSelectBeat={onSelectBeat}
                        />
                      ) : (
                        <BeatCard 
                          beat={beat}
                          isPlaying={currentBeat?.id === beat.id && isPlaying}
                          onPlay={handlePlay}
                          onAddToCart={addToCart}
                          onSelectProducer={onSelectProducer}
                          onSelectBeat={onSelectBeat}
                        />
                      )}
                    </motion.div>
                  ))}
                </div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center py-20 text-center space-y-6 bg-white/[0.02] rounded-[3rem] border border-white/5 w-full"
                >
                  <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center text-gray-600 mb-4 scale-150 opacity-20 animate-pulse">
                    <Search size={48} />
                  </div>
                  <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">
                    {selectedGenre ? "Nenhum ritmo encontrado neste género" : "Nenhum resultado encontrado"}
                  </h3>
                  <p className="text-gray-500 font-medium max-w-sm">Tente ajustar os seus filtros ou a sua pesquisa para encontrar o que procura.</p>
                  <button 
                    onClick={() => {
                      setSelectedGenre(null);
                      setSearchQuery('');
                      setPriceRange([0, 500000]);
                      setBpmRange([80, 200]);
                      setSelectedKey(null);
                      setSelectedScale(null);
                      setIsFreeDownloadOnly(false);
                      setIsFeaturedOnly(false);
                    }}
                    className="bg-amber-500 text-black px-8 py-3 rounded-full font-black uppercase tracking-widest text-[10px] hover:bg-amber-400 transition-all shadow-lg active:scale-95"
                  >
                    Reiniciar Pesquisa
                  </button>
                </motion.div>
              )
            )}

            {/* Intersection Observer Target */}
            {page * itemsPerPage < (isProducerTab ? filteredProducers.length : isPlaylistTab ? filteredPlaylists.length : filteredBeats.length) && (
              <div ref={loaderRef} className="flex justify-center py-20">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                  className="text-amber-500"
                >
                  <Loader2 size={32} />
                </motion.div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Recommended Producers Section */}
      <section className="max-w-7xl mx-auto px-6 py-32 border-t border-white/5 mt-20">
        <div className="flex items-center justify-between mb-12">
          {(() => {
            console.log("DEBUG: producers in AllBeatsPage:", producers?.length, producers);
            return null;
          })()}
          <div className="space-y-2">
            <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">Produtores <span className="text-blue-500">Destaque</span></h2>
            <p className="text-gray-500 text-xs font-black uppercase tracking-widest italic opacity-60">Os talentos mais quentes em Angola.</p>
          </div>
          {producers && producers.length > 0 && (
            <button className="text-blue-500 text-xs font-black uppercase tracking-widest hover:underline">Ver Todos</button>
          )}
        </div>

        {(!producers || producers.length === 0) ? (
          <div className="text-center py-20 bg-gradient-to-b from-white/[0.02] to-transparent border border-white/[0.05] rounded-[2.5rem] p-8 max-w-xl mx-auto space-y-6">
            <div className="w-16 h-16 rounded-full bg-white/[0.02] border border-white/[0.06] flex items-center justify-center text-gray-500 mx-auto animate-pulse">
              <Music size={24} className="text-[#5865F2]" />
            </div>
            <div className="space-y-2">
              <h3 className="text-white font-black uppercase text-sm tracking-wider">Nenhum produtor disponível</h3>
              <p className="text-gray-400 text-xs max-w-md mx-auto leading-relaxed font-semibold">
                De momento todos os produtores em destaque estão ativos em lançamentos diretos ou preparando novidades. Crie uma conta de produtor para ser o primeiro!
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-x-8 gap-y-12">
            {producers.slice(0, 5).map((producer) => {
              const hasCustomAvatar = producer.avatar && 
                !producer.avatar.includes('photo-1516280440614-37939bbacd81') && 
                !producer.avatar.includes('placeholder') && 
                !producer.avatar.includes('default');
              const initials = producer.name
                ? producer.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
                : 'P';

              return (
                <motion.div 
                  key={producer.id}
                  onClick={() => onSelectProducer(producer.username || producer.name)}
                  className="bg-transparent border-0 p-0 text-center flex flex-col items-center group cursor-pointer select-none transition-all duration-300 w-full"
                >
                  {/* High end larger round avatar with modern ring and hover effects */}
                  <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full mb-4 transition-all duration-300 ring-2 ring-white/5 lg:group-hover:ring-white/20 group-hover:scale-105 group-hover:shadow-[0_0_25px_rgba(255,255,255,0.08)] bg-[#0c0c0e] overflow-hidden">
                    {hasCustomAvatar ? (
                      <img 
                        src={producer.avatar} 
                        className="w-full h-full object-cover transition-transform duration-500 ease-out" 
                        referrerPolicy="no-referrer" 
                        alt={producer.name}
                      />
                    ) : (
                      <div className="w-full h-full bg-[#121214] flex items-center justify-center text-gray-400 font-bold text-lg uppercase font-mono select-none">
                        {initials}
                      </div>
                    )}
                  </div>

                  {/* Info Container with same-line Verified Badge */}
                  <div className="flex flex-col items-center w-full max-w-[150px]">
                    <div className="flex items-center gap-1 justify-center max-w-full">
                      <h4 className="text-sm sm:text-base font-extrabold text-white truncate text-center select-all uppercase italic tracking-tighter">{producer.name}</h4>
                      {(producer.isVerified || (producer as any).is_verified) && (
                        <div className="shrink-0">
                          <VerifiedBadge size="sm" />
                        </div>
                      )}
                    </div>
                    {producer.username && (
                      <p className="text-[11px] text-gray-500 text-center font-medium lowercase tracking-tight mt-0.5">
                        @{producer.username}
                      </p>
                    )}
                    
                    {/* Discrete stats and location - BeatStars style */}
                    <div className="flex flex-col items-center justify-center gap-0.5 mt-2.5 text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                      <span className="bg-white/[0.03] border border-white/5 px-2 py-0.5 rounded-full font-mono">
                        {producer.totalBeats || 0} BEATS
                      </span>
                      {Number(producer.totalPlays || 0) > 0 && (
                        <span className="text-blue-400 text-[9px] font-black uppercase tracking-widest mt-1">
                          {producer.totalPlays} Plays
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
