import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Music, Sparkles } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  description: string;
  count: string;
  color: string;
  imageUrl: string;
  isFeatured?: boolean;
}

const categories: Category[] = [
  {
    id: 'kizomba',
    name: 'Kizomba',
    description: 'Batidas sensuais e ritmos envolventes de Kizomba.',
    count: '',
    color: 'from-orange-600/40 to-red-600/40',
    imageUrl: 'https://i.ibb.co/508mhj3/20260524-131508.jpg',
    isFeatured: true,
  },
  {
    id: 'trap',
    name: 'Trap',
    description: '808s pesados e hi-hats rápidos para o teu próximo hit.',
    count: '',
    color: 'from-blue-600/40 to-purple-600/40',
    imageUrl: 'https://i.ibb.co/qQhcSf3/20260524-131403.jpg',
  },
  {
    id: 'drill',
    name: 'Drill',
    description: 'Desliza nos kicks com a energia brutal do Drill moderno.',
    count: '',
    color: 'from-zinc-700/40 to-stone-800/40',
    imageUrl: 'https://i.ibb.co/wZnPQTdt/20260524-131440.jpg',
  },
  {
    id: 'kuduro',
    name: 'Kuduro',
    description: 'Ritmos enérgicos e batidas frenéticas de Angola.',
    count: '',
    color: 'from-orange-600/40 to-yellow-600/40',
    imageUrl: 'https://images.unsplash.com/photo-1549490349-8643362247b5?w=800&auto=format&fit=crop',
  },
  {
    id: 'rb',
    name: 'R&B',
    description: 'Vibes suaves e melódicas para sons mais íntimos e vocais.',
    count: '',
    color: 'from-pink-600/40 to-purple-800/40',
    imageUrl: 'https://i.ibb.co/3yNLQnqY/20260520-174507.png',
  },
  {
    id: 'kompa',
    name: 'Kompa',
    description: 'Grooves suaves, cadenciados e dançantes das Caraíbas.',
    count: '',
    color: 'from-red-500/40 to-yellow-600/40',
    imageUrl: 'https://i.ibb.co/DDdzBxVL/20260520-174540.png',
  },
];

const CategoryCard = ({ category, onSelect }: { key?: string | number; category: Category; onSelect: (id: string) => void }) => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const img = new Image();
    img.src = category.imageUrl;
    img.onload = () => setIsLoaded(true);
  }, [category.imageUrl]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -6 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className="group relative overflow-hidden rounded-xl cursor-pointer aspect-square bg-[#0c0c12]/80 border border-white/5 hover:border-white/20 transition-all duration-200"
      onClick={() => onSelect(category.id)}
    >
      {/* Background Image with Zoom & Lazy Loading */}
      <div className="absolute inset-0 z-0 overflow-hidden bg-neutral-950">
        {/* Sensation Back-Gradient Placeholder */}
        <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-20 transition-opacity duration-300 ${isLoaded ? 'opacity-5' : 'opacity-20'}`} />

        <img 
          src={category.imageUrl || undefined} 
          alt={category.name} 
          loading="eager"
          decoding="async"
          onLoad={() => setIsLoaded(true)}
          className={`w-full h-full object-cover transition-all duration-300 ease-out group-hover:scale-105 ${
            isLoaded ? 'opacity-70 scale-100' : 'opacity-0 scale-105'
          }`}
        />
        {/* Subtle Dark Gradient Overlay */}
        <div className="absolute inset-0 bg-black/50 group-hover:bg-black/35 transition-colors duration-200" />
      </div>

      {/* Content - Bottom-aligned, clean layout */}
      <div className="relative z-10 h-full w-full flex flex-col justify-end p-4 text-left">
        <h3 className="text-white font-bold text-base sm:text-lg transition-colors drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
          {category.name}
        </h3>
      </div>
    </motion.div>
  );
};

export default function MusicCategories({ onSelectCategory }: { onSelectCategory: (id: string) => void }) {
  return (
    <section className="relative py-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header - Left-aligned modern BeatStars layout */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-white/[0.04]">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-gray-400">
              <Sparkles size={11} />
              <span className="text-[10px] font-bold uppercase tracking-wider">Coleções</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-black tracking-tight text-white">
              Explorar por Género
            </h2>
          </div>
          <p className="text-gray-400 text-xs max-w-sm mt-2 md:mt-0 font-medium leading-relaxed">
            Navega pela nossa biblioteca e encontra a sonoridade perfeita no ritmo ideal para o teu som.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <CategoryCard 
              key={category.id} 
              category={category} 
              onSelect={onSelectCategory} 
            />
          ))}
        </div>
      </div>
    </section>
  );
}
