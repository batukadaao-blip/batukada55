import React, { useState, useEffect } from 'react';
import { playlistStore, Playlist } from '../lib/playlistStore';
import { Beat } from '../types';
import { 
  Play, 
  Pause, 
  Disc, 
  ArrowLeft, 
  Trash2, 
  Calendar, 
  Music, 
  ShoppingCart, 
  Share2, 
  Globe, 
  Lock, 
  Clock, 
  Edit, 
  ArrowUp, 
  ArrowDown, 
  TrendingUp, 
  Heart, 
  BarChart4, 
  Check, 
  X,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PlaylistSkeleton } from './SkeletonLoader';

interface PlaylistDetailsPageProps {
  playlistId: string;
  beats: Beat[];
  onBack: () => void;
  onPlay: (beat: Beat) => void;
  isPlaying: boolean;
  currentBeat: Beat | null;
  onAddToCart?: (beat: Beat) => void;
}

export default function PlaylistDetailsPage({
  playlistId,
  beats,
  onBack,
  onPlay,
  isPlaying,
  currentBeat,
  onAddToCart
}: PlaylistDetailsPageProps) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [loading, setLoading] = useState(true);

  // Edit State
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editIsPublic, setEditIsPublic] = useState(true);
  const [editCoverImage, setEditCoverImage] = useState('');

  useEffect(() => {
    loadPlaylist();
    // Re-load when elements change inside modal
    window.addEventListener('playlistUpdated', loadPlaylist);
    return () => window.removeEventListener('playlistUpdated', loadPlaylist);
  }, [playlistId, user]);

  const loadPlaylist = async () => {
    setLoading(true);
    try {
      const searchUserId = user?.id || 'guest-visitor';
      const data = await playlistStore.fetchPlaylists(searchUserId);
      const matched = data.find(p => String(p.id) === String(playlistId));
      if (matched) {
        setPlaylist(matched);
        setEditTitle(matched.title);
        setEditDescription(matched.description || '');
        setEditIsPublic(matched.is_public);
        setEditCoverImage(matched.cover_image || '');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!playlist || !editTitle.trim()) return;

    try {
      const success = await playlistStore.updatePlaylist(
        playlist.id,
        editTitle.trim(),
        editDescription.trim(),
        editIsPublic,
        editCoverImage.trim()
      );

      if (success) {
        showToast('Playlist atualizada com sucesso!', 'success', 'Atualizado');
        setIsEditing(false);
        loadPlaylist();
        window.dispatchEvent(new CustomEvent('playlistUpdated'));
      } else {
        showToast('Ocorreu um erro ao atualizar a playlist.', 'error');
      }
    } catch (err) {
      showToast('Ocorreu um erro ao atualizar.', 'error');
    }
  };

  const handleRemoveBeat = async (beatId: string | number) => {
    if (!playlist) return;
    try {
      await playlistStore.removeBeatFromPlaylist(playlist.id, beatId);
      showToast('Beat removido da playlist', 'success');
      window.dispatchEvent(new CustomEvent('playlistUpdated'));
      loadPlaylist();
    } catch (e) {
      showToast('Ocorreu um erro ao remover o beat', 'error');
    }
  };

  const handleMoveBeat = async (index: number, direction: 'up' | 'down') => {
    if (!playlist || !playlist.beat_ids) return;

    const newBeatIds = [...playlist.beat_ids];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;

    if (targetIdx < 0 || targetIdx >= newBeatIds.length) return;

    // Swap elements
    const temp = newBeatIds[index];
    newBeatIds[index] = newBeatIds[targetIdx];
    newBeatIds[targetIdx] = temp;

    try {
      const success = await playlistStore.reorderPlaylistBeats(playlist.id, newBeatIds);
      if (success) {
        showToast('Posição atualizada com sucesso!', 'success', 'Reordenado');
        loadPlaylist();
        window.dispatchEvent(new CustomEvent('playlistUpdated'));
      } else {
        showToast('Erro ao reordenar beats.', 'error');
      }
    } catch (e) {
      showToast('Falha na reordenação.', 'error');
    }
  };

  const handleShare = () => {
    if (!playlist) return;
    const url = `${window.location.origin}/#/playlist/${playlist.id}`;
    navigator.clipboard.writeText(url);
    showToast('Ligação de partilha copiada para a área de transferência!', 'success', 'Partilhar Playlist');
  };

  if (loading) {
    return (
      <div className="py-6">
        <PlaylistSkeleton />
      </div>
    );
  }

  if (!playlist) {
    return (
      <div className="py-16 text-center text-gray-500 space-y-4">
        <Disc size={48} className="mx-auto text-gray-700 opacity-50 select-none" />
        <p className="font-bold">Playlist não encontrada ou indisponível.</p>
        <button 
          onClick={onBack}
          className="px-6 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs font-black uppercase tracking-wider text-white hover:bg-white/10 transition-colors"
        >
          Voltar a Descoberta
        </button>
      </div>
    );
  }

  // Get matching beat details aligned to current sorting order in playlist.beat_ids
  const playlistBeats = (playlist.beat_ids || [])
    .map(bId => beats.find(b => String(b.id) === String(bId)))
    .filter((b): b is Beat => !!b);

  // Generate dynamic cover montage
  const coverImages = playlistBeats.map(b => b.image).filter(Boolean).slice(0, 4);

  // Playlist Analytics calculations
  const totalStreams = playlistBeats.reduce((sum, b) => sum + Number(b.plays_count || 0), 0);
  // Simulated stats based on real streams
  const totalSaves = Math.round(totalStreams * 0.12) + (playlistBeats.length * 2);
  const engagementRate = playlistBeats.length > 0 
    ? Math.min(100, Math.round((totalSaves / (totalStreams || 1)) * 100 + 15)) 
    : 0;
  
  // Find top beat in playlist based on play count
  const topBeat = playlistBeats.length > 0 
    ? [...playlistBeats].sort((a, b) => (b.plays_count || 0) - (a.plays_count || 0))[0] 
    : null;

  const isOwner = playlist.user_id === user?.id;

  // Visual custom layout gradients for Spotify/Apple music look
  const visualThemeSeed = (playlist.title || '').length % 5;
  const themeGradients = [
    'from-purple-900/45 via-black to-black',
    'from-rose-950/45 via-black to-black',
    'from-emerald-950/45 via-black to-black',
    'from-amber-950/45 via-black to-black',
    'from-blue-950/45 via-black to-black'
  ];
  const selectedThemeGradient = themeGradients[visualThemeSeed];

  return (
    <div className={`space-y-8 animate-in fade-in duration-500 pb-16 relative bg-gradient-to-b ${selectedThemeGradient} p-6 md:p-8 rounded-3xl border border-white/5`}>
      
      {/* Back link */}
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-gray-400 hover:text-white transition-colors cursor-pointer group"
      >
        <ArrowLeft size={16} className="group-hover:-translate-x-0.5 transition-transform" />
        Voltar
      </button>

      {/* Playlist Header Row */}
      <div className="flex flex-col md:flex-row gap-6 md:gap-8 items-start md:items-end">
        {/* Collage Cover Image */}
        <div className="w-48 h-48 md:w-56 md:h-56 rounded-3xl overflow-hidden bg-white/5 border border-white/10 shadow-2xl relative shrink-0 group">
          {playlist.cover_image && playlist.cover_image.trim() !== "" ? (
            <img src={playlist.cover_image} alt="" className="w-full h-full object-cover" />
          ) : coverImages.length >= 4 ? (
            <div className="grid grid-cols-2 gap-0.5 w-full h-full">
              {coverImages.map((img, i) => (
                <img key={i} src={img} alt="" className="w-full h-full object-cover" />
              ))}
            </div>
          ) : coverImages.length > 0 ? (
            <img src={coverImages[0]} alt="" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-purple-600/[0.15]">
              <Disc size={48} className="text-purple-400" />
            </div>
          )}
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <Music size={28} className="text-white animate-pulse" />
          </div>
        </div>

        {/* Text Info */}
        <div className="space-y-4 flex-grow">
          <div className="flex items-center gap-2">
            <span className={`px-2.5 py-1 rounded-full text-[8.5px] font-black uppercase tracking-widest flex items-center gap-1 border ${
              playlist.is_public 
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                : 'bg-amber-500/10 border-amber-500/20 text-amber-500'
            }`}>
              {playlist.is_public ? <Globe size={10} /> : <Lock size={10} />}
              {playlist.is_public ? 'Pública' : 'Privada'}
            </span>
            {playlist.title.toLowerCase().includes('curadoria') || playlist.title.toLowerCase().includes('batukada') ? (
              <span className="px-2.5 py-1 rounded-full text-[8.5px] font-black uppercase tracking-widest bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center gap-1">
                <Sparkles size={10} /> Editorial
              </span>
            ) : null}
            <span className="text-[10px] font-black text-gray-500 tracking-wider uppercase">PLAYLIST DISK</span>
          </div>

          <h2 className="text-3xl md:text-5xl font-black text-white italic tracking-tight">{playlist.title}</h2>
          
          <p className="text-gray-300 text-sm max-w-xl pr-4 leading-relaxed font-semibold">
            {playlist.description || "Uma seleção exclusiva de vibez, batidas quentes e ritmos urbanos."}
          </p>

          <div className="text-xs text-gray-400 flex flex-wrap items-center gap-x-3 gap-y-1 font-bold">
            <span className="text-white">Criado por @{user?.email?.split('@')[0] || 'BatukadaEditor'}</span>
            <span>•</span>
            <span className="text-amber-500">{playlistBeats.length} {playlistBeats.length === 1 ? 'Beat' : 'Beats'}</span>
            <span>•</span>
            <span className="flex items-center gap-1 text-gray-400">
              <Clock size={12} /> {playlistBeats.length * 3} mins total
            </span>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-3 pt-2">
            {playlistBeats.length > 0 && (
              <button
                onClick={() => {
                  window.dispatchEvent(new CustomEvent('replacePlayerQueue', {
                    detail: { beats: playlistBeats, playFirst: true }
                  }));
                  showToast(`A carregar ${playlistBeats.length} beats no player!`, 'success', 'Player Atualizado');
                }}
                className="bg-[#5865F2] hover:bg-blue-600 hover:shadow-[#5865F2]/20 text-white font-black uppercase text-xs tracking-widest px-6 py-3.5 rounded-full flex items-center gap-2 shadow-xl active:scale-95 transition-all cursor-pointer"
              >
                {isPlaying && currentBeat && playlistBeats.some(pb => pb.id === currentBeat.id) ? (
                  <>
                    <Pause size={14} fill="currentColor" /> pausar vibe
                  </>
                ) : (
                  <>
                    <Play size={14} fill="currentColor" /> iniciar playlist
                  </>
                )}
              </button>
            )}

            <button 
              onClick={handleShare}
              className="p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-full text-gray-400 hover:text-white transition-all active:scale-95 cursor-pointer"
              title="Partilhar Playlist"
            >
              <Share2 size={16} />
            </button>

            {isOwner && (
              <button 
                onClick={() => setIsEditing(true)}
                className="px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-gray-400 hover:text-white transition-all text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 cursor-pointer"
              >
                <Edit size={12} /> Editar Vibe
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Analytics Dashboard Panel */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-5 rounded-3xl bg-black/40 border border-white/5 backdrop-blur-md">
        <div className="space-y-1">
          <p className="text-[10px] font-extrabold text-gray-500 uppercase tracking-widest flex items-center gap-1">
            <Play size={10} className="text-amber-500" /> Streams Totais
          </p>
          <p className="text-xl font-black text-white">{totalStreams.toLocaleString()} streams</p>
        </div>
        
        <div className="space-y-1">
          <p className="text-[10px] font-extrabold text-gray-500 uppercase tracking-widest flex items-center gap-1">
            <Heart size={10} className="text-rose-500" /> Saves / Curtidas
          </p>
          <p className="text-xl font-black text-white">{totalSaves.toLocaleString()} saves</p>
        </div>

        <div className="space-y-1">
          <p className="text-[10px] font-extrabold text-gray-500 uppercase tracking-widest flex items-center gap-1">
            <TrendingUp size={10} className="text-emerald-500" /> Engajamento
          </p>
          <p className="text-xl font-black text-white">{engagementRate}% score</p>
        </div>

        <div className="space-y-1">
          <p className="text-[10px] font-extrabold text-gray-500 uppercase tracking-widest flex items-center gap-1">
            <Sparkles size={10} className="text-purple-400" /> Destaque
          </p>
          <p className="text-xs font-black text-white truncate max-w-full">
            {topBeat ? `${topBeat.title} (${(topBeat.plays_count || 0).toLocaleString()} streams)` : 'Sem beats'}
          </p>
        </div>
      </div>

      {/* Beats List Section */}
      <div className="space-y-4">
        <h3 className="text-xs font-black tracking-widest text-[#F59E0B] uppercase italic">Beats na Playlist</h3>

        {playlistBeats.length === 0 ? (
          <div className="py-14 text-center border border-dashed border-white/5 rounded-3xl bg-white/[0.01]">
            <Disc size={32} className="text-gray-600 mx-auto mb-2.5 opacity-30 animate-spin" />
            <p className="text-xs font-bold text-gray-400">Esta playlist está vazia.</p>
            <p className="text-[10px] text-gray-500 mt-1">Navega pelo catálogo e clica em "Adicionar à Playlist" para recheá-la!</p>
          </div>
        ) : (
          <div className="bg-[#09090D]/80 border border-white/5 rounded-3xl overflow-hidden backdrop-blur-md">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/5 text-[9px] font-black text-gray-500 uppercase tracking-widest">
                    <th className="p-4 pl-6 w-12 text-center">#</th>
                    <th className="p-4">Beat</th>
                    <th className="p-4">Produtor</th>
                    <th className="p-4">Gênero</th>
                    {isOwner && <th className="p-4 w-20 text-center">Reordenar</th>}
                    <th className="p-4 w-12 text-right pr-6">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.03]">
                  {playlistBeats.map((b, idx) => {
                    const isCurrent = currentBeat?.id === b.id;
                    return (
                      <tr 
                        key={b.id} 
                        className={`group hover:bg-white/[0.01] transition-all ${isCurrent ? 'bg-[#5865F2]/5' : ''}`}
                      >
                        {/* Play Index */}
                        <td className="p-4 pl-6 text-center">
                          <button 
                            onClick={() => {
                              // Play clicked item and load the remaining elements in sequence to queue
                              const remainingBeats = playlistBeats.slice(idx);
                              window.dispatchEvent(new CustomEvent('replacePlayerQueue', {
                                detail: { beats: remainingBeats, playFirst: true }
                              }));
                            }}
                            className="text-gray-500 group-hover:text-white transition-colors cursor-pointer"
                          >
                            {isCurrent && isPlaying ? (
                              <Pause size={14} className="text-amber-500 animate-pulse mx-auto" />
                            ) : (
                              <Play size={14} className="opacity-0 group-hover:opacity-100 mx-auto" strokeWidth={3} />
                            )}
                            {(!isCurrent || !isPlaying) && (
                              <span className="text-xs font-mono font-black group-hover:hidden">{idx + 1}</span>
                            )}
                          </button>
                        </td>

                        {/* Covered title */}
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img 
                              src={(b.image && b.image.trim() !== '') ? b.image : 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=80'} 
                              alt="" 
                              className="w-10 h-10 rounded-xl object-cover border border-white/10 shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0">
                              <h5 className={`font-extrabold text-sm truncate ${isCurrent ? 'text-amber-500 font-extrabold' : 'text-white'}`}>{b.title}</h5>
                              <p className="text-[10px] text-gray-500 mt-0.5">{b.bpm} BPM</p>
                            </div>
                          </div>
                        </td>

                        {/* Producer info */}
                        <td className="p-4 font-bold text-xs text-gray-400 uppercase tracking-wide">
                          {b.producer}
                        </td>

                        {/* Genre tag */}
                        <td className="p-4">
                          <span className="px-2.5 py-1 rounded bg-white/5 text-[9px] font-black text-gray-400 uppercase tracking-widest border border-white/5">
                            {b.genre || 'Beat'}
                          </span>
                        </td>

                        {/* Sorting Up/Down controls for owner */}
                        {isOwner && (
                          <td className="p-4 text-center">
                            <div className="flex items-center justify-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button
                                disabled={idx === 0}
                                onClick={() => handleMoveBeat(idx, 'up')}
                                className="p-1 rounded bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white disabled:opacity-20 disabled:pointer-events-none transition-colors"
                                title="Subir Posição"
                              >
                                <ArrowUp size={12} />
                              </button>
                              <button
                                disabled={idx === playlistBeats.length - 1}
                                onClick={() => handleMoveBeat(idx, 'down')}
                                className="p-1 rounded bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white disabled:opacity-20 disabled:pointer-events-none transition-colors"
                                title="Descer Posição"
                              >
                                <ArrowDown size={12} />
                              </button>
                            </div>
                          </td>
                        )}

                        {/* Controls */}
                        <td className="p-4 pr-6 text-right">
                          <div className="flex items-center justify-end gap-3.5">
                            {onAddToCart && (
                              <button
                                onClick={() => onAddToCart(b)}
                                className="p-2 text-gray-400 hover:text-amber-500 bg-white/5 hover:bg-white/10 rounded-xl transition-all"
                                title="Adicionar ao Carrinho"
                              >
                                <ShoppingCart size={13} />
                              </button>
                            )}
                            {isOwner && (
                              <button
                                onClick={() => handleRemoveBeat(b.id)}
                                className="p-2 text-gray-500 hover:text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                                title="Remover da Playlist"
                              >
                                <Trash2 size={13} />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Edit Details Lightbox/Modal */}
      <AnimatePresence>
        {isEditing && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
            
            {/* Dark blur backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsEditing(false)}
              className="absolute inset-0 bg-black/95 backdrop-blur-md"
            />

            {/* Editing Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-white/10 bg-[#09090D] shadow-2xl p-6 md:p-8"
            >
              <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
                <div className="flex items-center gap-2">
                  <Sparkles size={18} className="text-[#5865F2]" />
                  <h3 className="text-base font-black tracking-widest text-white uppercase italic">
                    Editar Detalhes da Playlist
                  </h3>
                </div>
                <button 
                  onClick={() => setIsEditing(false)}
                  className="w-8 h-8 rounded-full bg-white/5 border border-white/5 flex items-center justify-center text-gray-400 hover:text-white"
                >
                  <X size={15} />
                </button>
              </div>

              <form onSubmit={handleUpdatePlaylist} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black uppercase text-gray-400 tracking-wider">Título da Playlist</label>
                  <input
                    type="text"
                    required
                    value={editTitle}
                    onChange={e => setEditTitle(e.target.value)}
                    className="w-full bg-white/[0.02] border border-white/10 rounded-2xl p-4 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black uppercase text-gray-400 tracking-wider">Descrição</label>
                  <textarea
                    rows={3}
                    value={editDescription}
                    onChange={e => setEditDescription(e.target.value)}
                    className="w-full bg-white/[0.02] border border-white/10 rounded-2xl p-4 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors resize-none"
                    placeholder="Fale um pouco sobre o mood destas batidas..."
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black uppercase text-gray-400 tracking-wider">Capa da Playlist (URL Opcional)</label>
                  <input
                    type="url"
                    value={editCoverImage}
                    onChange={e => setEditCoverImage(e.target.value)}
                    className="w-full bg-white/[0.02] border border-white/10 rounded-2xl p-4 text-xs text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                    placeholder="Cole um link de imagem (ex: Unsplash) se quiser capa customizada"
                  />
                </div>

                {/* Preset covers grid as help */}
                <div className="space-y-1.5">
                  <label className="text-[8px] font-black uppercase text-gray-500 tracking-wider">Artísticos Sugeridos</label>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150',
                      'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=150',
                      'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150',
                      'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=150'
                    ].map((preset, pIdx) => (
                      <button
                        type="button"
                        key={pIdx}
                        onClick={() => setEditCoverImage(preset)}
                        className={`h-12 rounded-xl overflow-hidden border transition-all relative ${editCoverImage === preset ? 'border-[#5865F2] scale-95' : 'border-transparent hover:scale-105'}`}
                      >
                        <img src={preset} className="w-full h-full object-cover" alt="" />
                        {editCoverImage === preset && (
                          <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-[#5865F2]">
                            <Check size={14} strokeWidth={4} />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Visibility Toggle */}
                <div className="flex gap-4 pt-1">
                  <div 
                    onClick={() => setEditIsPublic(true)}
                    className={`flex-1 p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-2.5 ${
                      editIsPublic 
                        ? 'border-[#5865F2] bg-[#5865F2]/5 text-white' 
                        : 'border-white/5 bg-white/[0.01] text-gray-500 hover:border-white/10'
                    }`}
                  >
                    <Globe size={16} className={editIsPublic ? 'text-[#5865F2]' : ''} />
                    <div className="text-left">
                      <p className="text-xs font-black">Pública</p>
                      <p className="text-[9px] font-semibold opacity-70">Descoberta para todos</p>
                    </div>
                  </div>

                  <div 
                    onClick={() => setEditIsPublic(false)}
                    className={`flex-1 p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-2.5 ${
                      !editIsPublic 
                        ? 'border-[#5865F2] bg-[#5865F2]/5 text-white' 
                        : 'border-white/5 bg-white/[0.01] text-gray-500 hover:border-white/10'
                    }`}
                  >
                    <Lock size={16} className={!editIsPublic ? 'text-[#5865F2]' : ''} />
                    <div className="text-left">
                      <p className="text-xs font-black">Privada</p>
                      <p className="text-[9px] font-semibold opacity-70">Só tu tens acesso</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-4 border-t border-white/5">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="flex-1 py-3.5 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 text-gray-400 hover:text-white font-black text-[10px] uppercase tracking-widest transition-all"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3.5 rounded-2xl bg-[#5865F2] text-white hover:bg-blue-600 font-black text-[10px] uppercase tracking-widest transition-all shadow-lg"
                  >
                    Guardar Alterações
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
