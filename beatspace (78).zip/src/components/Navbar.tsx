import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  ShoppingBag, 
  Music, 
  Menu, 
  X, 
  Sparkles, 
  MessageCircle, 
  Bell, 
  Compass, 
  TrendingUp, 
  Trophy, 
  Crown, 
  Radio, 
  UploadCloud, 
  LogIn, 
  UserPlus 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { getSupabase } from '../lib/supabase';
import SearchBar from './SearchBar';
import NotificationDropdown from './NotificationDropdown';
import { Notification } from '../types';
import { playSubtleNotificationSound } from '../lib/notifications';

const HOSTED_LOGO_URL = 'https://i.ibb.co/hF1MD85X/20260523-155411.png';

export default function Navbar({ 
  cartCount, 
  onOpenCart, 
  onOpenAuth, 
  onExplore, 
  onProducers, 
  onFeed,
  onGoDashboard, 
  onGoAdmin,
  onSignOut,
  onOpenMessages,
  onOpenNotifications,
  onOpenLicensing,
  onHome,
  onRankings,
  unreadCount,
  currentPage
}: { 
  cartCount: number, 
  onOpenCart: () => void, 
  onOpenAuth: (mode: 'login' | 'signup') => void, 
  onExplore: () => void, 
  onProducers: () => void, 
  onFeed?: () => void,
  onGoDashboard: () => void,
  onGoAdmin: () => void,
  onSignOut: () => void,
  onOpenMessages: () => void,
  onOpenNotifications: () => void,
  onOpenLicensing: () => void,
  onHome: () => void,
  onRankings: () => void,
  unreadCount: number,
  currentPage?: string
}) {
  const { user, profile, loading } = useAuth();
  const { language, setLanguage, t } = useLanguage();

  if (typeof window !== 'undefined') {
    console.count('Navbar render');
    console.count('Sidebar render');
  }

  const emailNormalized = user?.email?.toLowerCase()?.trim() || '';
  const isAdmin = 
    profile?.role === 'admin' || 
    user?.user_metadata?.role === 'admin' || 
    user?.app_metadata?.role === 'admin' || 
    user?.user_metadata?.account_type === 'admin' || 
    localStorage.getItem('beatangola_user_role') === 'admin' ||
    emailNormalized === 'dieluxpista@gmail.com' ||
    emailNormalized === 'miguelfranciscoalfredo24@gmail.com' ||
    emailNormalized === 'domingosdejesusk@gmail.com' ||
    emailNormalized === 'buzzinangola@gmail.com';
  
  console.log('RESOLVED IS_ADMIN STATUS:', isAdmin);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [logoError, setLogoError] = useState(false);

  const unreadNotifications = notifications.filter(n => n.read === false).length;

  useEffect(() => {
    console.log('[BOOT] Navbar mounted');
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const prevUnreadRef = useRef<number>(0);

  useEffect(() => {
    if (user) {
      fetchNotifications();
      
      // Real-time listener disabled temporarily to prevent concurrent queries/failed-fetch race conditions on update
      /*
      const supabase = getSupabase();
      const channel = supabase
        ?.channel('public:unread_notifications')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'notifications' },
          () => {
            fetchNotifications();
          }
        )
        .subscribe();
      */

      // Listen for instant local notification triggers for sub-second lagless sync
      const handleLocalNotification = () => {
        fetchNotifications();
      };
      window.addEventListener('new_notification_received', handleLocalNotification);

      return () => {
        // if (supabase && channel) supabase.removeChannel(channel as any);
        window.removeEventListener('new_notification_received', handleLocalNotification);
      };
    }
  }, [user]);

  useEffect(() => {
    if (user && unreadNotifications > prevUnreadRef.current) {
      playSubtleNotificationSound();
    }
    prevUnreadRef.current = unreadNotifications;
    if (user) {
      console.log(`NOTIFICATION BADGE COUNT: ${unreadNotifications}`);
      console.log(`NAVBAR NOTIFICATION COUNT: ${unreadNotifications}`);
    }
  }, [unreadNotifications, user]);

  const fetchNotifications = async () => {
    const supabase = getSupabase();
    if (!supabase || !user) return;

    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(20);

    if (data) setNotifications(data);
  };

  const handleSignout = async () => {
    const supabase = getSupabase();
    // Always clear cached credentials and demo sessions during signout!
    localStorage.removeItem('beatangola_demo_session');
    localStorage.removeItem('beatangola_user_role');
    
    if (supabase) {
      await supabase.auth.signOut();
    } else {
      window.dispatchEvent(new Event('auth_state_change'));
    }
    onSignOut();
  };

  const handleLogoClick = () => {
    if (user) {
      onExplore();
    } else {
      onHome();
    }
  };

  // Resolving user roles and capabilities
  const accountType = profile?.role || user?.user_metadata?.account_type || localStorage.getItem('beatangola_user_role') || 'seller';
  const isProducer = user && (accountType === 'seller' || accountType === 'sell' || accountType === 'producer' || isAdmin);

  const visitorLinks = [
    { id: 'EXPLORAR', label: t('nav.explore', 'Explorar'), icon: Compass, action: onExplore },
    { 
      id: 'TRENDING', 
      label: t('nav.trending', 'Trending'), 
      icon: TrendingUp,
      action: () => {
        onExplore();
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent('sortByChanged', { detail: 'trending' }));
        }, 100);
      } 
    },
    { id: 'RANKINGS', label: t('nav.rankings', 'Rankings'), icon: Trophy, action: onRankings },
    { id: 'PRODUTORES', label: t('nav.producers', 'Produtores'), icon: Crown, action: onProducers },
    { id: 'ENTRAR', label: t('nav.login', 'Entrar'), icon: LogIn, action: () => onOpenAuth('login') },
    { id: 'CRIAR_CONTA', label: t('nav.signup', 'Criar Conta'), icon: UserPlus, action: () => onOpenAuth('signup') },
  ];

  // Spotify/SoundCloud-inspired high-fidelity navigation links for logged-in members
  const authLinks = [
    { id: 'EXPLORAR', label: t('nav.explore', 'Explorar'), icon: Compass, action: onExplore },
    { id: 'FEED', label: t('nav.feed', 'Feed'), icon: Radio, action: onFeed || (() => {}) },
    { id: 'RANKINGS', label: t('nav.rankings', 'Rankings'), icon: Trophy, action: onRankings },
    { id: 'PRODUTORES', label: t('nav.producers', 'Produtores'), icon: Crown, action: onProducers },
  ];

  if (isProducer) {
    authLinks.push({
      id: 'UPLOAD',
      label: t('nav.upload', 'Upload'),
      icon: UploadCloud,
      action: () => {
        sessionStorage.setItem('trigger_upload_modal', 'true');
        onGoDashboard();
        window.dispatchEvent(new CustomEvent('openUploadModal'));
      }
    });
  }

  const currentLinks = user ? authLinks : visitorLinks;

  const centralLinks = currentLinks.filter(link => link.id !== 'ENTRAR' && link.id !== 'CRIAR_CONTA');
  const authOnlyLinks = currentLinks.filter(link => link.id === 'ENTRAR' || link.id === 'CRIAR_CONTA');

  const getIsActive = (linkId: string) => {
    switch (linkId) {
      case 'EXPLORAR':
        return currentPage === 'home' || currentPage === 'beat-details' || currentPage === 'playlist-details';
      case 'TRENDING':
        return currentPage === 'all-beats';
      case 'RANKINGS':
        return currentPage === 'producer-rankings';
      case 'PRODUTORES':
        return currentPage === 'producers' || currentPage === 'producer-profile';
      case 'FEED':
        return currentPage === 'feed';
      default:
        return false;
    }
  };

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-200 bg-[#060608]/95 backdrop-blur-md border-b border-white/[0.04] ${
        isScrolled 
          ? 'py-2 shadow-lg shadow-black/80' 
          : 'py-3'
      }`}
    >
      <div className="max-w-[1600px] mx-auto px-6 lg:px-8 flex items-center justify-between w-full h-11 md:h-13 gap-8">
        
        {/* LEFT Section: Logo & Nav Links */}
        <div className="flex items-center gap-8 flex-shrink-0 min-w-0">
          {/* Logo */}
          <div 
            className="flex items-center cursor-pointer group h-11 shrink-0 select-none"
            onClick={handleLogoClick}
          >
            {!logoError ? (
              <img 
                src={HOSTED_LOGO_URL}
                alt="BATUKADA Logo"
                onError={() => setLogoError(true)}
                className="h-[32px] md:h-[36px] w-auto object-contain select-none max-w-[160px] md:max-w-[220px] hover:brightness-110 transition-all duration-200"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-neutral-900 border border-white/5 rounded-lg flex items-center justify-center">
                  <Music className="text-white" size={15} strokeWidth={1.5} />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-extrabold text-white tracking-wider uppercase font-sans leading-tight">
                    BEAT<span className="text-neutral-400 font-normal">ANGOLA</span>
                  </span>
                  <span className="text-[8px] font-medium text-neutral-500 tracking-widest -mt-0.5">PREMIUM</span>
                </div>
              </div>
            )}
          </div>
 
          {/* Central Nav Links */}
          <div className="hidden lg:flex items-center gap-6 flex-shrink-0">
            {centralLinks.map((link) => {
              const isActive = getIsActive(link.id);
              const isUploadBtn = link.id === 'UPLOAD';
 
              if (isUploadBtn) {
                return (
                  <button
                    key={link.id}
                    onClick={link.action}
                    className="flex items-center gap-1.5 px-2.5 py-1 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded text-[11px] font-bold tracking-wider transition-all duration-150 active:scale-95 cursor-pointer whitespace-nowrap uppercase flex-shrink-0"
                  >
                    <link.icon size={12} strokeWidth={2} />
                    <span>{link.label}</span>
                  </button>
                );
              }
 
              return (
                <button
                  key={link.id}
                  onClick={link.action}
                  className={`relative text-[11px] font-bold tracking-wider py-1.5 uppercase group flex items-center gap-1 cursor-pointer h-9 whitespace-nowrap px-2 transition-all duration-150 flex-shrink-0 ${
                    isActive 
                      ? 'text-white font-extrabold' 
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <link.icon size={12} strokeWidth={2} className="opacity-80 group-hover:opacity-100 transition-opacity" />
                  <span>{link.label}</span>
                  {isActive && (
                    <motion.span 
                      layoutId="activeNavIndicator" 
                      className="absolute bottom-0 left-2 right-2 h-[2px] bg-[#5865F2] rounded-full" 
                      transition={{ type: "spring", stiffness: 400, damping: 35 }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* CENTER Section: Centered search bar */}
        <div id="3edq8z" className="flex-1 flex justify-center min-w-0">
          <div className="w-[420px] max-w-[420px] min-w-[420px]">
            <SearchBar />
          </div>
        </div>

        {/* RIGHT Section: User tools, Actions and Language Selector */}
        <div id="8d5rk8" className="flex items-center gap-4 flex-shrink-0">
          
          {/* SEARCH & ICONS Group */}
          <div className="flex items-center gap-1.5 flex-shrink-0">

            {/* Notifications & Messages (Visible on desktop & mobile) */}
            {user && (
              <>
                <div className="relative">
                  <button 
                    onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                    className="relative p-1.5 text-neutral-400 hover:text-rose-400 hover:bg-rose-500/5 rounded transition-all duration-150 active:scale-95 group flex items-center justify-center cursor-pointer"
                  >
                    <Bell size={15} strokeWidth={2} className={unreadNotifications > 0 ? "text-rose-500" : ""} />
                    {unreadNotifications > 0 && (
                      <span className="absolute top-1 right-1 bg-rose-600 text-[8px] text-white rounded-full h-3.5 min-w-[14px] px-0.5 flex items-center justify-center font-bold border border-[#060608]">
                        {unreadNotifications}
                      </span>
                    )}
                  </button>

                  <AnimatePresence>
                    {isNotificationsOpen && (
                      <NotificationDropdown 
                        onClose={() => setIsNotificationsOpen(false)} 
                        onViewAll={() => {
                          onOpenNotifications();
                          setIsNotificationsOpen(false);
                        }}
                        onMarkRead={() => {
                          fetchNotifications();
                        }}
                        onNavigateToDashboard={() => {
                          onGoDashboard();
                          setIsNotificationsOpen(false);
                        }}
                        notifications={notifications}
                        setNotifications={setNotifications}
                      />
                    )}
                  </AnimatePresence>
                </div>

                <button 
                  onClick={onOpenMessages}
                  className="relative p-1.5 text-neutral-400 hover:text-[#5865F2] hover:bg-[#5865F2]/5 rounded transition-all duration-150 active:scale-95 flex items-center justify-center cursor-pointer"
                >
                  <MessageCircle size={15} strokeWidth={2} />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 bg-[#5865F2] text-[8px] text-white rounded-full h-3.5 w-3.5 flex items-center justify-center font-bold">
                      {unreadCount}
                    </span>
                  )}
                </button>
              </>
            )}

            {/* Cart Icon (Visible on desktop & mobile) */}
            <button 
              onClick={onOpenCart}
              className="relative w-[38px] h-[38px] flex items-center justify-center rounded-[10px] bg-transparent hover:bg-white/[0.04] hover:shadow-[0_0_12px_rgba(88,101,242,0.25)] transition-all duration-200 ease-in-out active:scale-95 flex-shrink-0 cursor-pointer"
            >
              <ShoppingBag size={18} strokeWidth={1.8} className="text-[rgba(255,255,255,0.85)]" />
              {cartCount > 0 && (
                <span className="absolute top-[2px] right-[2px] bg-[#5865F2] text-white text-[8px] rounded-full h-3.5 w-3.5 flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </button>
          </div>

          {user && <div className="h-4 w-[1px] bg-white/10 mx-1 hidden lg:block flex-shrink-0" />}

          {/* DASHBOARD / ADMIN / SAIR or ENTRAR / CRIAR CONTA Buttons */}
          <div className="hidden lg:flex items-center gap-4 flex-shrink-0">
            {user ? (
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <button 
                  onClick={onGoDashboard}
                  className="inline-flex items-center justify-center px-2.5 py-1 text-xs font-bold text-neutral-200 hover:text-white border border-white/5 hover:border-white/10 bg-white/[0.02] hover:bg-neutral-900 rounded transition-all cursor-pointer whitespace-nowrap flex-shrink-0"
                >
                  {t('nav.dashboard', 'Dashboard')}
                </button>
                {isAdmin && (
                  <button 
                    onClick={onGoAdmin}
                    className="inline-flex items-center justify-center px-2.5 py-1 text-xs font-bold text-orange-400 hover:text-orange-300 border border-orange-500/10 hover:border-orange-500/15 bg-orange-500/[0.02] hover:bg-orange-500/[0.05] rounded transition-all cursor-pointer whitespace-nowrap flex-shrink-0"
                  >
                    {t('nav.adminPanel', 'Painel Admin')}
                  </button>
                )}
                <button 
                  onClick={handleSignout}
                  className="inline-flex items-center justify-center px-2 py-1 text-xs font-bold text-neutral-400 hover:text-red-400 transition-colors cursor-pointer whitespace-nowrap flex-shrink-0"
                >
                  {t('nav.logout', 'Sair')}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 flex-shrink-0">
                {authOnlyLinks.map((link) => {
                  const isEntrarBtn = link.id === 'ENTRAR';
                  const isCriarContaBtn = link.id === 'CRIAR_CONTA';
                  
                  if (isEntrarBtn) {
                    return (
                      <button
                        key={link.id}
                        onClick={link.action}
                        className="text-xs font-bold text-neutral-400 hover:text-white uppercase tracking-wider px-2.5 py-1 transition-all duration-150 flex items-center gap-1 active:scale-95 cursor-pointer whitespace-nowrap flex-shrink-0"
                      >
                        <link.icon size={12} strokeWidth={2} />
                        <span>{link.label}</span>
                      </button>
                    );
                  }

                  if (isCriarContaBtn) {
                    return (
                      <button
                        key={link.id}
                        onClick={link.action}
                        className="text-xs font-extrabold text-white bg-[#5865F2] hover:bg-[#4752C4] uppercase tracking-wider px-3.5 py-1.5 rounded transition-all duration-150 active:scale-95 text-center justify-center cursor-pointer flex items-center gap-1.5 select-none whitespace-nowrap flex-shrink-0"
                      >
                        <link.icon size={12} strokeWidth={2.25} />
                        <span>{link.label}</span>
                      </button>
                    );
                  }
                  return null;
                })}
              </div>
            )}

            {/* Premium Minimalist Language Switcher - Desktop */}
            <div className="h-5 w-px bg-white/10 mx-2 hidden lg:block flex-shrink-0" />
            <div id="desktop-lang-switcher" className="hidden lg:flex items-center gap-0.5 text-[10px] font-bold tracking-wider select-none h-9 self-center flex-shrink-0">
              <button 
                onClick={() => setLanguage('pt')}
                className={`transition-all duration-200 cursor-pointer py-1 px-1.5 hover:text-white rounded ${
                  language === 'pt' ? 'text-white font-bold bg-white/5' : 'text-white/45 hover:bg-white/[0.02]'
                }`}
                title="Português"
              >
                PT
              </button>
              <span className="text-white/15 select-none font-light px-0.5">|</span>
              <button 
                onClick={() => setLanguage('en')}
                className={`transition-all duration-200 cursor-pointer py-1 px-1.5 hover:text-white rounded ${
                  language === 'en' ? 'text-white font-bold bg-white/5' : 'text-white/45 hover:bg-white/[0.02]'
                }`}
                title="English"
              >
                EN
              </button>
            </div>
          </div>

          {/* Mobile elements (Dashboard/Admin for small screens, Mobile Menu button) */}
          <div className="flex items-center gap-1.5 flex-shrink-0 lg:hidden">
            {user && (
              <button 
                onClick={onGoDashboard}
                className="inline-flex sm:hidden items-center justify-center px-2.5 py-1 text-xs font-semibold text-neutral-300 hover:text-white border border-white/10 bg-white/[0.02] rounded-lg cursor-pointer whitespace-nowrap flex-shrink-0"
              >
                Dashboard
              </button>
            )}

            {/* Compact Language Toggler for Mobile */}
            <button 
              id="mobile-lang-switcher"
              onClick={() => setLanguage(language === 'pt' ? 'en' : 'pt')}
              className="lg:hidden flex items-center justify-center h-8 px-2 rounded-lg bg-white/[0.03] border border-white/5 hover:bg-white/[0.07] hover:border-white/10 active:scale-95 transition-all cursor-pointer text-[10px] font-extrabold tracking-widest text-neutral-300 select-none whitespace-nowrap uppercase flex-shrink-0"
              title={language === 'pt' ? 'Switch to English' : 'Mudar para Português'}
            >
              {language === 'pt' ? 'PT' : 'EN'}
            </button>
            
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-1.5 text-neutral-400 hover:text-white hover:bg-white/5 rounded-xl transition-all cursor-pointer flex-shrink-0"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
          
        </div>
      </div>

        {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Backdrop Blur Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-sm lg:hidden"
            />
            
            {/* Slide-in Menu */}
            <motion.div
              initial={{ opacity: 0, x: '100%' }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 220 }}
              className="fixed top-0 right-0 bottom-0 w-[85%] max-w-sm z-[90] bg-[#050505]/95 backdrop-blur-[14px] border-l border-white/[0.04] lg:hidden shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-y-auto"
            >
              <div className="flex flex-col h-full pt-28 pb-12 px-8">
                {/* Mobile Navigation Links */}
                <div className="flex flex-col gap-6 mb-12">
                  <p className="text-[10px] font-semibold text-neutral-500 uppercase tracking-widest mb-2">
                    {t('nav.navigation', 'Navegação')}
                  </p>
                  {currentLinks.map((link, i) => {
                    const isActive = getIsActive(link.id);
                    const isUploadBtn = link.id === 'UPLOAD';
                    const isEntrarBtn = link.id === 'ENTRAR';
                    const isCriarContaBtn = link.id === 'CRIAR_CONTA';

                    if (isCriarContaBtn) {
                      return (
                        <motion.button
                          key={link.id}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 + i * 0.05 }}
                          onClick={() => {
                            link.action();
                            setIsMobileMenuOpen(false);
                          }}
                          className="w-full text-center justify-center py-3 bg-white text-black rounded-lg font-semibold uppercase tracking-wider text-xs active:scale-95 transition-all flex items-center gap-2 mt-4 cursor-pointer select-none"
                        >
                          <link.icon size={16} strokeWidth={1.75} />
                          <span>{link.label}</span>
                        </motion.button>
                      );
                    }

                    if (isEntrarBtn) {
                      return (
                        <motion.button
                          key={link.id}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 + i * 0.05 }}
                          onClick={() => {
                            link.action();
                            setIsMobileMenuOpen(false);
                          }}
                          className="text-lg font-semibold text-left uppercase tracking-wider text-neutral-400 hover:text-white transition-colors group flex items-center gap-3 cursor-pointer mt-2"
                        >
                          <link.icon size={18} strokeWidth={1.5} className="text-neutral-500 group-hover:text-white transition-colors" />
                          <span>{link.label}</span>
                        </motion.button>
                      );
                    }

                    return (
                      <motion.button
                        key={link.id}
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.05 + i * 0.03 }}
                        onClick={() => {
                          link.action();
                          setIsMobileMenuOpen(false);
                        }}
                        className={`text-base font-semibold text-left uppercase tracking-wider transition-colors group flex items-center gap-3 cursor-pointer ${
                          isUploadBtn 
                            ? 'text-white bg-[#5865F2]/10 hover:bg-[#5865F2]/20 border border-[#5865F2]/20 px-3 py-2 rounded flex justify-center text-center mt-2'
                            : isActive 
                              ? 'text-white' 
                              : 'text-neutral-400 hover:text-white'
                        }`}
                      >
                        <link.icon size={16} strokeWidth={1.5} className={isUploadBtn ? "text-[#5865F2]" : "text-current opacity-70 group-hover:opacity-100 transition-opacity"} />
                        <span>{link.label}</span>
                      </motion.button>
                    );
                  })}
                </div>

                <div className="h-[1px] w-full bg-white/5 my-3" />
                
                {/* Mobile User Actions */}
                <div className="flex flex-col gap-4 mt-3">
                  <p className="text-[9px] font-bold text-gray-500 uppercase tracking-wider mb-1">
                    {t('nav.accountAndUtils', 'Conta & Utilitários')}
                  </p>
                  <button 
                    onClick={() => { onOpenCart(); setIsMobileMenuOpen(false); }}
                    className="flex items-center justify-between p-3 bg-[#18181b]/35 rounded border border-white/5 font-semibold text-white uppercase tracking-wider text-xs cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <ShoppingBag size={15} className="text-[#5865F2]" />
                      {t('nav.myCart', 'Meu Carrinho')}
                    </div>
                    <span className="bg-[#5865F2] text-white text-[9px] px-2 py-0.5 rounded font-mono font-bold">{cartCount}</span>
                  </button>

                  {user && (
                    <button 
                      onClick={() => { onOpenNotifications(); setIsMobileMenuOpen(false); }}
                      className="flex items-center justify-between p-3 bg-[#18181b]/35 rounded border border-white/5 font-semibold text-white uppercase tracking-wider text-xs cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        <Bell size={15} className="text-emerald-500" />
                        {t('nav.notifications', 'Notificações')}
                      </div>
                      {unreadNotifications > 0 && <span className="bg-emerald-500 text-white text-[9px] px-2 py-0.5 rounded font-mono font-bold">{unreadNotifications}</span>}
                    </button>
                  )}

                  {user && (
                    <button 
                      onClick={() => { onOpenMessages(); setIsMobileMenuOpen(false); }}
                      className="flex items-center justify-between p-3 bg-[#18181b]/35 rounded border border-white/5 font-semibold text-white uppercase tracking-wider text-xs cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        <MessageCircle size={15} className="text-[#5865F2]" />
                        {t('nav.messages', 'Mensagens')}
                      </div>
                      {unreadCount > 0 && <span className="bg-[#5865F2] text-white text-[9px] px-2 py-0.5 rounded font-mono font-bold">{unreadCount}</span>}
                    </button>
                  )}

                  {user && (
                    <div className="grid grid-cols-1 gap-2 mt-3">
                      <button 
                        onClick={() => { onGoDashboard(); setIsMobileMenuOpen(false); }}
                        className="w-full py-2.5 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded font-bold uppercase tracking-wider text-xs transition-colors cursor-pointer"
                      >
                        {isProducer ? t('nav.producerPortal', 'PORTAL DO PRODUTOR') : t('nav.artistDashboard', 'DASHBOARD DO ARTISTA')}
                      </button>
                      {/* Conditionally show Admin Link */}
                      {isAdmin && (
                        <button 
                           onClick={() => { onGoAdmin(); setIsMobileMenuOpen(false); }}
                           className="w-full py-2.5 bg-orange-600 hover:bg-orange-500 text-white rounded font-bold uppercase tracking-wider text-xs transition-colors cursor-pointer"
                        >
                          {t('nav.adminPanel', 'Painel Admin')}
                        </button>
                      )}
                      <button 
                        onClick={() => { handleSignout(); setIsMobileMenuOpen(false); }}
                        className="w-full py-2.5 bg-white/5 hover:bg-white/10 text-red-400 rounded font-bold uppercase tracking-wider text-xs transition-colors cursor-pointer"
                      >
                        {t('nav.logoutLong', 'Sair da Conta')}
                      </button>
                    </div>
                  )}
                </div>

                {/* Footer Credits Mobile */}
                <div className="mt-auto pt-8 flex flex-col items-center gap-4 text-center">
                  <div className="flex items-center gap-2.5 text-xs font-bold tracking-wider select-none">
                    <button
                      onClick={() => setLanguage('pt')}
                      className={`transition-all duration-200 cursor-pointer ${
                        language === 'pt' ? 'text-white' : 'text-white/45 hover:text-white/75'
                      }`}
                    >
                      Português
                    </button>
                    <span className="text-white/20">|</span>
                    <button
                      onClick={() => setLanguage('en')}
                      className={`transition-all duration-200 cursor-pointer ${
                        language === 'en' ? 'text-white' : 'text-white/45 hover:text-white/75'
                      }`}
                    >
                      English
                    </button>
                  </div>
                  <p className="text-[9px] font-semibold text-gray-500 uppercase tracking-widest leading-none">
                    © 2026 BATUKADA PREMIUM
                  </p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </nav>
  );
}
