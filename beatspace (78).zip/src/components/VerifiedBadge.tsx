import React, { useState } from 'react';

interface VerifiedBadgeProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | number;
  tooltipText?: string;
}

export default function VerifiedBadge({ className = '', size = 'md', tooltipText = 'Produtor Verificado' }: VerifiedBadgeProps) {
  const [showTooltip, setShowTooltip] = useState(false);

  // Map sizes to pixel values
  let dimension = 16;
  if (typeof size === 'number') {
    dimension = size;
  } else {
    switch (size) {
      case 'sm':
        dimension = 14; // mobile (14px–16px)
        break;
      case 'md':
        dimension = 16; // default (16px–18px)
        break;
      case 'lg':
        dimension = 18;
        break;
    }
  }

  return (
    <div 
      className="relative inline-flex items-center justify-center select-none shrink-0"
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <svg
        width={dimension}
        height={dimension}
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`inline-block transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer text-[#2997FF] ${className}`}
        style={{
          filter: 'drop-shadow(0 0 4px rgba(41, 151, 255, 0.25))',
        }}
      >
        {/* Premium Scalloped Star shape with crisp fill */}
        <path
          d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.152-.435.238-.9.238-1.4 0-2.21-1.71-3.99-3.818-3.99-.34 0-.67.05-1 .137C15.12 2.378 13.687 1.5 12 1.5s-3.12.878-3.77 2.147c-.33-.087-.66-.137-1-.137-2.11 0-3.82 1.78-3.82 3.99 0 .5.087.965.238 1.4-1.27.65-2.148 2.02-2.148 3.6 0 1.58.875 2.95 2.148 3.6-.152.435-.238.9-.238 1.4 0 2.21 1.71 3.99 3.818 3.99.34 0 .67-.05 1-.137.65 1.269 2.083 2.147 3.77 2.147s3.12-.878 3.77-2.147c.33.087.66.137 1 .137 2.11 0 3.82-1.78 3.82-3.99 0-.5-.087-.965-.238-1.4 1.27-.65 2.148-2.02 2.148-3.6z"
          fill="#2997FF"
        />
        {/* Crisply aligned white checkmark to ensure high contrast & pixel accuracy */}
        <path
          d="M9.5 12.5L11.5 14.5L15.5 9.5"
          stroke="#FFFFFF"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>

      {/* Small premium dark tooltip */}
      {showTooltip && (
        <div className="absolute bottom-full mb-1.5 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-[#000000] border border-white/10 text-[9px] font-extrabold uppercase tracking-widest text-[#2997FF] rounded-md shadow-2xl z-50 animate-in fade-in duration-150 whitespace-nowrap">
          {tooltipText}
        </div>
      )}
    </div>
  );
}
