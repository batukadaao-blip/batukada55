import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  Trash2, 
  Search, 
  CheckCheck, 
  Settings,
  ShoppingBag, 
  Upload, 
  Zap, 
  Flame, 
  UserPlus, 
  Heart, 
  MessageSquare, 
  CheckCircle, 
  User, 
  CreditCard, 
  Shield,
  ChevronRight,
  TrendingUp,
  Inbox,
  Award,
  Radio,
  Share2,
  FolderDot,
  ArrowUpRight,
  CornerDownRight,
  Info,
  Sparkles,
  X
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { getSupabase, getPublicUrl } from '../lib/supabase';

// Helper functions for robust, real-route resolution on notifications
function slugify(text: string): string {
  if (!text) return '';
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD') // remove accents
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 -]/g, '') // remove invalid chars
    .replace(/\s+/g, '-') // collapse whitespace and replace by -
    .replace(/-+/g, '-'); // collapse dashes
}

function extractQuotedTitle(message: string): string {
  if (!message) return '';
  // Try to find text between escaped double quotes \"...\"
  let match = message.match(/\\"[^\\]+\\"/);
  if (match) {
    return match[0].replace(/\\"/g, '');
  }
  // Match standard double quotes but exclude comments split by colon
  const mainPart = message.split(':')[0];
  match = mainPart.match(/"([^"]+)"/);
  if (match) {
    return match[1];
  }
  // Try single quotes '...'
  match = mainPart.match(/'([^']+)'/);
  if (match) {
    return match[1];
  }
  return '';
}

function translateNotificationType(type: string): string {
  const mapping: Record<string, string> = {
    purchase: 'COMPRA',
    purchase_confirmed: 'COMPRA',
    payment: 'COMPRA',
    withdrawal_approved: 'FINANCEIRO',
    withdrawal_rejected: 'FINANCEIRO',
    upload: 'NOVO BEAT',
    featured_beat: 'DESTAQUE',
    editor_pick: 'DESTAQUE',
    beat_trending: 'TENDÊNCIA',
    flash_sale: 'PROMOÇÃO',
    follower: 'SEGUIDOR',
    like: 'GOSTEI',
    comment: 'COMENTÁRIO',
    reply_comment: 'COMENTÁRIO',
    repost: 'REPOST',
    playlist_add: 'PLAYLIST',
    playlist_inclusion: 'PLAYLIST',
    verified: 'VERIFICADO',
    account: 'CONTA',
    account_updated: 'CONTA',
    security: 'SEGURANÇA',
    platform_update: 'PLATAFORMA',
  };
  return mapping[type] || type.replace('_', ' ').toUpperCase();
}

import { Notification } from '../types';
import InstagramLoader from './InstagramLoader';

const NOTIFICATION_ICONS: Record<string, any> = {
  purchase: ShoppingBag,
  upload: Upload,
  flash_sale: Zap,
  featured: Flame,
  follower: UserPlus,
  like: Heart,
  comment: MessageSquare,
  reply_comment: CornerDownRight,
  playlist_add: FolderDot,
  repost: Share2,
  beat_trending: TrendingUp,
  editor_pick: Award,
  featured_beat: Sparkles,
  playlist_inclusion: Radio,
  verified: CheckCircle,
  account: User,
  account_updated: User,
  payment: CreditCard,
  withdrawal_approved: ArrowUpRight,
  withdrawal_rejected: X,
  security: Shield,
  platform_update: Info,
  purchase_confirmed: CheckCircle
};

const NOTIFICATION_COLORS: Record<string, string> = {
  purchase: 'text-emerald-400 bg-emerald-400/10 border-emerald-500/20 shadow-[0_0_15px_rgba(52,211,153,0.1)]',
  upload: 'text-blue-400 bg-blue-400/10 border-blue-500/20 shadow-[0_0_15px_rgba(96,165,250,0.1)]',
  flash_sale: 'text-amber-400 bg-amber-400/10 border-amber-500/20 shadow-[0_0_15px_rgba(251,191,36,0.1)]',
  featured: 'text-rose-400 bg-rose-400/10 border-rose-500/15 shadow-[0_0_15px_rgba(251,113,133,0.1)]',
  follower: 'text-purple-400 bg-purple-400/10 border-purple-500/15 shadow-[0_0_15px_rgba(192,132,252,0.1)]',
  like: 'text-rose-400 bg-rose-400/10 border-rose-500/15 shadow-[0_0_15px_rgba(251,113,133,0.1)]',
  comment: 'text-indigo-400 bg-indigo-400/10 border-indigo-500/15 shadow-[0_0_15px_rgba(129,140,248,0.1)]',
  reply_comment: 'text-cyan-400 bg-cyan-400/10 border-cyan-500/15 shadow-[0_0_15px_rgba(34,211,238,0.1)]',
  playlist_add: 'text-teal-400 bg-teal-400/10 border-teal-500/15 shadow-[0_0_15px_rgba(45,212,191,0.1)]',
  repost: 'text-sky-400 bg-sky-400/10 border-sky-500/15 shadow-[0_0_15px_rgba(56,189,248,0.1)]',
  beat_trending: 'text-red-400 bg-red-400/10 border-red-500/15 shadow-[0_0_15px_rgba(248,113,113,0.1)]',
  editor_pick: 'text-yellow-400 bg-yellow-400/10 border-yellow-500/15 shadow-[0_0_15px_rgba(250,204,21,0.1)]',
  featured_beat: 'text-pink-400 bg-pink-400/10 border-pink-500/15 shadow-[0_0_15px_rgba(244,114,182,0.1)]',
  playlist_inclusion: 'text-violet-400 bg-violet-400/10 border-violet-500/15 shadow-[0_0_15px_rgba(167,139,250,0.1)]',
  verified: 'text-cyan-400 bg-cyan-400/10 border-cyan-500/15 shadow-[0_0_15px_rgba(34,211,238,0.1)]',
  account: 'text-gray-400 bg-gray-400/10 border-gray-500/20 shadow-[0_0_15px_rgba(156,163,175,0.1)]',
  account_updated: 'text-gray-400 bg-gray-400/10 border-gray-500/20 shadow-[0_0_15px_rgba(156,163,175,0.1)]',
  payment: 'text-emerald-400 bg-emerald-400/10 border-emerald-500/15 shadow-[0_0_15px_rgba(52,211,153,0.1)]',
  withdrawal_approved: 'text-green-400 bg-green-400/10 border-green-500/20 shadow-[0_0_15px_rgba(74,222,128,0.1)]',
  withdrawal_rejected: 'text-red-400 bg-red-400/10 border-red-500/30 shadow-[0_0_15px_rgba(248,113,113,0.1)]',
  security: 'text-red-400 bg-red-400/10 border-red-500/15 shadow-[0_0_15px_rgba(248,113,113,0.1)]',
  platform_update: 'text-blue-400 bg-blue-400/10 border-blue-500/15 shadow-[0_0_15px_rgba(96,165,250,0.1)]',
  purchase_confirmed: 'text-emerald-400 bg-emerald-400/10 border-emerald-500/15 shadow-[0_0_15px_rgba(52,211,153,0.1)]'
};

const getInitials = (message: string, title?: string) => {
  const cleanMessage = message || '';
  const cleanTitle = title || '';
  
  const userMatch = cleanMessage.match(/@(\w+)/) || cleanMessage.match(/^([a-zA-Z0-9_\s]{2,20})/);
  let name = userMatch ? userMatch[1].trim() : '';
  
  if (!name && cleanTitle) {
    name = cleanTitle.replace(/Novo|Novo\sComentário!|💬|❤️|💰|👥|💳|Seu|Sua/gi, '').trim();
  }
  
  if (!name || name.length < 2) return 'BT';
  
  const words = name.split(/\s+/);
  if (words.length > 1 && words[1][0]) {
    return (words[0][0] + words[1][0]).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
};

const stripEmojis = (text: string): string => {
  if (!text) return '';
  return text
    .replace(/[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD00-\uDFFF]|\uD83F[\uDC00-\uDFFF]|[\u2600-\u27BF]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
};

const renderNotificationAvatar = (item: any, styleClass: string, Icon: any, size = "w-10 h-10", profilesMap: Record<string, any> = {}) => {
  const isSystemType = [
    'purchase',
    'purchase_confirmed',
    'payment',
    'withdrawal_approved',
    'withdrawal_rejected',
    'verified',
    'account',
    'account_updated',
    'security',
    'platform_update'
  ].includes(item.type);

  if (isSystemType) {
    // Elegant BATUKADA Official Logo / avatar
    return (
      <div className={`${size} rounded-full bg-gradient-to-br from-blue-600 via-indigo-650 to-slate-950 border border-blue-500/30 flex items-center justify-center shadow-[0_0_10px_rgba(59,130,246,0.25)] shrink-0 overflow-hidden relative transition-all duration-300 group-hover:border-blue-400 group-hover:shadow-[0_0_15px_rgba(59,130,246,0.4)]`}>
        <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.15)_0%,rgba(255,255,255,0)_50%)] opacity-60" />
        <svg className="w-5 h-5 text-white/40 absolute" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M6 12V16M9 9V19M12 5V21M15 8V16M18 11V13" strokeLinecap="round" />
        </svg>
        <span className="text-white font-black text-[10.5px] italic tracking-tight relative z-10 select-none">B</span>
      </div>
    );
  }

  let meta = item.metadata;
  if (typeof meta === 'string') {
    try {
      meta = JSON.parse(meta);
    } catch {
      meta = {};
    }
  }

  // Check if there is a bulk-resolved avatar url first!
  const fId = meta?.follower_id || meta?.sender_id || meta?.actor_id;
  let bulkAvatarUrl = null;

  if (fId && profilesMap[fId]?.avatar_url) {
    bulkAvatarUrl = profilesMap[fId].avatar_url;
    console.log('LIVE PROFILE AVATAR BY ID:', bulkAvatarUrl, 'for profile ID:', fId);
  }

  // Check if there is a real avatar/image
  const rawAvatarUrl = bulkAvatarUrl || meta?.sender_avatar || meta?.avatar_url || item.avatar_url;

  console.log('RAW AVATAR URL FOR BUZZIN:', rawAvatarUrl);
  console.log('FULL ITEM:', item);

  if (rawAvatarUrl) {
    console.log('USING IMAGE BRANCH');
    const finalAvatarUrl = rawAvatarUrl.startsWith('http') || rawAvatarUrl.startsWith('/') || rawAvatarUrl.startsWith('data:')
      ? rawAvatarUrl
      : getPublicUrl('avatars', rawAvatarUrl);

    if (bulkAvatarUrl) {
      console.log('LIVE PROFILE AVATAR:', finalAvatarUrl);
    } else {
      console.log('HISTORICAL METADATA AVATAR FALLBACK:', finalAvatarUrl);
    }
    console.log('[NOTIFICATIONS AUDIT] Rendering real avatar URL:', finalAvatarUrl, 'for item:', item.id);
    console.log('RENDERING IMG:', finalAvatarUrl);
    console.log('SIZE CLASS:', size);
    
    return (
      <div className={`${size} rounded-full border border-blue-500/20 shadow-inner overflow-hidden shrink-0 transition-transform group-hover:scale-105 duration-200`}>
        <img
          src={finalAvatarUrl || undefined}
          alt="Avatar"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          onLoad={() => console.log('IMAGE LOADED:', finalAvatarUrl)}
          onError={() => console.log('IMAGE FAILED:', finalAvatarUrl)}
        />
      </div>
    );
  }

  // If music related and has a cover_url, show the cover image circular
  const rawCoverUrl = meta?.cover_url || item.cover_url;
  if (rawCoverUrl && ['upload', 'featured_beat', 'editor_pick', 'beat_trending', 'flash_sale', 'playlist_add', 'playlist_inclusion', 'like', 'comment', 'reply_comment', 'repost'].includes(item.type)) {
    const finalCoverUrl = rawCoverUrl.startsWith('http') || rawCoverUrl.startsWith('/') || rawCoverUrl.startsWith('data:')
      ? rawCoverUrl
      : getPublicUrl('beats', rawCoverUrl);

    return (
      <div className={`${size} rounded-full border border-blue-500/20 shadow-inner overflow-hidden shrink-0 transition-transform group-hover:scale-105 duration-200`}>
        <img
          src={finalCoverUrl || undefined}
          alt="Cover"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          onError={() => console.log('[NOTIFICATIONS AUDIT] IMAGE LOAD FAILED', finalCoverUrl)}
        />
      </div>
    );
  }

  // Custom initials fallback avatar (clean, minimalist, dark/blue, perfectly circular, subtle blue/slate border)
  const cleanInitials = getInitials(item.message, item.title);
  console.log('USING FALLBACK BRANCH');
  return (
    <div className={`${size} rounded-full flex items-center justify-center border border-blue-500/25 bg-gradient-to-br from-[#0a0f1d] to-[#05070d] text-blue-400 font-extrabold text-[10.5px] tracking-wide shrink-0 shadow-sm transition-all duration-200 group-hover:border-blue-400/40 group-hover:text-blue-300`}>
      {cleanInitials}
    </div>
  );
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread' | 'social' | 'music' | 'finance' | 'system'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [profilesMap, setProfilesMap] = useState<Record<string, { avatar_url?: string; username?: string; display_name?: string }>>({});
  const supabase = getSupabase();

  useEffect(() => {
    if (notifications && notifications.length > 0) {
      resolveRelatedProfiles(notifications);
    }
  }, [notifications]);

  const resolveRelatedProfiles = async (items: any[]) => {
    if (!supabase || !items || items.length === 0) return;

    const followerIds = new Set<string>();

    items.forEach(n => {
      let meta = n.metadata;
      if (typeof meta === 'string') {
        try {
          meta = JSON.parse(meta);
        } catch {
          meta = {};
        }
      }
      const fId = meta?.follower_id || meta?.sender_id || meta?.actor_id;
      if (fId) {
        followerIds.add(fId);
      }
    });

    const idList = Array.from(followerIds);

    if (idList.length === 0) return;

    try {
      console.log('[NOTIFICATIONS AUDIT] Resolving related profiles strictly by ID. ID List:', idList);
      let fetchedProfiles: any[] = [];

      if (idList.length > 0) {
        idList.forEach(finalResolvedId => {
          console.log('PROFILE LOOKUP ID:', finalResolvedId);
          console.log('QUERYING PROFILE WITH:', finalResolvedId);
        });

        const { data: byId, error: errId } = await supabase
          .from('profiles')
          .select('id, username, avatar_url, artistic_name, display_name')
          .in('id', idList);
        if (!errId && byId) {
          fetchedProfiles = [...fetchedProfiles, ...byId];
          console.log('[NOTIFICATIONS AUDIT] Fetched profiles by ID:', byId);
        } else if (errId) {
          console.error('[NOTIFICATIONS AUDIT] Error fetching by ID:', errId);
        }
      }

      if (fetchedProfiles.length > 0) {
        const map: Record<string, { avatar_url?: string; username?: string; display_name?: string }> = {};
        fetchedProfiles.forEach(p => {
          if (p.id) {
            map[p.id] = { 
              avatar_url: p.avatar_url, 
              username: p.username,
              display_name: p.artistic_name || p.display_name || p.username
            };
          }
        });
        console.log('[NOTIFICATIONS AUDIT] Resulting Profiles Map (Strict ID-only):', map);
        setProfilesMap(prev => ({ ...prev, ...map }));
      }
    } catch (err) {
      console.error('[NOTIFICATIONS] Error resolving related profiles in bulk:', err);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    if (!supabase) return;
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (data) {
        const unreadCount = data.filter(n => n.read === false).length;
        console.log(`NOTIFICATIONS OPENED: page, count: ${data.length}, unread: ${unreadCount}`);

        if (unreadCount > 0) {
          console.log(`MARKING NOTIFICATIONS AS READ: Auto-marking ${unreadCount} unread notifications as read upon page opening`);
          setNotifications(data.map(n => ({ ...n, read: true }) as Notification));
          console.log('UNREAD NOTIFICATIONS AFTER UPDATE: 0');

          try {
            const res = await fetch("/api/notifications/read-all", {
              method: "POST",
              headers: {
                "Content-Type": "application/json"
              },
              body: JSON.stringify({ userId: user.id })
            });

            if (!res.ok) {
              const errInfo = await res.json().catch(() => ({}));
              console.error('[NOTIFICATIONS] Auto-mark read on page load failure via proxy:', errInfo.error || res.statusText);
              console.log(`NOTIFICATION UPDATE RESULT: error - ${errInfo.error || res.statusText}`);
            } else {
              const result = await res.json();
              console.log(`NOTIFICATION UPDATE RESULT: success, updated entries: ${result.updated}`);
              // Instantly dispatch local notification read trigger
              window.dispatchEvent(new Event('new_notification_received'));
            }
          } catch (err) {
            console.error('[NOTIFICATIONS] Auto-mark read crash:', err);
            console.log(`NOTIFICATION UPDATE RESULT: failed - ${String(err)}`);
          }
        } else {
          setNotifications(data);
        }
      }
    } catch (err) {
      console.error('[NOTIFICATIONS] Load failed:', err);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (id: string) => {
    if (!supabase || isUpdating) return;
    
    setIsUpdating(true);
    const remainingCount = notifications.filter(n => n.id !== id && n.read === false).length;
    console.log(`MARKING NOTIFICATIONS AS READ: marked single notification ID ${id}`);
    // UI Update
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } as any : n));
    console.log(`UNREAD NOTIFICATIONS AFTER UPDATE: ${remainingCount}`);
    
    try {
      const res = await fetch("/api/notifications/read", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ id })
      });
      if (!res.ok) {
        const errInfo = await res.json().catch(() => ({}));
        console.error('[NOTIFICATIONS] Mark read error via proxy:', errInfo.error || res.statusText);
        console.log(`NOTIFICATION UPDATE RESULT: error - ${errInfo.error || res.statusText}`);
      } else {
        const result = await res.json();
        console.log(`NOTIFICATION UPDATE RESULT: success, updated entries: ${result.updated || 1}`);
        window.dispatchEvent(new Event('new_notification_received'));
      }
    } catch (err) {
      console.error('[NOTIFICATIONS] Severe error marking single read:', err);
      console.log(`NOTIFICATION UPDATE RESULT: failed - ${String(err)}`);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleNotificationClick = async (item: any) => {
    console.log('DETAIL CLICK WORKING');
    if (item.read === false) {
      await markAsRead(item.id);
    }

    let targetPath = '';
    switch (item.type) {
      case 'purchase':
      case 'purchase_confirmed':
      case 'payment':
        console.log("[DEBUG] route exists? Yes: /dashboard (Vendas ou Licenças Ativas)");
        localStorage.setItem('producer_dashboard_tab', 'Vendas');
        localStorage.setItem('artist_dashboard_tab', 'Licenças Ativas');
        targetPath = '/dashboard';
        break;

      case 'withdrawal_approved':
      case 'withdrawal_rejected':
        console.log("[DEBUG] route exists? Yes: /dashboard (Carteira)");
        localStorage.setItem('producer_dashboard_tab', 'Carteira');
        targetPath = '/dashboard';
        break;

      case 'upload':
      case 'featured_beat':
      case 'editor_pick':
      case 'beat_trending': {
        let bId = item.metadata?.beat_id || item.metadata?.target_id || item.target_id;
        if (!bId || bId === item.id) {
          const title = extractQuotedTitle(item.message);
          if (title) bId = slugify(title);
        }
        console.log("[DEBUG] route exists? Yes: /beat/" + bId + " or /all-beats");
        if (bId && bId !== item.id) {
          targetPath = `/beat/${bId}`;
        } else {
          targetPath = '/all-beats';
        }
        break;
      }

      case 'flash_sale':
        console.log("[DEBUG] route exists? Yes: /all-beats");
        targetPath = '/all-beats';
        break;

      case 'follower': {
        const targetActorId = item.metadata?.follower_id || item.metadata?.sender_id || item.metadata?.actor_id;
        let fUsername = (targetActorId && profilesMap[targetActorId]?.username) || item.metadata?.follower_username || item.metadata?.username;
        if (!fUsername && item.message && item.message.includes('@')) {
          const match = item.message.match(/@([^ ]+(?:\s+[^ ]+)*?)(?=\s+começou|\s+comecou|\s+is\s+now|\s+started)/i);
          let rawName = match ? match[1] : (item.message.match(/@([^ ]+)/)?.[1] || '');
          if (rawName) {
            rawName = rawName.trim();
            const dbSupabase = getSupabase();
            if (dbSupabase) {
              try {
                const { data: p } = await dbSupabase
                  .from('profiles')
                  .select('username')
                  .or(`username.eq.${rawName},display_name.eq.${rawName},artistic_name.eq.${rawName}`)
                  .maybeSingle();
                if (p && p.username) {
                  fUsername = p.username;
                }
              } catch (err) {
                console.warn("Failed to check profile via supabase query:", err);
              }
            }
            if (!fUsername) {
              fUsername = rawName.toLowerCase().replace(/[^a-z0-9_]/g, '');
            }
          }
        }
        console.log("[DEBUG] follower notification resolved username:", fUsername);
        if (fUsername) {
          targetPath = `/@${fUsername}`;
        } else {
          const fId = item.metadata?.follower_id || item.metadata?.target_id || item.target_id;
          if (fId && fId !== item.id) {
            targetPath = `/@${fId}`;
          } else {
            targetPath = '/feed';
          }
        }
        break;
      }

      case 'like':
      case 'comment':
      case 'reply_comment':
      case 'repost': {
        let bId = item.metadata?.beat_id || item.metadata?.target_id || item.target_id;
        if (!bId || bId === item.id) {
          const title = extractQuotedTitle(item.message);
          if (title) bId = slugify(title);
        }
        console.log("[DEBUG] route exists? Yes: /beat/" + bId + " or /all-beats");
        if (bId && bId !== item.id) {
          targetPath = `/beat/${bId}`;
        } else {
          targetPath = '/all-beats';
        }
        break;
      }

      case 'playlist_add':
      case 'playlist_inclusion': {
        const plId = item.metadata?.playlist_id || item.metadata?.target_id || item.target_id;
        console.log("[DEBUG] route exists? Yes: /playlist/" + plId + " or /feed");
        if (plId && plId !== item.id) {
          targetPath = `/playlist/${plId}`;
        } else {
          targetPath = '/feed';
        }
        break;
      }

      case 'verified':
      case 'account':
      case 'account_updated':
        console.log("[DEBUG] route exists? Yes: /dashboard (Definições ou Meu Perfil)");
        localStorage.setItem('producer_dashboard_tab', 'Definições da Conta');
        localStorage.setItem('artist_dashboard_tab', 'Meu Perfil');
        targetPath = '/dashboard';
        break;

      case 'security':
      case 'platform_update':
        console.log("[DEBUG] route exists? Yes: /notifications");
        targetPath = '/notifications';
        break;

      default:
        console.log("[DEBUG] route exists? Yes (fallback): /notifications");
        targetPath = '/notifications';
        break;
    }

    const finalPath = targetPath || '/notifications';
    setTimeout(() => {
      window.history.pushState({}, '', finalPath);
      window.dispatchEvent(new Event('popstate'));
    }, 100);
  };

  const markAllAsRead = async () => {
    if (!supabase || isUpdating) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setIsUpdating(true);
    console.log(`MARKING NOTIFICATIONS AS READ: manually mark all of them as read`);
    // UI update
    setNotifications(prev => prev.map(n => ({ ...n, read: true } as any)));
    console.log('UNREAD NOTIFICATIONS AFTER UPDATE: 0');

    try {
      const res = await fetch("/api/notifications/read-all", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ userId: user.id })
      });

      if (!res.ok) {
        const errInfo = await res.json().catch(() => ({}));
        console.error('[NOTIFICATIONS] Mark all read error via proxy:', errInfo.error || res.statusText);
        console.log(`NOTIFICATION UPDATE RESULT: error - ${errInfo.error || res.statusText}`);
      } else {
        const result = await res.json();
        console.log(`NOTIFICATION UPDATE RESULT: success, updated entries: ${result.updated}`);
        window.dispatchEvent(new Event('new_notification_received'));
      }
    } catch (err) {
      console.error('[NOTIFICATIONS] Severe error marking all read:', err);
      console.log(`NOTIFICATION UPDATE RESULT: failed - ${String(err)}`);
    } finally {
      setIsUpdating(false);
    }
  };

  const deleteNotification = async (id: string) => {
    if (!supabase) return;
    
    setNotifications(prev => prev.filter(n => n.id !== id));
    
    try {
      const res = await fetch("/api/notifications/delete", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ id })
      });
      if (!res.ok) {
        const errInfo = await res.json().catch(() => ({}));
        console.error('[NOTIFICATIONS] Delete error via proxy:', errInfo.error || res.statusText);
      }
    } catch (err) {
      console.error('[NOTIFICATIONS] Fast delete failed:', err);
    }
  };

  const clearAll = async () => {
    if (!supabase) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setNotifications([]);

    try {
      const res = await fetch("/api/notifications/delete-all", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ userId: user.id })
      });
      if (!res.ok) {
        const errInfo = await res.json().catch(() => ({}));
        console.error('[NOTIFICATIONS] Clear all error via proxy:', errInfo.error || res.statusText);
      }
    } catch (err) {
      console.error('[NOTIFICATIONS] Silent clear failed:', err);
    }
  };

  const filteredNotifications = notifications.filter(n => {
    const isUnread = n.read === false;
    
    const matchesFilter = 
      filter === 'all' || 
      (filter === 'unread' && isUnread) || 
      (filter === 'social' && ['follower', 'like', 'comment', 'reply_comment', 'repost', 'playlist_add'].includes(n.type)) ||
      (filter === 'music' && ['beat_trending', 'editor_pick', 'featured_beat', 'playlist_inclusion', 'featured', 'upload', 'flash_sale'].includes(n.type)) ||
      (filter === 'finance' && ['purchase', 'purchase_confirmed', 'payment', 'withdrawal_approved', 'withdrawal_rejected'].includes(n.type)) ||
      (filter === 'system' && ['verified', 'account', 'account_updated', 'security', 'platform_update'].includes(n.type));
    
    const matchesSearch = 
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      n.message.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-[#000000] pt-32 pb-24 relative overflow-hidden">
      
      {/* Background radial effects */}
      <div className="absolute -top-32 left-1/4 w-[500px] h-[500px] bg-rose-600/[0.04] rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute top-[40%] right-1/4 w-[400px] h-[400px] bg-red-655/[0.03] rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-6 relative z-10">
        
        {/* Modern Instagram-Star Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-12">
          <div>
            <motion.div 
               initial={{ opacity: 0, x: -20 }}
               animate={{ opacity: 1, x: 0 }}
               className="flex items-center gap-3 mb-4"
            >
              <div className="p-3 rounded-2xl bg-rose-500/10 text-rose-500 border border-rose-500/20 shadow-lg shadow-rose-500/5">
                <Bell size={24} className="animate-pulse" />
              </div>
              <span className="text-[10px] font-black text-rose-500 uppercase tracking-[0.45em]">Estúdio Atividades</span>
            </motion.div>
            <motion.h1 
               initial={{ opacity: 0, y: 18 }}
               animate={{ opacity: 1, y: 0 }}
               className="text-5xl md:text-6.5xl font-black text-white italic uppercase tracking-tighter leading-none"
            >
              Suas <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-500 to-pink-500">Notificações</span>
            </motion.h1>
          </div>

          <div className="flex items-center gap-3">
             <button 
               onClick={markAllAsRead}
               className="flex items-center gap-2 px-6 py-4 rounded-2xl bg-white/[0.02] border border-white/10 text-white font-black uppercase tracking-widest text-[9px] hover:bg-white/5 hover:border-rose-505/20 hover:text-rose-400 transition-all active:scale-95 cursor-pointer"
             >
               <CheckCheck size={14} className="text-rose-500" />
               Lidas
             </button>
             <button 
               onClick={clearAll}
               className="flex items-center gap-2 px-6 py-4 rounded-2xl bg-white/[0.02] border border-white/10 text-red-500 font-black uppercase tracking-widest text-[9px] hover:bg-red-500/10 hover:border-red-500/20 hover:text-red-400 transition-all active:scale-95 cursor-pointer"
             >
               <Trash2 size={14} />
               Limpar Tudo
             </button>
          </div>
        </div>

        {/* Toolbar & Filters Column */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
           {/* Futuristic Search bar with glow */}
           <div className="relative flex-grow group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-rose-500 transition-colors" size={20} />
              <input 
                type="text"
                placeholder="Pesquisar notificações, vendas, favoritos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-16 bg-white/[0.02] border border-white/5 rounded-2xl pl-12 pr-6 text-white font-bold outline-none focus:border-rose-500/20 focus:bg-white/[0.03] transition-all"
              />
           </div>

           {/* Responsive 6 Filter Category buttons */}
           <div className="flex items-center gap-1.5 bg-white/[0.01] border border-white/5 rounded-2xl p-1.5 backdrop-blur-3xl overflow-x-auto scrollbar-none">
             {[
               { id: 'all', label: 'Tudo' },
               { id: 'unread', label: 'Não Lidas' },
               { id: 'social', label: 'Social' },
               { id: 'music', label: 'Música' },
               { id: 'finance', label: 'Financeiro' },
               { id: 'system', label: 'Sistema' }
             ].map((opt) => (
               <button
                 key={opt.id}
                 onClick={() => setFilter(opt.id as any)}
                 className={`px-5 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all whitespace-nowrap cursor-pointer ${
                   filter === opt.id 
                     ? 'bg-gradient-to-r from-red-500 to-rose-600 border-rose-500/20 text-white shadow-lg shadow-rose-950/40' 
                     : 'text-gray-500 hover:text-white hover:bg-white/5'
                 }`}
               >
                 {opt.label}
               </button>
             ))}
           </div>
        </div>

        {/* Notifications Grid list */}
        <div className="space-y-3">
          {loading ? (
            <InstagramLoader label="Sincronizando Notificações..." />
          ) : filteredNotifications.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="py-24 flex flex-col items-center justify-center text-center px-12 bg-white/[0.01] border border-white/5 rounded-[2.5rem] backdrop-blur-xl"
            >
              <div className="w-16 h-16 rounded-3xl bg-white/[0.02] border border-white/5 flex items-center justify-center mb-6 text-gray-600">
                <Inbox size={32} className="animate-pulse" />
              </div>
              <h3 className="text-xl font-black text-white italic uppercase tracking-tight mb-2">Sem alertas</h3>
              <p className="text-gray-500 max-w-sm text-xs font-semibold leading-relaxed mb-6">
                Nenhum sinal encontrado nesta aba ou pesquisa. Aproveite o momento de sossego!
              </p>
              <button 
                onClick={() => { setFilter('all'); setSearchQuery(''); }}
                className="px-8 py-3.5 rounded-xl bg-white text-black font-black uppercase tracking-widest text-[10px] hover:scale-105 active:scale-95 transition-all shadow-xl"
              >
                Resetar Filtros
              </button>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 gap-2.5">
              <AnimatePresence initial={false}>
                {filteredNotifications.map((n, index) => {
                  const isUnread = n.read === false;
                  const Icon = NOTIFICATION_ICONS[n.type] || Bell;
                  const colorClass = NOTIFICATION_COLORS[n.type] || 'text-gray-400 bg-gray-400/10 border-gray-500/10';
                  
                  // --- TEMPORARY MANDATORY DEBUG LOGS ---
                  let metaObj = n.metadata;
                  if (typeof metaObj === 'string') {
                    try {
                      metaObj = JSON.parse(metaObj);
                    } catch {
                      metaObj = {};
                    }
                  }
                  const notification = {
                    ...n,
                    user: n.user_id,
                    avatar: profilesMap[metaObj?.follower_id || '']?.avatar_url || metaObj?.sender_avatar || metaObj?.avatar_url || (n as any).avatar_url,
                    follower: metaObj?.follower_id || null
                  };
                  if (n.type === 'follower') {
                    console.log('FULL FOLLOW NOTIFICATION:', n);
                    console.log('notification.user_id:', n.user_id);
                    console.log('metadata.follower_id:', metaObj?.follower_id);
                    console.log('metadata.sender_id:', metaObj?.sender_id);
                    console.log('metadata.actor_id:', metaObj?.actor_id);
                  }
                  console.log('FULL NOTIFICATION:', n);
                  console.log(notification.user);
                  console.log(notification.avatar);
                  console.log(notification.follower);

                  const fId = metaObj?.follower_id || metaObj?.sender_id || metaObj?.actor_id;
                  let displayMessage = stripEmojis(n.message);
                  let displayTitle = stripEmojis(n.title);

                  if (fId) {
                    const resolvedProfile = profilesMap[fId];
                    if (resolvedProfile) {
                      const profileName = resolvedProfile.display_name || resolvedProfile.username || 'Utilizador';
                      if (n.type === 'follower') {
                        displayMessage = `@${profileName} começou a seguir-te!`;
                      } else if (n.type === 'like') {
                        const beatTitleMatch = n.message.match(/gostou do teu beat "(.+)"/i);
                        if (beatTitleMatch) {
                          displayMessage = `${profileName} gostou do teu beat "${beatTitleMatch[1]}".`;
                        } else {
                          displayMessage = `${profileName} gostou do teu beat.`;
                        }
                      } else if (n.type === 'comment') {
                        const commentMatch = n.message.match(/comentou (no teu beat ".+"|aos .+ do teu beat ".+")/i);
                        if (commentMatch) {
                          displayMessage = `${profileName} ${commentMatch[0]}!`;
                        }
                      }
                    } else {
                      // Profile is designated but not found in the database (or deleted)
                      displayMessage = "Utilizador indisponível";
                    }
                  }
                  
                  return (
                    <motion.div
                      key={n.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -30 }}
                      transition={{ delay: Math.min(index * 0.04, 0.4) }}
                      onClick={() => handleNotificationClick(n)}
                      className={`group relative flex flex-col md:flex-row md:items-center gap-5 p-5 rounded-[1.6rem] border transition-all cursor-pointer overflow-hidden ${
                        isUnread 
                          ? 'bg-gradient-to-br from-white/[0.02] to-transparent border-white/10 hover:border-rose-500/20' 
                          : 'bg-transparent border-transparent hover:bg-white/[0.01] hover:border-white/5 opacity-50 hover:opacity-100 transition-opacity'
                      }`}
                    >
                      {/* Left glowing neon edge indicators for unreads */}
                      {isUnread && (
                        <div className="absolute top-0 left-0 bottom-0 w-1 bg-rose-500 shadow-[2px_0_15px_rgba(239,68,68,1)]" />
                      )}

                      {/* Avatar container with overlay badge */}
                      <div className="shrink-0 relative">
                        {renderNotificationAvatar(n, colorClass, Icon, "w-12 h-12", profilesMap)}
                        
                        {/* Action icon absolute overlay */}
                        <div className={`absolute -bottom-1 -right-1 w-5.5 h-5.5 rounded-full border border-[#0d121c] flex items-center justify-center ${colorClass.split(' ')[0]} ${colorClass.split(' ')[1]} bg-[#09090D] shadow`}>
                          <Icon size={10.5} />
                        </div>
                      </div>

                      {/* Card Content Column */}
                      <div className="flex-grow min-w-0 pr-10">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className={`text-[8px] font-black uppercase tracking-widest ${colorClass.split(' ')[0]}`}>
                             {translateNotificationType(n.type)}
                          </span>
                          <span className="text-[8px] text-gray-500 font-bold uppercase tracking-widest">
                            {format(new Date(n.created_at), "dd 'de' MMM, HH:mm", { locale: ptBR })}
                          </span>
                        </div>
                        
                        <h3 className={`text-base font-black text-white uppercase italic tracking-tighter leading-snug truncate ${isUnread ? 'text-rose-400' : ''}`}>
                           {displayTitle}
                        </h3>
                        <p className="text-gray-400 text-xs font-medium leading-relaxed max-w-3xl mt-0.5">
                           {displayMessage}
                        </p>
                      </div>

                      {/* Right action button set on hover */}
                      <div className="absolute top-1/2 -translate-y-1/2 right-5 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button 
                           onClick={(e) => {
                             e.stopPropagation();
                             deleteNotification(n.id);
                           }}
                           className="p-3 rounded-xl bg-red-500/10 text-red-500 border border-red-500/10 hover:bg-rose-600 hover:text-white transition-all active:scale-90 cursor-pointer"
                           title="Eliminar Notificação"
                         >
                           <Trash2 size={14} />
                         </button>
                         <button 
                           className="p-3 rounded-xl bg-white/5 text-gray-400 hover:text-white transition-all active:scale-90"
                         >
                           <ChevronRight size={14} />
                         </button>
                      </div>

                      {/* Mobile unread tiny indicator dot */}
                      {isUnread && (
                        <div className="md:hidden absolute top-5 right-5 w-2 h-2 bg-rose-500 rounded-full shadow-[0_0_8px_rgba(239,68,68,1)] animate-pulse" />
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* Dynamic Personalization controls block */}
        <div className="mt-16 p-8 md:p-10 rounded-[2.5rem] bg-gradient-to-br from-rose-500/5 via-violet-500/5 to-[#050508] border border-white/5 relative overflow-hidden group">
           <div className="absolute top-0 right-0 w-64 h-64 bg-rose-600/10 blur-[100px] rounded-full -z-10 group-hover:scale-130 transition-transform duration-1000" />
           
           <div className="flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
              <div className="text-center md:text-left">
                 <div className="flex items-center justify-center md:justify-start gap-4 mb-3">
                    <div className="p-2.5 rounded-xl bg-rose-500 text-white shadow-xl shadow-rose-600/10">
                       <Settings size={20} className="hover:rotate-45 transition-transform" />
                    </div>
                    <h3 className="text-xl md:text-2xl font-black text-white italic uppercase tracking-tighter">Notificações Ajustadas</h3>
                 </div>
                 <p className="text-gray-500 max-w-md font-medium text-xs leading-relaxed">
                   Determine as preferências de e-mail e alertas sonoros da sua conta para manter o foco total de criação no seu estúdio.
                 </p>
              </div>
              <button 
                onClick={() => alert("As preferências de notificação foram sincronizadas localmente com sucesso.")}
                className="px-8 py-4 rounded-xl bg-white text-black font-black uppercase tracking-widest text-[9px] shadow-2xl hover:scale-105 active:scale-95 transition-all cursor-pointer"
              >
                 Definições Rápidas
              </button>
           </div>
        </div>

      </div>
    </div>
  );
}
