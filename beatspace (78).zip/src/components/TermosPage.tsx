import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, FileText, ShieldAlert, Award, Landmark, UserCheck, HelpCircle } from 'lucide-react';

export default function TermosPage({ onBack }: { onBack: () => void }) {
  const [selectedDoc, setSelectedDoc] = useState<'platform' | 'basic' | 'premium' | 'exclusive'>('platform');

  const buyerMock = {
    name: "Artista Licenciado (Exemplo)",
    producer: "Soba Beats (Produtor Registado)",
    beat: "Afro Beat Luanda (Original Mix)",
    date: "24 de Maio de 2026",
    orderId: "BAT-77C1E4F9",
    bpm: "115 BPM",
    genre: "Afro House / Kuduro",
    price: "75.000 Kz"
  };

  // Helper clause data definition based on chosen license model
  const getClauseDetails = (type: 'basic' | 'premium' | 'exclusive') => {
    switch(type) {
      case 'basic':
        return {
          formats: "Ficheiro de Áudio comprimido de alta qualidade em formato MP3 (320kbps).",
          streams: "Até 5.000 (Cinco Mil) reproduções de áudio monetizadas em plataformas como Spotify, Apple Music e YouTube.",
          sales: "Distribuição física acumulada permitida até 50 (cinquenta) cópias físicas (CDs, cassetes ou pen-drives).",
          commercial: "Não autorizado para exibições e reproduções de canais de TV de grande público ou publicidade de âmbito corporativo.",
          exclusivity: "NÃO-EXCLUSIVO. O Produtor retém 100% dos direitos de continuar a comercializar e licenciar este instrumental para terceiros na plataforma.",
          ownership: "O Licenciado adquire apenas direitos não-exclusivos temporários e limitados de reprodução de áudio. Todas as masters originais permanecem sob controle titular do Produtor."
        };
      case 'premium':
        return {
          formats: "Ficheiros de Alta Definição: Master WAV (24-bit de estúdio) e MP3 (320kbps).",
          streams: "Até 50.000 (Cinquenta Mil) reproduções de áudio monetizadas em plataformas como Spotify, Apple Music e YouTube.",
          sales: "Distribuição física acumulada permitida até 500 (quinhentas) cópias físicas (CDs, cassetes ou pen-drives).",
          commercial: "Autorizado o uso comercial para transmissão em rádios locais e comunitárias angolanas. Sincronização permitida em 1 (um) videoclipe oficial monetizado no YouTube com limite de 50.000 visualizações.",
          exclusivity: "NÃO-EXCLUSIVO. Esta licença estende os direitos de rádio e áudio-visual. O instrumental permanece ativo para venda a outros membros.",
          ownership: "O Licenciado adquire direitos de exploração comercial ampliados, permanecendo o copyright da composição musical sob a titularidade originária do Produtor."
        };
      case 'exclusive':
        return {
          formats: "Ficheiros Completos de Produção: Faixas Separadas (Stems / Trackouts individuais em alta definição WAV), ficheiro Master WAV unificado e MP3.",
          streams: "ILIMITADO (Canais de streaming digitais como Spotify, Apple Music, YouTube Music sem qualquer barreira ou teto).",
          sales: "Distribuição física ILIMITADA (LPs, CDs, Cassetes, Pen-Drives promocionais).",
          commercial: "Videoclipes ilimitados com monetização ativa sem restrição de reproduções ou visualizações nas plataformas.",
          exclusivity: "EXCLUSIVIDADE ABSOLUTA E VITALÍCIA. A partir da confirmação desta transação, o instrumental é retirado de forma permanente do mercado da BATUKADA. Nenhuma nova licença para este instrumental será concedida.",
          ownership: "O Licenciado obtém a propriedade exclusiva da Gravação Master contendo a nova canção vocalizada. O Produtor original retém 50% dos direitos patrimoniais de composição e autor intelectual (Publisher/Direitos Autorais), devendo o Licenciado declarar as devidas parcerias aos órgãos conexos e sociedades representativas relevantes em Angola."
        };
    }
  };

  const clause = selectedDoc !== 'platform' ? getClauseDetails(selectedDoc) : null;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8 animate-in fade-in duration-500">
      
      {/* Header section with back button */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/10">
        <div>
          <button 
            onClick={onBack} 
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-all group mb-3 cursor-pointer"
          >
            <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
            <span className="text-xs font-bold uppercase tracking-widest">Voltar</span>
          </button>
          <div className="flex items-center gap-4">
            <img 
              src="https://i.ibb.co/hF1MD85X/20260523-155411.png" 
              className="w-12 h-12 object-contain filter drop-shadow-[0_2px_8px_rgba(245,158,11,0.25)]" 
              referrerPolicy="no-referrer"
              alt="BATUKADA Logo" 
            />
            <div>
              <h1 className="text-4xl font-black text-white italic uppercase tracking-tighter">
                TERMOS & <span className="text-amber-500">CONTRATOS</span>
              </h1>
              <p className="text-gray-400 text-xs uppercase tracking-widest font-bold">Assessoria jurídica e diretórios de licenciamento</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Selector System */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 bg-white/5 p-1.5 rounded-2xl border border-white/5">
        <button 
          onClick={() => setSelectedDoc('platform')}
          className={`px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
            selectedDoc === 'platform' 
              ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/10' 
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          Termos de Uso
        </button>
        <button 
          onClick={() => setSelectedDoc('basic')}
          className={`px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
            selectedDoc === 'basic' 
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/10' 
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          Licença Básica
        </button>
        <button 
          onClick={() => setSelectedDoc('premium')}
          className={`px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
            selectedDoc === 'premium' 
              ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/10' 
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          Licença Premium
        </button>
        <button 
          onClick={() => setSelectedDoc('exclusive')}
          className={`px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
            selectedDoc === 'exclusive' 
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/10' 
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          Licença Exclusiva
        </button>
      </div>

      {/* RENDER PLATFORM GENERAL TERMS */}
      {selectedDoc === 'platform' && (
        <div className="space-y-8 bg-white/5 border border-white/10 rounded-3xl p-6 md:p-10 text-gray-300 leading-relaxed text-sm">
          <div className="border-l-4 border-amber-500 pl-4 py-1 mb-6">
            <h3 className="text-white text-base font-black uppercase tracking-wider">Regulamento de Uso do Marketplace</h3>
            <p className="text-xs text-gray-400">Última atualização: Maio de 2026</p>
          </div>

          <section className="space-y-3">
            <h2 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
              <CheckCircle2 size={16} className="text-amber-500" />
              1. Aceitação dos Termos e Escopo Geral
            </h2>
            <p>
              Ao registrar uma conta, realizar uploads, ou concluir transações no marketplace da BATUKADA, você declara possuir plena capacidade civil e concorda de forma inequívoca em observar todas as diretrizes estipuladas no presente conjunto voluntário de termos. Este documento regulamenta a mediação tecnológica fornecida para facilitar as transações de masters originais entre licenciadores independentes de som e produtores profissionais e artistas angolanos.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
              <CheckCircle2 size={16} className="text-amber-500" />
              2. Identidade Artística e Perfis Digitais
            </h2>
            <p>
              Durante o cadastramento na plataforma, os vendedores têm a obrigação contratual de declarar o seu correspondente <strong>Nome Artístico Principal</strong>. Este nome servirá como identificação e chancela jurídica de autoria e propriedade intelectual em todas as masterizações fornecidas. Não é autorizada a adoção de termos abusivos, de reputação escusa de terceiros, marcas registradas protegidas globalmente ou identidades fingidas de outros músicos nacionais.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
              <CheckCircle2 size={16} className="text-amber-500" />
              3. Comercialização, Publicação e Garantias do Autor
            </h2>
            <p>
              A BATUKADA atua unicamente como portal facilitador e intermediário de hospedagem e faturamento eletrônico. Ao enviar instrumentais, pacotes de samples ou drumkits ao catálogo público, o Vendedor garante e subscreve a autoria primitiva absoluta da obra, afirmando que a obra não transgride nenhum direito conexo de terceiros, sob as devidas penalidades da Lei n.º 15/14 de Proteção dos Direitos de Autor e Conexos de Angola.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
              <CheckCircle2 size={16} className="text-amber-500" />
              4. Pagamento Seguro e Transferência Automática de Direitos
            </h2>
            <p>
              Todas as transações do marketplace são processadas e faturadas em Kwanzas (AOA) de forma integrada, mediante referências oficiais Multicaixa ou transferência bancária confirmada digitalmente pelo administrador. Uma vez chancelado e liquidado o pagamento de correspondente categoria de licença, os arquivos de áudio e os correspondentes contratos digitais vinculados são desbloqueados na conta do Artista Comprador em tempo real.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
              <CheckCircle2 size={16} className="text-amber-500" />
              5. Mudanças e Reformas nos Termos de Uso
            </h2>
            <p>
              A diretoria técnica da BATUKADA reserva-se o absoluto e discricionário direito de reestruturar, aditar ou modificar qualquer cláusula dos presentes termos a qualquer momento, de modo a refletir eventuais adaptações ou imperativos de regulação tributária em Luanda. A utilização continuada da plataforma após tais atualizações constituirá aceitação tácita e integral.
            </p>
          </section>
        </div>
      )}

      {/* RENDER MODEL LICENSES / CONTRACTS TAB */}
      {selectedDoc !== 'platform' && clause && (
        <div className="space-y-6">
          
          {/* Top warning alert */}
          <div className="p-4 bg-amber-500/10 border border-amber-500/30 text-amber-500 rounded-2xl flex items-center gap-4 text-xs font-bold leading-normal">
            <ShieldAlert size={18} className="shrink-0" />
            <p>
              Exibição de Contrato Geral e Padrão para fins de consulta e auditoria jurídica antes de efetuar transações na BATUKADA. Este documento reflete exatamente a estrutura jurídica e o tamanho dos contratos exportados via PDF pela plataforma.
            </p>
          </div>

          {/* MOCK LEGAL PAPER CONTAINER (STUNNING TYPOGRAPHY AND DETAIL) */}
          <div className="bg-stone-900 border-2 border-stone-800 rounded-[2.5rem] p-6 sm:p-12 text-stone-300 font-sans shadow-2xl relative overflow-hidden text-xs sm:text-sm leading-relaxed antialiased">
            
            {/* Header Border Strip */}
            <div className="absolute top-0 inset-x-0 h-2 bg-amber-500" />
            
            {/* Inner frame */}
            <div className="border border-stone-800 p-6 sm:p-8 space-y-8">
              
              {/* Document Stamp logo */}
              <div className="text-center space-y-2">
                <h3 className="font-black text-2xl tracking-widest text-[#F59E0B] italic uppercase">▲ BATUKADA</h3>
                <p className="text-[10px] tracking-widest font-mono text-stone-500">CONTRATO MODELO DE EXPORTAÇÃO AUTOMÁTICA • CHANCELA DIGITAL</p>
                <div className="w-16 h-0.5 bg-amber-500/30 mx-auto mt-2" />
              </div>

              {/* Header Box */}
              <div className="bg-stone-950 p-6 border border-stone-800 rounded-2xl grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p><strong className="text-amber-500">CÓDIGO DE REGISTO DIGITAL:</strong> <span className="font-mono">{buyerMock.orderId}</span></p>
                  <p><strong className="text-amber-500">CATEGORIA DE LICENÇA:</strong> <span className="uppercase font-bold">{selectedDoc} License</span></p>
                  <p><strong className="text-amber-500">DATA DA ASSINATURA:</strong> {buyerMock.date}</p>
                </div>
                <div className="space-y-2">
                  <p><strong className="text-amber-500">REGISTADO EM LUANDA, ANGOLA:</strong> SIM</p>
                  <p><strong className="text-amber-500">TEMPO DE VALIDADE:</strong> VITALÍCIA / INDETERMINADA</p>
                  <p><strong className="text-amber-500">BPM / GÉNERO:</strong> {buyerMock.bpm} • {buyerMock.genre}</p>
                </div>
              </div>

              {/* 16 DETAILED PARAGRAPHS */}
              <div className="space-y-6">
                
                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">1. Identificação Formal e Qualificação das Partes</h4>
                  <p>
                    O presente instrumento particular de contrato comercial regula de forma irrevogável e definitiva o faturamento entre o <strong>PRODUTOR/LICENCIADOR</strong>, doravante denominado simplesmente como <em>{buyerMock.producer}</em>, e o <strong>ARTISTA COMPRADOR</strong>, designado sob os termos como <em>{buyerMock.name}</em>, sob representação e chancelamento do portal BATUKADA.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">2. Direitos de Utilização Autorizados</h4>
                  <p>
                    O Produtor confere expressamente ao Comprador autorização temporária e vitalícia aplicável globalmente para fundar vocais, letras de composição escrita própria, sobrepostas diretas à master do instrumental original {buyerMock.beat}. 
                    Os formatos inclusos nesta categoria de licença compreendem: <span className="text-white italic font-bold">{clause.formats}</span>.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">3. Restrições e Limitações de Utilização Coletiva</h4>
                  <p>
                    É vedada ao Licenciado a prática de isolamento isolado de ondas sintéticas, loops de bateria ou de percussão, arranjamento individual de trechos melódicos simplificados para revenda subsequente ou publicação em diretórios de drum kits. Fica expressamente vedado o registo do instrumental puro (sem vocais) no Content ID de qualquer plataforma de distribuição, sob risco de banimento de canais e indenizações civis associados.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">4. Streaming Geral e Plataformas Digitais de Áudio</h4>
                  <p>
                    A veiculação e publicidade monetizada em portais modernos de streaming (incluindo Spotify, Apple Music, Deezer, TikTok) está restrita aos limites de tráfego desta categoria:
                    <br />
                    <span className="text-white font-bold block mt-1">Limite Estabelecido: {clause.streams}</span>
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">5. Vendas Físicas de Cópias no Mercado</h4>
                  <p>
                    É permitida a fabricação e venda física direta de álbuns, cassetes ou discos nos seguintes parâmetros acordados:
                    <br />
                    <span className="text-white font-bold block mt-1">Limite de Vendas Física: {clause.sales}</span>
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">6. Uso Comercial em Áudio-Visual e Sincronismo</h4>
                  <p>
                    Os limites para publicação em videoclipes ou trilhas sonoras estão condicionados ao seguinte:
                    <br />
                    <span className="text-white font-bold block mt-1">{clause.commercial}</span>
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">7. Propriedade Intelectual (Copyright)</h4>
                  <p>
                    A estrutura técnica, harmonia, arranjo e mixes do instrumental permanecem sob autoria integral e propriedade intelectual conexa originária do Produtor. 
                    No registo das sociedades de proteção de direitos no território angolano ou de outros países correlatos, os percentuais de direitos autorais de <strong>COMPOSIÇÃO MUSICAL (ROYALTY SPLIT)</strong> deverão ser obrigatoriamente declarados a contar em 50% (cinquenta por cento) para o Produtor original e 50% (cinquenta por cento) para o Artista.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">8. Crédito Obrigatório do Autor Original</h4>
                  <p>
                    O Artista Licenciado obriga-se civilmente a declarar de forma explícita e escrita o devido crédito do autor do som em qualquer publicação na web, descrições do YouTube, perfis de redes sociais e capas físicas de álbuns equivalentes. 
                    O formato exigido é: <span className="text-white italic">"Produzido por {buyerMock.producer}"</span> ou <span className="text-white italic">"Prod. {buyerMock.producer}"</span>.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">9. Proibição Absoluta de Revenda e Repasse de Amostras</h4>
                  <p>
                    Esta licença destina-se ao usufruto personalíssimo e indissociável do Artista Licenciado. Sob hipótese alguma o comprador poderá doar, alugar, penhorar, revender ou ceder cópias para parceiros ou bandas locais de gravação.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-805 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">10. Proibição de Pirataria Digital Compartilhada</h4>
                  <p>
                    O armazenamento e downloads subsequentes do instrumental são restritos aos estúdios de produção privada do comprador. Links abertos em diretórios desprotegidos na nuvem ou canais abertos violam estes termos legais de segurança conexos.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">11. Regulação de Direitos de Tráfego de Exclusividade e Ownership</h4>
                  <p>
                    <span className="text-white block font-bold mb-1">{clause.exclusivity}</span>
                    <span className="text-stone-400 block mt-1">{clause.ownership}</span>
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">12. Do Inadimplemento e Consequências por Infrações</h4>
                  <p>
                    Qualquer desvio intencional das cláusulas acordadas, em especial a ultrapassagem de streams estipulados ou a ocultação consciente de créditos, constitui uma infração sujeita a interrupções automáticas de reprodução sob os termos da Lei de Direitos de Autor e Conexos de Angola.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">13. Política de Reembolso Voluntário de Materiais Digitais</h4>
                  <p>
                    Tendo em vista a natureza irrevogável e instantânea do download direto e decifrado do instrumental, todos os valores faturados na transação {buyerMock.price} são definitivos e destituídos de reembolsos por retratação.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">14. Rescisão Definitiva dos Direitos de Distribuição</h4>
                  <p>
                    Caso ocorra qualquer fraude bancária do Multicaixa ou difamação agressiva contra o produtor, todos os direitos de uso são cancelados, devendo as cópias digitais e físicas serem apagadas imediatamente sob pena de litigação civil.
                  </p>
                </section>

                <section className="space-y-2 border-b border-stone-800/50 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">15. Jurisdição e Foro de Competência</h4>
                  <p>
                    Este contrato é integralmente fundamentado e interpretado em estrita sintonia com os estatutos e regulamentos da República de Angola. Decisões de litigação serão submetidas ao Foro da Comarca de Luanda, renunciando expressamente a quaisquer outros correspondentes.
                  </p>
                </section>

                <section className="space-y-2 pb-4">
                  <h4 className="text-sm font-black text-white uppercase tracking-wider text-amber-500">16. Assinatura Eletrônica das Partes</h4>
                  <p>
                    Ambas as partes declaram concordância expressa e vincular jurídica ao fechar a compra digital no marketplace BATUKADA, validando o hashing seguro de chave digital do negócio por criptografia.
                  </p>
                </section>

              </div>

              {/* Visual Digital Signature Block */}
              <div className="pt-8 border-t border-stone-800 grid grid-cols-1 md:grid-cols-2 gap-8 text-xs font-mono">
                <div className="space-y-2 p-4 bg-stone-950 rounded-xl border border-stone-800">
                  <p className="text-stone-500 font-sans uppercase">Assinatura do Vendedor:</p>
                  <p className="text-amber-500 font-mono italic font-bold">[ASSINADO: SOBA BEATS MASTERID-S991]</p>
                  <p className="text-[10px] text-stone-600">VALIDADO ELETRONICAMENTE - BATUKADA REGISTRY</p>
                </div>
                <div className="space-y-2 p-4 bg-stone-950 rounded-xl border border-stone-800">
                  <p className="text-stone-500 font-sans uppercase">Assinatura do Artista:</p>
                  <p className="text-blue-500 font-mono italic font-bold">[ASSINADO: {buyerMock.name.toUpperCase()}]</p>
                  <p className="text-[10px] text-stone-600">VALIDADO ELETRONICAMENTE - ARTISTA COMPRADOR</p>
                </div>
              </div>

              <div className="p-4 bg-stone-950 border border-stone-800 rounded-xl text-center text-[10px] font-mono text-stone-500">
                HASH DE DESPACHO SEGURO: F54EB2D27A7182C0E81177AC129BC9CA8C1277DA
              </div>

            </div>
          </div>

        </div>
      )}

    </div>
  );
}
