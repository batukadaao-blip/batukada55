
import React from 'react';
import { 
  Instagram, 
  Youtube, 
  Twitter, 
  MessageSquare, 
  Music,
  Send,
  ShieldCheck,
  Globe,
  ChevronDown,
  Mail,
  Smartphone
} from 'lucide-react';
import { motion } from 'motion/react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative pt-16 pb-12 overflow-hidden border-t border-white/10 bg-[#08080a] select-none text-left">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 mb-12 lg:mb-16">
          
          {/* Brand Section */}
          <div className="lg:col-span-4 space-y-6 text-left">
            <div className="flex items-center justify-start">
              <img
                src="https://i.ibb.co/kVskdWvb/batukada.png"
                alt="Batukada"
                className="h-8 md:h-9 w-auto object-contain shrink-0"
              />
            </div>
            
            <p className="text-gray-400 text-xs leading-relaxed max-w-sm font-medium">
              A maior plataforma angolana para produtores publicarem e comercializarem beats, drum kits e loop kits profissionalmente. Promovendo o talento nacional para o resto do mundo.
            </p>

            <div className="flex justify-start gap-2.5 pt-1">
              {[
                { icon: Instagram, href: 'https://www.instagram.com/batukada.co', target: '_blank', rel: 'noopener noreferrer' },
                { icon: Youtube, href: '#' },
                { icon: Twitter, href: '#' },
                { icon: MessageSquare, href: '#' },
                { icon: Smartphone, href: '#' }
              ].map((social, i) => (
                <motion.a
                  key={i}
                  href={social.href}
                  target={social.target}
                  rel={social.rel}
                  whileHover={{ y: -1 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-8 h-8 rounded bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 hover:border-white/20 transition-all duration-200 cursor-pointer"
                >
                  <social.icon size={13} className="stroke-[1.5]" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Links Sections */}
          <div className="lg:col-span-1" /> {/* Spacer */}
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:col-span-7 gap-8 text-left">
            <div className="space-y-4">
              <h3 className="text-white font-semibold text-xs tracking-wider uppercase">Marketplace</h3>
              <ul className="space-y-2.5">
                {['Explorar Beats', 'Kits', 'Produtores', 'Trending'].map((link) => (
                  <li key={link}>
                    <a href="#" className="text-gray-400 hover:text-white text-xs font-medium transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="text-white font-semibold text-xs tracking-wider uppercase">Empresa</h3>
              <ul className="space-y-2.5">
                {['Sobre Nós', 'Contacto', 'Blog', 'Carreiras'].map((link) => (
                  <li key={link}>
                    <a href="#" className="text-gray-400 hover:text-white text-xs font-medium transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="text-white font-semibold text-xs tracking-wider uppercase">Legais & Ajuda</h3>
              <ul className="space-y-2.5">
                {['Licenciamento', 'FAQ', 'Suporte', 'Termos'].map((link) => (
                  <li key={link}>
                    <a href="#" className="text-gray-400 hover:text-white text-xs font-medium transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Newsletter & Trust Banner */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center py-8 md:py-10 border border-white/10 bg-[#0c0c0e]/60 rounded-xl px-6 md:px-10 backdrop-blur-sm mb-10 md:mb-14 shadow-lg text-left">
          <div className="space-y-2">
            <div className="flex items-center justify-start gap-2.5">
              <div className="p-1.5 rounded bg-white/5 text-gray-300">
                <Mail size={14} className="stroke-[1.5]" />
              </div>
              <h3 className="text-sm font-bold text-white tracking-tight uppercase">Fique por dentro</h3>
            </div>
            <p className="text-gray-400 text-xs font-medium pl-1">
              Receba novos beats, novidades e kits recomendados diretamente no seu email.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-grow relative w-full">
              <input 
                type="email" 
                placeholder="Introduza o seu email" 
                className="w-full bg-[#131317] border border-white/10 rounded-lg py-3 pl-4 pr-12 text-white text-xs font-medium focus:border-[#5865F2] outline-none transition-all placeholder-gray-500 text-left"
              />
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="absolute right-1.5 top-1.5 bottom-1.5 aspect-square rounded bg-white text-black hover:bg-gray-200 transition-colors flex items-center justify-center cursor-pointer shadow-sm"
              >
                <Send size={11} className="stroke-[2]" />
              </motion.button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 md:gap-4 pt-6 border-t border-white/5 text-left w-full">
          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8 w-full md:w-auto">
            <p className="text-gray-400 text-xs font-medium text-center md:text-left">
              © {currentYear} <span className="text-white font-semibold">BATUKADA</span>. Todos os direitos reservados.
            </p>
            
            <div className="flex items-center gap-6 justify-center">
              <a href="#" className="text-gray-400 hover:text-white text-xs font-medium transition-colors">Privacidade</a>
              <a href="#" className="text-gray-400 hover:text-white text-xs font-medium transition-colors">Termos</a>
            </div>
          </div>

          <div className="flex flex-col items-center sm:flex-row gap-4 md:gap-6 w-full md:w-auto">
            {/* Trust Badges */}
            <div className="flex items-center gap-2 text-gray-400">
              <ShieldCheck size={14} className="stroke-[1.5]" />
              <span className="text-xs font-medium">Pagamentos 100% Seguros</span>
            </div>

            {/* Language Selector */}
            <button className="flex items-center gap-2 px-3 py-1.5 rounded bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:border-white/20 transition-all group cursor-pointer">
              <Globe size={12} className="group-hover:text-[#5865F2] transition-colors stroke-[1.5]" />
              <span className="text-xs font-medium">Português (AO)</span>
              <ChevronDown size={10} className="opacity-50 stroke-[1.5]" />
            </button>
          </div>
        </div>
      </div>

      {/* Modern line accent at the very bottom */}
      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-white/5" />
    </footer>
  );
}
