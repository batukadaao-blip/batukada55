import { useState, useEffect, useRef } from 'react';
import { Search, X, Music, User, Disc, CornerDownLeft } from 'lucide-react';
import { getSupabase } from '../lib/supabase';

interface SearchResultBeat {
  id: string | number;
  title: string;
  category: string | null;
  cover_url: string | null;
  artist_name: string | null;
  genre: string | null;
  producer_id: string;
}

interface SearchResultProfile {
  id: string;
  username: string;
  display_name: string | null;
  artistic_name: string | null;
  avatar_url: string | null;
  role: string | null;
}

export default function SearchBar() {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  
  // Results grouped
  const [beats, setBeats] = useState<SearchResultBeat[]>([]);
  const [kits, setKits] = useState<SearchResultBeat[]>([]);
  const [creators, setCreators] = useState<SearchResultProfile[]>([]);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const mobileInputRef = useRef<HTMLInputElement>(null);

  // Debounced query logic to prevent aggressive DB querying
  useEffect(() => {
    if (!query.trim()) {
      setBeats([]);
      setKits([]);
      setCreators([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const delayDebounceFn = setTimeout(async () => {
      try {
        const supabase = getSupabase();
        if (!supabase) return;

        const searchText = query.trim();

        // 1. Fetch relevant beats
        const { data: beatsData, error: beatsErr } = await supabase
          .from('beats')
          .select('id, producer_id, title, category, cover_url, artist_name, genre')
          .or(`title.ilike.%${searchText}%,genre.ilike.%${searchText}%,artist_name.ilike.%${searchText}%`)
          .limit(8);

        // 2. Fetch relevant profiles (creators, artists, buyers)
        const { data: profilesData, error: profilesErr } = await supabase
          .from('profiles')
          .select('id, username, display_name, artistic_name, avatar_url, role')
          .or(`display_name.ilike.%${searchText}%,username.ilike.%${searchText}%,artistic_name.ilike.%${searchText}%`)
          .limit(5);

        if (beatsErr) console.warn('[SEARCH] Beats search error:', beatsErr);
        if (profilesErr) console.warn('[SEARCH] Profiles search error:', profilesErr);

        if (beatsData) {
          // Categorize into beats and kits
          const allBeats = beatsData as SearchResultBeat[];
          const filteredBeats = allBeats.filter(
            b => b.category !== 'Loop Kit' && b.category !== 'Drum Kit'
          );
          const filteredKits = allBeats.filter(
            b => b.category === 'Loop Kit' || b.category === 'Drum Kit'
          );

          setBeats(filteredBeats.slice(0, 4));
          setKits(filteredKits.slice(0, 4));
        }

        if (profilesData) {
          setCreators(profilesData as SearchResultProfile[]);
        }
      } catch (err) {
        console.error('[SEARCH] Dynamic search request error:', err);
      } finally {
        setIsLoading(false);
      }
    }, 250); // 250ms debounce

    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  // Click outside to close dropdown menu (for desktop view)
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // ESC Listener to close or clear
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Escape') {
      setQuery('');
      setIsFocused(false);
      inputRef.current?.blur();
      mobileInputRef.current?.blur();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      triggerGlobalSearch();
    }
  };

  const triggerGlobalSearch = () => {
    if (!query.trim()) return;
    
    // Smooth transition to results page
    const searchUrl = `/all-beats?q=${encodeURIComponent(query.trim())}`;
    window.history.pushState({}, '', searchUrl);
    window.dispatchEvent(new Event('popstate'));
    
    // Close overlay state
    setIsFocused(false);
    setIsMobileOpen(false);
  };

  const handleSelectResult = (type: 'beat' | 'creator' | 'kit', item: any) => {
    let path = '/';
    if (type === 'beat' || type === 'kit') {
      path = `/beat/${item.id}`;
    } else if (type === 'creator') {
      path = `/@${item.username || item.id}`;
    }

    window.history.pushState({}, '', path);
    window.dispatchEvent(new Event('popstate'));

    setQuery('');
    setIsFocused(false);
    setIsMobileOpen(false);
  };

  // Pre-formatted Supabase Storage cover image links
  const getCoverUrl = (path: string | null): string | null => {
    if (!path || !path.trim()) return null;
    if (path.startsWith('http')) return path;
    const supabase = getSupabase();
    if (!supabase) return null;
    const { data } = supabase.storage.from('beats').getPublicUrl(path);
    return data?.publicUrl || null;
  };

  const getProfileAvatar = (path: string | null): string | null => {
    if (!path || !path.trim()) return null;
    if (path.startsWith('http')) return path;
    const supabase = getSupabase();
    if (!supabase) return null;
    const { data } = supabase.storage.from('avatars').getPublicUrl(path);
    return data?.publicUrl || null;
  };

  const hasAnyResults = beats.length > 0 || kits.length > 0 || creators.length > 0;

  return (
    <div ref={containerRef} className="relative z-50 flex items-center justify-center">
      
      {/* 1. Desktop & Tablet Inline Search Input */}
      <div className="hidden md:flex items-center relative w-full">
        <div 
          className={`flex items-center border h-[42px] rounded-xl w-full ${
            isFocused 
              ? 'bg-white/[0.06] border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.4)]' 
              : 'bg-white/[0.03] border-white/[0.06] hover:bg-white/[0.05] hover:border-white/[0.12]'
          }`}
        >
          <Search className="ml-4 text-neutral-500 shrink-0 mr-1.5 transition-colors duration-300" size={15} strokeWidth={2} />
          <input
            id="0ldvkz"
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onKeyDown={handleKeyDown}
            placeholder="Pesquisar beats, produtores..."
            className="w-full min-w-0 bg-transparent pr-4 pl-0 py-2 text-[12.5px] text-neutral-200 placeholder-neutral-500 focus:outline-none h-full font-sans leading-none"
          />
          {query && (
            <button 
              onClick={() => { setQuery(''); inputRef.current?.focus(); }}
              className="mr-3 text-neutral-500 hover:text-white transition-colors duration-150 py-1"
            >
              <X size={13} />
            </button>
          )}
        </div>

        {/* Floating Minimalist Dropdown menu for Desktop search */}
        {isFocused && (query.trim() || isLoading) && (
          <div className="absolute top-[50px] left-0 w-full bg-[#050505] border border-white/[0.06] rounded-[12px] shadow-[0_16px_40px_rgba(0,0,0,0.95)] overflow-hidden text-left p-3.5 flex flex-col gap-3 font-sans max-h-[500px] overflow-y-auto z-[200]">
            
            {isLoading && (
              <div className="text-[10px] text-neutral-500 py-4 text-center tracking-wider">
                Pesquisando base de dados...
              </div>
            )}

            {!isLoading && !hasAnyResults && (
              <div className="text-[10px] text-neutral-500 py-4 text-center tracking-wider">
                Nenhum resultado para "{query}"
              </div>
            )}

            {!isLoading && hasAnyResults && (
              <>
                {/* 1. Beats list */}
                {beats.length > 0 && (
                  <div className="flex flex-col gap-1">
                    <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest px-2 pb-1">
                      Beats
                    </span>
                    {beats.map((beat) => (
                      <button
                        key={beat.id}
                        onClick={() => handleSelectResult('beat', beat)}
                        className="flex items-center gap-2.5 p-1.5 hover:bg-white/[0.04] rounded-md transition-all text-left w-full cursor-pointer group"
                      >
                        <div className="w-8 h-8 rounded bg-neutral-950 border border-white/5 overflow-hidden flex items-center justify-center shrink-0">
                          {getCoverUrl(beat.cover_url) ? (
                            <img 
                              src={getCoverUrl(beat.cover_url) || undefined} 
                              alt={beat.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200" 
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <Music size={12} className="text-neutral-500" />
                          )}
                        </div>
                        <div className="min-w-0 flex-grow">
                          <p className="text-[11px] font-semibold text-white truncate leading-tight group-hover:text-[#5865F2] transition-colors">
                            {beat.title}
                          </p>
                          <p className="text-[9px] text-neutral-500 truncate mt-0.5">
                            {beat.artist_name || 'BATUKADA Beat'} · {beat.genre || 'Geral'}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}

                {/* 2. Sound Kits list */}
                {kits.length > 0 && (
                  <div className="flex flex-col gap-1 border-t border-white/[0.04] pt-2">
                    <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest px-2 pb-1">
                      Sound Kits & Loops
                    </span>
                    {kits.map((kit) => (
                      <button
                        key={kit.id}
                        onClick={() => handleSelectResult('kit', kit)}
                        className="flex items-center gap-2.5 p-1.5 hover:bg-white/[0.04] rounded-md transition-all text-left w-full cursor-pointer group"
                      >
                        <div className="w-8 h-8 rounded bg-neutral-950 border border-white/5 overflow-hidden flex items-center justify-center shrink-0">
                          {getCoverUrl(kit.cover_url) ? (
                            <img 
                              src={getCoverUrl(kit.cover_url) || undefined} 
                              alt={kit.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200" 
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <Disc size={12} className="text-neutral-400" />
                          )}
                        </div>
                        <div className="min-w-0 flex-grow">
                          <p className="text-[11px] font-semibold text-white truncate leading-tight group-hover:text-[#5865F2] transition-colors">
                            {kit.title}
                          </p>
                          <p className="text-[9px] text-neutral-500 truncate mt-0.5">
                            {kit.category || 'Sound Kit'}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}

                {/* 3. Profiles / Authors list */}
                {creators.length > 0 && (
                  <div className="flex flex-col gap-1 border-t border-white/[0.04] pt-2">
                    <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest px-2 pb-1">
                      Produtores e Artistas
                    </span>
                    {creators.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => handleSelectResult('creator', p)}
                        className="flex items-center gap-2.5 p-1.5 hover:bg-white/[0.04] rounded-md transition-all text-left w-full cursor-pointer group"
                      >
                        <div className="w-8 h-8 rounded-full bg-neutral-950 border border-white/5 overflow-hidden flex items-center justify-center shrink-0">
                          {getProfileAvatar(p.avatar_url) ? (
                            <img 
                              src={getProfileAvatar(p.avatar_url) || undefined} 
                              alt={p.username}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200" 
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <User size={12} className="text-neutral-500" />
                          )}
                        </div>
                        <div className="min-w-0 flex-grow">
                          <p className="text-[11px] font-semibold text-white truncate leading-tight group-hover:text-[#5865F2] transition-colors">
                            @{p.username || 'creator'}
                          </p>
                          <p className="text-[9px] text-neutral-500 truncate mt-0.5 capitalize">
                            {p.artistic_name || p.display_name || p.role || 'Produtor'}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}

                <button
                  onClick={triggerGlobalSearch}
                  className="w-full flex items-center justify-between mt-1 text-[10px] font-semibold text-neutral-400 hover:text-white hover:bg-white/[0.05] p-2 rounded-md transition-colors border-t border-white/[0.04]"
                >
                  <span>Ver todos os resultados para "{query}"</span>
                  <CornerDownLeft size={10} className="opacity-60" />
                </button>
              </>
            )}

          </div>
        )}
      </div>

      {/* 2. Responsive Search Icon (Mobile View) */}
      <div className="md:hidden">
        <button 
          onClick={() => setIsMobileOpen(true)}
          className="p-1.5 text-neutral-400 hover:text-white hover:bg-white/5 rounded transition-all duration-150 active:scale-95 flex items-center justify-center cursor-pointer"
        >
          <Search size={15} strokeWidth={2} />
        </button>
      </div>

      {/* 3. Mobile Search Overlay Screen Modal */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-[1000] bg-[#050505] flex flex-col p-4 md:hidden">
          
          {/* Header row */}
          <div className="flex items-center gap-3 w-full pb-3 border-b border-white/[0.06]">
            <Search className="text-neutral-500 shrink-0" size={16} />
            <input
              ref={mobileInputRef}
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Pesquisar batidas, autores, sound kits..."
              className="flex-grow bg-transparent py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none font-sans"
            />
            <button 
              onClick={() => setIsMobileOpen(false)}
              className="text-neutral-400 hover:text-white text-xs font-semibold px-2"
            >
              Fechar
            </button>
          </div>

          {/* Results Area for mobile screen */}
          <div className="flex-grow overflow-y-auto py-4 flex flex-col gap-5">
            {isLoading && (
              <div className="text-[11px] text-neutral-500 py-6 text-center tracking-wider font-sans">
                Pesquisando base de dados...
              </div>
            )}

            {!isLoading && !query.trim() && (
              <div className="text-[11px] text-neutral-500 py-6 text-center tracking-wide font-sans">
                Digite termos para procurar na plataforma.
              </div>
            )}

            {!isLoading && query.trim() && !hasAnyResults && (
              <div className="text-[11px] text-neutral-500 py-6 text-center tracking-wider font-sans">
                Nenhum resultado para "{query}"
              </div>
            )}

            {!isLoading && query.trim() && hasAnyResults && (
              <div className="flex flex-col gap-5">
                {/* Micro beats and kits result listings */}
                {beats.length > 0 && (
                  <div className="flex flex-col gap-2">
                    <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">
                      Beats
                    </span>
                    {beats.map((beat) => (
                      <div
                        key={beat.id}
                        onClick={() => handleSelectResult('beat', beat)}
                        className="flex items-center gap-3 p-2 bg-white/[0.02] border border-white/[0.04] rounded-lg cursor-pointer"
                      >
                        <div className="w-10 h-10 rounded bg-neutral-900 overflow-hidden flex items-center justify-center shrink-0 border border-white/5">
                          {getCoverUrl(beat.cover_url) ? (
                            <img src={getCoverUrl(beat.cover_url) || undefined} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <Music size={14} className="text-neutral-500" />
                          )}
                        </div>
                        <div className="min-w-0 flex-grow">
                          <p className="text-xs font-bold text-white truncate">{beat.title}</p>
                          <p className="text-[10px] text-neutral-400 truncate mt-0.5">{beat.artist_name || 'BATUKADA'} · {beat.genre || 'Geral'}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {kits.length > 0 && (
                  <div className="flex flex-col gap-2">
                    <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">
                      Sound Kits
                    </span>
                    {kits.map((kit) => (
                      <div
                        key={kit.id}
                        onClick={() => handleSelectResult('kit', kit)}
                        className="flex items-center gap-3 p-2 bg-white/[0.02] border border-white/[0.04] rounded-lg cursor-pointer"
                      >
                        <div className="w-10 h-10 rounded bg-neutral-900 overflow-hidden flex items-center justify-center shrink-0 border border-white/5">
                          {getCoverUrl(kit.cover_url) ? (
                            <img src={getCoverUrl(kit.cover_url) || undefined} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <Disc size={14} className="text-neutral-400" />
                          )}
                        </div>
                        <div className="min-w-0 flex-grow">
                          <p className="text-xs font-bold text-white truncate">{kit.title}</p>
                          <p className="text-[10px] text-neutral-400 truncate mt-0.5">{kit.category || 'Sound Kit'}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {creators.length > 0 && (
                  <div className="flex flex-col gap-2">
                    <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">
                      Produtores e Artistas
                    </span>
                    {creators.map((p) => (
                      <div
                        key={p.id}
                        onClick={() => handleSelectResult('creator', p)}
                        className="flex items-center gap-3 p-2 bg-white/[0.02] border border-white/[0.04] rounded-lg cursor-pointer"
                      >
                        <div className="w-10 h-10 rounded-full bg-neutral-900 overflow-hidden flex items-center justify-center shrink-0 border border-white/5">
                          {getProfileAvatar(p.avatar_url) ? (
                            <img src={getProfileAvatar(p.avatar_url) || undefined} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <User size={14} className="text-neutral-500" />
                          )}
                        </div>
                        <div className="min-w-0 flex-grow">
                          <p className="text-xs font-bold text-white truncate">@{p.username}</p>
                          <p className="text-[10px] text-neutral-400 truncate mt-0.5 capitalize">{p.artistic_name || p.display_name || 'Produtor'}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <button
                  onClick={triggerGlobalSearch}
                  className="w-full py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded-lg text-xs font-bold transition-all text-center mt-2 cursor-pointer"
                >
                  Pesquisar globalmente por "{query}"
                </button>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
