import React from 'react';
import { motion } from 'motion/react';
import { 
  X, 
  Bell, 
  Calendar, 
  ArrowUpRight, 
  User, 
  Music, 
  DollarSign, 
  CheckCircle, 
  Zap, 
  Heart, 
  MessageSquare, 
  Radio, 
  Shield, 
  Info, 
  Award, 
  TrendingUp, 
  Sparkles,
  ExternalLink,
  ChevronRight,
  FolderOpen
} from 'lucide-react';
import { getSupabase, getPublicUrl } from '../lib/supabase';

// Map icons
const NOTIFICATION_ICONS: Record<string, any> = {
  purchase: DollarSign,
  upload: Music,
  flash_sale: Zap,
  featured: Sparkles,
  follower: User,
  like: Heart,
  comment: MessageSquare,
  reply_comment: MessageSquare,
  playlist_add: FolderOpen,
  repost: Radio,
  beat_trending: TrendingUp,
  editor_pick: Award,
  featured_beat: Sparkles,
  playlist_inclusion: Radio,
  verified: CheckCircle,
  account: User,
  account_updated: User,
  payment: DollarSign,
  withdrawal_approved: ArrowUpRight,
  withdrawal_rejected: X,
  security: Shield,
  platform_update: Info,
  purchase_confirmed: CheckCircle
};

// Map color classes
const NOTIFICATION_COLORS: Record<string, { bg: string; text: string; glow: string }> = {
  purchase: { bg: 'bg-emerald-500/10 border-emerald-500/20', text: 'text-emerald-400', glow: 'shadow-emerald-950/20' },
  upload: { bg: 'bg-indigo-500/10 border-indigo-500/20', text: 'text-indigo-400', glow: 'shadow-indigo-950/20' },
  flash_sale: { bg: 'bg-sky-500/10 border-sky-500/20', text: 'text-sky-400', glow: 'shadow-sky-950/20' },
  featured: { bg: 'bg-blue-500/10 border-blue-500/20', text: 'text-blue-300', glow: 'shadow-blue-950/20' },
  follower: { bg: 'bg-blue-500/10 border-blue-500/20', text: 'text-blue-400', glow: 'shadow-blue-950/20' },
  like: { bg: 'bg-rose-500/10 border-rose-500/20', text: 'text-rose-400', glow: 'shadow-rose-950/20' },
  comment: { bg: 'bg-slate-500/10 border-slate-500/20', text: 'text-slate-300', glow: 'shadow-slate-950/20' },
  reply_comment: { bg: 'bg-slate-500/10 border-slate-500/20', text: 'text-slate-400', glow: 'shadow-slate-950/20' },
  playlist_add: { bg: 'bg-violet-500/10 border-violet-500/20', text: 'text-violet-400', glow: 'shadow-violet-950/20' },
  repost: { bg: 'bg-sky-500/10 border-sky-500/20', text: 'text-sky-450', glow: 'shadow-sky-950/20' },
  beat_trending: { bg: 'bg-indigo-500/10 border-indigo-500/20', text: 'text-indigo-400', glow: 'shadow-indigo-950/20' },
  editor_pick: { bg: 'bg-blue-500/10 border-blue-500/20', text: 'text-blue-400', glow: 'shadow-blue-950/20' },
  featured_beat: { bg: 'bg-indigo-500/10 border-indigo-500/20', text: 'text-indigo-300', glow: 'shadow-indigo-950/20' },
  playlist_inclusion: { bg: 'bg-sky-500/10 border-sky-500/20', text: 'text-sky-300', glow: 'shadow-sky-950/20' },
  verified: { bg: 'bg-blue-500/10 border-blue-500/20', text: 'text-blue-400', glow: 'shadow-blue-950/20' },
  account: { bg: 'bg-slate-500/10 border-slate-500/20', text: 'text-slate-400', glow: 'shadow-slate-950/20' },
  account_updated: { bg: 'bg-slate-500/10 border-slate-500/20', text: 'text-slate-400', glow: 'shadow-slate-950/20' },
  payment: { bg: 'bg-emerald-500/10 border-emerald-500/20', text: 'text-emerald-400', glow: 'shadow-emerald-950/20' },
  withdrawal_approved: { bg: 'bg-blue-500/10 border-blue-500/20', text: 'text-blue-400', glow: 'shadow-blue-950/20' },
  withdrawal_rejected: { bg: 'bg-rose-500/10 border-rose-500/30', text: 'text-rose-400', glow: 'shadow-rose-950/20' },
  security: { bg: 'bg-blue-500/10 border-blue-500/20', text: 'text-blue-500', glow: 'shadow-blue-950/20' },
  platform_update: { bg: 'bg-indigo-500/10 border-indigo-500/20', text: 'text-indigo-400', glow: 'shadow-indigo-950/20' },
  purchase_confirmed: { bg: 'bg-emerald-500/10 border-emerald-500/20', text: 'text-emerald-400', glow: 'shadow-emerald-950/20' }
};

function translateNotificationType(type: string): string {
  const mapping: Record<string, string> = {
    purchase: 'COMPRA',
    purchase_confirmed: 'COMPRA CONFIRMADA',
    payment: 'PAGAMENTO',
    withdrawal_approved: 'SAQUE APROVADO',
    withdrawal_rejected: 'SAQUE REJEITADO',
    upload: 'NOVO BEAT',
    featured_beat: 'BEAT EM DESTAQUE',
    editor_pick: 'ESCOLHA DOS EDITORES',
    beat_trending: 'BEAT TENDÊNCIA',
    flash_sale: 'PROMOÇÃO RELÂMPAGO',
    follower: 'NOVO SEGUIDOR',
    like: 'GOSTEI',
    comment: 'NOVO COMENTÁRIO',
    reply_comment: 'RESPOSTA A COMENTÁRIO',
    repost: 'REPOST',
    playlist_add: 'ADICIONADO À PLAYLIST',
    playlist_inclusion: 'INCLUSÃO DE PLAYLIST',
    verified: 'PERFIL VERIFICADO',
    account: 'SISTEMA DE CONTA',
    account_updated: 'CONTA ATUALIZADA',
    security: 'ALERTA DE SEGURANÇA',
    platform_update: 'RECURSO DE PLATAFORMA',
  };
  return mapping[type] || type.replace('_', ' ').toUpperCase();
}

function stripEmojis(text: string): string {
  if (!text) return '';
  return text
    .replace(/[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD00-\uDFFF]|\uD83F[\uDC00-\uDFFF]|[\u2600-\u27BF]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
}

interface NotificationDetailModalProps {
  notification: any;
  onClose: () => void;
  onDropdownClose?: () => void;
}

export default function NotificationDetailModal({ 
  notification, 
  onClose,
  onDropdownClose 
}: NotificationDetailModalProps) {
  if (!notification) return null;

  const [liveAvatar, setLiveAvatar] = React.useState<string | null>(null);
  const [liveDisplayName, setLiveDisplayName] = React.useState<string | null>(null);
  const [liveUsername, setLiveUsername] = React.useState<string | null>(null);

  React.useEffect(() => {
    const fetchLiveProfile = async () => {
      const sb = getSupabase();
      if (!sb) return;

      let meta = notification.metadata || {};
      if (typeof meta === 'string') {
        try {
          meta = JSON.parse(meta);
        } catch {
          meta = {};
        }
      }
      
      const fId = meta?.follower_id || meta?.sender_id || meta?.actor_id;

      try {
        let profileData: any = null;

        if (fId) {
          const { data } = await sb.from('profiles').select('avatar_url, display_name, artistic_name, username').eq('id', fId).maybeSingle();
          if (data) {
            profileData = data;
          } else {
            // Profile has an fId but was not found in the DB (deleted account)
            setLiveDisplayName("Utilizador indisponível");
          }
        }

        if (profileData) {
          if (profileData.avatar_url) {
            setLiveAvatar(profileData.avatar_url);
            console.log('LIVE PROFILE AVATAR:', profileData.avatar_url);
          }
          const bestName = profileData.artistic_name || profileData.display_name || profileData.username;
          if (bestName) {
            setLiveDisplayName(bestName);
          }
          if (profileData.username) {
            setLiveUsername(profileData.username);
          }
        }
      } catch (err) {
        console.error('Error fetching live profile in detail modal:', err);
      }
    };

    fetchLiveProfile();
  }, [notification]);

  const IconComponent = NOTIFICATION_ICONS[notification.type] || Bell;
  const colors = NOTIFICATION_COLORS[notification.type] || { bg: 'bg-white/5 border-white/10', text: 'text-slate-400', glow: '' };
  
  // Format dates elegantly
  const formatFullDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString('pt-AO', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    } catch (e) {
      return 'Recente';
    }
  };

  const getInitials = (message: string, title?: string) => {
    const cleanMessage = message || '';
    const cleanTitle = title || '';
    
    const userMatch = cleanMessage.match(/@(\w+)/) || cleanMessage.match(/^([a-zA-Z0-9_\s]{2,20})/);
    let name = userMatch ? userMatch[1].trim() : '';
    
    if (!name && cleanTitle) {
      name = cleanTitle.replace(/Novo|Novo\sComentário!|💬|❤️|💰|👥|💳|Seu|Sua/gi, '').trim();
    }
    
    if (!name || name.length < 2) return 'BT';
    
    const words = name.split(/\s+/);
    if (words.length > 1 && words[1][0]) {
      return (words[0][0] + words[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  // Determine navigation target paths (real route redirection list)
  const handleActionClick = async () => {
    let targetPath = '';

    switch (notification.type) {
      case 'purchase':
      case 'purchase_confirmed':
      case 'payment':
        localStorage.setItem('producer_dashboard_tab', 'Vendas');
        localStorage.setItem('artist_dashboard_tab', 'Licenças Ativas');
        targetPath = '/dashboard';
        break;

      case 'withdrawal_approved':
      case 'withdrawal_rejected':
        localStorage.setItem('producer_dashboard_tab', 'Carteira');
        targetPath = '/dashboard';
        break;

      case 'upload':
      case 'featured_beat':
      case 'editor_pick':
      case 'beat_trending': {
        const bId = notification.metadata?.beat_id || notification.metadata?.target_id || notification.target_id;
        if (bId && bId !== notification.id) {
          targetPath = `/beat/${bId}`;
        } else {
          targetPath = '/all-beats';
        }
        break;
      }

      case 'flash_sale':
        targetPath = '/all-beats';
        break;

      case 'follower': {
        let fUsername = liveUsername || notification.metadata?.follower_username || notification.metadata?.username;
        if (!fUsername && notification.message && notification.message.includes('@')) {
          const match = notification.message.match(/@([^ ]+(?:\s+[^ ]+)*?)(?=\s+começou|\s+comecou|\s+is\s+now|\s+started)/i);
          let rawName = match ? match[1] : (notification.message.match(/@([^ ]+)/)?.[1] || '');
          if (rawName) {
            rawName = rawName.trim();
            const dbSupabase = getSupabase();
            if (dbSupabase) {
              try {
                const { data: p } = await dbSupabase
                  .from('profiles')
                  .select('username')
                  .or(`username.eq.${rawName},display_name.eq.${rawName},artistic_name.eq.${rawName}`)
                  .maybeSingle();
                if (p && p.username) {
                  fUsername = p.username;
                }
              } catch (err) {
                console.warn("Error profile sync checking:", err);
              }
            }
            if (!fUsername) {
              fUsername = rawName.toLowerCase().replace(/[^a-z0-9_]/g, '');
            }
          }
        }
        if (fUsername) {
          targetPath = `/@${fUsername}`;
        } else {
          const fId = notification.metadata?.follower_id || notification.metadata?.target_id || notification.target_id;
          if (fId && fId !== notification.id) {
            targetPath = `/@${fId}`;
          } else {
            targetPath = '/feed';
          }
        }
        break;
      }

      case 'like':
      case 'comment':
      case 'reply_comment':
      case 'repost': {
        const bId = notification.metadata?.beat_id || notification.metadata?.target_id || notification.target_id;
        if (bId && bId !== notification.id) {
          targetPath = `/beat/${bId}`;
        } else {
          targetPath = '/all-beats';
        }
        break;
      }

      case 'playlist_add':
      case 'playlist_inclusion': {
        const plId = notification.metadata?.playlist_id || notification.metadata?.target_id || notification.target_id;
        if (plId && plId !== notification.id) {
          targetPath = `/playlist/${plId}`;
        } else {
          targetPath = '/feed';
        }
        break;
      }

      case 'verified':
      case 'account':
      case 'account_updated':
        localStorage.setItem('producer_dashboard_tab', 'Definições da Conta');
        localStorage.setItem('artist_dashboard_tab', 'Meu Perfil');
        targetPath = '/dashboard';
        break;

      case 'security':
      case 'platform_update':
        targetPath = '/notifications';
        break;

      default:
        targetPath = '/notifications';
        break;
    }

    const finalPath = targetPath || '/notifications';
    window.history.pushState({}, '', finalPath);
    window.dispatchEvent(new Event('popstate'));
    
    // Close modal
    onClose();
    // Close parent dropdown menu if provided
    if (onDropdownClose) {
      onDropdownClose();
    }
  };

  // Render contextualized information based on notification metadata
  const renderMetadataDetails = () => {
    const meta = notification.metadata || {};
    const hasKeys = Object.keys(meta).length > 0;

    // Is there follower info?
    const isFollower = notification.type === 'follower';
    // Is there financial/purchase?
    const isFinance = ['purchase', 'purchase_confirmed', 'payment', 'withdrawal_approved', 'withdrawal_rejected'].includes(notification.type);
    // Is it beat interaction (like, comment, upload, etc)?
    const isBeatRelated = ['like', 'comment', 'reply_comment', 'upload', 'featured_beat', 'editor_pick', 'beat_trending'].includes(notification.type);
    
    const isSystemType = [
      'verified',
      'account',
      'account_updated',
      'security',
      'platform_update'
    ].includes(notification.type);

    if (isSystemType) {
      return (
        <div className="bg-[#121319]/60 border border-white/5 rounded-2xl p-4 flex flex-col items-center text-center space-y-3 relative overflow-hidden backdrop-blur-sm shadow-xl">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-600 via-indigo-650 to-slate-950 border border-blue-500/30 flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.35)] overflow-hidden relative">
              <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.15)_0%,rgba(255,255,255,0)_50%)] opacity-60" />
              <svg className="w-8 h-8 text-white/30 absolute" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 12V16M9 9V19M12 5V21M15 8V16M18 11V13" strokeLinecap="round" />
              </svg>
              <span className="text-white font-[950] text-lg italic tracking-tight relative z-10 select-none">B</span>
            </div>
            <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white rounded-full p-1.5 border border-[#121319]">
              <CheckCircle size={12} strokeWidth={2.5} />
            </div>
          </div>
          <div>
            <h6 className="text-sm font-bold text-white leading-none mb-1">BATUKADA Oficial</h6>
            <p className="text-[10px] text-slate-500 font-semibold tracking-wider uppercase">Mensagem oficial do Sistema</p>
          </div>
          <div className="text-[10.5px] text-slate-400 max-w-[260px] mx-auto leading-relaxed">
            Esta é uma notificação validada e processada automaticamente pela plataforma BATUKADA.
          </div>
        </div>
      );
    }

    if (isFollower) {
      const fName = stripEmojis(liveDisplayName || meta.follower_name || meta.display_name || meta.username || meta.follower_username || 'Novo Seguidor');
      const fUsername = meta.follower_username || meta.username || '';
      const fAvatar = liveAvatar || meta.sender_avatar || meta.avatar_url || notification.avatar_url;
      let resolvedUrl = '';
      if (fAvatar) {
        resolvedUrl = fAvatar.startsWith('http') || fAvatar.startsWith('/') || fAvatar.startsWith('data:') ? fAvatar : getPublicUrl('avatars', fAvatar);
        if (liveAvatar) {
          console.log('LIVE PROFILE AVATAR:', resolvedUrl);
        } else {
          console.log('HISTORICAL METADATA AVATAR FALLBACK:', resolvedUrl);
        }
        console.log('[NOTIFICATIONS DETAIL MODAL AUDIT] Rendering real avatar URL:', resolvedUrl);
        console.log('RENDERING IMG:', resolvedUrl);
      }

      return (
        <div className="bg-[#121319]/60 border border-white/5 rounded-2xl p-4 flex flex-col items-center text-center space-y-3 relative overflow-hidden backdrop-blur-sm shadow-xl">
          <div className="relative">
            {fAvatar ? (
              <img 
                src={resolvedUrl || undefined} 
                alt={fName} 
                className="w-16 h-16 rounded-full object-cover border-2 border-blue-500/30 shadow-[0_0_12px_rgba(59,130,246,0.2)]"
                referrerPolicy="no-referrer"
                onLoad={() => console.log('IMAGE LOADED:', resolvedUrl)}
                onError={() => console.log('IMAGE FAILED:', resolvedUrl)}
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#0a0f1d] to-[#05070d] border border-blue-500/25 text-blue-400 font-extrabold text-xl flex items-center justify-center shadow-[0_0_12px_rgba(59,130,246,0.15)] select-none">
                {getInitials(notification.message, notification.title)}
              </div>
            )}
            <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white rounded-full p-1.5 border border-[#121319]">
              <User size={12} strokeWidth={2} />
            </div>
          </div>
          <div>
            <h6 className="text-sm font-bold text-white leading-none mb-1">{fName}</h6>
            {fUsername && <p className="text-xs text-slate-500 font-medium">@{fUsername}</p>}
          </div>
          <div className="text-[10.5px] text-slate-400 max-w-[260px] mx-auto leading-relaxed">
            Siga de volta ou acesse o perfil de criação dele para ver novos ritmos e criar colabs.
          </div>
        </div>
      );
    }

    if (isFinance) {
      const isDeclined = notification.type === 'withdrawal_rejected';
      const amount = meta.amount || meta.price || '';
      const orderId = meta.order_id || meta.transaction_id || '';
      const licType = meta.license_type || meta.license || '';
      const beatName = meta.beat_title || meta.title || '';

      return (
        <div className="bg-gradient-to-b from-[#121319]/85 to-[#0b0c10] border border-white/5 rounded-2xl p-5 relative overflow-hidden shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Comprovativo Digital</span>
            <span className={`text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded ${
              isDeclined ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
            }`}>
              {isDeclined ? 'Rejeitado' : 'Processado'}
            </span>
          </div>

          <div className="space-y-3.5">
            {amount && (
              <div className="text-center py-2">
                <p className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Valor total</p>
                <h3 className={`text-2xl font-black italic tracking-tighter ${isDeclined ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {amount}
                </h3>
              </div>
            )}

            <div className="grid grid-cols-2 gap-y-3 gap-x-2 text-xs border-t border-white/[0.03] pt-3.5 font-sans">
              {beatName && (
                <div>
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block mb-0.5">Beat Relacionado</span>
                  <span className="text-white font-bold max-w-[150px] truncate block">{beatName}</span>
                </div>
              )}
              {licType && (
                <div>
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block mb-0.5">Tipo de Licença</span>
                  <span className="text-neutral-300 font-semibold uppercase tracking-wide text-[10px]">{licType}</span>
                </div>
              )}
              {orderId && (
                <div className="col-span-2">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block mb-0.5">ID da Transação / Pedido</span>
                  <span className="text-slate-400 font-mono text-[10px] bg-white/[0.02] border border-white/5 px-2 py-0.5 rounded truncate block">{orderId}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }

    if (isBeatRelated) {
      const beatName = meta.beat_title || meta.title || '';
      const bCover = meta.cover_url || notification.cover_url;
      const bGenre = meta.genre || '';
      const bBpm = meta.bpm || '';

      if (beatName || bCover) {
        return (
          <div className="bg-[#121319]/60 border border-white/5 rounded-2xl p-4 flex items-center gap-4 relative overflow-hidden backdrop-blur-sm shadow-xl">
            <div className="w-16 h-16 rounded-xl overflow-hidden border border-white/[0.1] shrink-0 relative bg-[#09090D] flex items-center justify-center shadow-lg group-hover:scale-105">
              {bCover ? (
                <img 
                  src={(bCover.startsWith('http') || bCover.startsWith('/') || bCover.startsWith('data:') ? bCover : getPublicUrl('beats', bCover)) || undefined} 
                  alt={beatName} 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[#1d273a] to-[#0d121c] text-blue-400">
                  <Music size={22} className="opacity-75" />
                </div>
              )}
            </div>
            <div className="flex-grow min-w-0">
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block mb-0.5">Beat Associado</span>
              <h6 className="text-sm font-bold text-white italic uppercase tracking-tight truncate leading-tight mb-1">{beatName}</h6>
              <div className="flex items-center gap-2">
                {bGenre && (
                  <span className="text-[9px] bg-blue-500/10 border border-blue-500/20 text-blue-400 px-2 py-0.5 rounded font-bold uppercase tracking-wide">
                    {bGenre}
                  </span>
                )}
                {bBpm && (
                  <span className="text-[9.5px] text-slate-500 font-mono">
                    {bBpm} BPM
                  </span>
                )}
              </div>
            </div>
          </div>
        );
      }
    }

    if (!hasKeys) {
      return (
        <div className="bg-[#121319]/45 border border-white/5 rounded-2xl p-4 flex items-center justify-center text-center">
          <p className="text-slate-500 text-xs font-semibold">
            Sem detalhes adicionais disponíveis.
          </p>
        </div>
      );
    }

    return (
      <div className="bg-[#121319]/45 border border-white/5 rounded-2xl p-4 flex items-center justify-center text-center">
        <p className="text-slate-500 text-xs font-semibold">
          Sem detalhes adicionais disponíveis.
        </p>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-[10010] flex items-center justify-center p-4 cursor-default pointer-events-auto">
      {/* Blurred overlay */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/80 backdrop-blur-md z-[10011]"
      />

      {/* Main modal dialog */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ type: 'spring', damping: 26, stiffness: 240 }}
        className="bg-[#08090d] border border-white/[0.06] rounded-[2rem] w-full max-w-[460px] overflow-hidden relative shadow-[0_0_60px_rgba(59,130,246,0.12)] flex flex-col z-[10012] pointer-events-auto"
      >
        {/* Glow neon accents */}
        <div className="absolute top-0 right-0 w-52 h-52 bg-blue-600/[0.04] rounded-full blur-[70px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-52 h-52 bg-indigo-600/[0.03] rounded-full blur-[70px] pointer-events-none" />

        {/* Modal Top header */}
        <div className="p-6 border-b border-white/5 flex items-center justify-between relative bg-white/[0.005]">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center border ${colors.bg} ${colors.text} ${colors.glow}`}>
              <IconComponent size={16} />
            </div>
            <div>
              <p className="text-[9px] font-black tracking-widest text-[#5865f2] uppercase leading-none mb-0.5">
                {translateNotificationType(notification.type)}
              </p>
              <h4 className="text-xs font-semibold text-slate-400 tracking-wide leading-none">Dossier de Notificação</h4>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/[0.02] border border-white/5 hover:border-blue-500/20 text-gray-400 hover:text-blue-400 hover:bg-blue-950/20 transition-all duration-300 cursor-pointer"
          >
            <X size={14} />
          </button>
        </div>

        {/* Modal Core scrolling page body */}
        <div className="p-6 space-y-5 overflow-y-auto custom-scrollbar max-h-[460px] relative">
          <div className="space-y-2">
            <h3 className="text-base font-black italic text-white uppercase tracking-tight leading-snug">
              {stripEmojis(notification.title)}
            </h3>
            <p className="text-slate-300 text-xs font-medium leading-relaxed font-sans">
              {stripEmojis(notification.message)}
            </p>
          </div>

          {/* Time & Dates Info section */}
          <div className="flex items-center gap-2 text-[10.5px] text-slate-500 font-medium">
            <Calendar size={12} className="text-slate-600 shrink-0" />
            <span>Emitido em {formatFullDate(notification.created_at)}</span>
          </div>

          {/* Dynamic contextual section render */}
          <div className="pt-2">
            {renderMetadataDetails()}
          </div>
        </div>

        {/* Modal Bottom Footer Action Trigger */}
        <div className="p-5 border-t border-white/5 bg-[#030305] flex items-center gap-3">
          <button 
            onClick={onClose}
            className="flex-1 py-3 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] text-slate-400 hover:text-white text-[11px] font-bold uppercase tracking-wider transition-all cursor-pointer"
          >
            Fechar detalhes
          </button>
          <button 
            onClick={handleActionClick}
            className="flex-1 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-650 hover:from-blue-500 hover:to-indigo-600 text-white text-[11px] font-bold uppercase tracking-wider transition-all scale-100 active:scale-95 shadow-md flex items-center justify-center gap-1.5 group cursor-pointer"
          >
            <span>Ver na plataforma</span>
            <ArrowUpRight size={12} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

      </motion.div>
    </div>
  );
}
