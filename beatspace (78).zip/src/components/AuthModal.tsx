import React, { useState, useEffect } from 'react';
import { getSupabase } from '../lib/supabase';
import { X, ArrowLeft, ShieldCheck, Disc, Headphones, Check, ArrowRight, Sparkles } from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { sendNotification } from '../lib/notifications';
import { motion, AnimatePresence } from 'motion/react';

export default function AuthModal({ isOpen, onClose, initialMode = 'login', onAuthSuccess, onNavigateToTerms }: { isOpen: boolean, onClose: () => void, initialMode?: 'login' | 'signup', onAuthSuccess?: (role: string) => void, onNavigateToTerms?: () => void }) {
  const { showToast } = useToast();
  const [isLogin, setIsLogin] = useState(initialMode === 'login');
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const [isCheckingUsername, setIsCheckingUsername] = useState(false);
  const [isUsernameAvailable, setIsUsernameAvailable] = useState<boolean | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [reason, setReason] = useState<'seller' | 'buyer' | null>(null);
  const [step, setStep] = useState<1 | 2>(1);
  const [isLoading, setIsLoading] = useState(false);

  const validateUsername = (value: string) => {
    const cleaned = value.trim();
    if (!cleaned) {
      return 'O username é obrigatório.';
    }
    const regex = /^[a-z0-9._]+$/;
    if (!regex.test(cleaned)) {
      if (/\s/.test(value)) {
        return 'O username não pode conter espaços.';
      }
      return 'Apenas são permitidos: letras minúsculas, números, . e _';
    }
    return null;
  };

  // Real-time username check with debounce
  useEffect(() => {
    if (isLogin || step !== 2 || !username) {
      setIsUsernameAvailable(null);
      setUsernameError(null);
      return;
    }

    const clean = username.toLowerCase().trim();
    const errorMsg = validateUsername(clean);
    
    if (errorMsg) {
      setUsernameError(errorMsg);
      setIsUsernameAvailable(false);
      return;
    } else {
      setUsernameError(null);
    }

    const supabase = getSupabase();
    if (!supabase) {
      // Mock validation for Sandbox/Demo
      setIsCheckingUsername(true);
      const timer = setTimeout(() => {
        setIsCheckingUsername(false);
        if (clean === 'admin' || clean === 'produtor' || clean === 'vendedor') {
          setIsUsernameAvailable(false);
          setUsernameError('Este username já está em uso.');
        } else {
          setIsUsernameAvailable(true);
          setUsernameError(null);
        }
      }, 500);
      return () => clearTimeout(timer);
    }

    setIsCheckingUsername(true);
    const delayDebounceFn = setTimeout(async () => {
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('id')
          .eq('username', clean)
          .maybeSingle();

        if (error) {
          console.error('Erro ao verificar username:', error);
        }
        if (data) {
          setIsUsernameAvailable(false);
          setUsernameError('Este username já está em uso.');
        } else {
          setIsUsernameAvailable(true);
          setUsernameError(null);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setIsCheckingUsername(false);
      }
    }, 450);

    return () => clearTimeout(delayDebounceFn);
  }, [username, isLogin, step]);

  // Preload the cinematic login background image for fast display
  useEffect(() => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = 'https://i.ibb.co/qMpqnFyP/d69ef753c3d736f90309f6c7fe9d519d.jpg';
    // @ts-ignore
    link.setAttribute('fetchpriority', 'high');
    document.head.appendChild(link);
    return () => {
      if (document.head.contains(link)) {
        document.head.removeChild(link);
      }
    };
  }, []);

  // Reset state when modal opens
  useEffect(() => {
    setIsLogin(initialMode === 'login');
    setStep(1);
    setReason(null);
    setUsername('');
    setUsernameError(null);
    setIsUsernameAvailable(null);
  }, [initialMode, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    console.log("handleSubmit triggered", { isLogin, email, password });
    
    // Manual validation
    if (!email || !password) {
      showToast("Por favor, preencha todos os campos obrigatórios.", "error", "Autenticação");
      return;
    }
    
    const supabase = getSupabase();
    if (!supabase) {
      console.log('Supabase is not configured - proceeding in Sandbox/Demo mode.');
      setIsLoading(true);
      setTimeout(() => {
        const userRole = reason || 'seller';
        const cleanUsername = username.toLowerCase().trim() || (name || email.split('@')[0]).toLowerCase().replace(/[^a-z0-9_]/g, '');
        
        // Generate a mock direct demo session
        const demoSession = {
          user: {
            id: 'demo-user-12345',
            email: email,
            user_metadata: {
              full_name: name || email.split('@')[0],
              artistic_name: name || email.split('@')[0],
              username: cleanUsername,
              account_type: userRole
            }
          },
          session: {
            access_token: 'demo-token',
            user: { id: 'demo-user-12345' }
          },
          profile: {
            id: 'demo-user-12345',
            role: userRole,
            display_name: name || email.split('@')[0],
            username: cleanUsername
          }
        };

        localStorage.setItem('beatangola_demo_session', JSON.stringify(demoSession));
        localStorage.setItem('beatangola_user_role', userRole);
        
        // Dispatch custom authentication event to reload AuthContext immediately!
        window.dispatchEvent(new Event('auth_state_change'));

        showToast(isLogin ? `Bem-vindo de volta (Modo Sandbox)!` : `Conta de demonstração criada com sucesso!`, 'success', 'Login de Demonstração');
        onAuthSuccess?.(userRole);
        onClose();
        setIsLoading(false);
      }, 800);
      return;
    }
    
    setIsLoading(true);
    console.log("Supabase client initialized");
    let userRole = reason || 'seller';

    try {
      if (isLogin) {
        let data: any = null;
        let loginSuccess = false;

        try {
          console.log("Signing in (proxy)...", { email });
          const response = await fetch('/api/auth/login', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ email, password })
          });

          if (response.ok) {
            data = await response.json();
            console.log("Resultado do signIn (proxy):", { data, status: response.status });

            if (data?.session) {
              console.log("Setting session on client with URL:", (supabase as any).supabaseUrl);
              const { error: sessionError } = await supabase.auth.setSession(data.session);
              if (sessionError) {
                console.error("setSession error", sessionError);
                const isNetworkBlocked = sessionError.message?.toLowerCase().includes("failed to fetch") || 
                                         sessionError.message?.toLowerCase().includes("fail to fetch") ||
                                         (sessionError as any).status === 0;

                if (isNetworkBlocked) {
                  showToast("Ligação ao banco de dados bloqueada! Desative o Adblocker, uBlock ou Brave Shields temporariamente.", "warning", "Ligação Bloqueada");
                }
                showToast("Erro ao estabelecer sessão: " + sessionError.message, "error", "Sessão");
                setIsLoading(false);
                return;
              }
              console.log("Session set successfully");
              loginSuccess = true;
            }
          } else {
            let errorData: any = {};
            try {
              errorData = await response.json();
            } catch (e) {
              // ignore
            }
            console.warn("SignIn proxy response not ok, attempting direct client-side login...", errorData);
            
            // If the proxy returns a specific invalid credentials or similar auth error, we should alert it directly so the user knows
            const errorMessage = errorData?.message || errorData?.error?.message;
            if (errorMessage && (errorMessage.includes('Invalid login credentials') || errorMessage.includes('invalid_credentials') || errorMessage.includes('credenciais inválidas') || errorMessage.includes('E-mail ou senha incorretos'))) {
              showToast('E-mail ou senha incorretos. Por favor, verifique os seus dados e tente novamente.', 'error', 'Dados Incorretos');
              setIsLoading(false);
              return;
            }
          }
        } catch (fetchErr) {
          console.warn("Fetch failed for login proxy, fallback to direct client-side: ", fetchErr);
        }

        // Direct client-side login if proxy was not successful
        if (!loginSuccess) {
          console.log("Attempting direct client-side Supabase authentication...");
          const { data: directData, error: directError } = await supabase.auth.signInWithPassword({ email, password });
          if (directError) {
            console.error("Direct signIn error:", directError);
            const errMsg = directError.message || '';
            const isNetworkBlocked = errMsg.toLowerCase().includes("failed to fetch") || 
                                     errMsg.toLowerCase().includes("fail to fetch") ||
                                     (directError as any).status === 0;

            if (isNetworkBlocked) {
              showToast("Erro de rede / Bloqueio detetado. Por favor, certifique-se de que não tem extensões como Adblock ou Brave Shields a interferir.", "warning", "Conexão Impedida");
            }
            
            if (errMsg.includes('Invalid credentials') || errMsg.includes('invalid_api_key') || errMsg.includes('Email not confirmed')) {
              showToast('Credenciais inválidas ou e-mail não confirmado. Verifique e tente novamente.', 'error', 'Erro de Login');
            } else {
              showToast('Erro ao realizar login: ' + directError.message, 'error', 'Erro de Login');
            }
            setIsLoading(false);
            return;
          }
          data = directData;
          console.log("Direct client-side login successful!", data);
        }

        userRole = data.user?.user_metadata?.account_type || 'seller';
        console.log("Signed in successfully, role detected:", userRole);
        showToast(`Bem-vindo de volta, ${data.user?.user_metadata?.full_name || 'utilizador'}!`, 'success', 'Login bem-sucedido');
      } else {
        console.log("Signing up...");
        if (!acceptedTerms) {
          showToast('Você precisa aceitar os Termos e Condições para continuar.', 'error', 'Cadastro');
          setIsLoading(false);
          return;
        }

        const cleanUsername = username.toLowerCase().trim();
        if (!cleanUsername) {
          showToast('Por favor, defina o seu username.', 'error', 'Cadastro');
          setIsLoading(false);
          return;
        }
        if (!/^[a-z0-9._]+$/.test(cleanUsername)) {
          showToast('O username contém caracteres inválidos. Apenas são aceites letras minúsculas, números, pontos (.) ou underscores (_).', 'error', 'Formato Inválido');
          setIsLoading(false);
          return;
        }

        // Verify uniqueness in Supabase profiles database
        const { data: existingUser, error: checkError } = await supabase
          .from('profiles')
          .select('id')
          .eq('username', cleanUsername)
          .maybeSingle();

        if (checkError) {
          console.warn("Error checking username uniqueness:", checkError);
        }

        if (existingUser) {
          showToast('Este username já está em uso.', 'error', 'Indisponível');
          setIsLoading(false);
          return;
        }

        const { data, error } = await supabase.auth.signUp({ 
          email, 
          password,
          options: {
              data: {
                  full_name: name,
                  artistic_name: name,
                  username: cleanUsername,
                  account_type: reason || 'seller'
              }
          }
        });
        if (error) {
          console.error("signUp error", error);
          const errorMessage = error.message.toLowerCase();
          const isNetworkBlocked = errorMessage.includes("failed to fetch") || 
                                   errorMessage.includes("fail to fetch") ||
                                   (error as any).status === 0;

          if (isNetworkBlocked) {
            showToast("Erro ao conectar ao banco de dados durante o cadastro. Certifique-se de que não tem extensões de privacidade ou bloqueadores de anúncios ativos (ex. Brave Shields, uBlock).", "warning", "Ligação Bloqueada");
          }
          
          const isAlreadyRegistered = errorMessage.includes('already registered') || errorMessage.includes('user already exists');
          
          if (isAlreadyRegistered) {
            showToast('Este email já está registrado. Por favor, entre com sua senha em vez de se cadastrar.', 'error', 'Email Registrado');
            setIsLogin(true);
          } else {
            showToast(error.message, 'error', 'Cadastro');
          }
          setIsLoading(false);
          return;
        }
        console.log("Signed up successfully");
        userRole = reason || 'seller';
        
        if (data.user) {
          // Immediately perform client-side upsert/update of the profile to write/ensure correct artistic_name and clean username
          try {
            const profileData = {
              id: data.user.id,
              display_name: name,
              artistic_name: name,
              full_name: name,
              username: cleanUsername,
              role: userRole
            };
            
            const { error: profileError } = await supabase
              .from('profiles')
              .upsert(profileData, { onConflict: 'id' });
              
            if (profileError) {
              console.warn("Client profile upsert failed, retrying with unique username suffix:", profileError);
              const uniqueSuffix = data.user.id.slice(0, 5);
              const fallbackProfileData = {
                ...profileData,
                username: `${cleanUsername}_${uniqueSuffix}`
              };
              const { error: fallbackError } = await supabase
                .from('profiles')
                .upsert(fallbackProfileData, { onConflict: 'id' });
              if (fallbackError) {
                console.error("Client profile unique fallback upsert failed:", fallbackError);
              }
            }
          } catch (profileCatchError) {
            console.error("Client profile creation exception ignored:", profileCatchError);
          }

          showToast('Conta criada com sucesso! Bem-vindo à BATUKADA.', 'success', 'Bem-vindo');
          sendNotification(
            data.user.id, 
            'account', 
            'Bem-vindo à BATUKADA! 🇦🇴', 
            'Estamos felizes por estares aqui. Explora os melhores beats ou começa a vender os teus!'
          );
        }
      }
      
      // Store role to ensure persistence in this session/app
      localStorage.setItem('beatangola_user_role', userRole);
      
      console.log("Closing modal and calling success with role:", userRole);
      onAuthSuccess?.(userRole);
      onClose();
    } catch (err) {
      console.error("Caught exception during auth:", err);
      showToast('Erro inesperado: ' + (err instanceof Error ? err.message : String(err)), 'error', 'Erro');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="auth_page_overlay" className="fixed inset-0 z-[110] flex flex-col md:flex-row bg-[#000000] overflow-y-auto">
      {/* LEFT COLUMN: Cinematic Studio Background Image */}
      <div className="hidden md:flex md:w-[45%] lg:w-[55%] h-screen relative overflow-hidden flex-col justify-between p-12 shrink-0 select-none sticky top-0">
        <img 
          src="https://i.ibb.co/qMpqnFyP/d69ef753c3d736f90309f6c7fe9d519d.jpg"
          alt="BATUKADA Studio Background"
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 hover:scale-105"
          loading="eager"
          // @ts-ignore
          fetchPriority="high"
          referrerPolicy="no-referrer"
        />
        <div 
          className="absolute inset-0 z-10" 
          style={{ 
            background: "linear-gradient(to right, rgba(0, 0, 0, 0.92), rgba(0, 0, 0, 0.65))" 
          }} 
        />
        
        {/* Animated Accent Light Flare */}
        <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-[#5865F2]/5 blur-[120px] rounded-full z-10 pointer-events-none" />

        {/* Content over image */}
        <div className="relative z-20 flex flex-col h-full justify-between">
          <div className="mt-auto mb-8">
            <h1 
              className="font-black text-white italic uppercase mb-6 whitespace-pre-line"
              style={{ 
                fontSize: "clamp(50px, 4.5vw, 76px)", 
                lineHeight: "0.94", 
                letterSpacing: "-0.045em" 
              }}
            >
              Venda Beats{"\n"}em Angola.
            </h1>
            <p className="text-gray-300 text-xs sm:text-sm font-semibold max-w-sm leading-relaxed">
              A plataforma moderna para produtores, artistas e criadores.
            </p>
          </div>

          <div className="text-[10px] text-gray-400 font-extrabold uppercase tracking-widest">
            © {new Date().getFullYear()} BATUKADA — Luanda, Angola
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Fundo totalmente preto (#000000) */}
      <div className="flex-1 min-h-screen md:min-h-0 md:h-screen flex items-center justify-center p-4 sm:p-8 lg:p-12 bg-[#000000] relative overflow-y-auto">
        {/* Floating Close Button in corner */}
        <button 
          type="button"
          id="close_auth_modal_btn"
          className="absolute top-6 right-6 text-gray-400 hover:text-white w-[42px] h-[42px] flex items-center justify-center rounded-[12px] bg-white/[0.03] border border-[#6366f1]/[0.18] hover:bg-white/[0.08] hover:border-[#6366f1]/[0.4] hover:shadow-[0_0_12px_rgba(99,102,241,0.25)] transition-all duration-[250ms] ease-in-out z-30 cursor-pointer"
          onClick={onClose}
        >
          <X size={18} />
        </button>

        {/* The Card / Login Panel */}
        <motion.div 
          id="auth_modal_card"
          initial={{ opacity: 0, scale: 0.98, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className={`border border-white/[0.06] rounded-[18px] w-full transition-all duration-300 shadow-sm relative overflow-hidden ${
            isLogin 
              ? 'max-w-[460px] p-6 sm:p-8 md:p-10' 
              : step === 1
                ? 'max-w-[460px] md:max-w-[640px] p-6 sm:p-8 md:p-10'
                : 'max-w-[460px] p-6 sm:p-8 md:p-10'
          }`}
          style={{ 
            background: "rgba(5, 5, 5, 0.88)", 
            backdropFilter: "blur(8px)" 
          }}
        >

          {/* Central Logo, Title & Header Block */}
          <div className="flex flex-col items-center text-center mt-1 mb-6">
            <div className="relative group mb-3">
              <img 
                src="https://i.ibb.co/hF1MD85X/20260523-155411.png"
                alt="BATUKADA"
                className="h-[44px] sm:h-[48px] w-auto object-contain select-none hover:brightness-110 transition-all duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white italic uppercase tracking-tighter mb-1 select-none">
              {isLogin 
                ? 'Bem-vindo de volta' 
                : step === 1 
                  ? 'Como pretende usar a BATUKADA?' 
                  : 'Finalizar Cadastro'}
            </h2>
            <p className="text-gray-400 text-xs font-semibold max-w-sm">
              {isLogin 
                ? 'Acesse sua área exclusiva na BATUKADA.' 
                : step === 1 
                  ? 'Selecione a sua jornada para continuarmos.' 
                  : 'Preencha os seus dados de identificação.'}
            </p>
          </div>

          <AnimatePresence mode="wait">
            {isLogin ? (
              /* ==================== LOGIN WORKFLOW ==================== */
              <motion.form 
                key="login-form"
                onSubmit={handleSubmit} 
                className="space-y-3.5"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
              >
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block ml-1">E-mail</label>
                  <input 
                    type="email" 
                    placeholder="seu@email.com" 
                    className="w-full bg-[#101010] hover:bg-[#121212] border border-white/[0.06] hover:border-white/[0.12] focus:border-[#5865F2]/50 rounded-[14px] py-3 px-4 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all duration-200" 
                    value={email} 
                    onChange={e => setEmail(e.target.value)} 
                    required 
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block ml-1">Senha</label>
                  <input 
                    type="password" 
                    placeholder="••••••••" 
                    className="w-full bg-[#101010] hover:bg-[#121212] border border-white/[0.06] hover:border-white/[0.12] focus:border-[#5865F2]/50 rounded-[14px] py-3 px-4 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all duration-200" 
                    value={password} 
                    onChange={e => setPassword(e.target.value)} 
                    required 
                  />
                  <div className="flex justify-end pt-1">
                    <button 
                      type="button" 
                      onClick={() => {
                        showToast('Funcionalidade de recuperação enviada para implementação.', 'info', 'Recuperação de Senha');
                      }}
                      className="text-[11px] text-white/50 hover:text-[#5865F2] font-medium transition-colors cursor-pointer"
                    >
                      Esqueceu a senha?
                    </button>
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full text-white font-black h-[50px] rounded-[14px] uppercase text-xs tracking-[0.2em] mt-5 flex items-center justify-center gap-2 select-none disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-[160ms]"
                  style={{
                    background: "linear-gradient(180deg, #6366f1 0%, #5458ee 100%)",
                    boxShadow: "0 4px 12px rgba(88, 101, 242, 0.15)"
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-1px)";
                    e.currentTarget.style.filter = "brightness(1.08)";
                    e.currentTarget.style.boxShadow = "0 6px 16px rgba(88, 101, 242, 0.22)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.filter = "brightness(1)";
                    e.currentTarget.style.boxShadow = "0 4px 12px rgba(88, 101, 242, 0.15)";
                  }}
                >
                  {isLoading && <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />}
                  Entrar
                </button>

                <button type="button" className="mt-6 text-xs font-semibold text-gray-400 hover:text-white w-full text-center transition-colors block cursor-pointer" onClick={() => setIsLogin(false)}>
                  Ainda não tem conta? <span className="text-[#5865F2] font-semibold hover:underline">Crie uma agora.</span>
                </button>
              </motion.form>
            ) : step === 1 ? (
              /* ==================== SIGNUP STEP 1: CHOICE ==================== */
              <motion.div
                key="signup-step-1"
                className="space-y-6"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              >
                <div className="bg-[#101010] border border-white/[0.04] rounded-[14px] p-4 flex items-center justify-between">
                  <p className="text-gray-400 text-xs font-medium">Já possui uma conta?</p>
                  <button type="button" className="text-[#5865F2] text-xs font-black uppercase hover:text-blue-300 transition-colors cursor-pointer" onClick={() => setIsLogin(true)}>Entrar</button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Seller Option */}
                  <button
                    type="button"
                    onClick={() => setReason('seller')}
                    className={`relative text-left p-5 sm:p-6 rounded-[14px] border transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer h-[155px] sm:h-[175px] group ${
                      reason === 'seller'
                        ? 'bg-[#5865F2]/10 border-[#5865F2]'
                        : 'bg-white/[0.02] hover:bg-white/[0.04] border-white/[0.06] hover:border-white/[0.12]'
                    }`}
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className={`w-9 h-9 rounded-[10px] flex items-center justify-center border transition-all ${
                        reason === 'seller' ? 'bg-[#5865F2] border-[#5865F2] text-white' : 'bg-white/5 border-white/10 text-gray-400'
                      }`}>
                        <Disc size={18} className={reason === 'seller' ? 'animate-spin' : ''} style={{ animationDuration: '4s' }} />
                      </div>
                      
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                        reason === 'seller' ? 'bg-[#5865F2] border-[#5865F2]' : 'border-white/20'
                      }`}>
                        {reason === 'seller' && <Check size={12} className="text-white stroke-[3px]" />}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-white font-black uppercase text-xs tracking-wider mb-1">
                        Vendedor
                      </h3>
                      <p className="text-gray-400 text-[11px] sm:text-xs font-semibold leading-snug">
                        Publicar e vender beats
                      </p>
                      <p className="text-gray-500 text-[10px] mt-1 hidden sm:block leading-snug font-normal">
                        Carregar faixas, gerir pacotes e licenças exclusivas.
                      </p>
                    </div>
                  </button>

                  {/* Buyer Option */}
                  <button
                    type="button"
                    onClick={() => setReason('buyer')}
                    className={`relative text-left p-5 sm:p-6 rounded-[14px] border transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer h-[155px] sm:h-[175px] group ${
                      reason === 'buyer'
                        ? 'bg-[#5865F2]/10 border-[#5865F2]'
                        : 'bg-white/[0.02] hover:bg-white/[0.04] border-white/[0.06] hover:border-white/[0.12]'
                    }`}
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className={`w-9 h-9 rounded-[10px] flex items-center justify-center border transition-all ${
                        reason === 'buyer' ? 'bg-[#5865F2] border-[#5865F2] text-white' : 'bg-white/5 border-white/10 text-gray-400'
                      }`}>
                        <Headphones size={18} />
                      </div>
                      
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                        reason === 'buyer' ? 'bg-[#5865F2] border-[#5865F2]' : 'border-white/20'
                      }`}>
                        {reason === 'buyer' && <Check size={12} className="text-white stroke-[3px]" />}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-white font-black uppercase text-xs tracking-wider mb-1">
                        Comprador
                      </h3>
                      <p className="text-gray-400 text-[11px] sm:text-xs font-semibold leading-snug">
                        Explorar, comprar e licenciar beats
                      </p>
                      <p className="text-gray-500 text-[10px] mt-1 hidden sm:block leading-snug font-normal">
                        Ouvir prévias, apoiar talentos angolanos e descarregar.
                      </p>
                    </div>
                  </button>
                </div>

                <button 
                  type="button" 
                  onClick={() => setStep(2)}
                  disabled={!reason}
                  className="w-full text-white font-black h-[50px] rounded-[14px] uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed select-none transition-all duration-[160ms]"
                  style={{
                    background: !reason ? "#303036" : "linear-gradient(180deg, #6366f1 0%, #5458ee 100%)",
                    boxShadow: !reason ? "none" : "0 4px 12px rgba(88, 101, 242, 0.15)"
                  }}
                  onMouseEnter={(e) => {
                    if (!reason) return;
                    e.currentTarget.style.transform = "translateY(-1px)";
                    e.currentTarget.style.filter = "brightness(1.08)";
                    e.currentTarget.style.boxShadow = "0 6px 16px rgba(88, 101, 242, 0.22)";
                  }}
                  onMouseLeave={(e) => {
                    if (!reason) return;
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.filter = "brightness(1)";
                    e.currentTarget.style.boxShadow = "0 4px 12px rgba(88, 101, 242, 0.15)";
                  }}
                >
                  Continuar
                  <ArrowRight size={14} className="stroke-[3px]" />
                </button>
              </motion.div>
            ) : (
              /* ==================== SIGNUP STEP 2: DETAILS ==================== */
              <motion.form
                key="signup-step-2"
                onSubmit={handleSubmit}
                className="space-y-4"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3 }}
              >
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block ml-1">Nome Artístico</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Jay Marshal" 
                    className="w-full bg-[#101010] hover:bg-[#121212] border border-white/[0.06] hover:border-white/[0.12] focus:border-[#5865F2]/50 rounded-[14px] py-3 px-4 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all duration-200" 
                    value={name} 
                    onChange={e => setName(e.target.value)} 
                    required 
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block ml-1">Username</label>
                  <div className="relative flex items-center">
                    <span className="absolute left-4 text-gray-500 font-bold text-sm pointer-events-none select-none">@</span>
                    <input 
                      type="text" 
                      placeholder="buzzinlabs" 
                      className={`w-full bg-[#101010] hover:bg-[#121212] border ${
                        usernameError 
                          ? 'border-red-500/30 focus:border-red-500/60 focus:ring-1 focus:ring-red-500/10' 
                          : isUsernameAvailable 
                            ? 'border-emerald-500/30 focus:border-emerald-500/60 focus:ring-1 focus:ring-emerald-500/10' 
                            : 'border-white/[0.06] focus:border-[#5865F2]/50 hover:border-white/[0.12]'
                      } rounded-[14px] py-3 pl-8 pr-28 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all duration-200`} 
                      value={username} 
                      onChange={e => {
                        const inputVal = e.target.value.toLowerCase().replace(/\s/g, '');
                        setUsername(inputVal);
                      }} 
                      required 
                    />
                    {/* Real-time Status indicator */}
                    <div className="absolute right-4 flex items-center justify-center">
                      {isCheckingUsername ? (
                        <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                      ) : isUsernameAvailable === true ? (
                        <span className="text-emerald-400 text-[10px] font-bold uppercase tracking-wider">Disponível</span>
                      ) : isUsernameAvailable === false && !usernameError ? (
                        <span className="text-red-400 text-[10px] font-bold uppercase tracking-wider">Em uso</span>
                      ) : null}
                    </div>
                  </div>
                  {/* Visual Hint or Validation Error */}
                  {usernameError ? (
                    <p className="text-red-400 text-[10px] font-semibold mt-1 ml-1 leading-none">{usernameError}</p>
                  ) : (
                    <p className="text-gray-500 text-[10px] sm:text-[11px] font-medium mt-1 ml-1 leading-none">
                      Seu perfil será:{' '}
                      <span className="text-amber-500 font-bold uppercase tracking-tight">
                        batukada.com/@{username || 'username'}
                      </span>
                    </p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block ml-1">E-mail</label>
                  <input 
                    type="email" 
                    placeholder="seu@email.com" 
                    className="w-full bg-[#101010] hover:bg-[#121212] border border-white/[0.06] hover:border-white/[0.12] focus:border-[#5865F2]/50 rounded-[14px] py-3 px-4 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all duration-200" 
                    value={email} 
                    onChange={e => setEmail(e.target.value)} 
                    required 
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block ml-1">Senha</label>
                  <input 
                    type="password" 
                    placeholder="••••••••" 
                    className="w-full bg-[#101010] hover:bg-[#121212] border border-white/[0.06] hover:border-white/[0.12] focus:border-[#5865F2]/50 rounded-[14px] py-3 px-4 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all duration-200" 
                    value={password} 
                    onChange={e => setPassword(e.target.value)} 
                    required 
                  />
                </div>

                <div className="flex items-start gap-3 py-2.5 px-3 bg-white/[0.01] border border-white/[0.04] rounded-[14px]">
                  <input 
                    id="terms_and_conditions_checkbox"
                    type="checkbox" 
                    checked={acceptedTerms} 
                    onChange={e => setAcceptedTerms(e.target.checked)}
                    className="w-4.5 h-4.5 rounded border-white/10 bg-[#0B0B0F] text-[#5865F2] focus:ring-[#5865F2]/40 cursor-pointer accent-[#5865F2] transition-colors mt-0.5" 
                    required
                  />
                  <label htmlFor="terms_and_conditions_checkbox" className="text-xs text-gray-400 select-none cursor-pointer leading-relaxed">
                    Eu concordo com os{' '}
                    <button 
                      type="button"
                      onClick={() => {
                        onClose();
                        onNavigateToTerms?.();
                      }}
                      className="text-[#5865F2] hover:underline hover:text-[#5865F2]/80 font-black inline transition-colors"
                    >
                      Termos e Condições
                    </button>
                  </label>
                </div>

                <button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full text-white font-black h-[50px] rounded-[14px] uppercase text-xs tracking-[0.2em] mt-3 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed select-none transition-all duration-[160ms]"
                  style={{
                    background: "linear-gradient(180deg, #6366f1 0%, #5458ee 100%)",
                    boxShadow: "0 4px 12px rgba(88, 101, 242, 0.15)"
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-1px)";
                    e.currentTarget.style.filter = "brightness(1.08)";
                    e.currentTarget.style.boxShadow = "0 6px 16px rgba(88, 101, 242, 0.22)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.filter = "brightness(1)";
                    e.currentTarget.style.boxShadow = "0 4px 12px rgba(88, 101, 242, 0.15)";
                  }}
                >
                  {isLoading && <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />}
                  Finalizar Cadastro
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
}
