import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Search, Check } from 'lucide-react';

export const ALL_COORDINATED_GENRES = [
  "Afro Beat",
  "Afro House",
  "Afro Trap",
  "Afro Soul",
  "Amapiano",
  "Kuduro",
  "Trap",
  "Drill",
  "Boom Bap",
  "Hip Hop",
  "Rap",
  "Lo-Fi",
  "Lo-Fi Jazz",
  "R&B",
  "Soul",
  "Pop",
  "Pop Trap",
  "Dancehall",
  "Reggaeton",
  "Gospel",
  "House",
  "Deep House",
  "Tech House",
  "EDM",
  "Funk",
  "Funk Brasileiro",
  "Jersey Club",
  "Kompa",
  "Kizomba",
  "Semba",
  "Zouk",
  "Ghetto Zouk",
  "Jazz",
  "Piano",
  "Acoustic",
  "Instrumental",
  "Cinematic",
  "Orchestral",
  "Melodic",
  "Sad",
  "Chill",
  "Ambient",
  "Detroit",
  "UK Drill",
  "Plug",
  "Rage",
  "Cloud Rap",
  "Experimental",
  "Outro"
];

interface GenreSelectProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

export default function GenreSelect({
  value,
  onChange,
  placeholder = "Selecionar Gênero",
  className = ""
}: GenreSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const filteredGenres = ALL_COORDINATED_GENRES.filter(g =>
    g.toLowerCase().includes(search.toLowerCase())
  );

  const handleSelect = (genre: string) => {
    onChange(genre);
    setIsOpen(false);
    setSearch("");
  };

  return (
    <div ref={containerRef} className={`relative w-full ${className}`}>
      {/* Selector Trigger Button */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between w-full bg-[#000000] border border-white/5 rounded-2xl p-4 text-sm font-bold text-white hover:border-white/10 focus-within:border-amber-500/50 cursor-pointer transition-all duration-300 shadow-md select-none group"
      >
        <span className={value ? "text-white font-extrabold italic uppercase tracking-wider" : "text-gray-500 font-semibold"}>
          {value || placeholder}
        </span>
        <ChevronDown
          size={16}
          className={`text-gray-400 group-hover:text-white transition-transform duration-300 ${
            isOpen ? "rotate-180 text-amber-500" : ""
          }`}
        />
      </div>

      {/* Brand Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="absolute z-50 left-0 right-0 mt-2 bg-[#000000] border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.9)] overflow-hidden backdrop-blur-xl"
          >
            {/* Search inputs panel bar */}
            <div className="flex items-center gap-2 px-3 py-3 border-b border-white/5 bg-white/[0.02]">
              <Search size={14} className="text-gray-500 shrink-0" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Pesquisar gênero..."
                className="w-full bg-transparent border-none outline-none focus:ring-0 text-xs font-bold text-white placeholder:text-gray-600 font-sans"
                autoFocus
              />
            </div>

            {/* List options wrapper */}
            <div className="max-h-60 overflow-y-auto py-1 [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-track]:bg-black/40 [&::-webkit-scrollbar-thumb]:bg-white/10 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:hover:bg-amber-500/30">
              {filteredGenres.length > 0 ? (
                filteredGenres.map(g => {
                  const isSelected = value === g;
                  return (
                    <div
                      key={g}
                      onClick={() => handleSelect(g)}
                      className={`flex items-center justify-between px-4 py-2.5 text-xs font-semibold cursor-pointer select-none transition-all duration-200 border-l-2 ${
                        isSelected
                          ? "bg-amber-500/10 text-amber-400 border-amber-500 font-bold"
                          : "text-gray-300 border-transparent hover:bg-white/[0.03] hover:text-white"
                      }`}
                    >
                      <span className="uppercase tracking-wide font-mono">{g}</span>
                      {isSelected && (
                        <Check size={12} className="text-amber-400 shrink-0" />
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="px-4 py-4 text-center text-xs text-gray-600 font-semibold font-sans italic selection:bg-transparent">
                  Nenhum gênero encontrado
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
