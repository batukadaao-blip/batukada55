import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { playlistStore, Playlist } from '../lib/playlistStore';
import { Beat } from '../types';
import { X, Plus, FolderHeart, Globe, Lock, Music2, Check, Disc, Disc3, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AddToPlaylistModal() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedBeat, setSelectedBeat] = useState<Beat | null>(null);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [loading, setLoading] = useState(false);

  // New playlist creation form
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [isPublic, setIsPublic] = useState(true);

  useEffect(() => {
    const handleOpen = (e: Event) => {
      const customEvent = e as CustomEvent<{ beat: Beat }>;
      if (customEvent.detail && customEvent.detail.beat) {
        if (!user) {
          showToast('Inicia sessão para organizar os teus beats em playlists!', 'info', 'Autenticação Necessária');
          // Trigger auth open if user likes
          window.dispatchEvent(new CustomEvent('openAuthModal'));
          return;
        }
        setSelectedBeat(customEvent.detail.beat);
        setIsOpen(true);
        setShowCreateForm(false);
        setNewTitle('');
        setNewDescription('');
      }
    };

    window.addEventListener('showAddToPlaylist', handleOpen);
    return () => window.removeEventListener('showAddToPlaylist', handleOpen);
  }, [user, showToast]);

  useEffect(() => {
    if (isOpen && user) {
      loadPlaylists();
    }
  }, [isOpen, user]);

  const loadPlaylists = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const data = await playlistStore.fetchPlaylists(user.id);
      setPlaylists(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newTitle.trim()) return;

    try {
      const created = await playlistStore.createPlaylist(
        user.id,
        newTitle.trim(),
        newDescription.trim(),
        isPublic
      );
      showToast(`Playlist "${created.title}" criada com sucesso!`, 'success', 'Playlist Criada');
      setNewTitle('');
      setNewDescription('');
      setShowCreateForm(false);
      await loadPlaylists();
    } catch (e) {
      showToast('Ocorreu um erro ao criar a playlist.', 'error');
    }
  };

  const handleToggleBeat = async (playlist: Playlist) => {
    if (!selectedBeat) return;
    const hasBeat = playlist.beat_ids?.includes(String(selectedBeat.id));

    try {
      if (hasBeat) {
        await playlistStore.removeBeatFromPlaylist(playlist.id, selectedBeat.id);
        showToast(`Removido de "${playlist.title}"`, 'info', 'Playlist Atualizada');
      } else {
        await playlistStore.addBeatToPlaylist(playlist.id, selectedBeat.id);
        showToast(`Adicionado a "${playlist.title}"`, 'success', 'Beat Adicionado');
      }
      
      // Notify components to update playlists dynamically
      window.dispatchEvent(new CustomEvent('playlistUpdated'));
      await loadPlaylists();
    } catch (e) {
      showToast('Erro ao atualizar playlist.', 'error');
    }
  };

  const handleDeletePlaylist = async (playlistId: string, title: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm(`Tens a certeza que desejas eliminar a playlist "${title}"?`)) return;

    try {
      await playlistStore.deletePlaylist(playlistId);
      showToast(`Playlist "${title}" eliminada.`, 'info', 'Playlist Removida');
      window.dispatchEvent(new CustomEvent('playlistUpdated'));
      await loadPlaylists();
    } catch (e) {
      showToast('Falha ao eliminar playlist.', 'error');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => setIsOpen(false)}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />

      {/* Modal Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-[#09090D] shadow-2xl shadow-[#5865F2]/10 p-6 md:p-8"
      >
        {/* Glow effect */}
        <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-[#5865F2] to-transparent" />

        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <FolderHeart size={20} className="text-[#5865F2]" />
            <h3 className="text-lg font-black tracking-tight text-white uppercase italic">
              Adicionar à Playlist
            </h3>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="w-8 h-8 rounded-full bg-white/5 border border-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {selectedBeat && (
          <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-white/[0.02] border border-white/5 mb-5">
            <img 
              src={selectedBeat.image || 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=100'} 
              alt={selectedBeat.title}
              className="w-12 h-12 rounded-xl object-cover shrink-0 border border-white/10"
              referrerPolicy="no-referrer"
            />
            <div className="min-w-0">
              <h4 className="font-extrabold text-white truncate leading-tight">{selectedBeat.title}</h4>
              <p className="text-[10px] font-black text-[#F59E0B] tracking-wider uppercase mt-0.5">{selectedBeat.producer}</p>
            </div>
          </div>
        )}

        <AnimatePresence mode="wait">
          {!showCreateForm ? (
            <motion.div
              key="list"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              {/* Playlists List Container */}
              <div className="max-h-60 overflow-y-auto custom-scrollbar space-y-2.5 pr-1">
                {loading ? (
                  <div className="flex flex-col items-center justify-center py-10 gap-2">
                    <Disc3 className="text-gray-600 animate-spin" size={24} />
                    <span className="text-[10px] font-black tracking-widest text-gray-500 uppercase">A carregar playlists...</span>
                  </div>
                ) : playlists.length === 0 ? (
                  <div className="text-center py-8 border border-dashed border-white/5 rounded-2xl bg-white/[0.01]">
                    <Music2 className="text-gray-600 mx-auto mb-2.5 opacity-40" size={28} />
                    <p className="text-xs font-bold text-gray-400">Nenhuma playlist criada ainda.</p>
                    <p className="text-[10px] text-gray-500 mt-1">Cria uma no botão abaixo para começar.</p>
                  </div>
                ) : (
                  playlists.map(pl => {
                    const hasBeat = pl.beat_ids?.includes(String(selectedBeat?.id));
                    return (
                      <div 
                        key={pl.id}
                        onClick={() => handleToggleBeat(pl)}
                        className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.01] hover:bg-white/[0.04] border border-white/5 hover:border-white/10 transition-all cursor-pointer group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-xl bg-purple-600/[0.15] border border-purple-500/20 flex items-center justify-center shrink-0">
                            {pl.cover_image ? (
                              <img src={pl.cover_image} className="w-full h-full object-cover rounded-xl" alt="" />
                            ) : (
                              <Disc size={18} className="text-purple-400" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <h5 className="font-extrabold text-white text-sm truncate leading-snug">{pl.title}</h5>
                            <p className="text-[10px] text-gray-500 truncate flex items-center gap-1.5 mt-0.5">
                              {pl.is_public ? <Globe size={10} /> : <Lock size={10} />}
                              {pl.beat_ids?.length || 0} {pl.beat_ids?.length === 1 ? 'beat' : 'beats'}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {/* Trash icon for owner deletion */}
                          {pl.user_id === user?.id && (
                            <button
                              onClick={(e) => handleDeletePlaylist(pl.id, pl.title, e)}
                              className="opacity-0 group-hover:opacity-100 p-2 text-gray-500 hover:text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all"
                              title="Eliminar Playlist"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}

                          <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                            hasBeat 
                              ? 'bg-emerald-500 border-emerald-500 text-black shadow-lg shadow-emerald-500/20' 
                              : 'border-white/20 text-transparent group-hover:border-white/40'
                          }`}>
                            <Check size={10} strokeWidth={3} />
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Add New Playlist Button */}
              <button
                onClick={() => setShowCreateForm(true)}
                className="w-full py-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 text-white font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <Plus size={14} className="text-[#5865F2]" />
                Criar Nova Playlist
              </button>
            </motion.div>
          ) : (
            <motion.form
              key="create"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              onSubmit={handleCreatePlaylist}
              className="space-y-4"
            >
              <div className="space-y-1.5">
                <label className="text-[9px] font-black uppercase text-gray-400 tracking-wider">Título da Playlist</label>
                <input 
                  type="text"
                  required
                  placeholder="Ex: Kizomba Caliente 2026"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full bg-white/[0.02] border border-white/10 rounded-2xl p-3.5 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-black uppercase text-gray-400 tracking-wider">Descrição (Opcional)</label>
                <textarea
                  placeholder="Uma pequena nota sobre o mood do set..."
                  value={newDescription}
                  onChange={e => setNewDescription(e.target.value)}
                  rows={2}
                  className="w-full bg-white/[0.02] border border-white/10 rounded-2xl p-3.5 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors resize-none"
                />
              </div>

              {/* Visibility Option */}
              <div className="flex gap-4">
                <div 
                  onClick={() => setIsPublic(true)}
                  className={`flex-1 p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-2.5 ${
                    isPublic 
                      ? 'border-[#5865F2] bg-[#5865F2]/5 text-white' 
                      : 'border-white/5 bg-white/[0.01] text-gray-400 hover:border-white/10'
                  }`}
                >
                  <Globe size={16} className={isPublic ? 'text-[#5865F2]' : ''} />
                  <div className="text-left">
                    <p className="text-xs font-black">Pública</p>
                    <p className="text-[9px] font-semibold opacity-70">Todos podem ver</p>
                  </div>
                </div>

                <div 
                  onClick={() => setIsPublic(false)}
                  className={`flex-1 p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-2.5 ${
                    !isPublic 
                      ? 'border-[#5865F2] bg-[#5865F2]/5 text-white' 
                      : 'border-white/5 bg-white/[0.01] text-gray-400 hover:border-white/10'
                  }`}
                >
                  <Lock size={16} className={!isPublic ? 'text-[#5865F2]' : ''} />
                  <div className="text-left">
                    <p className="text-xs font-black">Privada</p>
                    <p className="text-[9px] font-semibold opacity-70">Apenas tu podes ver</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="flex-1 py-3.5 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 text-gray-400 hover:text-white font-black text-[10px] uppercase tracking-widest transition-all"
                >
                  Voltar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3.5 rounded-2xl bg-[#5865F2] text-white hover:bg-blue-600 font-black text-[10px] uppercase tracking-widest transition-all shadow-lg shadow-[#5865F2]/10"
                >
                  Guardar Playlist
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
