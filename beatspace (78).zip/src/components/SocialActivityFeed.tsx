import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { 
  Music, 
  Package, 
  Heart, 
  MessageSquare, 
  ListMusic, 
  Award, 
  UserPlus, 
  Radio, 
  Globe,
  Clock,
  ChevronRight,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { io } from 'socket.io-client';

interface Activity {
  id: string;
  user_id?: string;
  username?: string;
  avatar_url?: string;
  type: 'beat_upload' | 'kit_upload' | 'follow' | 'like' | 'comment' | 'playlist_created' | 'featured' | 'verified';
  actor_name: string;
  actor_username: string;
  actor_avatar?: string;
  target_id?: string;
  target_title?: string;
  target_cover?: string;
  metadata?: any;
  created_at: string;
}

interface SocialActivityFeedProps {
  userId?: string; 
  username?: string; 
  showTitle?: boolean;
  onDiscoverProducers?: () => void;
}

// Memory-friendly image referrers & icon helpers cached
const getActivityIcon = (type: Activity['type']) => {
  switch (type) {
    case 'beat_upload':
      return <Music className="w-4 h-4 text-emerald-400" />;
    case 'kit_upload':
      return <Package className="w-4 h-4 text-cyan-400" />;
    case 'follow':
      return <UserPlus className="w-4 h-4 text-purple-400" />;
    case 'like':
      return <Heart className="w-4 h-4 text-pink-500 fill-pink-500/20" />;
    case 'comment':
      return <MessageSquare className="w-4 h-4 text-amber-400" />;
    case 'playlist_created':
      return <ListMusic className="w-4 h-4 text-violet-400" />;
    case 'featured':
      return <Award className="w-4 h-4 text-amber-500" />;
    case 'verified':
      return <CheckCircle2 className="w-4 h-4 text-[#2997FF] fill-black" />;
    default:
      return <Globe className="w-4 h-4 text-blue-400" />;
  }
};

const getRelativeTime = (dateStr: string) => {
  try {
    const past = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - past.getTime();
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHrs = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHrs / 24);

    if (diffSecs < 10) return 'Agora mesmo';
    if (diffSecs < 60) return `há ${diffSecs}s`;
    if (diffMins < 60) return `há ${diffMins}m`;
    if (diffHrs < 24) return `há ${diffHrs}h`;
    return `há ${diffDays}d`;
  } catch (_) {
    return 'Há instantes';
  }
};

const SocialActivityFeedComponent = ({ userId, username, showTitle = true, onDiscoverProducers }: SocialActivityFeedProps) => {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [loading, setLoading] = useState<boolean>(true);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const socketRef = useRef<any>(null);

  // Use AbortController inside fetch logic to protect from memory leaks & race conditions
  const fetchFeed = useCallback(async (signal?: AbortSignal) => {
    try {
      let url = '/api/activity/feed?limit=35';
      if (userId) {
        url = `/api/activity/following/${userId}?limit=35`;
      } else if (username) {
        url = `/api/activity/profile/${username}?limit=35`;
      }

      // 30-second cache check
      const cacheKey = `feed_cache_${url}`;
      const cached = sessionStorage.getItem(cacheKey);
      if (cached) {
        try {
          const { data, timestamp } = JSON.parse(cached);
          if (Date.now() - timestamp < 30000) {
            setActivities(data);
            setLoading(false);
            return;
          }
        } catch (_) {}
      }

      const res = await fetch(url, { signal });
      if (res.ok) {
        const data = await res.json();
        setActivities(data);
        try {
          sessionStorage.setItem(cacheKey, JSON.stringify({
            data,
            timestamp: Date.now()
          }));
        } catch (_) {}
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.warn('Error fetching activity feed:', err);
      }
    } finally {
      setLoading(false);
    }
  }, [userId, username]);

  useEffect(() => {
    const controller = new AbortController();
    fetchFeed(controller.signal);

    // Establish Socket.IO real-time connection with total sandbox isolation
    try {
      const socketUrl = window.location.origin && window.location.origin !== 'null' ? window.location.origin : '';
      const socket = io(socketUrl, {
        transports: ['websocket', 'polling'],
        reconnectionDelayMax: 10000,
        reconnectionAttempts: 4
      });
      socketRef.current = socket;

      socket.on('connect', () => {
        setIsConnected(true);
        console.log('[REAL-TIME FEED] Live with active link');
      });

      socket.on('disconnect', () => {
        setIsConnected(false);
      });

      socket.on('new_social_activity', (newAct: Activity) => {
        // Safe channel filtering
        if (username) {
          const profileMatch = 
            newAct.actor_username?.toLowerCase() === username.toLowerCase() ||
            newAct.username?.toLowerCase() === username.toLowerCase() ||
            newAct.target_title?.toLowerCase().includes(username.toLowerCase());
          if (!profileMatch) return;
        }
        
        setActivities(prev => {
          if (prev.some(a => a.id === newAct.id)) return prev;
          return [newAct, ...prev.slice(0, 40)];
        });
      });

      return () => {
        controller.abort();
        if (socket) socket.disconnect();
      };
    } catch (err) {
      console.warn('Could not bind real-time socket listeners:', err);
    }
  }, [userId, username, fetchFeed]);

  // Polling fallback - fully cleanable, low volume (15 seconds)
  useEffect(() => {
    const timer = setInterval(() => {
      fetchFeed();
    }, 15000);
    return () => clearInterval(timer);
  }, [fetchFeed]);

  // Performance memo for heavy operations
  const filteredActivities = useMemo(() => {
    return activities.filter(act => {
      if (activeFilter === 'all') return true;
      if (activeFilter === 'uploads') return act.type === 'beat_upload' || act.type === 'kit_upload';
      if (activeFilter === 'social') return act.type === 'follow' || act.type === 'like' || act.type === 'comment';
      return true;
    });
  }, [activities, activeFilter]);

  const fallbackWidget = useMemo(() => {
    if (!loading && activities.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-12 px-6 text-center border border-white/[0.04] bg-[#0B0B0F]/25 rounded-2xl relative overflow-hidden backdrop-blur-xl">
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-blue-500/20 to-transparent" />
          <Radio className="w-10 h-10 text-neutral-600 animate-pulse mb-4" />
          <p className="text-base font-black text-white uppercase italic tracking-tighter sm:text-lg">
            Segue produtores para descobrir novos sons.
          </p>
          <p className="text-xs text-neutral-400 mt-2 max-w-sm font-medium leading-relaxed">
            Os produtores que segues ainda não partilharam atividades ou uploads novos.
          </p>
          <button 
            onClick={() => {
              if (onDiscoverProducers) {
                onDiscoverProducers();
              } else {
                window.dispatchEvent(new CustomEvent('changePage', { detail: { page: 'producers' } }));
              }
            }}
            className="mt-6 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shadow-xl shadow-blue-600/15 active:scale-95 cursor-pointer italic flex items-center gap-2"
          >
            Descobrir Produtores
          </button>
        </div>
      );
    }
    return null;
  }, [loading, activities.length, onDiscoverProducers]);

  return (
    <div className="w-full flex flex-col" id="social-activity-feed-panel">
      {showTitle && (
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-500 relative flex items-center justify-center">
              <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
            </div>
            <div>
              <h3 className="text-xs font-black uppercase tracking-widest text-neutral-100">BATUKADA LIVE</h3>
              <p className="text-[9px] text-neutral-500 font-mono">ATIVIDADE EM TEMPO REAL</p>
            </div>
          </div>
          
          <div className="flex items-center gap-1 px-2 py-0.5 bg-white/[0.02] border border-white/[0.05] rounded-full text-[8px] font-mono text-neutral-400">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse mr-1" />
            <span>{isConnected ? "SINO" : "REDE"}</span>
          </div>
        </div>
      )}

      {/* TABS SELECTOR - Fully aligned with the prompt */}
      <div className="flex gap-1 overflow-x-auto pb-3 mb-4 scrollbar-none">
        {[
          { id: 'all', label: 'Tudo' },
          { id: 'uploads', label: 'Uploads' },
          { id: 'social', label: 'Social' }
        ].map(filter => (
          <button
            key={filter.id}
            onClick={() => setActiveFilter(filter.id)}
            className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all border whitespace-nowrap cursor-pointer ${
              activeFilter === filter.id 
                ? 'bg-orange-500 border-orange-600 text-white shadow-lg shadow-orange-500/10' 
                : 'bg-white/[0.02] border-white/[0.05] text-neutral-400 hover:text-white hover:bg-white/[0.05]'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <span className="w-6 h-6 border-2 border-white/10 border-t-white/80 rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-3 max-h-[500px] overflow-y-auto scrollbar-none pr-1">
          {fallbackWidget}
          <AnimatePresence initial={false}>
            {filteredActivities.map((act) => (
              <motion.div
                key={act.id}
                initial={{ opacity: 0, y: 15, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, transition: { duration: 0.15 } }}
                layout
                className="group relative flex items-start gap-3 p-3 bg-white/[0.01] hover:bg-white/[0.03] border border-white/[0.03] hover:border-white/[0.08] rounded-xl transition-all duration-300 backdrop-blur-md overflow-hidden cursor-pointer"
                onClick={() => {
                  if (act.type === 'beat_upload' || act.type === 'featured' || act.type === 'like' || act.type === 'comment') {
                    if (act.target_id) {
                      window.dispatchEvent(new CustomEvent('selectBeatPlay', { detail: { beatId: act.target_id } }));
                    }
                  } else {
                    const usernameToGo = act.actor_username || act.username || 'membro';
                    window.location.href = `/producer/${usernameToGo}`;
                  }
                }}
              >
                <div className="absolute right-0 top-0 w-24 h-24 bg-gradient-to-bl from-white/[0.01] to-transparent rounded-bl-full group-hover:from-orange-500/[0.02] transition-all duration-500 pointer-events-none" />

                <div className="relative shrink-0 mt-0.5">
                  {((act.actor_avatar && act.actor_avatar.trim() !== '') || (act.avatar_url && act.avatar_url.trim() !== '')) ? (
                    <img 
                      src={(act.actor_avatar && act.actor_avatar.trim() !== '') ? act.actor_avatar : act.avatar_url} 
                      alt={act.actor_name} 
                      className="w-10 h-10 rounded-lg object-cover border border-white/10 group-hover:border-orange-500/30 transition-all duration-300"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-lg bg-white/[0.03] border border-white/10 flex items-center justify-center font-black text-neutral-300 uppercase text-xs">
                      {(act.actor_username || act.username || 'me').substring(0, 2)}
                    </div>
                  )}
                  <span className="absolute -bottom-1 -right-1 w-5.5 h-5.5 rounded-full bg-black border border-white/[0.08] flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-300">
                    {getActivityIcon(act.type)}
                  </span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1.5">
                    <span className="text-xs font-bold text-white group-hover:text-orange-400 transition-colors duration-200 truncate">
                      @{act.actor_username || act.username}
                    </span>
                    <span className="shrink-0 text-[10px] font-medium font-mono text-neutral-500 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      {getRelativeTime(act.created_at)}
                    </span>
                  </div>

                  <p className="text-xs text-neutral-400 font-semibold leading-relaxed mt-1">
                    {act.type === 'beat_upload' && (
                      <span>carregou um novo beat <strong className="text-neutral-200">"{act.target_title}"</strong></span>
                    )}
                    {act.type === 'kit_upload' && (
                      <span>lançou o drumkit <strong className="text-neutral-200">"{act.target_title}"</strong></span>
                    )}
                    {act.type === 'follow' && (
                      <span>começou a seguir <strong className="text-neutral-200">@{act.target_title || 'Produtor'}</strong></span>
                    )}
                    {act.type === 'like' && (
                      <span>gostou do beat <strong className="text-neutral-200">"{act.target_title}"</strong></span>
                    )}
                    {act.type === 'comment' && (
                      <span>comentou em <strong className="text-neutral-200">"{act.target_title}"</strong>: <i className="text-neutral-400 block text-[11px] mt-0.5 border-l-2 border-white/10 pl-2">"{act.metadata?.comment || '...'}"</i></span>
                    )}
                    {act.type === 'playlist_created' && (
                      <span>criou uma nova playlist <strong className="text-neutral-200">"{act.target_title}"</strong></span>
                    )}
                    {act.type === 'featured' && (
                      <span>destacado na homepage: <strong className="text-amber-400 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded text-[10px] uppercase font-bold inline-block mt-0.5 animate-pulse">⭐ {act.metadata?.campaign || 'Destaque'}</strong></span>
                    )}
                    {act.type === 'verified' && (
                      <span>tornou-se <strong className="text-[#2997FF] bg-[#2997FF]/10 border border-[#2997FF]/20 px-1.5 py-0.5 rounded text-[10px] uppercase font-bold inline-flex items-center gap-1 mt-0.5 animate-pulse">🔥 Verified Producer</strong></span>
                    )}
                  </p>

                  {(((act.target_cover && act.target_cover.trim() !== '') || (act.metadata?.target_cover && act.metadata?.target_cover.trim() !== ''))) && (act.type === 'beat_upload' || act.type === 'kit_upload' || act.type === 'featured' || act.type === 'playlist_created') && (
                    <div className="mt-2.5 flex items-center gap-2 p-1.5 bg-white/[0.02] border border-white/[0.04] rounded-lg group-hover:border-white/[0.08] transition-all duration-300">
                      <img 
                        src={(act.target_cover && act.target_cover.trim() !== '') ? act.target_cover : act.metadata?.target_cover} 
                        alt="Preview" 
                        className="w-10 h-10 rounded object-cover shadow border border-white/10"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
                        <span className="text-[10px] font-mono font-bold tracking-wider text-neutral-500 uppercase block">
                          {act.type === 'kit_upload' ? 'SOUNDKIT' : (act.metadata?.genre || 'MUSIC')}
                        </span>
                        <span className="text-xs font-bold text-neutral-300 group-hover:text-white transition-colors duration-200 truncate block">
                          {act.target_title}
                        </span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 ml-auto text-neutral-600 group-hover:text-orange-400 transition-colors duration-300 transform group-hover:translate-x-0.5" />
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};

export const SocialActivityFeed = React.memo(SocialActivityFeedComponent);
export default SocialActivityFeed;
