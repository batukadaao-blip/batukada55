import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Beat } from '../types';
import { Play, Pause, ShoppingCart, Heart, Activity, User, Package, X, ListMusic, ShieldCheck, Download, Plus } from 'lucide-react';
import VerifiedBadge from './VerifiedBadge';
import { motion, AnimatePresence } from 'motion/react';
import { getSupabase, getPublicUrl } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { sendPremiumNotification } from '../lib/notifications';
import { playService } from '../lib/playService';

interface BeatCardProps {
  key?: string | number;
  beat: Beat & { type?: 'beat' | 'kit'; category?: string };
  isPlaying: boolean;
  onPlay: (beat: Beat) => void;
  onAddToCart: (beat: Beat) => void;
  onSelectProducer?: (producerName: string) => void;
  onSelectBeat?: (beat: Beat) => void;
}

// Shared caches across all BeatCard instances (avoids massive parallel duplicate database requests)
interface ProducerCacheData {
  isVerified: boolean;
  premiumBadge: string | null;
}
const producerVerificationCache = new Map<string, ProducerCacheData>();
const activeVerificationPromises = new Map<string, Promise<ProducerCacheData>>();

const userFavoriteCache = new Map<string, boolean>();
const activeFavoritePromises = new Map<string, Promise<boolean>>();

function BeatCard({ beat, isPlaying, onPlay, onAddToCart, onSelectProducer, onSelectBeat }: BeatCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const isKit = beat.type === 'kit' || !!(beat.category && (
    beat.category === 'Drum Kit' || 
    beat.category === 'Loop Kit' || 
    beat.category === 'drum-kit' || 
    beat.category === 'loop-kit' || 
    beat.category === 'sample-pack' || 
    beat.category.toLowerCase().includes('kit') || 
    beat.category.toLowerCase().includes('pack')
  ));
  const supabase = getSupabase();
  const { user } = useAuth();
  const [isProducerVerified, setIsProducerVerified] = useState(false);
  const [producerPremiumBadge, setProducerPremiumBadge] = useState<string | null>(null);

  useEffect(() => {
    if (!supabase) return;
    const cacheKey = beat.producer_id || beat.producer_name || beat.producer;
    if (!cacheKey) return;

    if (producerVerificationCache.has(cacheKey)) {
      const cached = producerVerificationCache.get(cacheKey)!;
      setIsProducerVerified(cached.isVerified);
      setProducerPremiumBadge(cached.premiumBadge);
      return;
    }

    if (activeVerificationPromises.has(cacheKey)) {
      activeVerificationPromises.get(cacheKey)!.then(val => {
        setIsProducerVerified(val.isVerified);
        setProducerPremiumBadge(val.premiumBadge);
      });
      return;
    }

    const fetchVerification = async (): Promise<ProducerCacheData> => {
      try {
        let query = supabase.from('profiles').select('is_verified, phone');
        if (beat.producer_id) {
          query = query.eq('id', beat.producer_id);
        } else {
          query = query.eq('display_name', beat.producer_name || beat.producer);
        }
        const { data } = await query.maybeSingle();
        let premiumBadge: string | null = null;
        if (data?.phone && data.phone.startsWith('{')) {
          try {
            const parsed = JSON.parse(data.phone);
            premiumBadge = parsed.premium_badge || null;
          } catch {}
        }
        const isVerified = !!data?.is_verified;
        const resObj = { isVerified, premiumBadge };
        producerVerificationCache.set(cacheKey, resObj);
        return resObj;
      } catch (err) {
        console.warn('Silent skip verification fetch:', err);
        return { isVerified: false, premiumBadge: null };
      }
    };

    const promise = fetchVerification();
    activeVerificationPromises.set(cacheKey, promise);
    promise.then(val => {
      setIsProducerVerified(val.isVerified);
      setProducerPremiumBadge(val.premiumBadge);
      activeVerificationPromises.delete(cacheKey);
    });
  }, [supabase, beat.producer_id, beat.producer, beat.producer_name]);

  useEffect(() => {
    if (!supabase) return;

    const beatIdStr = String(beat.id);
    let queryBeatId = beatIdStr;
    if (/^\d+$/.test(queryBeatId)) {
        const padded = queryBeatId.padStart(12, '0');
        queryBeatId = `00000000-0000-0000-0000-${padded}`;
    }

    if (userFavoriteCache.has(queryBeatId)) {
      setIsFavorited(userFavoriteCache.get(queryBeatId)!);
      return;
    }

    if (activeFavoritePromises.has(queryBeatId)) {
      activeFavoritePromises.get(queryBeatId)!.then(val => {
        setIsFavorited(val);
      });
      return;
    }

    const checkFavorite = async (): Promise<boolean> => {
      try {
        const { data: { user: currentUser } } = await supabase.auth.getUser();
        if (!currentUser) return false;
        
        const { data, error } = await supabase
            .from('favorites')
            .select('beat_id')
            .eq('user_id', currentUser.id)
            .eq('beat_id', queryBeatId);
        
        if (error) return false;
        const exists = !!(data && data.length > 0);
        userFavoriteCache.set(queryBeatId, exists);
        return exists;
      } catch (e) {
        return false;
      }
    };

    const promise = checkFavorite();
    activeFavoritePromises.set(queryBeatId, promise);
    promise.then(val => {
      setIsFavorited(val);
      activeFavoritePromises.delete(queryBeatId);
    });

    const handleFavChange = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && String(customEvent.detail.beatId) === beatIdStr) {
        setIsFavorited(customEvent.detail.isFavorited);
        userFavoriteCache.set(queryBeatId, customEvent.detail.isFavorited);
      }
    };

    window.addEventListener('favoriteStatusChanged', handleFavChange);
    return () => {
      window.removeEventListener('favoriteStatusChanged', handleFavChange);
    };
  }, [supabase, beat.id]);

  const toggleFavorite = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!supabase) {
        console.warn('[FAVORITE] Supabase not initialized');
        return;
    }

    const { data: { user: currentUser }, error: userError } = await supabase.auth.getUser();

    if (userError || !currentUser) {
        console.warn('[FAVORITE] User not logged in or session expired');
        return;
    }

    const userId = currentUser.id;
    let queryBeatId = String(beat.id);
    if (/^\d+$/.test(queryBeatId)) {
        const padded = queryBeatId.padStart(12, '0');
        queryBeatId = `00000000-0000-0000-0000-${padded}`;
    }
    
    console.log('[FAVORITE] toggleFavorite target details:', {
        beat_object: beat,
        raw_beat_id: beat.id,
        query_beat_id: queryBeatId,
        user_id: userId,
        currently_favorited: isFavorited
    });

    try {
        if (isFavorited) {
            console.log('[FAVORITE] Attempting to delete favorite from database:', { user_id: userId, beat_id: queryBeatId });
            const { error } = await supabase
                .from('favorites')
                .delete()
                .eq('user_id', userId)
                .eq('beat_id', queryBeatId);
            
            if (error) {
                console.error('[FAVORITE] Error deleting favorite:', error);
                throw error;
            }
            console.log('[FAVORITE] Favorite deleted successfully from database');
            setIsFavorited(false);
            userFavoriteCache.set(queryBeatId, false);
            window.dispatchEvent(new CustomEvent('favoriteStatusChanged', { detail: { beatId: beat.id, isFavorited: false } }));
        } else {
            // ==========================================
            // VALIDATION CHECKS
            // ==========================================
            
            // 1. is NOT null/undefined
            if (!queryBeatId) {
                const errMsg = '[FAVORITE] Validation failed: query_beat_id is null/undefined';
                console.error(errMsg);
                throw new Error(errMsg);
            }

            // 2. has a valid UUID structure
            const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
            if (!uuidRegex.test(queryBeatId)) {
                const errMsg = `[FAVORITE] Validation failed: Beat ID "${queryBeatId}" is not a valid UUID format`;
                console.error(errMsg);
                throw new Error(errMsg);
            }

            // 3. actually exists in the beats table (database record check)
            // Note: Since 'beats.id' in the database is an integer (number), we query by numeric ID
            const numericId = Number(beat.id);
            console.log('[FAVORITE] Validating existence of beat_id in "beats" table...', numericId);
            const { data: beatRecord, error: fetchErr } = await supabase
                .from('beats')
                .select('id')
                .eq('id', numericId)
                .maybeSingle();

            if (fetchErr) {
                const errMsg = `[FAVORITE] Validation check database query error: ${fetchErr.message}`;
                console.error(errMsg, fetchErr);
                throw new Error(errMsg);
            }

            if (!beatRecord) {
                const errMsg = `[FAVORITE] Validation failed: Beat ID "${numericId}" does not exist in the database "beats" table`;
                console.error(errMsg);
                throw new Error(errMsg);
            }

            if (Number(beatRecord.id) !== numericId) {
                const errMsg = `[FAVORITE] Validation failed: Record ID in database "${beatRecord.id}" does not match targeted beat ID "${numericId}"`;
                console.error(errMsg);
                throw new Error(errMsg);
            }

            console.log('[FAVORITE] Validation SUCCEEDED. Attempting to insert favorite into database:', { user_id: userId, beat_id: queryBeatId });
            const { data: insertResponse, error: insertError } = await supabase
                .from('favorites')
                .insert({ user_id: userId, beat_id: queryBeatId })
                .select();
            
            if (insertError) {
                console.error('[FAVORITE] Error inserting favorite:', insertError);
                throw insertError;
            }
            console.log('[FAVORITE] Favorite inserted successfully into database:', insertResponse);
            setIsFavorited(true);
            userFavoriteCache.set(queryBeatId, true);
            window.dispatchEvent(new CustomEvent('favoriteStatusChanged', { detail: { beatId: beat.id, isFavorited: true } }));

            // Track analytics event dynamically
            try {
              import('@/src/lib/analytics').then(m => {
                m.trackAnalyticsEvent('like', {
                  producerId: beat.producer_id,
                  beatId: beat.id,
                  userId: userId || undefined
                });
              });
            } catch (err) {
              console.error("[ANALYTICS] Like tracking error:", err);
            }

            // Register Like Social Activity
            try {
              const bCover = getPublicUrl('beats', (beat as any).cover_url || beat.image || '');
              const actName = currentUser?.user_metadata?.artistic_name || currentUser?.user_metadata?.full_name || currentUser?.email?.split('@')[0] || 'Artista';
              const actUsername = currentUser?.user_metadata?.username || currentUser?.email?.split('@')[0]?.toLowerCase().replace(/\s+/g, '') || 'artista';
              
              await fetch('/api/activity/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  user_id: currentUser?.id,
                  type: 'like',
                  actor_name: actName,
                  actor_username: actUsername,
                  actor_avatar: currentUser?.user_metadata?.avatar_url || null,
                  target_id: beat.id,
                  target_title: beat.title,
                  target_cover: bCover,
                  metadata: {
                    genre: beat.genre,
                    type: beat.type || 'beat'
                  }
                })
              });
            } catch (actErr) {
              console.warn('Silent issue registering like activity:', actErr);
            }

            // Emit real-time like notification to the beat's producer
            try {
              if (beat.producer_id && userId !== beat.producer_id) {
                const senderName = currentUser.user_metadata?.full_name || currentUser.user_metadata?.username || currentUser.email?.split('@')[0] || 'Um artista';
                const bCover = getPublicUrl('beats', (beat as any).cover_url || beat.image || '');
                await sendPremiumNotification({
                  userId: beat.producer_id,
                  actorId: userId,
                  type: 'like' as any,
                  title: 'Novo Favorito! ❤️',
                  message: `${senderName} gostou do teu beat "${beat.title}".`,
                  metadata: {
                    cover_url: bCover,
                    beat_id: beat.id
                  }
                });
                console.log('[NOTIFICATION] Favorite premium notification sent to:', beat.producer_id);
              }
            } catch (notifErr) {
              console.warn('Silent skip favorite notification dispatch inside BeatCard:', notifErr);
            }
        }
    } catch (error: any) {
        console.error('[FAVORITE] Error toggling favorite:', error.message || error);
    }
  };

  return (
    <motion.div 
      whileHover={{ y: -4 }}
      onClick={() => onSelectBeat ? onSelectBeat(beat) : setShowDetails(true)}
      className="group relative bg-[#0c0c12]/65 border border-white/[0.04] rounded-2xl p-3.5 transition-all hover:bg-[#12121c]/90 hover:border-white/[0.08] hover:shadow-xl cursor-pointer"
    >
      {/* Artwork Section */}
      <div className="relative aspect-square overflow-hidden rounded-xl mb-3.5 bg-[#07070a] group-hover:shadow-[0_8px_24px_rgba(0,0,0,0.6)] transition-all">
        <img 
          src={beat.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400'} 
          alt={beat.title} 
          loading="lazy"
          decoding="async"
          className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105" 
          onError={(e) => {
            e.currentTarget.onerror = null; // Prevent infinite loops
            e.currentTarget.src = 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400';
          }}
        />
        
        {beat.is_free_download && (
          <div className="absolute top-3 left-3 px-2 py-0.5 bg-[#5865F2] text-white text-[9px] font-bold tracking-tight rounded shadow-md z-10">
            Gratuito
          </div>
        )}
        
        {/* Play Overlay (Beats only) */}
        {!isKit && (
          <div className="absolute inset-0 bg-black/50 md:opacity-0 md:group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 backdrop-blur-xs">
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={(e) => {
                e.stopPropagation();
                onPlay(beat);
              }}
              className="w-12 h-12 rounded-full bg-[#5865F2] text-white flex items-center justify-center shadow-lg"
            >
              {isPlaying ? <Pause className="w-5 h-5" fill="currentColor" /> : <Play className="w-5 h-5 ml-0.5" fill="currentColor" />}
            </motion.button>
            
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (onSelectBeat) {
                  onSelectBeat(beat);
                } else {
                  setShowDetails(true);
                }
              }}
              className="px-2.5 py-1 bg-black/70 hover:bg-[#5865F2] hover:text-white transition-all rounded text-white font-medium text-[10px]"
              title="Ver Detalhes"
            >
              Detalhes
            </button>
          </div>
        )}

        {/* Kits Overlay */}
        {isKit && (
          <div className="absolute inset-0 bg-black/50 md:opacity-0 md:group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 backdrop-blur-xs">
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (onSelectBeat) {
                  onSelectBeat(beat);
                } else {
                  setShowDetails(true);
                }
              }}
              className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-lg"
            >
              <Package className="w-5 h-5" />
            </motion.button>

            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (onSelectBeat) {
                  onSelectBeat(beat);
                } else {
                  setShowDetails(true);
                }
              }}
              className="px-2.5 py-1 bg-black/70 hover:bg-[#5865F2] hover:text-white transition-all rounded text-white font-medium text-[10px]"
              title="Ver Detalhes"
            >
              Detalhes
            </button>
          </div>
        )}

        {/* BPM or Kit Badge */}
        <div className="absolute top-3 right-3 bg-black/65 backdrop-blur-md px-2 py-0.5 rounded border border-white/5 flex items-center gap-1">
          {isKit ? (
            <>
              <Package size={9} className="text-blue-400" />
              <span className="text-[10px] font-medium text-gray-300 tracking-tight">{beat.category || 'Kit'}</span>
            </>
          ) : (
            <>
              <Activity size={9} className="text-[#5865F2]" />
              <span className="text-[10px] font-medium text-gray-300">{beat.bpm} BPM</span>
            </>
          )}
        </div>
      </div>

      {/* Info Section */}
      <div className="space-y-2 px-0.5">
        <div className="flex justify-between items-start gap-2">
          <div className="overflow-hidden flex-1">
            <h3 
              onClick={(e) => {
                if (onSelectBeat) {
                  e.stopPropagation();
                  onSelectBeat(beat);
                }
              }}
              className="text-sm font-bold text-white tracking-tight truncate leading-tight hover:text-[#5865F2] transition-colors"
            >
              {beat.title}
            </h3>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onSelectProducer?.(beat.producer_username || beat.producer_name || beat.producer || 'Unknown Producer');
              }} 
              className="group/prod flex items-center gap-1 text-gray-400 text-[10px] font-medium hover:text-white transition-colors py-0.5"
            >
              <User size={9} className="text-gray-500" />
              <span className="truncate">@{beat.producer_username || beat.producer_name || beat.producer || 'Unknown Producer'}</span>
              {isProducerVerified && (
                <VerifiedBadge size="sm" />
              )}
              {producerPremiumBadge && (
                <span className={`text-[8px] font-bold px-1 rounded scale-90 shrink-0 ${
                  producerPremiumBadge === 'trending' ? 'bg-amber-500/10 text-amber-500' :
                  producerPremiumBadge === 'top_producer' ? 'bg-purple-500/10 text-purple-400' :
                  producerPremiumBadge === 'elite_seller' ? 'bg-[#5865F2]/10 text-blue-400' :
                  producerPremiumBadge === 'rising_star' ? 'bg-blue-500/10 text-blue-400' :
                  'bg-[#5865F2]/10 text-[#5865F2]'
                }`} title={`Premium: ${producerPremiumBadge.toUpperCase()}`}>
                  {producerPremiumBadge.replace('_', ' ')}
                </span>
              )}
            </button>
          </div>
          <div className="flex items-center shrink-0">
            <button
              onClick={(e) => {
                e.stopPropagation();
                window.dispatchEvent(new CustomEvent('addToPlayerQueue', { detail: { beat } }));
              }}
              className="text-gray-500 hover:text-[#5865F2] transition-colors p-1"
              title="Adicionar à Fila de Espera"
            >
              <Plus size={16} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                window.dispatchEvent(new CustomEvent('showAddToPlaylist', { detail: { beat } }));
              }}
              className="text-gray-500 hover:text-[#5865F2] transition-colors p-1"
              title="Adicionar à Playlist"
            >
              <ListMusic size={16} />
            </button>
            <button 
              onClick={toggleFavorite}
              className={`${isFavorited ? 'text-rose-500' : 'text-gray-500 hover:text-rose-500'} transition-colors p-1`}
            >
              <Heart className="w-[16px] h-[16px]" fill={isFavorited ? 'currentColor' : 'none'} />
            </button>
          </div>
        </div>

        {/* Tags / Subtitle */}
        <div className="flex gap-1 flex-wrap items-center">
          <span className="text-[9px] font-medium text-gray-400 bg-white/5 px-2 py-0.5 rounded">{beat.genre}</span>
          {!isKit && (
            <span className="text-[9px] font-semibold text-[#5865F2] bg-[#5865F2]/10 px-2 py-0.5 rounded flex items-center gap-1" title={`${Number(playService.getPlayCount(beat.id, beat.plays_count || 0)).toLocaleString()} reproduções`}>
              <Play size={8} className="fill-[#5865F2] text-[#5865F2] shrink-0" />
              {Number(playService.getPlayCount(beat.id, beat.plays_count || 0)).toLocaleString()} Streams
            </span>
          )}
          {isKit && <span className="text-[9px] font-medium text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded">Sound Kit</span>}
        </div>
        
        {/* Price & Cart */}
        <div className="flex items-center justify-between pt-2 border-t border-white/[0.04]">
          <div className="flex flex-col">
            {beat.is_free_download ? (
              <span className="text-xs font-black text-[#5865F2]">Gratuito</span>
            ) : (
              <>
                <span className="text-[9px] text-gray-500 leading-none mb-0.5">{isKit ? 'Kit Completo' : 'Licença Simples'}</span>
                <span className="text-sm font-bold text-white tracking-tight">
                  {typeof beat.price === 'object' && beat.price !== null
                    ? (beat.price.basic !== undefined && beat.price.basic !== null ? Number(beat.price.basic).toLocaleString('pt-AO') : '0')
                    : Number(beat.price || 0).toLocaleString('pt-AO')}{' '}
                  <span className="text-[10px] text-[#5865F2] font-semibold">Kz</span>
                </span>
              </>
            )}
          </div>
          {user?.id === beat.producer_id ? (
            <div className="text-[9px] font-medium text-gray-500 text-center truncate max-w-[100px] px-2" title="Este beat é seu">
              Artigo Próprio
            </div>
          ) : beat.is_free_download ? (
            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={(e) => {
                e.stopPropagation();
                // Real Direct Download logic for kits/beats
                const downloadUrl = beat.demo_url || beat.master_url || beat.audioUrl;
                if (downloadUrl) {
                  // Track interactive download event
                  try {
                    import('@/src/lib/analytics').then(m => {
                      m.trackAnalyticsEvent('download', {
                        producerId: beat.producer_id,
                        beatId: beat.id
                      });
                    });
                  } catch (err) {
                    console.error("[ANALYTICS] Download tracking error:", err);
                  }

                  const a = document.createElement('a');
                  a.href = downloadUrl;
                  a.download = `${beat.title || 'SoundKit'}.zip`;
                  a.target = '_blank';
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                } else {
                  if (onSelectBeat) {
                    onSelectBeat(beat);
                  } else {
                    setShowDetails(true);
                  }
                }
              }}
              className="px-2.5 h-8 rounded-lg bg-[#5865F2]/20 border border-[#5865F2]/20 flex items-center justify-center gap-1 text-[#5865F2] hover:bg-[#5865F2] hover:text-white transition-all mr-1.5"
              title="Baixar Grátis"
            >
              <Download size={11} />
              <span className="font-bold text-[10px]">Baixar</span>
            </motion.button>
          ) : (
            <div className="flex items-center gap-1">
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={(e) => {
                  e.stopPropagation();
                  if (onSelectBeat) {
                    onSelectBeat(beat);
                  } else {
                    window.dispatchEvent(new CustomEvent('showCheckout', { detail: beat }));
                  }
                }}
                className="px-3 h-8 rounded-lg bg-[#5865F2] text-white text-[10px] font-bold hover:bg-[#4752C4] transition-all"
                title="Comprar Agora"
              >
                Comprar
              </motion.button>
              {user?.id !== beat.producer_id && (
                <motion.button 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddToCart(beat);
                  }}
                  className="w-8 h-8 rounded-lg bg-white/5 border border-white/5 flex items-center justify-center text-gray-400 hover:bg-[#5865F2]/10 hover:text-[#5865F2] transition-all"
                  title="Adicionar ao Carrinho"
                >
                  <ShoppingCart className="w-4 h-4" />
                </motion.button>
              )}
            </div>
          )}
        </div>
      </div>

      {createPortal(
        <AnimatePresence>
          {showDetails && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
              onClick={() => setShowDetails(false)}
            >
              <motion.div 
                initial={{ scale: 0.95, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 20 }}
                className="relative w-full max-w-2xl bg-[#0F0F15] border border-white/10 rounded-[2.5rem] p-6 md:p-8 overflow-hidden shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button 
                  onClick={() => setShowDetails(false)}
                  className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <X size={20} />
                </button>

                <div className="grid md:grid-cols-2 gap-8 items-start mt-4">
                  {/* Artwork */}
                  <div className="space-y-4">
                    <div className="aspect-square rounded-[2rem] overflow-hidden border border-white/5 bg-[#0a0a0f]">
                      <img 
                        src={beat.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400'} 
                        alt={beat.title} 
                        loading="lazy"
                        decoding="async"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400';
                        }}
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    
                    {/* Play preview */}
                    {!isKit && (
                      <div className="space-y-2">
                        <button
                          onClick={() => onPlay(beat)}
                          className="w-full py-4 rounded-2xl bg-amber-500 hover:bg-amber-600 text-black font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 transition-colors shadow-lg shadow-amber-500/20 cursor-pointer"
                        >
                          {isPlaying ? (
                            <>
                              <Pause size={16} fill="currentColor" /> Pausar Demo
                            </>
                          ) : (
                            <>
                              <Play size={16} fill="currentColor" className="ml-0.5" /> Ouvir Demo
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => {
                            setShowDetails(false);
                            window.dispatchEvent(new CustomEvent('addToPlayerQueue', { detail: { beat } }));
                          }}
                          className="w-full py-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-amber-500/10 hover:border-amber-500/20 text-white hover:text-amber-500 font-black uppercase tracking-widest text-[9px] flex items-center justify-center gap-2 transition-all cursor-pointer"
                        >
                          <Plus size={12} className="text-amber-500" /> Adicionar à Fila
                        </button>

                        <button
                          onClick={() => {
                            setShowDetails(false);
                            window.dispatchEvent(new CustomEvent('showAddToPlaylist', { detail: { beat } }));
                          }}
                          className="w-full py-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 text-white font-black uppercase tracking-widest text-[9px] flex items-center justify-center gap-2 transition-all cursor-pointer"
                        >
                          <ListMusic size={12} className="text-[#5865F2]" /> Adicionar à Playlist
                        </button>
                      </div>
                    )}
                  </div>
                              {/* Details */}
                  <div className="space-y-6">
                    <div className="text-left">
                      <span className="inline-flex py-1 px-2 text-[9px] bg-[#5865F2]/10 border border-[#5865F2]/20 text-[#5865F2] font-semibold tracking-wider uppercase rounded">{beat.genre}</span>
                      <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight leading-tight mt-1">{beat.title}</h2>
                      <p className="text-gray-400 text-xs mt-2 flex items-center gap-1.5 flex-wrap">
                        <span>Produtor:</span>
                        <button 
                          onClick={() => {
                            onSelectProducer?.(beat.producer_username || beat.producer_name || beat.producer || 'Unknown Producer');
                            setShowDetails(false);
                          }}
                          className="text-[#5865F2] hover:text-[#4752C4] transition font-medium cursor-pointer flex items-center gap-1"
                        >
                          <span>@{beat.producer_username || beat.producer_name || beat.producer || 'Unknown Producer'}</span>
                          {isProducerVerified && (
                            <VerifiedBadge size="sm" />
                          )}
                        </button>
                      </p>
                    </div>

                    {/* Attributes */}
                    <div className="grid grid-cols-2 gap-3 pb-4 border-b border-white/5">
                      {!isKit && (
                        <div className="bg-[#18181b]/35 border border-white/5 p-3 rounded">
                          <span className="text-gray-400 text-[8px] font-bold uppercase tracking-wider block">Ritmo</span>
                          <span className="text-white text-xs font-semibold">{beat.bpm} BPM</span>
                        </div>
                      )}
                      <div className="bg-[#18181b]/35 border border-white/5 p-3 rounded">
                        <span className="text-gray-400 text-[8px] font-bold uppercase tracking-wider block">Categoria</span>
                        <span className="text-white text-xs font-semibold uppercase tracking-wider">{isKit ? (beat.category || 'Sound Kit') : 'Type Beat'}</span>
                      </div>
                    </div>

                    {/* Licensing Prices */}
                    <div className="space-y-3">
                      <h4 className="text-white text-[10px] font-bold uppercase tracking-wider text-left">Valores e Licenciamento</h4>
                      
                      {/* Basic */}
                      <div className="flex items-center justify-between p-3.5 bg-white/[0.02] hover:bg-white/5 border border-white/5 hover:border-white/10 rounded-lg transition-all">
                        <div className="text-left">
                          <span className="text-white text-xs font-semibold">Licença Básica</span>
                          <span className="text-gray-400 text-[10px] block">MP3 de alta qualidade</span>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <span className="text-white font-bold text-sm font-mono">{beat.price.basic.toLocaleString()} Kz</span>
                          <button 
                            onClick={() => {
                              onAddToCart(beat);
                              setShowDetails(false);
                            }}
                            className="p-2 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded transition-colors cursor-pointer"
                            title="Adicionar ao Carrinho"
                          >
                            <ShoppingCart size={13} />
                          </button>
                        </div>
                      </div>

                      {/* Premium (Beats only) */}
                      {!isKit && beat.price.premium > 0 && (
                        <div className="flex items-center justify-between p-3.5 bg-white/[0.02] hover:bg-white/5 border border-white/5 hover:border-white/10 rounded-lg transition-all">
                          <div className="text-left">
                            <span className="text-white text-xs font-semibold">Licença Premium</span>
                            <span className="text-gray-400 text-[10px] block">WAV + MP3 de alta qualidade</span>
                          </div>
                          <div className="flex items-center gap-2.5">
                            <span className="text-white font-bold text-sm font-mono">{beat.price.premium.toLocaleString()} Kz</span>
                            <button 
                              onClick={() => {
                                onAddToCart({ ...beat, price: { ...beat.price, basic: beat.price.premium } });
                                setShowDetails(false);
                              }}
                              className="p-2 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded transition-colors cursor-pointer"
                              title="Adicionar ao Carrinho"
                            >
                              <ShoppingCart size={13} />
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Exclusive (Beats only) */}
                      {!isKit && beat.price.exclusive > 0 && (
                        <div className="flex items-center justify-between p-3.5 bg-white/[0.02] hover:bg-white/5 border border-white/5 hover:border-white/10 rounded-lg transition-all">
                          <div className="text-left">
                            <span className="text-white text-xs font-semibold">Licença Exclusiva</span>
                            <span className="text-gray-400 text-[10px] block">Stems + WAV + MP3 completa</span>
                          </div>
                          <div className="flex items-center gap-2.5">
                            <span className="text-white font-bold text-sm font-mono">{beat.price.exclusive.toLocaleString()} Kz</span>
                            <button 
                              onClick={() => {
                                onAddToCart({ ...beat, price: { ...beat.price, basic: beat.price.exclusive } });
                                setShowDetails(false);
                              }}
                              className="p-2 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded transition-colors cursor-pointer"
                              title="Adicionar ao Carrinho"
                            >
                              <ShoppingCart size={13} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </motion.div>
  );
}

export default React.memo(BeatCard);


