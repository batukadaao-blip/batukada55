import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Play, Pause, Music, Disc, Sparkles, Sliders } from 'lucide-react';
import { Beat } from '../types';

export default function ExploreSection({ 
  beats, 
  onExplore,
  currentBeat,
  isPlaying,
  onPlay
}: { 
  beats?: Beat[], 
  onExplore: () => void,
  currentBeat?: Beat | null,
  isPlaying?: boolean,
  onPlay?: (beat: Beat) => void
}) {
  // Use ONLY real beats from database props
  const displayBeats = beats && beats.length > 0 ? beats.slice(0, 4) : [];

  // Keep track of the highlighted card index in the stacked flow
  const [activeIndex, setActiveIndex] = useState(0);

  // Auto-cycles the active focal point card every 4.5 seconds for a living slideshow
  useEffect(() => {
    if (displayBeats.length > 1) {
      const timer = setInterval(() => {
        setActiveIndex((prev) => (prev + 1) % displayBeats.length);
      }, 4500);
      return () => clearInterval(timer);
    }
  }, [displayBeats.length]);

  return (
    <section id="hero_redesign_explore_section" className="relative mt-12 mb-16 py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden">
      {/* Preload real artwork headers for immediate performance */}
      {displayBeats.map((b) => (
        b.image && <link key={`preload-hero-${b.id}`} rel="preload" as="image" href={b.image} />
      ))}

      {/* Premium Cinematic Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_rgba(88,101,242,0.03),_transparent_35%)] -z-10 pointer-events-none" />

      <div className="grid lg:grid-cols-12 gap-10 items-center">
        {/* Left Side: Modern Copywriting */}
        <motion.div 
          className="lg:col-span-12 xl:col-span-5 flex flex-col items-start text-left z-20"
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <div className="inline-flex items-center gap-1.5 bg-[#5865F2]/10 border border-[#5865F2]/15 px-2.5 py-1 rounded mb-4">
            <Sparkles size={11} className="text-[#5865F2]" />
            <span className="text-[#5865F2] text-[10px] font-bold uppercase tracking-wider">
              Catálogo de Angola
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-snug mb-4">
            Explore Beats de <br className="hidden sm:inline" />
            Todos os Estilos e Ritmos
          </h2>

          <p className="text-gray-400 text-xs md:text-sm mb-5 max-w-md leading-relaxed">
            Navegue pelo catálogo vivo de Angola com dinâmicas exclusivas de curadoria e produção premium em tempo real. Produções reais de artistas reais.
          </p>

          <button 
            type="button"
            id="explore_section_action_btn"
            onClick={onExplore}
            className="group relative overflow-hidden bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold uppercase text-[10px] tracking-wider px-5 py-3 rounded flex items-center gap-2 transition-all cursor-pointer transform active:scale-[0.98]"
          >
            Explorar Catálogo de Type Beats 
            <ArrowRight size={13} className="group-hover:translate-x-0.5 transition-transform duration-200" />
          </button>
        </motion.div>

        {/* Right Side: Showcase stack of auto-moving / floating cards */}
        <div id="deck_stack_container" className="lg:col-span-12 xl:col-span-7 relative h-[420px] sm:h-[480px] md:h-[530px] w-full flex items-center justify-center mt-8 lg:mt-0 z-10 select-none">
          {/* Subtle geometric circle behind layout to establish canvas depth */}
          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 w-[340px] sm:w-[480px] h-[340px] sm:h-[480px] border border-white/[0.03] rounded-full [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_70%)] pointer-events-none -z-15" />
          
          <div className="relative w-full max-w-[320px] sm:max-w-[400px] h-full flex items-center justify-center">
            {displayBeats.length === 0 ? (
              /* High-end Premium Elegant Empty State if No Beats Uploaded to real database */
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full aspect-[4/5] sm:aspect-square bg-[#0c0c12]/60 border border-white/[0.04] rounded-2xl flex flex-col items-center justify-center p-8 text-center"
              >
                <div className="w-12 h-12 rounded-full bg-white/[0.02] border border-white/[0.04] flex items-center justify-center mb-4 animate-pulse">
                  <Music className="text-gray-500" size={20} />
                </div>
                <h3 className="text-white font-bold text-sm tracking-wide mb-1">
                  Nenhum beat disponível ainda
                </h3>
                <p className="text-gray-400 text-xs max-w-[220px] leading-relaxed">
                  Os produtores estão finalizando novas faixas. Fique ligado para as primeiras novidades!
                </p>
              </motion.div>
            ) : (
              displayBeats.map((beat, idx) => {
                const isCurrent = currentBeat?.id === beat.id;
                const isCurrentlyPlaying = isCurrent && isPlaying;

                // Calculate order layer relative to the active selection
                const relativePos = (idx - activeIndex + displayBeats.length) % displayBeats.length;
                
                // Define 3D stacking visual coordinates & angles
                let zIndex = 10 - relativePos;
                let scale = 1 - relativePos * 0.08;
                let xOffset = relativePos * 30; // Slide back right offset
                let yOffset = relativePos * -20; // Cascade upwards
                let rotateAngle = relativePos === 0 ? 0 : relativePos === 1 ? -4 : relativePos === 2 ? 5 : -2;
                let opacity = relativePos >= 3 ? 0 : 1 - relativePos * 0.35;

                // Custom float constants depending on the index to create non-synchronized floating patterns
                const floatDuration = idx === 0 ? 5 : idx === 1 ? 6.5 : idx === 2 ? 5.8 : 7.2;
                const yFloatRange = idx % 2 === 0 ? [-10, 8, -10] : [8, -12, 8];
                const rFloatRange = idx % 2 === 0 ? [-2, 1.5, -2] : [1, -1.5, 1];

                // Elegant placeholder image for beats with missing cover image
                const coverImage = beat.image || 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=600&auto=format&fit=crop&q=80';

                return (
                  <motion.div
                    key={`stacked-hero-${beat.id}-${idx}`}
                    style={{ zIndex }}
                    animate={{
                      x: xOffset,
                      y: yOffset,
                      scale,
                      rotate: rotateAngle,
                      opacity
                    }}
                    transition={{
                      type: "spring",
                      stiffness: 140,
                      damping: 24
                    }}
                    onClick={() => setActiveIndex(idx)}
                    className="absolute w-full aspect-[4/5] sm:aspect-square bg-[#0c0c12]/90 rounded-2xl border border-white/[0.04] p-4 flex flex-col justify-between overflow-hidden cursor-pointer shadow-xl transition-all duration-500 backdrop-blur-xl group"
                  >
                    {/* Slow Continuous Float Layer */}
                    <motion.div 
                      className="absolute inset-0 flex flex-col p-4 justify-between h-full w-full pointer-events-none"
                      animate={{ 
                        y: yFloatRange, 
                        rotate: rFloatRange
                      }}
                      transition={{
                        repeat: Infinity,
                        duration: floatDuration,
                        ease: "easeInOut"
                      }}
                    >
                      {/* Immersive Background Picture with Zoom on Hover */}
                      <div className="absolute inset-0 -z-10 bg-neutral-950 overflow-hidden rounded-xl">
                        {/* Interactive Glass Shine Top Highlight */}
                        <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-white/10 to-transparent z-10" />

                        <img 
                          src={coverImage} 
                          alt={beat.title}
                          loading="eager"
                          decoding="async"
                          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 pointer-events-none"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-black/5 z-10" />

                        {/* Premium reactive glow on hovered master selection */}
                        {relativePos === 0 && (
                          <div className="absolute inset-0 bg-[#5865F2]/5 group-hover:bg-[#5865F2]/10 mix-blend-color-dodge transition-colors duration-500 pointer-events-none" />
                        )}
                      </div>

                      {/* Top Stats Section */}
                      <div className="flex justify-between items-start w-full relative z-20 pointer-events-auto">
                        <span className="bg-black/80 backdrop-blur-md text-[10px] text-white font-semibold py-0.5 px-2 rounded border border-white/10 flex items-center gap-1 shadow">
                          <Music size={10} className="text-[#5865F2]" />
                          {beat.genre || 'Beat'}
                        </span>
                        
                        {!(beat.type === 'kit' || (beat.category && (beat.category.toLowerCase().includes('kit') || beat.category.toLowerCase().includes('pack')))) ? (
                          <span className="bg-[#5865F2]/10 backdrop-blur-md text-[10px] text-blue-400 font-semibold py-0.5 px-2 rounded border border-[#5865F2]/15 shadow-sm flex items-center gap-1">
                            <Sliders size={10} />
                            {beat.bpm} BPM
                          </span>
                        ) : (
                          <span className="bg-[#5865F2]/10 backdrop-blur-md text-[10px] text-blue-400 font-semibold py-0.5 px-2 rounded border border-[#5865F2]/15 shadow-sm flex items-center gap-1">
                            <Sliders size={10} />
                            {beat.category || 'KIT'}
                          </span>
                        )}
                      </div>

                      {/* Central Instant Listening Mechanism */}
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 z-30 pointer-events-auto">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (onPlay) onPlay(beat);
                          }}
                          className="w-12 h-12 bg-[#5865F2] hover:bg-[#4752C4] hover:scale-105 text-white rounded-full flex items-center justify-center shadow-md active:scale-95 transition-all duration-300 cursor-pointer"
                          title={isCurrentlyPlaying ? "Pausar beat" : "Ouvir beat"}
                        >
                          {isCurrentlyPlaying ? (
                            <Pause size={20} className="fill-white text-white" />
                          ) : (
                            <Play size={20} className="fill-white text-white ml-0.5" />
                          )}
                        </button>
                      </div>

                      {/* Information Footer */}
                      <div className="relative z-20 w-full pointer-events-auto mt-auto pt-6 bg-gradient-to-t from-black via-black/60 to-transparent rounded-b-xl">
                        <div className="flex justify-between items-end gap-2 mb-1">
                          <div className="min-w-0 flex-1">
                            <h3 className="text-white font-bold tracking-tight text-sm sm:text-base truncate group-hover:text-[#5865F2] transition-colors">
                              {beat.title}
                            </h3>
                            <p className="text-gray-400 text-xs truncate mt-0.5">
                              {beat.producer_name || beat.producer}
                            </p>
                          </div>
                          
                          {/* Interactive Listening indicator/pulse */}
                          <div className="flex h-6 items-center gap-1 px-1">
                            {isCurrentlyPlaying ? (
                              <div className="flex gap-[2px] items-end h-3">
                                <span className="w-[3px] bg-[#5865F2] rounded-full h-3 animate-pulse" style={{ animationDuration: '0.6s' }} />
                                <span className="w-[3px] bg-[#5865F2] rounded-full h-2 animate-pulse" style={{ animationDuration: '0.4s', animationDelay: '0.15s' }} />
                                <span className="w-[3px] bg-[#5865F2] rounded-full h-4 animate-pulse" style={{ animationDuration: '0.8s', animationDelay: '0.3s' }} />
                              </div>
                            ) : (
                              <Disc size={13} className="text-gray-600" />
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  </motion.div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
