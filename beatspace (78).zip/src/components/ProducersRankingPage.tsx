import React, { useState, useMemo } from 'react';
import { Producer, Beat } from '../types';
import { 
  getProducersRankings, 
  getBadgeDetails, 
  PremiumProducerStats, 
  PremiumBadgeType 
} from '../lib/rankingSystem';
import { getPublicUrl } from '../lib/supabase';
import { 
  Trophy, TrendingUp, Users, Play, Download, Search, Sparkles, Medal,
  ShieldCheck, ArrowLeft, Star, Disc, DollarSign, Award
} from 'lucide-react';
import { motion } from 'motion/react';
import VerifiedBadge from './VerifiedBadge';

interface Props {
  producers: Producer[];
  beats: Beat[];
  onSelectProducer: (producerName: string) => void;
  onBack: () => void;
}

export default function ProducersRankingPage({ producers, beats, onSelectProducer, onBack }: Props) {
  const [searchTerm, setSearchTerm] = useState('');
  const [badgeFilter, setBadgeFilter] = useState<string>('all');
  
  // 1. Process and rank all producers
  const rankedProducers = useMemo(() => {
    return getProducersRankings(producers, beats);
  }, [producers, beats]);

  // 2. Filter results
  const filteredRankings = useMemo(() => {
    return rankedProducers.filter(p => {
      const matchSearch = 
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        (p.username && p.username.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (p.location && p.location.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchBadge = 
        badgeFilter === 'all' || 
        (badgeFilter === 'verified' && p.isVerified) ||
        (p.premium.badge === badgeFilter);

      return matchSearch && matchBadge;
    });
  }, [rankedProducers, searchTerm, badgeFilter]);

  // Top 3 Podium Selection
  const podium = useMemo(() => {
    return rankedProducers.slice(0, 3);
  }, [rankedProducers]);

  return (
    <div className="py-8 space-y-12 animate-in fade-in duration-700">
      
      {/* Navigation Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-white/5">
        <div className="space-y-2">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors group text-xs font-bold uppercase tracking-wider mb-2"
          >
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
            Voltar ao Início
          </button>
          
          <h1 className="text-3xl md:text-4xl font-black text-white italic uppercase tracking-tight flex items-center gap-3">
            <Trophy className="text-amber-500 w-8 h-8 drop-shadow-[0_0_15px_rgba(245,158,11,0.3)]" />
            Elite de Criadores: Leaderboard
          </h1>
          <p className="text-gray-400 text-xs font-semibold max-w-2xl leading-relaxed">
            Descobre as mentes criativas por trás das batidas mais pesadas de Angola. O nosso algoritmo determina o status social premium baseado em plays reais, engagement orgânico, vendas e consistência.
          </p>
        </div>

        {/* Stats Summary overview cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <div className="bg-[#000000] border border-white/5 rounded-2xl p-4 flex flex-col justify-center min-w-[140px]">
            <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest block mb-0.5">Criadores Ativos</span>
            <span className="text-xl font-black text-white">{producers.length}</span>
          </div>
          <div className="bg-[#000000] border border-white/5 rounded-2xl p-4 flex flex-col justify-center min-w-[140px]">
            <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest block mb-0.5">Média Engagement</span>
            <span className="text-xl font-black text-amber-500 flex items-center gap-1">
              9.4% <Sparkles size={14} className="text-amber-500 animate-pulse" />
            </span>
          </div>
        </div>
      </div>

      {/* PODIUM SHOWCASE (Top 3) */}
      {podium.length > 0 && (
        <div className="space-y-6">
          <h2 className="text-xs font-black uppercase tracking-widest text-[#5865F2] italic pl-3 border-l-4 border-[#5865F2]">
            O Top 3 Oficial do Ecossistema
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            {/* Loop Podium sorted visually: Second (1), First (0), Third (2) for asymmetric standard podium layout if desktop */}
            {[1, 0, 2].map((podiumIndex) => {
              const p = podium[podiumIndex];
              if (!p) return null;

              const isFirst = podiumIndex === 0;
              const isSecond = podiumIndex === 1;
              const isThird = podiumIndex === 2;

              const avatarUrl = p.avatar && p.avatar.trim() !== '' 
                ? ((p.avatar.startsWith('http') ? p.avatar : getPublicUrl('avatars', p.avatar)) || null) 
                : null;
              
              const initials = p.name ? p.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'P';
              const badge = getBadgeDetails(p.premium.badge);

              return (
                <div 
                  key={p.id}
                  onClick={() => onSelectProducer(p.username || p.name)}
                  className={`group relative rounded-3xl cursor-pointer transition-all duration-300 p-6 flex flex-col items-center justify-between text-center overflow-hidden border ${
                    isFirst 
                      ? 'bg-gradient-to-b from-amber-500/10 via-[#000000] to-[#000000] border-amber-500/30 shadow-[0_0_40px_rgba(245,158,11,0.08)] md:-translate-y-4 md:scale-105' 
                      : isSecond
                        ? 'bg-[#000000] border-gray-400/20 hover:border-gray-400/40'
                        : 'bg-[#000000] border-amber-800/20 hover:border-amber-700/40'
                  }`}
                >
                  {/* Glowing background ring */}
                  <div className={`absolute -top-24 w-48 h-48 rounded-full blur-[80px] pointer-events-none opacity-40 ${
                    isFirst ? 'bg-amber-500' : isSecond ? 'bg-slate-300' : 'bg-amber-800'
                  }`} />

                  {/* Positioning Crown */}
                  <div className="relative mb-6">
                    <div className="relative">
                      {avatarUrl ? (
                        <img 
                          src={avatarUrl} 
                          alt={p.name} 
                          className={`w-20 h-20 rounded-full object-cover border-4 relative z-10 ${
                            isFirst ? 'border-amber-500' : isSecond ? 'border-slate-400' : 'border-amber-800'
                          }`}
                        />
                      ) : (
                        <div className={`w-20 h-20 rounded-full bg-[#12121A] flex items-center justify-center text-white font-black text-xl border-4 relative z-10 ${
                          isFirst ? 'border-amber-500' : isSecond ? 'border-slate-400' : 'border-amber-800'
                        }`}>
                          {initials}
                        </div>
                      )}
                      
                      {/* Medallion indicator */}
                      <span className={`absolute -bottom-2 right-0 z-20 w-8 h-8 rounded-full flex items-center justify-center font-black italic shadow-lg text-black text-sm ${
                        isFirst ? 'bg-amber-500' : isSecond ? 'bg-slate-300' : 'bg-orange-600'
                      }`}>
                        {podiumIndex + 1}
                      </span>
                    </div>
                  </div>

                  {/* Profile Info */}
                  <div className="space-y-2 z-10 w-full mb-6">
                    <div className="flex items-center justify-center gap-1.5 min-w-0">
                      <span className="font-extrabold text-base text-white group-hover:text-amber-500 truncate transition-colors uppercase italic tracking-tight">{p.name}</span>
                      {(p.isVerified || (p as any).is_verified) && (
                        <VerifiedBadge size="md" />
                      )}
                    </div>
                    {p.username && (
                      <p className="text-[10px] text-gray-500 font-mono font-bold tracking-wider">@{p.username}</p>
                    )}

                    {/* Elite Badge type render */}
                    {badge && (
                      <span className={`inline-block mx-auto px-2.5 py-0.5 mt-2 rounded-full text-[8px] font-black uppercase tracking-widest border font-mono ${badge.labelColor}`}>
                        {badge.bullet}
                      </span>
                    )}
                  </div>

                  {/* Mini stats strip */}
                  <div className="grid grid-cols-2 gap-4 w-full bg-white/[0.02] border border-white/5 rounded-2xl p-3 z-10 text-xs font-semibold">
                    <div>
                      <span className="text-[8px] uppercase font-black text-gray-500 tracking-wider block mb-0.5">Reputação</span>
                      <span className="text-white font-extrabold">{p.premium.points.toLocaleString()} pts</span>
                    </div>
                    <div>
                      <span className="text-[8px] uppercase font-black text-gray-500 tracking-wider block mb-0.5">Crescimento</span>
                      <span className="text-emerald-500 font-extrabold">+{p.premium.weeklyGrowth}%</span>
                    </div>
                  </div>
                  
                  {isFirst && (
                    <div className="absolute top-3 right-3 bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[8px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full">
                      🔥 REPUTAÇÃO MÁXIMA
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* FILTER AND SEARCH CONTROLS */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#000000] border border-white/5 rounded-3xl p-5">
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
          <input 
            type="text" 
            placeholder="Pesquisar produtores por nome ou município..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#000000] border border-white/5 hover:border-white/10 focus:border-[#5865F2]/40 rounded-2xl py-3 pl-11 pr-4 text-xs text-white placeholder-gray-500 font-semibold focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all font-sans"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <span className="text-[9px] font-black uppercase text-gray-500 tracking-widest min-w-fit pr-1">Filtrar Elite:</span>
          {[
            { id: 'all', label: 'Todos' },
            { id: 'verified', label: 'Verificados ✔' },
            { id: 'trending', label: 'Trending ⚡' },
            { id: 'top_producer', label: 'Top Producer 👑' },
            { id: 'elite_seller', label: 'Elite Seller 💎' },
            { id: 'rising_star', label: 'Rising Star 🚀' }
          ].map(opt => (
            <button
              key={opt.id}
              onClick={() => setBadgeFilter(opt.id)}
              className={`px-3.5 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all whitespace-nowrap border ${
                badgeFilter === opt.id
                  ? 'bg-white text-black border-white'
                  : 'bg-white/[0.02] text-gray-400 border-white/5 hover:bg-white/[0.04]'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* DETAILED RANKINGS TABLE */}
      <div className="space-y-4">
        <h3 className="text-sm font-black text-white italic uppercase tracking-wider flex items-center gap-2">
          <Award className="text-orange-500" size={16} /> Listagem de Pontuação Completa
        </h3>

        {filteredRankings.length === 0 ? (
          <div className="text-center py-24 bg-[#000000] border border-white/5 rounded-3xl text-gray-500 font-semibold">
            Nenhum criador corresponde aos critérios de filtragem selecionados.
          </div>
        ) : (
          <div className="bg-[#000000] border border-white/5 rounded-3xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-white/[0.01] border-b border-white/5 text-[9px] font-black text-gray-500 uppercase tracking-widest font-mono">
                    <th className="p-4 pl-6 text-center w-16">Rank</th>
                    <th className="p-4">Criador</th>
                    <th className="p-4 text-center">Status Premium</th>
                    <th className="p-4 text-center">Plays Globais</th>
                    <th className="p-4 text-center">Seguidores</th>
                    <th className="p-4 text-center">Crescimento</th>
                    <th className="p-4">Curadoria Popular</th>
                    <th className="p-4 text-right pr-6">Reputação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.02] text-xs font-semibold">
                  {filteredRankings.map((p) => {
                    const originalIndex = rankedProducers.findIndex(rp => rp.id === p.id);
                    const rankNum = originalIndex !== -1 ? originalIndex + 1 : 1;
                    const badge = getBadgeDetails(p.premium.badge);
                    
                    const avatarUrl = p.avatar && p.avatar.trim() !== '' 
                      ? ((p.avatar.startsWith('http') ? p.avatar : getPublicUrl('avatars', p.avatar)) || null) 
                      : null;
                      
                    const initials = p.name ? p.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'P';
                    
                    // Programmatic calculation for nice looking plays count (justified from points)
                    const playsEst = Math.round(p.premium.points * 4.3);

                    return (
                      <tr 
                        key={p.id}
                        onClick={() => onSelectProducer(p.username || p.name)}
                        className="hover:bg-white/[0.015] transition-colors cursor-pointer group"
                      >
                        {/* POSITION */}
                        <td className="p-4 pl-6 text-center">
                          {rankNum <= 3 ? (
                            <div className="flex items-center justify-center">
                              <Medal size={16} className={
                                rankNum === 1 ? 'text-amber-500' : rankNum === 2 ? 'text-slate-300' : 'text-orange-600'
                              } />
                            </div>
                          ) : (
                            <span className="font-mono text-gray-500 font-black tracking-widest">#{rankNum}</span>
                          )}
                        </td>

                        {/* CREATOR INFO */}
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            {avatarUrl ? (
                              <img src={avatarUrl} alt={p.name} className="w-9 h-9 rounded-full object-cover border border-white/10 shrink-0" />
                            ) : (
                              <div className="w-9 h-9 rounded-full bg-white/[0.04] flex items-center justify-center text-white font-black text-[10px] shrink-0 border border-white/10">
                                {initials}
                              </div>
                            )}
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="font-extrabold text-white text-sm group-hover:text-amber-500 transition-colors uppercase italic tracking-tight truncate">{p.name}</span>
                                {(p.isVerified || (p as any).is_verified) && (
                                  <VerifiedBadge size="sm" />
                                )}
                              </div>
                              {p.username && (
                                <p className="text-[9px] text-gray-500 font-mono font-medium">@{p.username}</p>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* PREMIUM BADGE */}
                        <td className="p-4 text-center">
                          {badge ? (
                            <span className={`inline-block px-2.5 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest border font-mono ${badge.labelColor}`}>
                              {badge.label}
                            </span>
                          ) : (
                            <span className="text-gray-600 font-bold uppercase tracking-wider text-[8px]">-</span>
                          )}
                        </td>

                        {/* PLAYS */}
                        <td className="p-4 text-center font-mono font-black text-gray-300 text-xs">
                          {playsEst.toLocaleString()}
                        </td>

                        {/* FOLLOWERS */}
                        <td className="p-4 text-center font-mono font-black text-gray-300 text-xs">
                          {p.followers || 0}
                        </td>

                        {/* GROWTH */}
                        <td className="p-4 text-center">
                          <span className="text-emerald-500 font-extrabold flex items-center justify-center gap-0.5 font-mono text-xs">
                            +{p.premium.weeklyGrowth}%
                          </span>
                        </td>

                        {/* TOP PLAYLIST */}
                        <td className="p-4 text-gray-400 font-semibold truncate max-w-[150px]">
                          <div className="flex items-center gap-1.5 text-xs">
                            <Disc size={10} className="text-gray-500 animate-spin duration-10000" />
                            <span>{p.premium.topPlaylistTitle}</span>
                          </div>
                        </td>

                        {/* SCORE POINTS */}
                        <td className="p-4 text-right pr-6 font-mono text-amber-500 font-black text-sm">
                          {p.premium.points.toLocaleString()} <span className="text-[10px] font-bold text-gray-500 tracking-wide font-sans">PTS</span>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

    </div>
  );
}
