import React, { useState, useEffect } from 'react';
import { getSupabase } from '@/src/lib/supabase';
import { adminStore } from '@/src/lib/adminStore';
import { notifyVerified } from '@/src/lib/notifications';
import { createSocialActivity } from '@/src/lib/activity';
import VerifiedBadge from '../VerifiedBadge';
import { Search, CheckCircle2, XCircle, ShieldCheck, Landmark, Cpu } from 'lucide-react';

export default function AdminProducersManagement() {
  const [producers, setProducers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [confirmModal, setConfirmModal] = useState<{ id: string; isVerified: boolean; name: string } | null>(null);
  const supabase = getSupabase();

  useEffect(() => {
    fetchProducers();
  }, [supabase]);

  async function fetchProducers() {
    if (!supabase) return;
    setLoading(true);
    
    try {
      // Fetch all profiles to be extremely robust and avoid missing anybody due to role mismatches
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('*');
      
      if (profilesError) {
        console.error("Error fetching producers profiles:", profilesError);
        setProducers([]);
        setLoading(false);
        return;
      }

      if (profilesData && profilesData.length > 0) {
        // Fetch beat counts in-memory to bypass relation joins entirely
        const { data: beatsData, error: beatsError } = await supabase
          .from('beats')
          .select('id, producer_id');

        if (beatsError) {
          console.warn("Could not fetch beats for counts in-memory:", beatsError);
        }

        const countsMap = new Map<string, number>();
        (beatsData || []).forEach(b => {
          if (b.producer_id) {
            countsMap.set(b.producer_id, (countsMap.get(b.producer_id) || 0) + 1);
          }
        });

        // Strict producer filtering
        const filteredProfiles = profilesData.filter((p: any) => {
          const totalBeats = countsMap.get(p.id) || 0;

          // 1. Must have at least 1 beat published
          if (totalBeats === 0) {
            return false;
          }

          // 2. Must not be empty account
          const displayName = (p.display_name || p.artistic_name || p.full_name || '').trim();
          const username = p.username || '';
          if (!displayName && !username) {
            return false;
          }

          // 3. Must not have email name
          const mainName = p.artistic_name || p.display_name || p.full_name || p.username || '';
          const hasEmailName = mainName.includes('@') || username.includes('@');
          if (hasEmailName) {
            return false;
          }

          return true;
        });

        const mappedProducers = filteredProfiles.map(p => ({
          ...p,
          beats: [{ count: countsMap.get(p.id) || 0 }]
        }));

        setProducers(mappedProducers);
      } else {
        setProducers([]);
      }
    } catch (err) {
      console.error("Exception in fetchProducers:", err);
      setProducers([]);
    } finally {
      setLoading(false);
    }
  }

  async function updateProducerStatus(id: string, field: string, value: any, name: string) {
    if (!supabase) return;
    
    if (field === 'is_verified') {
      console.log("VERIFY CLICK", id, value);
    } else {
      console.log("STATUS UPDATE CLICK", id, field, value);
    }
    
    // Optimistic UI update
    setProducers(prev => prev.map(p => p.id === id ? { ...p, [field]: value } : p));

    try {
      if (!supabase) return;
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData?.session?.access_token;

      // Call server-side API proxy to bypass RLS policies
      const res = await fetch('/api/admin/profiles/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(accessToken ? { 'Authorization': `Bearer ${accessToken}` } : {})
        },
        body: JSON.stringify({
          profileId: id,
          updates: { [field]: value }
        })
      });

      const resJson = await res.json();
      if (field === 'is_verified') {
        console.log("VERIFY RESPONSE", resJson.data);
        console.log("VERIFY ERROR", resJson.error);
      }

      if (!res.ok || resJson.error) {
        throw new Error(resJson.error || "Erro ao atualizar no servidor");
      }
      
      // Log administrative action
      const adminName = 'António (Root)';
      if (field === 'is_verified') {
        adminStore.addLog(
          adminName,
          value ? 'Verificar Produtor' : 'Remover Verificação',
          id,
          'profile',
          value 
            ? `Atribuída verificação oficial com selo premium ao produtor ${name}`
            : `Removido selo de verificação oficial do produtor ${name}`
        );
        if (value) {
          try {
            await notifyVerified(id);
          } catch (notifErr) {
            console.warn('Silent notify verified fail:', notifErr);
          }

          // Create dynamic feed activity
          const p = producers.find(item => item.id === id);
          if (p) {
            try {
              await createSocialActivity({
                user_id: id,
                type: 'verified',
                actor_name: name,
                actor_username: p.username || 'producer',
                actor_avatar: p.avatar_url || null,
              });
            } catch (actErr) {
              console.warn('Silent social activity verified creation fail:', actErr);
            }
          }
        }
      } else if (field === 'verification_status') {
        adminStore.addLog(
          adminName,
          `Alterar Status: ${value}`,
          id,
          'profile',
          `Alterado status dos detalhes bancários de ${name} para ${value}`
        );
      }
    } catch (err: any) {
      console.error("Failed to update status on server:", err);
      // Revert optimistic update
      setProducers(prev => prev.map(p => p.id === id ? { ...p, [field]: !value } : p));
      alert("Erro ao atualizar o estado do produtor: " + (err.message || err));
    }
  }

  async function toggleVerified(id: string, isVerifiedValue: boolean) {
    const p = producers.find(item => item.id === id);
    const name = p ? (p.display_name || p.artistic_name || p.full_name || 'Produtor') : 'Produtor';
    await updateProducerStatus(id, 'is_verified', isVerifiedValue, name);
  }

  async function updateProducerBadge(id: string, badgeValue: string | null, name: string) {
    if (!supabase) return;
    
    // Fetch the current record first to avoid wiping out metadata
    const { data } = await supabase.from('profiles').select('phone, is_verified').eq('id', id).maybeSingle();
    let oldSettings: any = {};
    if (data?.phone && data.phone.startsWith('{')) {
      try {
        oldSettings = JSON.parse(data.phone);
      } catch {}
    }
    
    const newSettings = {
      ...oldSettings,
      premium_badge: badgeValue || null
    };
    
    const newPhoneString = JSON.stringify(newSettings);
    
    try {
      if (!supabase) return;
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData?.session?.access_token;

      const res = await fetch('/api/admin/profiles/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(accessToken ? { 'Authorization': `Bearer ${accessToken}` } : {})
        },
        body: JSON.stringify({
          profileId: id,
          updates: { phone: newPhoneString }
        })
      });

      const resJson = await res.json();
      if (!res.ok || resJson.error) {
        throw new Error(resJson.error || "Erro ao atualizar badge no servidor");
      }
      
      // Update local state directly
      setProducers(prev => prev.map(p => p.id === id ? { ...p, phone: newPhoneString } : p));
    } catch (error: any) {
      console.error("Error setting badge:", error);
      alert("Erro ao salvar Badge do Produtor: " + error.message);
      return;
    }
    
    // Log administrative action
    const adminName = 'António (Root)';
    adminStore.addLog(
      adminName,
      'Definir Badge Premium',
      id,
      'profile',
      `Definido o status premium "${badgeValue || 'Nenhum'}" para o produtor ${name}`
    );
  }

  async function confirmVerificationChange() {
    if (!confirmModal) return;
    const { id, isVerified, name } = confirmModal;
    setConfirmModal(null);
    await updateProducerStatus(id, 'is_verified', isVerified, name);
  }

  const filteredProducers = producers.filter(p => {
    const name = (p.display_name || p.artistic_name || p.full_name || p.username || 'Sem Nome').toLowerCase();
    const email = (p.email || '').toLowerCase();
    const searchLow = searchTerm.toLowerCase();
    const matchesSearch = name.includes(searchLow) || email.includes(searchLow);
    const matchesFilter = filter === 'all' || p.verification_status === filter;
    return matchesSearch && matchesFilter;
  });

  if (loading) {
    return (
      <div className="p-16 text-center text-neutral-400 font-mono text-xs flex flex-col items-center justify-center gap-3">
        <Cpu className="w-5 h-5 animate-spin text-[#5865F2]" />
        CARREGANDO MAPA DE PRODUTORES...
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Subheader and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black uppercase italic tracking-tight text-white flex items-center gap-2">
            <Landmark className="text-[#5865F2] w-5 h-5" />
            CONTROLO de PRODUTORES e CONTAS PARCEIRAS
          </h2>
          <p className="text-xs text-neutral-400 font-medium font-sans">Administração de produtores, gestão de KYC e verificação oficial de criadores.</p>
        </div>

        {/* Filters/Search block */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-60">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500 w-3.5 h-3.5" />
            <input 
              type="text" 
              placeholder="Pesquisar por nome ou e-mail..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0a0a0f] border border-white/[0.05] hover:border-white/[0.10] focus:border-[#5865F2]/45 rounded-xl py-2 pl-9 pr-4 text-xs text-white placeholder-neutral-500 font-semibold focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all font-sans"
            />
          </div>

          <select 
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-[#0a0a0f] border border-white/[0.05] hover:border-white/[0.10] rounded-xl py-2 px-3 text-[10px] text-neutral-400 uppercase tracking-widest font-black outline-none cursor-pointer focus:border-[#5865F2]/50 font-mono"
          >
            <option value="all">Filtro de Dados (Todos)</option>
            <option value="approved">Aprovados</option>
            <option value="pending">Pendentes</option>
            <option value="rejected">Rejeitados</option>
          </select>
        </div>
      </div>

      {filteredProducers.length === 0 ? (
        <div className="bg-black/40 border border-white/[0.04] p-12 rounded-2xl text-center text-neutral-500">
          Nenhum produtor registado com os critérios escolhidos.
        </div>
      ) : (
        <div className="bg-[#050505] border border-white/[0.04] rounded-2xl overflow-hidden shadow-2xl relative">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-[#09090C]/80 border-b border-white/[0.04] text-neutral-500 text-[10px] uppercase tracking-widest font-black font-mono">
                <tr>
                  <th className="p-5 pl-6">Nome / Selo</th>
                  <th className="p-5">E-mail</th>
                  <th className="p-5">Status Payout (Dados)</th>
                  <th className="p-5 text-center">Beats Ativos</th>
                  <th className="p-5 text-right pr-6">AÇÕES OPERACIONAIS</th>
                </tr>
              </thead>
              <tbody className="text-xs font-semibold divide-y divide-white/[0.02]">
                {filteredProducers.map(p => {
                  const producer = p;
                  const name = p.display_name || p.artistic_name || p.full_name || 'Produtor';
                  
                  // Parse phone JSON for active premium badge
                  let activeBadge = '';
                  if (p.phone && p.phone.startsWith('{')) {
                    try {
                      const parsed = JSON.parse(p.phone);
                      activeBadge = parsed.premium_badge || '';
                    } catch {}
                  }

                  return (
                    <tr key={p.id} className="hover:bg-white/[0.015] transition-colors border-b border-white/[0.02] last:border-0">
                      <td className="p-5 pl-6">
                        <div className="flex items-center gap-2.5">
                          <span className="font-extrabold text-neutral-100 hover:text-white uppercase italic tracking-tight">{name}</span>
                          {p.is_verified && <VerifiedBadge size="sm" />}
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          {producer.is_verified ? (
                            <button
                              onClick={() => toggleVerified(producer.id, false)}
                              className="px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-white/70 hover:bg-white/10 text-[10px] uppercase font-black tracking-wider transition cursor-pointer"
                            >
                              Remover Verified
                            </button>
                          ) : (
                            <button
                              onClick={() => toggleVerified(producer.id, true)}
                              className="px-3 py-1 rounded-lg bg-[#5865F2] hover:bg-[#4752C4] text-white text-[10px] uppercase font-black tracking-wider transition animate-pulse cursor-pointer"
                            >
                              Verificar Produtor
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="p-5 text-neutral-400 font-mono text-[11px] font-medium">{p.email}</td>
                      <td className="p-5">
                        <span className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border font-mono ${
                          p.verification_status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                          p.verification_status === 'rejected' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 
                          'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}>
                          {p.verification_status || 'pendente'}
                        </span>
                      </td>
                      <td className="p-5 text-center text-neutral-300 font-mono font-black text-xs">
                        {p.beats?.[0]?.count || 0}
                      </td>
                      <td className="p-5 text-right pr-6">
                        <div className="flex items-center justify-end gap-2 text-neutral-200">
                          <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest mr-1">Dados Bancários:</span>
                          <button 
                            onClick={() => updateProducerStatus(p.id, 'verification_status', 'approved', name)} 
                            className="p-2 bg-emerald-500/5 hover:bg-emerald-500/10 text-emerald-400 rounded-lg transition-colors cursor-pointer" 
                            title="Aprovar Payout"
                          >
                            <CheckCircle2 size={13}/>
                          </button>
                          <button 
                            onClick={() => updateProducerStatus(p.id, 'verification_status', 'rejected', name)} 
                            className="p-2 bg-rose-500/5 hover:bg-rose-500/10 text-rose-400 rounded-lg transition-colors cursor-pointer" 
                            title="Rejeitar Payout"
                          >
                            <XCircle size={13}/>
                          </button>
                          
                          <div className="h-4 w-px bg-white/10 mx-1.5" />

                          <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest mr-0.5">Selo:</span>
                          <select
                            value={activeBadge}
                            onChange={(e) => updateProducerBadge(p.id, e.target.value || null, name)}
                            className="bg-[#121217] hover:bg-[#181822] text-xs text-neutral-300 font-bold px-2.5 py-1.5 rounded-lg border border-white/5 focus:outline-none focus:border-amber-500/50 cursor-pointer text-[9px] uppercase font-mono tracking-wider transition-all"
                            title="Alterar Atribuição de Status Premium"
                          >
                            <option value="">NENHUM</option>
                            <option value="verified">VERIFIED</option>
                            <option value="trending">TRENDING</option>
                            <option value="top_producer">TOP PROD</option>
                            <option value="elite_seller">ELITE SELLER</option>
                            <option value="rising_star">RISING STAR</option>
                          </select>
                          
                          <div className="h-4 w-px bg-white/10 mx-1.5" />
                          
                          {p.is_verified ? (
                            <button 
                              onClick={() => setConfirmModal({ id: p.id, isVerified: false, name })} 
                              className="px-3 py-1.5 rounded-lg text-white/90 bg-white/[0.06] border border-white/[0.08] hover:bg-white/[0.12] transition-all flex items-center gap-1.5 font-black uppercase tracking-widest text-[9px] cursor-pointer"
                              title="Remover Selo Verificado"
                            >
                              Remover Verified
                            </button>
                          ) : (
                            <button 
                              onClick={() => setConfirmModal({ id: p.id, isVerified: true, name })} 
                              className="px-3 py-1.5 rounded-lg text-white bg-[#1D9BF0] hover:bg-[#1A8CD8] transition-all flex items-center gap-1.5 font-black uppercase tracking-widest text-[9px] cursor-pointer"
                              title="Atribuir Selo de Verificação"
                            >
                              Verificar
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {confirmModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
          <div className="bg-[#0b0b11] border border-white/[0.08] rounded-2xl max-w-sm w-full p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <h3 className="text-base font-black text-white uppercase italic tracking-tight mb-2">
              Confirmar Alteração de Selo
            </h3>
            <p className="text-xs text-neutral-400 font-sans leading-relaxed mb-6">
              {confirmModal.isVerified 
                ? `Confirmar verificação oficial do produtor "${confirmModal.name}"? Isso adicionará o selo azul e gerará um feed de atividade.`
                : `Remover selo verified do produtor "${confirmModal.name}"?`
              }
            </p>
            <div className="flex items-center justify-end gap-3 font-mono text-[10px] uppercase font-black">
              <button
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 text-neutral-300 rounded-lg transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={confirmVerificationChange}
                className={`px-4 py-2 rounded-lg text-white transition-all cursor-pointer ${
                  confirmModal.isVerified
                    ? 'bg-[#1D9BF0] hover:bg-[#1A8CD8]'
                    : 'bg-rose-500 hover:bg-rose-600'
                }`}
              >
                {confirmModal.isVerified ? 'Confirmar Verificação' : 'Remover'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
