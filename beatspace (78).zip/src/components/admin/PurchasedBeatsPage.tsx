import React, { useState, useEffect } from 'react';
import { getSupabase, getPublicUrl, getBeatSignedUrl } from '@/src/lib/supabase';
import { useAuth } from '@/src/context/AuthContext';
import { Download, Lock, CheckCircle2, Clock, FileText, Music, Info, ExternalLink, Check } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { generateLicensePDF } from '@/src/lib/licenseTemplates';
import InstagramLoader from '../InstagramLoader';

export default function PurchasedBeatsPage() {
  const [purchases, setPurchases] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = getSupabase();
  const { user } = useAuth();

  useEffect(() => {
    fetchPurchases();
  }, [supabase, user]);

  async function fetchPurchases() {
    if (!supabase || !user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('purchased_beats')
        .select('*, beats(*), orders(*)')
        .eq('customer_id', user.id);
      
      if (error) {
        console.error("Error fetching purchases:", error);
      } else if (data) {
        setPurchases(data);
      }
    } catch (err) {
      console.error("Exception fetching purchases:", err);
    } finally {
      setLoading(false);
    }
  }

  const generateLicenseFile = (beatTitle: string, licenseType: string, buyerName: string, orderId: string, date: string, producerName: string, bpm?: string | number, genre?: string, price?: string) => {
    const doc = new jsPDF();
    generateLicensePDF(doc, {
      beatTitle,
      licenseType,
      buyerName,
      producerName,
      orderId,
      date,
      bpm,
      genre,
      price
    });
  };

  async function handleDownloadBeat(p: any, fileKey: 'master' | 'demo' | 'stems' = 'master') {
    if (!supabase) return;
    const beat = p.beats;
    if (!beat) {
      alert("Metadados do instrumental em falta.");
      return;
    }

    let filePath = '';
    if (fileKey === 'stems') {
      filePath = beat.stems_url;
    } else if (fileKey === 'demo') {
      filePath = beat.demo_url;
    } else {
      filePath = beat.master_url;
    }

    if (!filePath) {
      alert("Nenhum ficheiro correspondente de áudio para esta opção está associado a esta obra neste momento.");
      return;
    }

    try {
      // Secure downloads for masters and stems
      if (fileKey === 'master' || fileKey === 'stems') {
        const signedUrl = await getBeatSignedUrl(beat.id, fileKey);
        if (signedUrl) {
          window.open(signedUrl, '_blank');
          return;
        } else {
          alert("Não foi possível gerar um link seguro para o ficheiro premium. Certifique-se de que o pagamento foi confirmado.");
          return;
        }
      }

      // Create secure signed download url for 60 seconds (for previews / demo)
      const { data, error } = await supabase.storage
        .from('beats')
        .createSignedUrl(filePath, 60);

      if (error) throw error;

      if (data?.signedUrl) {
         window.open(data.signedUrl, '_blank');
      } else {
        alert("Não foi possível resolver o link seguro. A tentar ligação direta...");
        const fallbackUrl = getPublicUrl('beats', filePath);
        if (fallbackUrl) window.open(fallbackUrl, '_blank');
      }
    } catch (err: any) {
      console.error("Signed URL helper failure, attempting direct link fallback...:", err);
      const fallbackUrl = getPublicUrl('beats', filePath);
      if (fallbackUrl) {
        window.open(fallbackUrl, '_blank');
      } else {
        alert("Erro fatal ao estabelecer download de segurança.");
      }
    }
  }

  function handleDownloadLicense(p: any) {
    try {
      const beatTitle = p.beats?.title || 'Beat';
      const licenseType = p.license_type || (p.license_id === 1 ? 'basic' : p.license_id === 2 ? 'premium' : 'exclusive');
      const buyerName = user?.user_metadata?.full_name || user?.email || 'Artista';
      const orderId = p.order_id || 'N/A';
      const purchaseDate = p.created_at ? new Date(p.created_at).toLocaleDateString() : new Date().toLocaleDateString();
      const producerName = p.beats?.producer_profile?.artistic_name || p.beats?.producer_profile?.display_name || p.beats?.producer_name || p.beats?.producer || 'Produtor Autorizado';

      const bpm = p.beats?.bpm || '120';
      const genre = p.beats?.genre || 'Afro House / Semba / Kuduro';
      const priceVal = p.price_paid ? `${p.price_paid.toLocaleString('pt-AO')} Kz` : p.beats?.price ? `${p.beats.price.toLocaleString('pt-AO')} Kz` : 'N/A';

      generateLicenseFile(beatTitle, licenseType, buyerName, orderId, purchaseDate, producerName, bpm, genre, priceVal);
    } catch (err) {
      console.error("Error creating license file:", err);
      alert("Erro ao descarregar a licença.");
    }
  }

  if (loading) {
    return <InstagramLoader label="A carregar o seu portfólio de compras..." />;
  }

  if (purchases.length === 0) {
    return (
      <div className="p-8 bg-[#0B0B0F] min-h-screen text-white flex flex-col justify-center items-center">
        <div className="bg-white/5 border border-white/10 p-12 rounded-[40px] max-w-md text-center space-y-6">
          <Lock size={48} className="text-gray-500 mx-auto" />
          <h2 className="text-2xl font-black italic uppercase">Sem Compras Ativas</h2>
          <p className="text-gray-400 text-sm">
            Aqui serão listados os teus instrumentais e licenças adquiridas. Visita o nosso catálogo de beats para fazeres a tua primeira aquisição!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 bg-[#0B0B0F] min-h-screen text-white max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-black italic uppercase">As Minhas <span className="text-orange-500">Compras</span></h1>
        <p className="text-gray-400 text-sm mt-1">Gerencia facilmente os teus instrumentais libertados e contratos de utilização exclusivos.</p>
      </div>

      <div className="grid gap-6">
        {purchases.map(p => {
          const isPaid = p.orders?.status === 'paid' || p.orders === null; // Fallback to paid if order was created previously/mocked.
          const status = p.orders?.status || 'comprado';
          const licType = p.license_type || 'basic';
          
          return (
            <div key={p.id} className="bg-white/[0.03] hover:bg-white/[0.05] border border-white/10 p-6 md:p-8 rounded-[32px] flex flex-col gap-6 transition-all duration-300 relative group overflow-hidden">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div className="flex items-center gap-5 shrink-0">
                  <div className="relative w-16 h-16 rounded-2xl overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center text-gray-400">
                    {p.beats?.cover_url ? (
                      <img 
                        src={getPublicUrl('beats', p.beats.cover_url)} 
                        alt={p.beats?.title} 
                        className="w-full h-full object-cover" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <Music size={24} />
                    )}
                    {!isPaid && (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-yellow-500 backdrop-blur-[2px]">
                        <Lock size={18} />
                      </div>
                    )}
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-extrabold text-white text-lg group-hover:text-blue-400 transition-colors">{p.beats?.title || 'Obra Sem Nome'}</h3>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 text-[10px] font-black uppercase tracking-wider">
                        Licença {licType === 'exclusive' ? 'Ilimitada (WAV + Stems)' : licType === 'premium' ? 'Premium (MP3 + WAV)' : 'Básica (MP3)'}
                      </span>
                      <span className="text-gray-500 text-xs font-medium">| ID Pedido: {p.order_id?.substring(0, 8).toUpperCase() || 'N/A'}</span>
                    </div>
                    <p className="text-[11px] text-gray-500">
                      Comprado em: {p.orders?.created_at ? new Date(p.orders.created_at).toLocaleDateString() : new Date().toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {/* Status Indicator */}
                <div className="flex flex-col items-start md:items-end justify-center px-2 shrink-0">
                  {isPaid ? (
                    <span className="flex items-center gap-1.5 text-xs text-green-500 font-extrabold bg-green-500/10 px-3 py-1 rounded-full border border-green-500/20 uppercase tracking-widest">
                      <CheckCircle2 size={12} /> Disponível
                    </span>
                  ) : status === 'waiting_confirmation' ? (
                    <span className="flex items-center gap-1.5 text-xs text-amber-500 font-extrabold bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20 uppercase tracking-widest">
                      <Clock size={12} /> Em Verificação
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 text-xs text-yellow-500 font-extrabold bg-yellow-500/10 px-3 py-1 rounded-full border border-yellow-500/20 uppercase tracking-widest">
                      <Clock size={12} /> Pagamento Em Falta
                    </span>
                  )}
                </div>
              </div>

              {/* Dynamic Deliveries & Terms Summary */}
              {isPaid && (
                <div className="border-t border-white/5 pt-4 space-y-4">
                  <div>
                    <h4 className="text-gray-400 text-[10px] font-black uppercase tracking-wider mb-2">Ficheiros Disponíveis para Descarregar</h4>
                    <div className="flex flex-wrap gap-2.5">
                      {/* Delivering MP3 for Basic */}
                      {licType === 'basic' && (
                        <button 
                          onClick={() => handleDownloadBeat(p, 'master')}
                          className="bg-blue-600 hover:bg-blue-500 text-white font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 transition-all active:scale-95 uppercase tracking-wider cursor-pointer"
                        >
                          <Download size={13} /> Descarregar MP3 Principal
                        </button>
                      )}

                      {/* Delivering MP3 + WAV for Premium */}
                      {licType === 'premium' && (
                        <>
                          <button 
                            onClick={() => handleDownloadBeat(p, 'master')}
                            className="bg-orange-600 hover:bg-orange-500 text-white font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 transition-all active:scale-95 uppercase tracking-wider cursor-pointer"
                          >
                            <Download size={13} /> Descarregar Ficheiro WAV
                          </button>
                          <button 
                            onClick={() => handleDownloadBeat(p, 'demo')}
                            className="bg-white/5 border border-white/10 hover:bg-white/10 text-white font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 transition-all active:scale-95 uppercase tracking-wider cursor-pointer"
                          >
                            <Download size={13} /> Descarregar Fone MP3
                          </button>
                        </>
                      )}

                      {/* Delivering MP3 + WAV + optional stems for Unlimited */}
                      {licType === 'exclusive' && (
                        <>
                          <button 
                            onClick={() => handleDownloadBeat(p, 'master')}
                            className="bg-purple-600 hover:bg-purple-500 text-white font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 transition-all active:scale-95 uppercase tracking-wider cursor-pointer"
                          >
                            <Download size={13} /> Descarregar Master WAV
                          </button>
                          {p.beats?.stems_url && (
                            <button 
                              onClick={() => handleDownloadBeat(p, 'stems')}
                              className="bg-blue-600 hover:bg-blue-500 text-white font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 transition-all active:scale-95 uppercase tracking-wider cursor-pointer"
                            >
                              <Download size={13} /> Descarregar Stems (ZIP)
                            </button>
                          )}
                        </>
                      )}

                      <button 
                        onClick={() => handleDownloadLicense(p)}
                        className="bg-white/10 hover:bg-white/15 text-white font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 transition-all active:scale-95 uppercase tracking-wider cursor-pointer"
                      >
                        <FileText size={13} /> Ver Licença Comercial (.txt)
                      </button>
                    </div>
                  </div>

                  {/* Licensing Terms Summary */}
                  <div className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl">
                    <h5 className="text-[10px] uppercase font-black tracking-widest text-gray-500 mb-1.5">Acordo de Licença & Direitos de Uso</h5>
                    <ul className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[10px] text-gray-400">
                      <li className="flex items-center gap-1.5">
                        <Check size={11} className="text-green-500 shrink-0" />
                        Esta é uma licença não-exclusiva.
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check size={11} className="text-green-500 shrink-0" />
                        A revenda ou redistribuição do beat não é permitida.
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check size={11} className="text-green-500 shrink-0" />
                        Crédito obrigatório ao produtor (ex: Prod. {p.beats?.producer_name || 'Produtor'}).
                      </li>
                    </ul>
                  </div>
                </div>
              )}

              {/* Locked view */}
              {!isPaid && (
                <div className="border-t border-white/5 pt-4 flex gap-3">
                  <button 
                    disabled 
                    className="bg-white/5 border border-white/5 text-gray-500 font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 cursor-not-allowed uppercase tracking-wider"
                    title="Aguardando confirmação do pagamento pelo administrador."
                  >
                    <Lock size={12} /> Ficheiros Bloqueados
                  </button>
                  <button 
                    disabled 
                    className="bg-white/5 border border-white/5 text-gray-500 font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 cursor-not-allowed uppercase tracking-wider"
                  >
                    <Lock size={12} /> Sem Contrato Ativo
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      {/* Information Helper box */}
      <div className="bg-white/5 border border-white/10 p-6 rounded-3xl flex items-start gap-4 text-xs text-gray-400">
        <Info size={16} className="text-blue-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-gray-300">Como funciona a liberação de ficheiros?</p>
          <p>O tempo de liberação depende diretamente da verificação manual do comprovativo de pagamento pela nossa equipe. Normalmente, os ficheiros são desbloqueados em menos de 2 horas.</p>
        </div>
      </div>
    </div>
  );
}
