import React from 'react';
import { LayoutDashboard, ShoppingCart, Music, Users, Banknote, DollarSign, ArrowUpRight, AlertTriangle, Star, Database } from 'lucide-react';

export default function AdminDashboard({ currentTab, setCurrentTab }: { currentTab: string, setCurrentTab: (tab: string) => void }) {
  const tabs = [
    { id: 'overview', name: 'Dashboard', icon: LayoutDashboard, color: 'text-blue-400' },
    { id: 'orders', name: 'Orders', icon: ShoppingCart, color: 'text-emerald-400' },
    { id: 'beats', name: 'Beats', icon: Music, color: 'text-purple-400' },
    { id: 'clientes', name: 'Clientes', icon: Users, color: 'text-pink-400' },
    { id: 'payouts', name: 'Produtores', icon: Banknote, color: 'text-yellow-400' },
    { id: 'financial', name: 'Faturamentos', icon: DollarSign, color: 'text-amber-400' },
    { id: 'withdrawals', name: 'Levantamentos', icon: ArrowUpRight, color: 'text-orange-400' },
    { id: 'reports', name: 'Denúncias', icon: AlertTriangle, color: 'text-red-400' },
    { id: 'featured', name: 'Destaques', icon: Star, color: 'text-violet-400' },
    { id: 'system-logs', name: 'System Logs', icon: Database, color: 'text-cyan-400' },
  ];

  return (
    <div className="w-full lg:w-56 shrink-0 flex flex-nowrap lg:flex-col overflow-x-auto lg:overflow-x-visible gap-1 p-1 rounded-xl bg-[#09090b] border border-white/5 scrollbar-none sticky top-24 lg:max-h-[calc(100vh-110px)]">
      <div className="hidden lg:block px-3 py-2 border-b border-white/5 mb-1.5 text-left">
        <span className="text-[10px] font-bold tracking-wider text-[#A1A1AA] uppercase">Painel Administrativo</span>
      </div>
      
      {tabs.map(tab => {
        const isActive = currentTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setCurrentTab(tab.id)}
            className={`flex items-center gap-2.5 px-3 py-2 rounded text-xs font-semibold transition-all relative whitespace-nowrap cursor-pointer shrink-0 ${
              isActive 
                ? 'bg-[#5865F2] text-white' 
                : 'text-neutral-400 hover:bg-white/5 hover:text-white'
            }`}
          >
            <tab.icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-neutral-500'}`} />
            <span>{tab.name}</span>
          </button>
        );
      })}
    </div>
  );
}
