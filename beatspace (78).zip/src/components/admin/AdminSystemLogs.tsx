import React, { useState, useEffect } from 'react';
import { getSupabase } from '../../lib/supabase';
import { 
  AlertTriangle, 
  Trash2, 
  RefreshCw, 
  CheckCircle2, 
  Database, 
  FileText, 
  ShieldCheck, 
  Clock, 
  Search, 
  X, 
  ListRestart, 
  Coins, 
  Image, 
  Music, 
  Users, 
  FolderSync 
} from 'lucide-react';

interface SystemLog {
  id: string;
  type: string;
  message: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  route?: string;
  userId?: string;
  stack?: string;
  timestamp: string;
  details?: any;
}

interface BackupItem {
  backup_id: string;
  type: 'beat' | 'playlist' | 'profile';
  original_id: string;
  deleted_at: string;
  data: any;
}

interface StorageReport {
  success: boolean;
  summary: {
    totalBeatsChecked: number;
    totalStorageFilesChecked: number;
    orphanedFilesCount: number;
    beatsWithoutAudioCount: number;
    beatsWithoutCoverCount: number;
    brokenLinksCount: number;
  };
  orphanedFiles: string[];
  beatsWithoutAudio: any[];
  beatsWithoutCover: any[];
  brokenLinks: any[];
}

export default function AdminSystemLogs() {
  const [activeSubTab, setActiveSubTab] = useState<'logs' | 'recovery' | 'storage'>('logs');
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [backups, setBackups] = useState<BackupItem[]>([]);
  const [storageReport, setStorageReport] = useState<StorageReport | null>(null);
  
  const [loadingLogs, setLoadingLogs] = useState(false);
  const [loadingBackups, setLoadingBackups] = useState(false);
  const [loadingStorage, setLoadingStorage] = useState(false);
  
  const [logTypeFilter, setLogTypeFilter] = useState<string>('all');
  const [logSeverityFilter, setLogSeverityFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [selectedLog, setSelectedLog] = useState<SystemLog | null>(null);

  const fetchLogs = async () => {
    setLoadingLogs(true);
    try {
      const supabase = getSupabase();
      if (!supabase) return;
      const { data: { session } } = await supabase.auth.getSession();
      
      const res = await fetch('/api/system/logs', {
        headers: {
          'Authorization': `Bearer ${session?.access_token}`
        }
      });
      const data = await res.json();
      if (data.success) {
        setLogs(data.logs);
      }
    } catch (err) {
      console.error('Failed to fetch logs:', err);
    } finally {
      setLoadingLogs(false);
    }
  };

  const fetchBackups = async () => {
    setLoadingBackups(true);
    try {
      const supabase = getSupabase();
      if (!supabase) return;
      const { data: { session } } = await supabase.auth.getSession();
      
      const res = await fetch('/api/system/recovery/list', {
        headers: {
          'Authorization': `Bearer ${session?.access_token}`
        }
      });
      const data = await res.json();
      if (data.success) {
        setBackups(data.backups);
      }
    } catch (err) {
      console.error('Failed to fetch backups:', err);
    } finally {
      setLoadingBackups(false);
    }
  };

  const runStorageValidator = async () => {
    setLoadingStorage(true);
    try {
      const supabase = getSupabase();
      if (!supabase) return;
      const { data: { session } } = await supabase.auth.getSession();
      
      const res = await fetch('/api/system/storage/validate', {
        headers: {
          'Authorization': `Bearer ${session?.access_token}`
        }
      });
      const data = await res.json();
      if (data.success) {
        setStorageReport(data);
      }
    } catch (err) {
      console.error('Failed to run storage validation:', err);
    } finally {
      setLoadingStorage(false);
    }
  };

  const clearLogs = async () => {
    if (!window.confirm('Tem a certeza que deseja limpar todos os logs do sistema?')) return;
    try {
      const supabase = getSupabase();
      if (!supabase) return;
      const { data: { session } } = await supabase.auth.getSession();
      
      const res = await fetch('/api/system/logs/clear', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`
        }
      });
      const data = await res.json();
      if (data.success) {
        setLogs([]);
        setSelectedLog(null);
      }
    } catch (err) {
      console.error('Failed to clear logs:', err);
    }
  };

  const restoreBackup = async (backupId: string) => {
    setRestoringId(backupId);
    try {
      const supabase = getSupabase();
      if (!supabase) return;
      const { data: { session } } = await supabase.auth.getSession();
      
      const res = await fetch('/api/system/recovery/restore', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token}`
        },
        body: JSON.stringify({ backupId })
      });
      const data = await res.json();
      if (data.success) {
        alert('Item restaurado com sucesso na base de dados ativa!');
        fetchBackups();
      } else {
        alert('Falha ao restaurar: ' + (data.error || 'Erro desconhecido'));
      }
    } catch (err: any) {
      alert('Erro ao restaurar: ' + err.message);
    } finally {
      setRestoringId(null);
    }
  };

  useEffect(() => {
    if (activeSubTab === 'logs') {
      fetchLogs();
    } else if (activeSubTab === 'recovery') {
      fetchBackups();
    } else if (activeSubTab === 'storage' && !storageReport) {
      runStorageValidator();
    }
  }, [activeSubTab]);

  const filteredLogs = logs.filter(log => {
    const matchesType = logTypeFilter === 'all' || log.type === logTypeFilter;
    const matchesSeverity = logSeverityFilter === 'all' || log.severity === logSeverityFilter;
    
    const term = searchQuery.toLowerCase();
    const matchesSearch = !searchQuery || 
      log.message.toLowerCase().includes(term) ||
      (log.route && log.route.toLowerCase().includes(term)) ||
      (log.userId && log.userId.toLowerCase().includes(term));
      
    return matchesType && matchesSeverity && matchesSearch;
  });

  const getSeverityBadge = (sec: string) => {
    switch (sec) {
      case 'critical':
        return <span className="px-2 py-0.5 rounded text-[9px] font-black bg-red-900/30 text-red-400 border border-red-500/30">CRITICAL</span>;
      case 'error':
        return <span className="px-2 py-0.5 rounded text-[9px] font-black bg-orange-950/40 text-orange-400 border border-orange-500/20">ERROR</span>;
      case 'warning':
        return <span className="px-2 py-0.5 rounded text-[9px] font-black bg-yellow-950/40 text-yellow-500 border border-yellow-500/20">WARNING</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[9px] font-black bg-[#101015] text-neutral-400 border border-white/[0.04]">INFO</span>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.04]">
        <div>
          <h2 className="text-xl font-black tracking-tight flex items-center gap-2 text-white">
            <Database className="w-5 h-5 text-[#5865F2]" />
            ESTABILIDADE & AUDITORIA DO SISTEMA
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Logs profissionais, backups automáticos de segurança e integridade física de arquivos em tempo real.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-[#0a0a0f] border border-white/[0.04] p-1 rounded-xl shrink-0">
          <button
            onClick={() => setActiveSubTab('logs')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all duration-300 ${
              activeSubTab === 'logs' ? 'bg-[#5865F2] text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            System Logs
          </button>
          <button
            onClick={() => setActiveSubTab('recovery')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all duration-300 ${
              activeSubTab === 'recovery' ? 'bg-[#5865F2] text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Sistema de Recuperação
          </button>
          <button
            onClick={() => setActiveSubTab('storage')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all duration-300 ${
              activeSubTab === 'storage' ? 'bg-[#5865F2] text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Validador de Storage
          </button>
        </div>
      </div>

      {/* 1. TAB: RECENT LOGS */}
      {activeSubTab === 'logs' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-500" />
              <input
                type="text"
                placeholder="Pesquisar log, rota, ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0a0a0f] border border-white/[0.04] rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-[#5865F2]/50 transition-all font-mono"
              />
            </div>

            <select
              value={logTypeFilter}
              onChange={(e) => setLogTypeFilter(e.target.value)}
              className="bg-[#0a0a0f] border border-white/[0.04] rounded-xl px-3 py-2 text-xs text-neutral-400 focus:outline-none focus:border-[#5865F2]/50"
            >
              <option value="all">Filtro: Todos os Tipos</option>
              <option value="frontend_uncaught">Frontend Uncaught (Crashes)</option>
              <option value="api_error">Erro de API</option>
              <option value="security_spam">Anti-Spam / Rate-Limits</option>
              <option value="security_abuse">Suspeitas / Invasões</option>
              <option value="performance_slow">Performance / APIs Lentas</option>
              <option value="recovery">Recuperação de Dados</option>
              <option value="network_failure">Falha de Rede Cliente</option>
            </select>

            <select
              value={logSeverityFilter}
              onChange={(e) => setLogSeverityFilter(e.target.value)}
              className="bg-[#0a0a0f] border border-white/[0.04] rounded-xl px-3 py-2 text-xs text-neutral-400 focus:outline-none focus:border-[#5865F2]/50"
            >
              <option value="all">Gravidade: Omitir</option>
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="error">Error</option>
              <option value="critical">Critical</option>
            </select>

            <div className="flex items-center gap-2">
              <button
                onClick={fetchLogs}
                disabled={loadingLogs}
                className="flex-1 bg-[#0a0a0f] hover:bg-white/[0.02] border border-white/[0.04] text-neutral-300 rounded-xl px-3 py-2 text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all text-center"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingLogs ? 'animate-spin' : ''}`} />
                Atualizar
              </button>
              <button
                onClick={clearLogs}
                className="bg-red-950/20 hover:bg-red-950/40 border border-red-900/10 text-red-400 rounded-xl px-3 py-2 text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Limpar
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Logs List Table */}
            <div className={`bg-[#050508] border border-white/[0.04] rounded-2xl overflow-hidden ${selectedLog ? 'lg:col-span-7' : 'lg:col-span-12'}`}>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-white/[0.03] bg-white/[0.01]">
                      <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400">Timestamp / Origem</th>
                      <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400">Gravidade</th>
                      <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400">Mensagem do Incidente</th>
                      <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400 text-right">Acção</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loadingLogs ? (
                      <tr>
                        <td colSpan={4} className="px-4 py-12 text-center text-xs text-neutral-500 font-mono animate-pulse">
                          A ligar ao ledger operacional de logs e auditorias de infraestrutura...
                        </td>
                      </tr>
                    ) : filteredLogs.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-4 py-12 text-center text-xs text-neutral-500 font-mono">
                          Nenhum incidente ou registo localizado com os filtros selecionados.
                        </td>
                      </tr>
                    ) : (
                      filteredLogs.map(log => (
                        <tr 
                          key={log.id} 
                          onClick={() => setSelectedLog(log)}
                          className={`border-b border-white/[0.02] text-xs font-mono transition-colors cursor-pointer ${
                            selectedLog?.id === log.id ? 'bg-[#5865F2]/5' : 'hover:bg-white/[0.01]'
                          }`}
                        >
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="flex flex-col">
                              <span className="text-neutral-500 text-[10px]">
                                {new Date(log.timestamp).toLocaleTimeString()}
                              </span>
                              <span className="text-[10px] font-extrabold uppercase text-[#5865F2] mt-0.5">
                                {log.type}
                              </span>
                            </div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {getSeverityBadge(log.severity)}
                          </td>
                          <td className="px-4 py-3">
                            <div className="max-w-[280px] sm:max-w-md truncate text-neutral-200">
                              {log.message}
                            </div>
                            {log.route && (
                              <div className="text-[9px] text-[#A1A1AA]/50 truncate mt-0.5">
                                {log.route}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedLog(log);
                              }}
                              className="text-[10px] font-black uppercase text-[#5865F2] hover:text-[#5865F2]/80 transition-all font-sans"
                            >
                              Detalhes
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Selected Log Sidebar Detail Panel */}
            {selectedLog && (
              <div className="lg:col-span-5 bg-[#0a0a0f] border border-white/[0.04] p-5 rounded-2xl self-start space-y-4 relative">
                <button 
                  onClick={() => setSelectedLog(null)} 
                  className="absolute top-4 right-4 text-neutral-500 hover:text-white transition-all p-1"
                >
                  <X className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2 pb-3 border-b border-white/[0.04]">
                  <FileText className="w-4 h-4 text-[#5865F2]" />
                  <span className="text-xs font-black uppercase tracking-wider text-white">Inspeção de Payload</span>
                </div>

                <div className="space-y-3 font-mono text-xs">
                  <div>
                    <span className="text-neutral-500 block text-[10px] uppercase">ID do Registo</span>
                    <span className="text-neutral-200 break-all">{selectedLog.id}</span>
                  </div>

                  <div>
                    <span className="text-neutral-500 block text-[10px] uppercase">Classificação</span>
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-yellow-400 capitalize bg-yellow-400/10 px-1.5 py-0.5 rounded text-[10px] font-bold">
                        {selectedLog.type}
                      </span>
                      {getSeverityBadge(selectedLog.severity)}
                    </div>
                  </div>

                  <div>
                    <span className="text-neutral-500 block text-[10px] uppercase">Timestamp Completo</span>
                    <span className="text-neutral-200">{new Date(selectedLog.timestamp).toLocaleString()}</span>
                  </div>

                  {selectedLog.route && (
                    <div>
                      <span className="text-neutral-500 block text-[10px] uppercase">Caminho / Endpoint Afetado</span>
                      <span className="text-[#5865F2] break-all">{selectedLog.route}</span>
                    </div>
                  )}

                  {selectedLog.userId && (
                    <div>
                      <span className="text-neutral-500 block text-[10px] uppercase">Utilizador</span>
                      <span className="text-neutral-400 break-all">{selectedLog.userId}</span>
                    </div>
                  )}

                  <div>
                    <span className="text-neutral-500 block text-[10px] uppercase">Mensagem Descritiva</span>
                    <p className="text-neutral-300 mt-1 bg-black/40 p-2.5 rounded border border-white/[0.02] whitespace-pre-wrap leading-relaxed">
                      {selectedLog.message}
                    </p>
                  </div>

                  {selectedLog.stack && (
                    <div>
                      <span className="text-neutral-500 block text-[10px] uppercase">Trace de Error (Stack)</span>
                      <pre className="text-[10px] text-red-400 mt-1 bg-red-950/10 p-2.5 rounded border border-red-500/10 overflow-x-auto max-h-48 scrollbar-thin">
                        {selectedLog.stack}
                      </pre>
                    </div>
                  )}

                  {selectedLog.details && Object.keys(selectedLog.details).length > 0 && (
                    <div>
                      <span className="text-neutral-500 block text-[10px] uppercase">Metadados de Contexto</span>
                      <pre className="text-[10px] text-emerald-400 mt-1 bg-emerald-950/10 p-2.5 rounded border border-emerald-500/10 overflow-x-auto">
                        {JSON.stringify(selectedLog.details, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. TAB: DELETED RESTORE / BACKUP SAFETY */}
      {activeSubTab === 'recovery' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2">
            <div>
              <h3 className="text-sm font-black uppercase text-white tracking-wider flex items-center gap-1.5">
                <FolderSync className="w-4 h-4 text-emerald-400" />
                Ledger Físico de Soft-Delete & Backups Ativos
              </h3>
              <p className="text-neutral-400 text-xs mt-0.5">
                Se os utilizadores finais, capas ou beats forem logicamente eliminados, os seus dados e conexões físicas no Storage permanecem intactos aqui.
              </p>
            </div>
            
            <button
              onClick={fetchBackups}
              disabled={loadingBackups}
              className="bg-[#0a0a0f] hover:bg-white/[0.02] border border-white/[0.04] text-neutral-300 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all"
            >
              <RefreshCw className={`w-3 h-3 ${loadingBackups ? 'animate-spin' : ''}`} />
              Sincronizar Ledger
            </button>
          </div>

          <div className="bg-[#050508] border border-white/[0.04] rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/[0.03] bg-white/[0.01]">
                    <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400">Tipo de Dado</th>
                    <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400">Referência Original</th>
                    <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400">Título / Nome de Identificação</th>
                    <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400">Exclusão (Data)</th>
                    <th className="px-4 py-3 text-[9px] font-mono uppercase tracking-wider text-neutral-400 text-right">Ação Operacional</th>
                  </tr>
                </thead>
                <tbody>
                  {loadingBackups ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-12 text-center text-xs text-neutral-500 font-mono animate-pulse">
                        A consolidar backups de beats, capas, playlists e profiles salvos...
                      </td>
                    </tr>
                  ) : backups.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-12 text-center text-xs text-neutral-500 font-mono">
                        Nenhum item em soft-delete listado para recuperação. Toda a integridade está a 100%.
                      </td>
                    </tr>
                  ) : (
                    backups.map(item => {
                      // Extract name based on type
                      let displayName = 'Sem nome';
                      if (item.type === 'beat') {
                        displayName = item.data?.title || `Beat ID: ${item.original_id}`;
                      } else if (item.type === 'playlist') {
                        displayName = item.data?.playlist?.title || `Playlist ID: ${item.original_id}`;
                      } else if (item.type === 'profile') {
                        displayName = item.data?.display_name || item.data?.artistic_name || `Utilizador ID: ${item.original_id}`;
                      }

                      return (
                        <tr key={item.backup_id} className="border-b border-white/[0.02] text-xs font-mono hover:bg-white/[0.01] transition-colors">
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                              item.type === 'beat' ? 'bg-purple-900/20 text-purple-400 border border-purple-500/20' :
                              item.type === 'playlist' ? 'bg-blue-900/20 text-blue-400 border border-blue-500/20' :
                              'bg-pink-900/20 text-pink-400 border border-pink-500/20'
                            }`}>
                              {item.type}
                            </span>
                          </td>
                          <td className="px-4 py-3 break-all text-neutral-400">
                            {item.original_id}
                          </td>
                          <td className="px-4 py-3 font-sans font-bold text-white">
                            {displayName}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-neutral-500 text-[10px]">
                            {new Date(item.deleted_at).toLocaleString()}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <button
                              onClick={() => restoreBackup(item.backup_id)}
                              disabled={restoringId === item.backup_id}
                              className="bg-emerald-500 hover:bg-emerald-600 disabled:bg-neutral-800 text-black px-3.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer inline-flex items-center gap-1 font-sans shadow-lg shadow-emerald-500/10"
                            >
                              <ListRestart className="w-3.5 h-3.5" />
                              {restoringId === item.backup_id ? 'Restaurando...' : 'Restaurar'}
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. TAB: STORAGE PHYSICAL INTEGRITY VALIDATOR */}
      {activeSubTab === 'storage' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between pb-2">
            <div>
              <h3 className="text-sm font-black uppercase text-white tracking-wider flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-sky-400" />
                Varredura Automatizada contra Ativos Órfãos e Broken Links
              </h3>
              <p className="text-neutral-400 text-xs mt-0.5">
                Verifica de forma cruzada toda a base de dados em busca de links sem covers correspondentes ou beats sem ficheiros de música activos.
              </p>
            </div>
            
            <button
              onClick={runStorageValidator}
              disabled={loadingStorage}
              className="bg-[#0a0a0f] hover:bg-white/[0.02] border border-white/[0.04] text-neutral-300 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingStorage ? 'animate-spin' : ''}`} />
              Executar Nova Varredura
            </button>
          </div>

          {storageReport && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-4 rounded-2xl">
                <span className="text-neutral-500 text-[9px] font-mono block uppercase tracking-wider">Beats Catalogados</span>
                <span className="text-2xl font-black text-white block mt-1">{storageReport.summary.totalBeatsChecked}</span>
              </div>
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-4 rounded-2xl">
                <span className="text-neutral-500 text-[9px] font-mono block uppercase tracking-wider">Ficheiros de Storage</span>
                <span className="text-2xl font-black text-white block mt-1">{storageReport.summary.totalStorageFilesChecked}</span>
              </div>
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-4 rounded-2xl">
                <span className="text-red-500/80 text-[9px] font-mono block uppercase tracking-wider">Erros de Audio</span>
                <span className="text-2xl font-black text-red-400 block mt-1">{storageReport.summary.beatsWithoutAudioCount}</span>
              </div>
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-4 rounded-2xl">
                <span className="text-amber-500/80 text-[9px] font-mono block uppercase tracking-wider">Missing Covers</span>
                <span className="text-2xl font-black text-amber-500 block mt-1">{storageReport.summary.beatsWithoutCoverCount}</span>
              </div>
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-4 rounded-2xl col-span-2 md:col-span-1">
                <span className="text-purple-500/80 text-[9px] font-mono block uppercase tracking-wider">Arquivos Órfãos</span>
                <span className="text-2xl font-black text-purple-400 block mt-1">{storageReport.summary.orphanedFilesCount}</span>
              </div>
            </div>
          )}

          {loadingStorage ? (
            <div className="p-12 text-center text-xs text-neutral-500 font-mono animate-pulse">
              A interrogar Buckets e as tabelas Postgres do projecto para auditoria cruzada...
            </div>
          ) : !storageReport ? (
            <div className="p-12 text-center text-xs text-neutral-500 font-mono">
              Inicie uma verificação para inspecionar orphans ou tracks com links de CDN quebrados.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Orphaned files card container */}
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-5 rounded-2xl space-y-3">
                <h4 className="text-xs font-black uppercase text-purple-400 flex items-center gap-1.5 tracking-wider">
                  <Coins className="w-4 h-4" />
                  Arquivos Órfãos do Storage ({storageReport.summary.orphanedFilesCount})
                </h4>
                <p className="text-[11px] text-[#A1A1AA]/70 leading-relaxed font-sans">
                  Ficheiros de som ou pacotes stem que persistem no Storage do Supabase mas não estão mapeados em nenhum Beat ativo.
                </p>
                {storageReport.orphanedFiles.length === 0 ? (
                  <div className="text-[11px] text-emerald-400 font-mono italic">Zero ficheiros dispersos detectados.</div>
                ) : (
                  <ul className="space-y-1.5 bg-black/40 p-3 rounded-xl border border-white/[0.02] max-h-56 overflow-y-auto font-mono text-[10px] text-neutral-400 scrollbar-thin">
                    {storageReport.orphanedFiles.map((file, i) => (
                      <li key={i} className="flex justify-between hover:text-white transition-colors py-0.5 border-b border-white/[0.01]">
                        <span>{file}</span>
                        <span className="text-[9px] text-neutral-600 font-black">ORPHANED_AUDIO</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Broken Links / missing tracks */}
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-5 rounded-2xl space-y-3">
                <h4 className="text-xs font-black uppercase text-red-400 flex items-center gap-1.5 tracking-wider">
                  <AlertTriangle className="w-4 h-4" />
                  Links CDN Quebrados ou Inexistentes ({storageReport.summary.brokenLinksCount})
                </h4>
                <p className="text-[11px] text-[#A1A1AA]/70 leading-relaxed font-sans">
                  Registo de Beats que apontam para capas ou arquivos demomaster que foram editados ou eliminados de forma corrupta.
                </p>
                {storageReport.brokenLinks.length === 0 ? (
                  <div className="text-[11px] text-emerald-400 font-mono italic">Todos os links apontam para ficheiros válidos e síncronos!</div>
                ) : (
                  <ul className="space-y-1.5 bg-black/40 p-3 rounded-xl border border-white/[0.02] max-h-56 overflow-y-auto font-mono text-[10px] text-red-400/80 scrollbar-thin">
                    {storageReport.brokenLinks.map((link, i) => (
                      <li key={i} className="flex flex-col border-b border-white/[0.01] pb-1">
                        <span className="font-bold text-neutral-300">Beat: {link.title} (ID: {link.id})</span>
                        <span className="text-[9px] text-[#A1A1AA]/60 mt-0.5">Motivo: {link.reason}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Beats without Audio */}
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-5 rounded-2xl space-y-3">
                <h4 className="text-xs font-black uppercase text-amber-500 flex items-center gap-1.5 tracking-wider">
                  <Music className="w-4 h-4" />
                  Beats Sem Qualquer Áudio ({storageReport.summary.beatsWithoutAudioCount})
                </h4>
                <p className="text-[11px] text-[#A1A1AA]/70 leading-relaxed font-sans">
                  Beats listados em catálogo que não contêm qualquer instrumental indexado para ouvir.
                </p>
                {storageReport.beatsWithoutAudio.length === 0 ? (
                  <div className="text-[11px] text-emerald-400 font-mono italic">Zero instrumentais vazios detectados em catálogo.</div>
                ) : (
                  <ul className="space-y-1.5 bg-black/40 p-3 rounded-xl border border-white/[0.02] max-h-56 overflow-y-auto font-mono text-[10px] text-neutral-400 scrollbar-thin">
                    {storageReport.beatsWithoutAudio.map((beat, i) => (
                      <li key={i} className="flex flex-col border-b border-white/[0.01] pb-1">
                        <span className="font-bold text-neutral-300">{beat.title} (ID: {beat.id})</span>
                        <span className="text-[9px] text-[#A1A1AA]/60 mt-0.5">Motivo: {beat.reason}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Beats without Cover */}
              <div className="bg-[#0a0a0f] border border-white/[0.04] p-5 rounded-2xl space-y-3">
                <h4 className="text-xs font-black uppercase text-blue-400 flex items-center gap-1.5 tracking-wider">
                  <Image className="w-4 h-4" />
                  Beats Sem Capas Configuradas ({storageReport.summary.beatsWithoutCoverCount})
                </h4>
                <p className="text-[11px] text-[#A1A1AA]/70 leading-relaxed font-sans">
                  Beats em catálogo que estão a usar uma imagem em fallback por ausência de capa física associada no upload.
                </p>
                {storageReport.beatsWithoutCover.length === 0 ? (
                  <div className="text-[11px] text-emerald-400 font-mono italic">Todos os instrumentais têm uma capa oficial síncrone.</div>
                ) : (
                  <ul className="space-y-1.5 bg-black/40 p-3 rounded-xl border border-white/[0.02] max-h-56 overflow-y-auto font-mono text-[10px] text-neutral-400 scrollbar-thin">
                    {storageReport.beatsWithoutCover.map((beat, i) => (
                      <li key={i} className="flex flex-col border-b border-white/[0.01] pb-1">
                        <span className="font-bold text-neutral-300">{beat.title} (ID: {beat.id})</span>
                        <span className="text-[9px] text-[#A1A1AA]/60 mt-0.5">Motivo: {beat.reason}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
