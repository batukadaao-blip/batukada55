import React, { useState, useEffect } from 'react';
import { getSupabase } from '@/src/lib/supabase';
import { Music, ShoppingCart, DollarSign, Activity, Sparkles, TrendingUp, Landmark } from 'lucide-react';

export default function AdminDashboardOverview() {
  const [stats, setStats] = useState({ beats: 0, orders: 0, revenue: 0, pending: 0 });
  const supabase = getSupabase();

  useEffect(() => {
    async function fetchData() {
      if (!supabase) return;

      const { count: beatsCount } = await supabase.from('beats').select('*', { count: 'exact', head: true });
      const { data: orders } = await supabase.from('orders').select('*');
      
      const totalOrders = orders?.length || 0;
      const totalRevenue = orders?.filter(o => o.status === 'paid').reduce((sum, o) => {
        const orderPrice = o.amount !== undefined && o.amount !== null ? o.amount : (o.price || 0);
        return sum + orderPrice;
      }, 0) || 0;
      const pendingPayments = orders?.filter(o => o.status === 'pending').length || 0;

      setStats({
        beats: beatsCount || 0,
        orders: totalOrders,
        revenue: totalRevenue,
        pending: pendingPayments
      });
    }
    fetchData();
  }, [supabase]);

  const cards = [
    { 
      title: 'Total Beats', 
      value: stats.beats.toLocaleString(), 
      icon: Music, 
      color: 'text-purple-400', 
      bg: 'bg-purple-500/5', 
      border: 'hover:border-purple-500/20' 
    },
    { 
      title: 'Total Orders', 
      value: stats.orders.toLocaleString(), 
      icon: ShoppingCart, 
      color: 'text-emerald-400', 
      bg: 'bg-emerald-500/5', 
      border: 'hover:border-emerald-500/20' 
    },
    { 
      title: 'Total Receita', 
      value: `${stats.revenue.toLocaleString()} Kz`, 
      icon: DollarSign, 
      color: 'text-amber-400', 
      bg: 'bg-amber-500/5', 
      border: 'hover:border-amber-500/20' 
    },
    { 
      title: 'Pagamentos Pendentes', 
      value: stats.pending.toString(), 
      icon: Activity, 
      color: 'text-[#5865F2]', 
      bg: 'bg-[#5865F2]/5', 
      border: 'hover:border-[#5865F2]/20' 
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Overview Banner and Insight */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-white/[0.01] border border-white/[0.03] mb-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#5865F2]/10 to-transparent border border-[#5865F2]/10 flex items-center justify-center text-[#5865F2]">
            <TrendingUp size={18} />
          </div>
          <div>
            <h3 className="text-xs font-black uppercase text-white tracking-wider">Desempenho Geral</h3>
            <p className="text-[11px] text-[#A1A1AA] mt-0.5">Indicadores do ecossistema e volumetria acumulada da sua infraestrutura.</p>
          </div>
        </div>
        <div className="text-[10px] uppercase font-bold text-[#A1A1AA] font-mono tracking-widest bg-white/5 border border-white/5 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
          <Sparkles size={11} className="text-[#5865F2] animate-pulse" />
          ATUALIZAÇÃO AUTOMÁTICA
        </div>
      </div>

      {/* Grid of cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map(card => {
          const IconComponent = card.icon;
          return (
            <div 
              key={card.title} 
              className={`bg-black/40 border border-white/[0.04] p-6 rounded-2xl transition-all duration-300 hover:scale-[1.02] hover:-translate-y-1 hover:shadow-2xl hover:shadow-white/[0.01] ${card.border} group`}
            >
              <div className="flex items-center justify-between gap-4">
                <span className="text-neutral-500 text-[10px] uppercase tracking-widest font-black font-mono">
                  {card.title}
                </span>
                <div className={`p-2.5 rounded-xl ${card.bg} ${card.color} transition-all duration-300 group-hover:scale-110`}>
                  <IconComponent size={15} />
                </div>
              </div>
              
              <div className="mt-4">
                <p className="text-3xl font-black tracking-tighter text-white font-sans group-hover:text-neutral-100 transition-colors">
                  {card.value}
                </p>
                <div className="flex items-center gap-1 mt-1 text-[9px] text-[#A1A1AA] font-semibold">
                  <span className="text-emerald-400">↑ Ativo</span>
                  • Métrica Realtime
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Access panel inside overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
        {/* Operational Status panel */}
        <div className="bg-[#050505]/60 border border-white/[0.03] rounded-2xl p-6">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="w-8 h-8 rounded-lg bg-orange-500/10 border border-orange-500/10 flex items-center justify-center text-orange-400">
              <Landmark size={14} />
            </div>
            <h4 className="text-xs font-black uppercase text-white tracking-widest">Informações do Sistema</h4>
          </div>
          <div className="space-y-3.5 text-xs text-[#A1A1AA] font-medium">
            <div className="flex items-center justify-between py-1.5 border-b border-white/[0.02]">
              <span>Servidores API</span>
              <span className="font-mono text-[10px] text-emerald-400 font-bold uppercase tracking-wider bg-emerald-500/10 px-2 py-0.5 rounded">OPERAÇÃO NORMAL</span>
            </div>
            <div className="flex items-center justify-between py-1.5 border-b border-white/[0.02]">
              <span>Supabase Cluster</span>
              <span className="font-mono text-[10px] text-emerald-400 font-bold uppercase tracking-wider bg-emerald-500/10 px-2 py-0.5 rounded">CONECTADO</span>
            </div>
            <div className="flex items-center justify-between py-1.5">
              <span>Auditoria Geral RLS</span>
              <span className="font-mono text-[10px] text-blue-400 font-bold uppercase tracking-wider bg-blue-500/10 px-2 py-0.5 rounded">SEGURO</span>
            </div>
          </div>
        </div>

        {/* Editor Quick Notice panel */}
        <div className="bg-[#050505]/60 border border-white/[0.03] rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <span className="text-[9px] font-black uppercase tracking-widest text-[#5865F2] font-mono bg-[#5865F2]/10 border border-[#5865F2]/15 px-2 py-1 rounded">DICA OPERACIONAL</span>
            <p className="text-xs text-neutral-400 mt-4 leading-relaxed font-semibold">
              Usa a barra de navegação à esquerda para aceder a controlos em tempo real para beats, orders de compra, faturamentos, perfis dos produtores e moderação de denúncias.
            </p>
          </div>
          <div className="text-[10px] text-neutral-500 mt-4 italic">
            BATUKADA Enterprise Dashboard v2.0
          </div>
        </div>
      </div>
    </div>
  );
}
