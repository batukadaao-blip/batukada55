import React, { useState, useEffect } from 'react';
import { adminStore, Report, AdminLog } from '@/src/lib/adminStore';
import { getSupabase } from '@/src/lib/supabase';
import { 
  AlertTriangle, 
  Check, 
  Trash2, 
  UserPlus, 
  EyeOff, 
  Search, 
  ShieldAlert, 
  FileText, 
  Ban, 
  CheckCircle, 
  XOctagon, 
  RefreshCw,
  MoreVertical,
  Activity,
  UserCheck
} from 'lucide-react';

export default function AdminReportsManagement() {
  const [reports, setReports] = useState<Report[]>([]);
  const [logs, setLogs] = useState<AdminLog[]>([]);
  const [activeSubTab, setActiveSubTab] = useState<'reports' | 'logs'>('reports');
  
  // Search and Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'resolved' | 'ignored'>('all');
  const [filterType, setFilterType] = useState<'all' | 'beat' | 'comment' | 'profile'>('all');
  const [openActionId, setOpenActionId] = useState<string | null>(null);

  // Modal input states
  const [showActionModal, setShowActionModal] = useState(false);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [reasonText, setReasonText] = useState('');
  const [actionType, setActionType] = useState<string>('');

  const supabase = getSupabase();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setReports(adminStore.getReports());
    setLogs(adminStore.getLogs());
  };

  const handleResolveReport = (report: Report, status: 'resolved' | 'ignored') => {
    adminStore.updateReportStatus(report.id, status, 'António (Root)');
    loadData();
    setOpenActionId(null);
  };

  const openActionForm = (report: Report, type: 'hide_beat' | 'delete_comment' | 'suspend_user' | 'ban_user') => {
    setSelectedReport(report);
    setActionType(type);
    setReasonText('');
    setShowActionModal(true);
    setOpenActionId(null);
  };

  const executeAction = async () => {
    if (!selectedReport) return;
    
    const adminName = 'António (Root)';
    const commentOrBeatTitle = selectedReport.target_name;
    const targetId = selectedReport.target_id;
    
    if (actionType === 'hide_beat') {
      adminStore.setBeatHiddenStatus(targetId, true, adminName, reasonText || 'Violação de direitos autorais / Termos');
      adminStore.updateReportStatus(selectedReport.id, 'resolved', adminName);
    } else if (actionType === 'delete_comment') {
      adminStore.hideComment(targetId, adminName, reasonText || 'Spam / Comportamento inadequado na secção de comentários');
      // Update comment in local storage comments if matched
      try {
        // Also remove comments from matching posts
        localStorage.removeItem(`comments_${targetId}`);
      } catch (err) {
        console.warn('Silent comments deletion bypass:', err);
      }
      adminStore.updateReportStatus(selectedReport.id, 'resolved', adminName);
    } else if (actionType === 'suspend_user' || actionType === 'ban_user') {
      const statusType = actionType === 'suspend_user' ? 'suspended' : 'banned_perm';
      adminStore.updateUserStatus(targetId, statusType, adminName, reasonText || 'Denunciado múltiplos abusos');
      adminStore.updateReportStatus(selectedReport.id, 'resolved', adminName);

      // Attempt profile update in Supabase
      if (supabase) {
        try {
          await supabase.from('profiles').update({ role: statusType }).eq('id', targetId);
          console.log('[SUPABASE USER BAN] Profile role updated successfully to:', statusType);
        } catch (dbErr) {
          console.error('[SUPABASE USER BAN] Profile role write fallback:', dbErr);
        }
      }
    }

    setShowActionModal(false);
    setSelectedReport(null);
    loadData();
  };

  // Filtered reports
  const filteredReports = reports.filter(item => {
    const matchesSearch = 
      item.reporter_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.target_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.reason.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
    const matchesType = filterType === 'all' || item.target_type === filterType;

    return matchesSearch && matchesStatus && matchesType;
  });

  // Filtered Logs
  const filteredLogs = logs.filter(log => {
    return log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.admin_name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="space-y-6">
      {/* Sub Tabs Toggle */}
      <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-2 rounded-2xl">
        <div className="flex gap-2">
          <button
            onClick={() => { setActiveSubTab('reports'); setSearchTerm(''); }}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${activeSubTab === 'reports' ? 'bg-[#5865F2] text-white shadow-lg shadow-[#5865F2]/20' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <ShieldAlert size={14} />
            Denúncias Recebidas ({reports.filter(r => r.status === 'pending').length})
          </button>
          <button
            onClick={() => { setActiveSubTab('logs'); setSearchTerm(''); }}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${activeSubTab === 'logs' ? 'bg-[#5865F2] text-white shadow-lg shadow-[#5865F2]/20' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <Activity size={14} />
            Logs de Auditoria ({logs.length})
          </button>
        </div>
        <div className="text-gray-500 text-[10px] font-mono pr-4 select-none">ADMIN CONTROL CENTER</div>
      </div>

      {/* Main Filter and Search Controls */}
      <div className="bg-gray-900/40 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search Bar */}
          <div className="flex-1 bg-black/40 border border-white/5 rounded-2xl px-4 py-3 flex items-center gap-3">
            <Search className="text-gray-500 shrink-0" size={18} />
            <input
              type="text"
              placeholder={activeSubTab === 'reports' ? "Pesquisar por denunciante, alvo ou conteúdo..." : "Pesquisar logs por ação, admin ou detalhes..."}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none outline-none text-white text-sm w-full placeholder:text-gray-600"
            />
          </div>

          {/* Type and Status Filters for Reports Subtab */}
          {activeSubTab === 'reports' && (
            <div className="flex flex-wrap gap-3">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="bg-black/40 border border-white/5 text-gray-400 rounded-2xl px-4 py-3 text-xs font-bold uppercase tracking-widest outline-none focus:border-[#5865F2]/50"
              >
                <option value="all">Tipos (Todos)</option>
                <option value="beat">Beats</option>
                <option value="comment">Comentários</option>
                <option value="profile">Perfis</option>
              </select>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="bg-black/40 border border-white/5 text-gray-400 rounded-2xl px-4 py-3 text-xs font-bold uppercase tracking-widest outline-none focus:border-[#5865F2]/50"
              >
                <option value="all">Estados (Todos)</option>
                <option value="pending">Pendentes</option>
                <option value="resolved">Resolvido</option>
                <option value="ignored">Ignorado</option>
              </select>
            </div>
          )}
        </div>
      </div>

      {activeSubTab === 'reports' ? (
        <div className="bg-gray-900/20 border border-white/[0.08] rounded-3xl overflow-hidden shadow-2xl">
          {filteredReports.length === 0 ? (
            <div className="p-16 text-center text-gray-500">
              <AlertTriangle className="mx-auto mb-4 text-[#5865F2]/40" size={48} />
              <p className="text-sm font-bold uppercase tracking-widest text-white italic">Nenhuma denúncia encontrada</p>
              <p className="text-xs text-gray-500 mt-1">Todas as denúncias enviadas pelos utilizadores já foram resolvidas!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead className="bg-white/[0.02] border-b border-white/[0.06] text-gray-400 text-[10px] uppercase tracking-widest font-black">
                  <tr>
                    <th className="p-5">Alvo / Tipo</th>
                    <th className="p-5">Denunciante</th>
                    <th className="p-5">Motivo / Detalhes</th>
                    <th className="p-5">Data</th>
                    <th className="p-5">Status</th>
                    <th className="p-5 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="text-sm divide-y divide-white/[0.04]">
                  {filteredReports.map(report => (
                    <tr key={report.id} className="hover:bg-white/[0.01] transition-colors">
                      <td className="p-5">
                        <div className="space-y-1">
                          <p className="font-bold text-white max-w-[180px] truncate" title={report.target_name}>
                            {report.target_name}
                          </p>
                          <span className={`inline-block px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                            report.target_type === 'beat' ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' :
                            report.target_type === 'comment' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' :
                            'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                          }`}>
                            {report.target_type}
                          </span>
                        </div>
                      </td>
                      <td className="p-5">
                        <div className="text-white font-medium">{report.reporter_name}</div>
                        <div className="text-gray-500 text-[10px] font-mono truncate max-w-[120px]">{report.reporter_id}</div>
                      </td>
                      <td className="p-5 max-w-xs">
                        <div className="text-[#5865F2] font-black tracking-widest uppercase text-[10px] mb-1">
                          {report.reason.replace('_', ' ')}
                        </div>
                        <div className="text-gray-400 text-xs leading-relaxed line-clamp-2" title={report.details}>
                          {report.details}
                        </div>
                      </td>
                      <td className="p-5 text-gray-500 text-xs">
                        {new Date(report.created_at).toLocaleDateString()}
                      </td>
                      <td className="p-5">
                        <span className={`px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${
                          report.status === 'pending' ? 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20' :
                          report.status === 'resolved' ? 'bg-green-500/10 text-green-500 border-green-500/20' :
                          'bg-gray-500/10 text-gray-400 border-gray-500/20'
                        }`}>
                          {report.status}
                        </span>
                      </td>
                      <td className="p-5 text-right relative">
                        {report.status === 'pending' ? (
                          <div className="flex items-center justify-end gap-2">
                            {/* Standard Accept Resolution Buttons */}
                            <button
                              onClick={() => handleResolveReport(report, 'resolved')}
                              className="p-2 bg-green-500/10 hover:bg-green-500/20 text-green-400 rounded-lg transition-colors"
                              title="Marcar como Resolvida"
                            >
                              <Check size={14} />
                            </button>
                            <button
                              onClick={() => handleResolveReport(report, 'ignored')}
                              className="p-2 bg-gray-500/10 hover:bg-gray-500/20 text-gray-400 rounded-lg transition-colors"
                              title="Ignorar Denúncia"
                            >
                              <XOctagon size={14} />
                            </button>

                            {/* Dropdown toggle for content execution (moderation) actions */}
                            <div className="relative inline-block">
                              <button
                                onClick={() => setOpenActionId(openActionId === report.id ? null : report.id)}
                                className="p-2 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition-colors"
                              >
                                <MoreVertical size={14} />
                              </button>

                              {openActionId === report.id && (
                                <div className="absolute right-0 mt-2 w-52 bg-gray-950 border border-white/15 rounded-xl py-1 z-50 shadow-2xl animate-in fade-in slide-in-from-top-1 duration-150">
                                  <div className="px-3 py-1.5 border-b border-white/5 text-[9px] font-black text-gray-500 uppercase tracking-widest">Ações Administrativas</div>
                                  
                                  {report.target_type === 'beat' && (
                                    <button
                                      onClick={() => openActionForm(report, 'hide_beat')}
                                      className="w-full text-left px-4 py-2 text-xs hover:bg-white/5 text-red-400 flex items-center gap-2 font-medium"
                                    >
                                      <EyeOff size={12} />
                                      Ocultar / Remover Beat
                                    </button>
                                  )}

                                  {report.target_type === 'comment' && (
                                    <button
                                      onClick={() => openActionForm(report, 'delete_comment')}
                                      className="w-full text-left px-4 py-2 text-xs hover:bg-white/5 text-red-400 flex items-center gap-2 font-medium"
                                    >
                                      <Trash2 size={12} />
                                      Excluir Comentário
                                    </button>
                                  )}

                                  <button
                                    onClick={() => openActionForm(report, 'suspend_user')}
                                    className="w-full text-left px-4 py-2 text-xs hover:bg-white/5 text-yellow-400 flex items-center gap-2 font-medium"
                                  >
                                    <Ban size={12} />
                                    Suspender Produtor
                                  </button>
                                  
                                  <button
                                    onClick={() => openActionForm(report, 'ban_user')}
                                    className="w-full text-left px-4 py-2 text-xs hover:bg-white/5 text-red-500 flex items-center gap-2 font-medium border-t border-white/5"
                                  >
                                    <XOctagon size={12} />
                                    Banimento Permanente
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        ) : (
                          <span className="text-gray-600 text-[11px] font-bold uppercase tracking-widest italic select-none">Sem ações pendentes</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        /* AUDIT LOGS DISPLAY */
        <div className="bg-gray-900/20 border border-white/[0.08] rounded-3xl overflow-hidden shadow-2xl">
          {filteredLogs.length === 0 ? (
            <div className="p-16 text-center text-gray-500">
              <FileText className="mx-auto mb-4 text-[#5865F2]/40" size={48} />
              <p className="text-sm font-bold uppercase tracking-widest text-white italic">Nenhum log encontrado</p>
              <p className="text-xs text-gray-500 mt-1">Utiliza filtros ou pesquise noutros campos acima.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead className="bg-white/[0.02] border-b border-white/[0.06] text-gray-400 text-[10px] uppercase tracking-widest font-black">
                  <tr>
                    <th className="p-5">Administrador</th>
                    <th className="p-5">Ação Realizada</th>
                    <th className="p-5">Detalhes da Ação</th>
                    <th className="p-5">Alvo / Tipo</th>
                    <th className="p-5 text-right">Data & Hora</th>
                  </tr>
                </thead>
                <tbody className="text-sm divide-y divide-white/[0.04]">
                  {filteredLogs.map(log => (
                    <tr key={log.id} className="hover:bg-white/[0.01] transition-colors font-mono text-xs">
                      <td className="p-5 font-sans font-bold text-white">
                        {log.admin_name}
                      </td>
                      <td className="p-5 font-sans">
                        <span className={`px-2.5 py-1 rounded text-[9px] font-black uppercase tracking-widest ${
                          log.action.includes('Aprovar') || log.action.includes('Verificar') ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                          log.action.includes('Ocultar') || log.action.includes('Excluir') || log.action.includes('Suspender') || log.action.includes('Ban') ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                          'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}>
                          {log.action}
                        </span>
                      </td>
                      <td className="p-5 text-gray-300 max-w-sm font-sans font-medium line-clamp-2" title={log.details}>
                        {log.details}
                      </td>
                      <td className="p-5">
                        <div className="space-y-1">
                          <code className="bg-white/5 px-2 py-1 rounded text-gray-400 text-[10px] tracking-tight">{log.target_id.slice(0, 12)}...</code>
                          <span className="block text-[8px] font-bold text-gray-500 uppercase tracking-widest">{log.target_type}</span>
                        </div>
                      </td>
                      <td className="p-5 text-right text-gray-500 font-sans text-xs">
                        {new Date(log.created_at).toLocaleString('pt-PT')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Moderation / Action execution confirmation modal */}
      {showActionModal && selectedReport && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-gray-950 border border-white/10 rounded-[2rem] w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="p-8 border-b border-white/5 bg-gradient-to-r from-red-600/10 to-transparent">
              <div className="flex items-center gap-3">
                <AlertTriangle className="text-red-500 shrink-0" size={24} />
                <h3 className="text-xl font-black italic uppercase tracking-tighter text-white">
                  Confirmar Ação de Moderação
                </h3>
              </div>
              <p className="text-xs text-gray-400 font-medium mt-1">Autoridade administrativa sobre o conteúdo e utilizador.</p>
            </div>

            <div className="p-8 space-y-6">
              <div className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl space-y-2">
                <span className="block text-[9px] font-black uppercase text-[#5865F2] tracking-widest">Conteúdo Alvo</span>
                <p className="text-white font-black uppercase tracking-tight text-sm truncate">{selectedReport.target_name}</p>
                <div className="flex gap-4 text-xs font-semibold text-gray-400 mt-1">
                  <div>Tipo: <span className="text-white capitalize">{selectedReport.target_type}</span></div>
                  <div>ID Alvo: <code className="text-gray-500 font-mono bg-white/5 px-1.5 py-0.5 rounded text-[10px]">{selectedReport.target_id.slice(0, 12)}...</code></div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-[9px] font-black uppercase text-gray-500 tracking-widest">Justificação Administrativa / Motivo</label>
                <textarea
                  value={reasonText}
                  onChange={(e) => setReasonText(e.target.value)}
                  placeholder="Escreve uma justificação para esta ação. Isto será registado nos logs de auditoria e pode ser enviado ao utilizador."
                  className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-xs text-white placeholder:text-gray-600 outline-none focus:border-[#5865F2]/50 h-28 resize-none font-medium leading-relaxed"
                />
              </div>
            </div>

            <div className="p-8 bg-white/[0.01] border-t border-white/5 flex gap-3 justify-end">
              <button
                onClick={() => { setShowActionModal(false); setSelectedReport(null); }}
                className="px-6 py-3 border border-white/10 text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-white/5 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={executeAction}
                className="px-6 py-3 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold uppercase tracking-widest shadow-lg shadow-red-900/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                Executar Ação
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
