import React, { useState, useEffect } from 'react';
import { adminStore, FeaturedContent } from '@/src/lib/adminStore';
import { playlistStore, Playlist } from '@/src/lib/playlistStore';
import { getSupabase, getPublicUrl } from '@/src/lib/supabase';
import { 
  Star, 
  Music, 
  Users, 
  ListMusic, 
  Search, 
  Check, 
  Sparkles,
  RefreshCw,
  Plus,
  MapPin,
  Sliders,
  Calendar,
  BarChart2,
  TrendingUp,
  Award
} from 'lucide-react';
import { Beat } from '@/src/types';

export default function AdminFeaturedManagement() {
  const [activeSegment, setActiveSegment] = useState<'beats' | 'producers' | 'playlists'>('beats');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Data pools
  const [beats, setBeats] = useState<Beat[]>([]);
  const [producers, setProducers] = useState<any[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [featuredList, setFeaturedList] = useState<FeaturedContent[]>([]);
  const [loading, setLoading] = useState(true);

  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  const supabase = getSupabase();

  const getEditorialConfig = (type: string, id: string) => {
    try {
      const stored = localStorage.getItem(`batukada_editorial_config_${type}_${id}`);
      if (stored) return JSON.parse(stored);
    } catch (e) {}
    return {
      priority: 50,
      start_date: '',
      end_date: '',
      campaign: 'None'
    };
  };

  const handleUpdateEditorialConfig = async (
    item: any, 
    type: 'beat' | 'producer' | 'playlist', 
    fields: { priority?: number; start_date?: string; end_date?: string; campaign?: string }
  ) => {
    const targetId = String(item.id);
    const currentConfig = getEditorialConfig(type, targetId);
    const updated = { ...currentConfig, ...fields };
    localStorage.setItem(`batukada_editorial_config_${type}_${targetId}`, JSON.stringify(updated));

    // Also update custom property in lists for instant visual update
    if (type === 'beat') {
      setBeats(prev => prev.map((b: any) => String(b.id) === targetId ? { 
        ...b, 
        featured_priority: updated.priority, 
        featured_start: updated.start_date, 
        featured_end: updated.end_date,
        campaign: updated.campaign 
      } : b));
    } else if (type === 'producer') {
      setProducers(prev => prev.map((p: any) => String(p.id) === targetId ? { 
        ...p, 
        featured_priority: updated.priority, 
        featured_start: updated.start_date, 
        featured_end: updated.end_date,
        campaign: updated.campaign 
      } : p));
    } else if (type === 'playlist') {
      setPlaylists(prev => prev.map((p: any) => String(p.id) === targetId ? { 
        ...p, 
        featured_priority: updated.priority, 
        featured_start: updated.start_date, 
        featured_end: updated.end_date,
        campaign: updated.campaign 
      } as any : p));
    }

    // Persist to Supabase Database
    if (supabase) {
      try {
        const payload: any = {
          featured_priority: updated.priority,
          featured_start: updated.start_date || null,
          featured_end: updated.end_date || null,
          campaign: updated.campaign !== 'None' ? updated.campaign : null
        };

        if (type === 'beat') {
          await supabase.from('beats').update(payload).eq('id', item.id);
        } else if (type === 'producer') {
          await supabase.from('profiles').update(payload).eq('id', item.id);
        } else if (type === 'playlist') {
          await supabase.from('playlists').update({ featured_priority: updated.priority } as any).eq('id', item.id);
        }

        // Register editorial featured social activity
        try {
          const bCover = type === 'beat' ? getPublicUrl('beats', item.cover_url || '') : (item.cover_image || item.avatar_url || '');
          fetch('/api/activity/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              type: 'featured',
              actor_name: 'BeatAngola Editor',
              actor_username: 'beatangola',
              target_id: String(item.id),
              target_title: item.title || item.display_name || item.artistic_name || 'Destaque',
              target_cover: bCover,
              metadata: {
                contentType: type,
                campaign: updated.campaign || 'Destaque Oficial'
              }
            })
          }).catch(() => {});
        } catch (actErr) {
          console.warn('Silent skip admin featured social activity log:', actErr);
        }
      } catch (e) {
        console.warn("DB update failed, using local storage backup:", e);
      }
    }
  };

  useEffect(() => {
    loadAllData();
  }, [activeSegment]);

  const loadAllData = async () => {
    setLoading(true);
    setFeaturedList(adminStore.getFeaturedItems());
    
    if (!supabase) {
      setLoading(false);
      return;
    }

    try {
      if (activeSegment === 'beats') {
        const { data: beatsData } = await supabase.from('beats').select('*');
        
        if (beatsData) {
          // Map database structure to Beat Interface
          const mappedBeats = beatsData.map((b: any) => {
            let extractedKey = b.key;
            let extractedScale = b.scale;
            if (b.tags && Array.isArray(b.tags)) {
              const kt = b.tags.find((t: string) => t.startsWith('_key:'));
              if (kt) extractedKey = kt.split(':')[1];
              const st = b.tags.find((t: string) => t.startsWith('_scale:'));
              if (st) extractedScale = st.split(':')[1];
            }
            const cleanTags = b.tags ? b.tags.filter((t: string) => !t.startsWith('_key:') && !t.startsWith('_scale:')) : [];

            return {
              id: b.id,
              title: b.title,
              producer: b.producer_name || b.artist_name || 'Produtor',
              producer_id: b.producer_id,
              genre: b.genre || 'Afro House / Semba / Kuduro',
              tags: cleanTags,
              price: {
                basic: Number(b.price_basic || 0),
                premium: Number(b.price_premium || 0),
                exclusive: Number(b.price_exclusive || 0)
              },
              image: b.cover_url ? getPublicUrl('beats', b.cover_url) : 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=300',
              audioUrl: b.demo_url ? getPublicUrl('beats', b.demo_url) : '',
              bpm: b.bpm || 120,
              key: extractedKey || 'C',
              scale: extractedScale || 'Maior',
              featured: b.featured === true || adminStore.isFeatured('beat', String(b.id)),
              featured_priority: b.featured_priority !== undefined && b.featured_priority !== null ? b.featured_priority : getEditorialConfig('beat', String(b.id)).priority,
              featured_start: b.featured_start || getEditorialConfig('beat', String(b.id)).start_date,
              featured_end: b.featured_end || getEditorialConfig('beat', String(b.id)).end_date,
              campaign: b.campaign || getEditorialConfig('beat', String(b.id)).campaign,
            };
          });
          setBeats(mappedBeats);
        }
      } else if (activeSegment === 'producers') {
        const { data: profilesData } = await supabase.from('profiles').select('*');
        const { data: beatsData } = await supabase.from('beats').select('*');
        
        let followersList: any[] = [];
        let playsList: any[] = [];
        try {
          const { data: fData } = await supabase.from('followers').select('*');
          if (fData) followersList = fData;
        } catch (e) {}
        try {
          const { data: pData } = await supabase.from('beat_plays').select('*');
          if (pData) playsList = pData;
        } catch (e) {}

        if (profilesData) {
          const processed = profilesData.map((p: any) => {
            const pBeats = (beatsData || []).filter((b: any) => b.producer_id === p.id);
            const pFollowers = followersList.filter((f: any) => f.following_id === p.id).length;
            const pPlays = playsList.filter((pl: any) => pBeats.some(b => b.id === pl.beat_id)).length;
            return {
              ...p,
              total_beats: pBeats.length,
              followers_count: pFollowers,
              plays_count: pPlays,
              featured: p.featured === true || adminStore.isFeatured('producer', String(p.id)),
              featured_priority: p.featured_priority !== undefined && p.featured_priority !== null ? p.featured_priority : getEditorialConfig('producer', String(p.id)).priority,
              featured_start: p.featured_start || getEditorialConfig('producer', String(p.id)).start_date,
              featured_end: p.featured_end || getEditorialConfig('producer', String(p.id)).end_date,
              campaign: p.campaign || getEditorialConfig('producer', String(p.id)).campaign,
            };
          });
          setProducers(processed);
        }
      } else if (activeSegment === 'playlists') {
        // Fetch a global pool of playlists. Since playlists might be individual, we query public playlists or all.
        try {
          const { data } = await supabase.from('playlists').select('*');
          if (data) {
            setPlaylists(data as Playlist[]);
          } else {
            // Fallback to local playlists from storage
            const localPls = await playlistStore.fetchPlaylists('');
            setPlaylists(localPls);
          }
        } catch (e) {
          const localPls = await playlistStore.fetchPlaylists('');
          setPlaylists(localPls);
        }
      }
    } catch (err) {
      console.error('Error loading admin featured selector data:', err);
    }
    
    setLoading(false);
  };

  const handleToggleFeatured = async (item: any, type: 'beat' | 'producer' | 'playlist') => {
    const targetId = String(item.id);
    const isCurrentlyFeatured = adminStore.isFeatured(type, targetId);
    
    let title = '';
    let image = '';

    if (type === 'beat') {
      title = item.title;
      image = item.image || item.cover_url;
    } else if (type === 'producer') {
      title = item.display_name || item.artistic_name || item.full_name || 'Produtor Oficial';
      image = item.avatar_url;
    } else if (type === 'playlist') {
      title = item.title;
      image = item.cover_image;
    }

    const nextFeatured = !isCurrentlyFeatured;

    // 1. Update localStorage instantly for visual snap-responsiveness
    adminStore.toggleFeatureItem(type, targetId, title, nextFeatured, image);
    
    if (nextFeatured) {
      const defaultConf = {
        priority: 50,
        start_date: '',
        end_date: '',
        campaign: 'None'
      };
      localStorage.setItem(`batukada_editorial_config_${type}_${targetId}`, JSON.stringify(defaultConf));
    } else {
      localStorage.removeItem(`batukada_editorial_config_${type}_${targetId}`);
      if (editingItemId === targetId) {
        setEditingItemId(null);
      }
    }

    // 2. Refresh local state lists for ultra-crisp responsive feedback
    if (type === 'beat') {
      setBeats(prev => prev.map((b: any) => String(b.id) === targetId ? { 
        ...b, 
        featured: nextFeatured, 
        featured_priority: nextFeatured ? 50 : 0 
      } : b));
    } else if (type === 'producer') {
      setProducers(prev => prev.map((p: any) => String(p.id) === targetId ? { 
        ...p, 
        featured: nextFeatured, 
        featured_priority: nextFeatured ? 50 : 0 
      } : p));
    } else if (type === 'playlist') {
      setPlaylists(prev => prev.map((p: any) => String(p.id) === targetId ? { 
        ...p, 
        featured: nextFeatured 
      } as any : p));
    }

    // 3. Refresh featured state list
    setFeaturedList(adminStore.getFeaturedItems());

    // 4. Persist state in Supabase Database in realtime
    if (supabase) {
      try {
        if (type === 'beat') {
          const { error } = await supabase
            .from('beats')
            .update({
              featured: nextFeatured,
              featured_at: nextFeatured ? new Date().toISOString() : null,
              featured_priority: nextFeatured ? 50 : 0
            })
            .eq('id', item.id);
          if (error) console.error("Could not write featured status to Beats in Supabase:", error);
        } else if (type === 'producer') {
          const { error } = await supabase
            .from('profiles')
            .update({
              featured: nextFeatured,
              featured_at: nextFeatured ? new Date().toISOString() : null,
              featured_priority: nextFeatured ? 50 : 0
            } as any)
            .eq('id', item.id);
          if (error) console.error("Could not write featured status to Profiles in Supabase:", error);
        } else if (type === 'playlist') {
          const { error } = await supabase
            .from('playlists')
            .update({
              featured: nextFeatured
            } as any)
            .eq('id', item.id);
          if (error) console.error("Could not write featured status to Playlists in Supabase:", error);
        }
      } catch (dbErr) {
        console.warn("DB write bypassed gracefully:", dbErr);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner introducing dynamic highlights */}
      <div className="bg-gradient-to-r from-[#5865F2]/20 via-orange-500/10 to-transparent p-6 rounded-3xl border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-orange-400 font-bold uppercase tracking-widest text-[10px]">
            <Sparkles size={12} /> Curadoria de Conteúdos
          </div>
          <h3 className="text-xl font-black italic uppercase tracking-tighter text-white">Gestão de Destaques Dinâmicos</h3>
          <p className="text-xs text-gray-400 max-w-xl">
            Promove talentos e conteúdos de elite diretamente na landing page e carrosséis principais do Batukada. Todas as atualizações aplicam-se instantaneamente!
          </p>
        </div>
        <div className="bg-black/30 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/5 shrink-0 flex items-center gap-3">
          <Star className="text-yellow-400 fill-yellow-400" size={18} />
          <div>
            <div className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Destaques Ativos</div>
            <div className="text-lg font-black text-white">{featuredList.length} Itens</div>
          </div>
        </div>
      </div>

      {/* Selector controls & Search */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Navigation panel */}
        <div className="lg:col-span-1 bg-gray-900/20 border border-white/[0.08] p-4 rounded-3xl space-y-2">
          <span className="block text-[9px] font-black uppercase text-gray-500 tracking-widest px-3 mb-2">Segmentação</span>
          
          <button
            onClick={() => { setActiveSegment('beats'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between p-4 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${activeSegment === 'beats' ? 'bg-[#5865F2] text-white' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <div className="flex items-center gap-3">
              <Music size={16} />
              Beats do Catálogo
            </div>
            <span className="text-[10px] opacity-70">
              {featuredList.filter(f => f.type === 'beat').length} Destacados
            </span>
          </button>

          <button
            onClick={() => { setActiveSegment('producers'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between p-4 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${activeSegment === 'producers' ? 'bg-[#5865F2] text-white' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <div className="flex items-center gap-3">
              <Users size={16} />
              Produtores (Perfis)
            </div>
            <span className="text-[10px] opacity-70">
              {featuredList.filter(f => f.type === 'producer').length} Destacados
            </span>
          </button>

          <button
            onClick={() => { setActiveSegment('playlists'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between p-4 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${activeSegment === 'playlists' ? 'bg-[#5865F2] text-white' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <div className="flex items-center gap-3">
              <ListMusic size={16} />
              Playlists Públicas
            </div>
            <span className="text-[10px] opacity-70">
              {featuredList.filter(f => f.type === 'playlist').length} Destacados
            </span>
          </button>
        </div>

        {/* Content Explorer table area */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-black/40 border border-white/5 rounded-2xl px-4 py-3 flex items-center gap-3">
            <Search className="text-gray-500 shrink-0" size={18} />
            <input
              type="text"
              placeholder={`Pesquisar por nome ou detalhes em ${activeSegment}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none outline-none text-white text-sm w-full placeholder:text-gray-700 font-medium"
            />
          </div>

          <div className="bg-gray-900/20 border border-white/[0.08] rounded-3xl overflow-hidden shadow-xl min-h-[300px]">
            {loading ? (
              <div className="p-16 text-center text-gray-500 flex flex-col items-center justify-center gap-3">
                <RefreshCw size={24} className="animate-spin text-orange-500" />
                <span className="text-xs font-bold uppercase tracking-widest text-gray-400">A carregar registos...</span>
              </div>
            ) : (
              <div>
                {activeSegment === 'beats' && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-white/[0.01] border-b border-white/[0.05] text-gray-400 text-[9px] uppercase tracking-widest font-black">
                        <tr>
                          <th className="p-4">Beat</th>
                          <th className="p-4">Produtor / Gênero</th>
                          <th className="p-4 text-right">Destaque</th>
                        </tr>
                      </thead>
                      <tbody className="text-xs divide-y divide-white/[0.03]">
                        {beats
                          .filter(b => b.title.toLowerCase().includes(searchTerm.toLowerCase()) || b.producer.toLowerCase().includes(searchTerm.toLowerCase()))
                          .map(beat => {
                            const isFeatured = adminStore.isFeatured('beat', String(beat.id));
                            const config = getEditorialConfig('beat', String(beat.id));
                            const isEditing = editingItemId === String(beat.id);

                            const stableSeed = String(beat.id).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                            const promotionalPlays = (stableSeed * 7) % 1800 + 400;
                            const promotionalSales = (stableSeed * 3) % 12 + 1;
                            const clickRate = ((stableSeed % 80) / 10 + 2.1).toFixed(1);

                            return (
                              <React.Fragment key={beat.id}>
                                <tr className="hover:bg-white/[0.01] transition-colors">
                                  <td className="p-4">
                                    <div className="flex items-center gap-3">
                                      <img src={beat.image} alt={beat.title} className="w-8 h-8 rounded-lg object-cover bg-white/5" />
                                      <div>
                                        <p className="font-bold text-white uppercase italic tracking-tight">{beat.title}</p>
                                        <span className="text-[9px] text-gray-500 font-mono">BPM: {beat.bpm}</span>
                                        {isFeatured && (
                                          <div className="flex flex-wrap gap-1 mt-1">
                                            {(beat.featured_priority || config.priority) === 100 && (
                                              <span className="px-1.5 py-0.5 rounded bg-red-500/10 border border-red-500/20 text-[8px] font-black text-red-500 uppercase tracking-widest">Hero Spotlight</span>
                                            )}
                                            {(beat.featured_priority || config.priority) === 80 && (
                                              <span className="px-1.5 py-0.5 rounded bg-orange-500/10 border border-orange-500/20 text-[8px] font-black text-orange-500 uppercase tracking-widest">Curation High</span>
                                            )}
                                            {(beat.featured_priority || config.priority) === 50 && (
                                              <span className="px-1.5 py-0.5 rounded bg-[#5865F2]/10 border border-[#5865F2]/20 text-[8px] font-black text-[#5865F2] uppercase tracking-widest">Standard Curated</span>
                                            )}
                                            {(beat.featured_priority || config.priority) === 20 && (
                                              <span className="px-1.5 py-0.5 rounded bg-gray-500/10 border border-gray-500/20 text-[8px] font-black text-gray-400 uppercase tracking-widest">Discovery Low</span>
                                            )}
                                            {config.campaign && config.campaign !== 'None' && (
                                              <span className="px-1.5 py-0.5 rounded bg-purple-500/10 border border-purple-500/20 text-[8px] font-black text-purple-400 uppercase tracking-widest">{config.campaign}</span>
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </td>
                                  <td className="p-4">
                                    <div className="text-white font-medium">{beat.producer}</div>
                                    <div className="text-orange-400 text-[10px] font-bold uppercase tracking-wide">{beat.genre}</div>
                                  </td>
                                  <td className="p-4 text-right">
                                    <div className="flex items-center gap-2 justify-end">
                                      {isFeatured && (
                                        <button
                                          onClick={() => setEditingItemId(isEditing ? null : String(beat.id))}
                                          className={`p-1.5 rounded-xl border transition-all ${
                                            isEditing 
                                              ? 'bg-[#5865F2]/20 border-[#5865F2] text-white' 
                                              : 'bg-white/5 border-white/[0.05] text-gray-400 hover:bg-white/10 hover:text-white'
                                          }`}
                                          title="Configurações Editoriais"
                                        >
                                          <Sliders size={12} />
                                        </button>
                                      )}
                                      <button
                                        onClick={() => handleToggleFeatured(beat, 'beat')}
                                        className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                                          isFeatured 
                                            ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20 flex items-center gap-1.5' 
                                            : 'bg-white/5 text-gray-400 hover:bg-white/10 flex items-center gap-1.5'
                                        }`}
                                      >
                                        <Star size={10} className={isFeatured ? 'fill-yellow-500' : ''} />
                                        {isFeatured ? 'Destaque' : 'Promover'}
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                                {isEditing && (
                                  <tr className="bg-white/[0.02]">
                                    <td colSpan={3} className="p-4 border-l-2 border-[#5865F2] space-y-4">
                                      <div className="flex flex-col gap-1.5">
                                        <div className="flex items-center gap-2 text-[#5865F2]">
                                          <Sparkles size={14} />
                                          <span className="text-[10px] font-black uppercase tracking-widest">Configuração da Campanha de Destaque</span>
                                        </div>
                                        <p className="text-[11px] text-gray-400">Personaliza as prioridades de posicionamento, agendamentos automáticos e segmentação para "{beat.title}".</p>
                                      </div>

                                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <div className="space-y-1.5">
                                          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block">Nível de Prioridade</label>
                                          <select
                                            value={beat.featured_priority !== undefined ? beat.featured_priority : config.priority}
                                            onChange={(e) => handleUpdateEditorialConfig(beat, 'beat', { priority: Number(e.target.value) })}
                                            className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white uppercase font-bold outline-none cursor-pointer focus:border-[#5865F2] transition-colors"
                                          >
                                            <option value={20}>Baixa (20) - Feed Geral</option>
                                            <option value={50}>Média (50) - Secção Editorial</option>
                                            <option value={80}>Alta (80) - Carrossel Em Alta</option>
                                            <option value={100}>Hero (100) - Destaque Principal</option>
                                          </select>
                                        </div>

                                        <div className="space-y-1.5">
                                          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block font-sans">Agendamento (Período)</label>
                                          <div className="grid grid-cols-2 gap-2">
                                            <div>
                                              <input
                                                type="date"
                                                value={beat.featured_start || config.start_date || ''}
                                                onChange={(e) => handleUpdateEditorialConfig(beat, 'beat', { start_date: e.target.value })}
                                                className="w-full bg-black/60 border border-white/10 rounded-xl px-2.5 py-2 text-[10px] text-white outline-none focus:border-[#5865F2] cursor-text"
                                              />
                                            </div>
                                            <div>
                                              <input
                                                type="date"
                                                value={beat.featured_end || config.end_date || ''}
                                                onChange={(e) => handleUpdateEditorialConfig(beat, 'beat', { end_date: e.target.value })}
                                                className="w-full bg-black/60 border border-white/10 rounded-xl px-2.5 py-2 text-[10px] text-white outline-none focus:border-[#5865F2] cursor-text"
                                              />
                                            </div>
                                          </div>
                                        </div>

                                        <div className="space-y-1.5">
                                          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block">Campanha Editorial</label>
                                          <select
                                            value={beat.campaign || config.campaign || 'None'}
                                            onChange={(e) => handleUpdateEditorialConfig(beat, 'beat', { campaign: e.target.value })}
                                            className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none cursor-pointer focus:border-[#5865F2]"
                                          >
                                            <option value="None">Nenhuma Campanha</option>
                                            <option value="Trap Angola Week">Trap Angola Week 🇦🇴</option>
                                            <option value="Afro House Rising">Afro House Rising 🔥</option>
                                            <option value="Kuduro Essentials">Kuduro Essentials 🥁</option>
                                            <option value="Producer Spotlight">Producer Spotlight 💡</option>
                                          </select>
                                        </div>
                                      </div>

                                      <div className="bg-black/40 border border-white/5 rounded-2xl p-3 flex items-center justify-between gap-6">
                                        <div className="flex items-center gap-2 text-gray-400">
                                          <BarChart2 size={14} className="text-[#5865F2]" />
                                          <span className="text-[10px] font-bold uppercase tracking-wider">Métricas Editoriais Estimadas</span>
                                        </div>
                                        <div className="flex gap-6">
                                          <div className="text-right">
                                            <span className="block text-[8px] font-bold text-gray-500 uppercase tracking-widest leading-none mb-1">Plays</span>
                                            <strong className="text-xs font-mono font-bold text-green-400">+{promotionalPlays}</strong>
                                          </div>
                                          <div className="text-right">
                                            <span className="block text-[8px] font-bold text-gray-500 uppercase tracking-widest leading-none mb-1">CTR Médio</span>
                                            <strong className="text-xs font-mono font-bold text-blue-400">{clickRate}%</strong>
                                          </div>
                                          <div className="text-right">
                                            <span className="block text-[8px] font-bold text-gray-500 uppercase tracking-widest leading-none mb-1">Vendas</span>
                                            <strong className="text-xs font-mono font-bold text-purple-400">+{promotionalSales}</strong>
                                          </div>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                )}
                              </React.Fragment>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                )}

                {activeSegment === 'producers' && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-white/[0.01] border-b border-white/[0.05] text-gray-400 text-[9px] uppercase tracking-widest font-black">
                        <tr>
                          <th className="p-4">Produtor</th>
                          <th className="p-4">Localização</th>
                          <th className="p-4">Métricas REAIS</th>
                          <th className="p-4 text-right">Destaque</th>
                        </tr>
                      </thead>
                      <tbody className="text-xs divide-y divide-white/[0.03]">
                        {producers
                          .filter(p => {
                            const totalBeats = p.total_beats || 0;
                            if (totalBeats === 0) return false;
                            
                            const displayName = (p.display_name || p.artistic_name || p.full_name || '').trim();
                            const username = p.username || '';
                            if (!displayName && !username) return false;
                            const hasEmailName = displayName.includes('@') || username.includes('@');
                            if (hasEmailName) return false;
                            return true;
                          })
                          .filter(p => (p.display_name || p.artistic_name || '').toLowerCase().includes(searchTerm.toLowerCase()) || (p.city || p.location || '').toLowerCase().includes(searchTerm.toLowerCase()))
                          .map(prod => {
                            const isFeatured = adminStore.isFeatured('producer', String(prod.id));
                            const config = getEditorialConfig('producer', String(prod.id));
                            const isEditing = editingItemId === String(prod.id);

                            const name = prod.artistic_name || prod.display_name || prod.full_name || prod.username || 'Produtor Oficial';
                            const username = prod.username || name.toLowerCase().replace(/\s/g, '');
                            const initials = name
                              .split(' ')
                              .filter(Boolean)
                              .map((n: string) => n[0])
                              .join('')
                              .slice(0, 2)
                              .toUpperCase() || 'P';

                            const stableSeed = String(prod.id).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                            const extraFollowers = (stableSeed * 4) % 150 + 20;
                            const profileViews = (stableSeed * 9) % 2500 + 350;

                            return (
                              <React.Fragment key={prod.id}>
                                <tr className="hover:bg-white/[0.01] transition-colors">
                                  <td className="p-4">
                                    <div className="flex items-center gap-3">
                                      {prod.avatar_url ? (
                                        <img src={prod.avatar_url} alt={name} className="w-8 h-8 rounded-full object-cover bg-white/5 border border-white/5" />
                                      ) : (
                                        <div className="w-8 h-8 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 font-bold text-xs flex items-center justify-center font-mono select-none">
                                          {initials}
                                        </div>
                                      )}
                                      <div>
                                        <p className="font-bold text-white uppercase italic tracking-tight">{name}</p>
                                        <span className="text-[9px] text-[#5865F2] font-semibold tracking-wider block">@{username}</span>
                                        {isFeatured && (
                                          <div className="flex flex-wrap gap-1 mt-1">
                                            {(prod.featured_priority || config.priority) === 100 && (
                                              <span className="px-1.5 py-0.5 rounded bg-red-500/10 border border-red-500/20 text-[8px] font-black text-red-500 uppercase tracking-widest">Hero Spotlight</span>
                                            )}
                                            {(prod.featured_priority || config.priority) === 80 && (
                                              <span className="px-1.5 py-0.5 rounded bg-orange-500/10 border border-orange-500/20 text-[8px] font-black text-orange-500 uppercase tracking-widest">Curation High</span>
                                            )}
                                            {(prod.featured_priority || config.priority) === 50 && (
                                              <span className="px-1.5 py-0.5 rounded bg-[#5865F2]/10 border border-[#5865F2]/20 text-[8px] font-black text-[#5865F2] uppercase tracking-widest">Standard Curated</span>
                                            )}
                                            {(prod.featured_priority || config.priority) === 20 && (
                                              <span className="px-1.5 py-0.5 rounded bg-gray-500/10 border border-gray-500/20 text-[8px] font-black text-gray-400 uppercase tracking-widest">Discovery Low</span>
                                            )}
                                            {config.campaign && config.campaign !== 'None' && (
                                              <span className="px-1.5 py-0.5 rounded bg-purple-500/10 border border-purple-500/20 text-[8px] font-black text-purple-400 uppercase tracking-widest">{config.campaign}</span>
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </td>
                                  <td className="p-4">
                                    <div className="flex items-center gap-1.5 text-white font-bold select-none">
                                      <MapPin size={11} className="text-[#5865F2] shrink-0" />
                                      <span className="truncate">{prod.location || prod.city || 'Luanda, Angola'}</span>
                                    </div>
                                  </td>
                                  <td className="p-4">
                                    <div className="flex flex-wrap items-center gap-2 md:gap-4 text-[10px] uppercase font-black tracking-wider">
                                      <div className="bg-orange-500/5 border border-orange-500/15 text-orange-400 px-2 py-1 rounded-md">
                                        Beats: <strong className="font-mono font-bold">{prod.total_beats || 0}</strong>
                                      </div>
                                      <div className="bg-blue-500/5 border border-blue-500/15 text-blue-400 px-2 py-1 rounded-md">
                                        Plays: <strong className="font-mono font-bold">{prod.plays_count || 0}</strong>
                                      </div>
                                      <div className="bg-purple-500/5 border border-purple-500/15 text-purple-400 px-2 py-1 rounded-md">
                                        Follows: <strong className="font-mono font-bold">{prod.followers_count || 0}</strong>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="p-4 text-right">
                                    <div className="flex items-center gap-2 justify-end">
                                      {isFeatured && (
                                        <button
                                          onClick={() => setEditingItemId(isEditing ? null : String(prod.id))}
                                          className={`p-1.5 rounded-xl border transition-all ${
                                            isEditing 
                                              ? 'bg-[#5865F2]/20 border-[#5865F2] text-white' 
                                              : 'bg-white/5 border-white/[0.05] text-gray-400 hover:bg-white/10 hover:text-white'
                                          }`}
                                          title="Configurações Editoriais"
                                        >
                                          <Sliders size={12} />
                                        </button>
                                      )}
                                      <button
                                        onClick={() => handleToggleFeatured(prod, 'producer')}
                                        className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                                          isFeatured 
                                            ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20 flex items-center gap-1.5' 
                                            : 'bg-white/5 text-gray-400 hover:bg-white/10 flex items-center gap-1.5'
                                        }`}
                                      >
                                        <Star size={10} className={isFeatured ? 'fill-yellow-500' : ''} />
                                        {isFeatured ? 'Destaque' : 'Promover'}
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                                {isEditing && (
                                  <tr className="bg-white/[0.02]">
                                    <td colSpan={4} className="p-4 border-l-2 border-[#5865F2] space-y-4 text-left">
                                      <div className="flex flex-col gap-1.5">
                                        <div className="flex items-center gap-2 text-[#5865F2]">
                                          <Sparkles size={14} />
                                          <span className="text-[10px] font-black uppercase tracking-widest">Configuração do Destaque de Produtor</span>
                                        </div>
                                        <p className="text-[11px] text-gray-400">Personaliza o posicionamento do perfil do produtor "{name}" nas secções de destaque e na homepage.</p>
                                      </div>

                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-1.5">
                                          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block">Nível de Prioridade</label>
                                          <select
                                            value={prod.featured_priority !== undefined ? prod.featured_priority : config.priority}
                                            onChange={(e) => handleUpdateEditorialConfig(prod, 'producer', { priority: Number(e.target.value) })}
                                            className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white uppercase font-bold outline-none cursor-pointer focus:border-[#5865F2] transition-colors"
                                          >
                                            <option value={20}>Baixa (20) - Feed de Descoberta</option>
                                            <option value={50}>Média (50) - Secção Editorial</option>
                                            <option value={80}>Alta (80) - Carrossel Produtores em Alta</option>
                                            <option value={100}>Hero (100) - Banner em Destaque</option>
                                          </select>
                                        </div>

                                        <div className="space-y-1.5">
                                          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block">Campanha de Apoio / Spotlight</label>
                                          <select
                                            value={prod.campaign || config.campaign || 'None'}
                                            onChange={(e) => handleUpdateEditorialConfig(prod, 'producer', { campaign: e.target.value })}
                                            className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none cursor-pointer focus:border-[#5865F2]"
                                          >
                                            <option value="None">Nenhum Apoio Específico</option>
                                            <option value="Producer Spotlight">Producer Spotlight 💡</option>
                                            <option value="Kuduro Essentials">Kuduro Legends 🥁</option>
                                            <option value="Afro House Rising">Afro House Pioneers 🔥</option>
                                          </select>
                                        </div>
                                      </div>

                                      <div className="bg-black/40 border border-white/5 rounded-2xl p-3 flex items-center justify-between gap-6">
                                        <div className="flex items-center gap-2 text-gray-400">
                                          <BarChart2 size={14} className="text-[#5865F2]" />
                                          <span className="text-[10px] font-bold uppercase tracking-wider">Aumento de Engajamento Projetado</span>
                                        </div>
                                        <div className="flex gap-6">
                                          <div className="text-right">
                                            <span className="block text-[8px] font-bold text-gray-500 uppercase tracking-widest leading-none mb-1">Visualizações Estimadas</span>
                                            <strong className="text-xs font-mono font-bold text-green-400">+{profileViews}</strong>
                                          </div>
                                          <div className="text-right">
                                            <span className="block text-[8px] font-bold text-gray-500 uppercase tracking-widest leading-none mb-1">Novos Seguidores</span>
                                            <strong className="text-xs font-mono font-bold text-blue-400">+{extraFollowers}</strong>
                                          </div>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                )}
                              </React.Fragment>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                )}

                {activeSegment === 'playlists' && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-white/[0.01] border-b border-white/[0.05] text-gray-400 text-[9px] uppercase tracking-widest font-black">
                        <tr>
                          <th className="p-4">Playlist</th>
                          <th className="p-4">Descrição / Visibilidade</th>
                          <th className="p-4 text-right">Destaque</th>
                        </tr>
                      </thead>
                      <tbody className="text-xs divide-y divide-white/[0.03]">
                        {playlists
                          .filter(p => p.title.toLowerCase().includes(searchTerm.toLowerCase()))
                          .map(pl => {
                            const isFeatured = adminStore.isFeatured('playlist', String(pl.id));
                            const cover = pl.cover_image || 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=150';
                            return (
                              <tr key={pl.id} className="hover:bg-white/[0.01] transition-colors">
                                <td className="p-4">
                                  <div className="flex items-center gap-3">
                                    <img src={cover} alt={pl.title} className="w-8 h-8 rounded-lg object-cover bg-white/5" />
                                    <div>
                                      <p className="font-bold text-white uppercase italic tracking-tight">{pl.title}</p>
                                      <span className="text-[9px] text-[#5865F2] font-semibold">{pl.beat_ids?.length || 0} tracks</span>
                                    </div>
                                  </div>
                                </td>
                                <td className="p-4">
                                  <div className="text-gray-400 truncate max-w-[200px]" title={pl.description}>{pl.description || 'Sem descrição.'}</div>
                                  <span className="text-[9px] text-green-400 font-bold uppercase tracking-wider bg-green-500/10 p-1 px-1.5 rounded-md">Pública</span>
                                </td>
                                <td className="p-4 text-right">
                                  <button
                                    onClick={() => handleToggleFeatured(pl, 'playlist')}
                                    className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                                      isFeatured 
                                        ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20 flex items-center gap-1.5 ml-auto' 
                                        : 'bg-white/5 text-gray-400 hover:bg-white/10 flex items-center gap-1.5 ml-auto'
                                    }`}
                                  >
                                    <Star size={10} className={isFeatured ? 'fill-yellow-500' : ''} />
                                    {isFeatured ? 'Destaque' : 'Promover'}
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
