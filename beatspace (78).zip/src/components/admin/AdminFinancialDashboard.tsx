import React, { useState, useEffect } from 'react';
import { getSupabase } from '@/src/lib/supabase';
import { motion } from 'motion/react';
import { CheckCircle2, XCircle, Search, Loader2, Wallet, DollarSign, Receipt, AlertTriangle } from 'lucide-react';

export default function AdminFinancialDashboard() {
  console.log('ADMIN FINANCIAL DASHBOARD COMPONENT LOADED');
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [stats, setStats] = useState({
    totalPlatformEarnings: 0,
    totalConfirmedRevenue: 0,
    totalProducerPayouts: 0,
    platformNetProfit: 0
  });
  const [statsLoading, setStatsLoading] = useState(true);
  const supabase = getSupabase();

  useEffect(() => {
    fetchWithdrawals();
    fetchPlatformStats();

    const handleGlobalClick = (e: MouseEvent) => {
      if (e.target instanceof HTMLElement) {
        console.log('REALTIME FRONTEND CLICK ON ELEMENT:', {
          tagName: e.target.tagName,
          id: e.target.id,
          className: e.target.className
        });
      } else {
        console.log('REALTIME FRONTEND CLICK ON ELEMENT (NON-HTML)');
      }
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('click', handleGlobalClick, true);
    }

    const handleRefresh = () => {
      console.log('[REALTIME] Manual layout refresh triggered via custom event');
      fetchPlatformStats();
    };

    let bc: BroadcastChannel | null = null;
    if (typeof window !== 'undefined') {
      window.addEventListener('financialMetricsChanged', handleRefresh);
      if ('BroadcastChannel' in window) {
        bc = new BroadcastChannel('financial_updates');
        bc.onmessage = (event) => {
          if (event.data === 'refresh') {
            console.log('[REALTIME] BroadcastChannel update received, fetching metrics');
            fetchPlatformStats();
          }
        };
      }
    }

    if (!supabase) return;
    const channel = supabase
      .channel('schema-orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders'
        },
        (payload) => {
          console.log('[REALTIME] Supabase real-time change detected on orders:', payload);
          fetchPlatformStats();
        }
      )
      .subscribe();

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('financialMetricsChanged', handleRefresh);
        window.removeEventListener('click', handleGlobalClick, true);
      }
      if (bc) {
        bc.close();
      }
      supabase.removeChannel(channel);
    };
  }, [supabase]);

  async function fetchPlatformStats() {
    if (!supabase) return;
    setStatsLoading(true);
    try {
      // REQUIRED DEBUG LOGS
      console.log('REFRESHING PLATFORM METRICS');

      const { data: paidOrders, error } = await supabase
        .from('orders')
        .select('*')
        .eq('status', 'paid');

      if (error) {
        console.error("Error fetching paid orders:", error);
        return;
      }

      let totalRevenue = 0;
      let totalProducerEarnings = 0;
      let totalPlatformFee = 0;

      if (paidOrders) {
        paidOrders.forEach((o) => {
          const amount = Number(o.amount !== undefined && o.amount !== null ? o.amount : (o.price || o.total_amount || 0));
          const producerEarnings = amount * 0.9;
          const platformFee = amount - producerEarnings;

          // REQUIRED DEBUG LOGS
          console.log('ORDER AMOUNT:', amount);
          console.log('PRODUCER EARNINGS:', producerEarnings);
          console.log('PLATFORM FEE:', platformFee);

          totalRevenue += amount;
          totalProducerEarnings += producerEarnings;
          totalPlatformFee += platformFee;
        });
      }

      const platformProfit = totalPlatformFee;

      // REQUIRED DEBUG LOGS
      console.log('PAID ORDERS COUNT:', paidOrders?.length);
      console.log('UPDATED PLATFORM PROFIT:', platformProfit);

      setStats({
        totalPlatformEarnings: totalPlatformFee,
        totalConfirmedRevenue: totalRevenue,
        totalProducerPayouts: totalProducerEarnings,
        platformNetProfit: totalPlatformFee
      });
    } catch (err) {
      console.error("Exception loading platform financial stats:", err);
    } finally {
      setStatsLoading(false);
    }
  }

  async function fetchWithdrawals() {
    if (!supabase) return;
    setLoading(true);
    try {
      console.log('FETCHING WITHDRAWALS...');
      console.log('WITHDRAWAL TABLE ACCESS');
      const { data, error } = await supabase
        .from('withdrawal_requests')
        .select('*')
        .order('created_at', { ascending: false });

      console.log('SUPABASE RESPONSE:', data);
      console.log('SUPABASE ERROR:', error);

      if (error) {
        throw error;
      }

      const requests = data || [];
      const profileIds = Array.from(new Set(requests.map((r: any) => r.producer_id).filter(Boolean)));
      
      let profileMap = new Map<string, any>();
      let bankInfoMap = new Map<string, any>();

      if (profileIds.length > 0) {
        // Fetch profiles display_name and email using producer_id
        const { data: profiles, error: pErr } = await supabase
          .from('profiles')
          .select('id, display_name, email')
          .in('id', profileIds);
        
        if (!pErr && profiles) {
          profileMap = new Map(profiles.map(p => [p.id, p]));
        }

        // Fetch producer_banking_info using producer_id
        const { data: bankInfos, error: bErr } = await supabase
          .from('producer_banking_info')
          .select('*')
          .in('producer_id', profileIds);

        if (!bErr && bankInfos) {
          bankInfoMap = new Map(bankInfos.map(b => [b.producer_id, b]));
        }
      }

      const mapped = requests.map((r: any) => ({
        ...r,
        profiles: profileMap.get(r.producer_id) || { display_name: 'Desconhecido', email: '' },
        bank_info: bankInfoMap.get(r.producer_id) || null
      }));

      // REQUIRED LOG
      console.log('REAL WITHDRAWALS:', mapped);

      setWithdrawals(mapped);
    } catch (err) {
      console.error("Critical error in fetchWithdrawals:", err);
      setWithdrawals([]);
    } finally {
      setLoading(false);
    }
  }

  const approveWithdrawal = async (w: any) => {
    await handleAction(w.id, 'approve', w);
  };

  const rejectWithdrawal = async (w: any) => {
    await handleAction(w.id, 'reject', w);
  };

  async function handleAction(id: string, action: 'approve' | 'reject', withdrawalRaw?: any) {
    if (!supabase) return;
    setActionLoading(id);
    console.log(`[WITHDRAWAL MANAGER] Initiating ${action} action on request ID: ${id}`);
    
    try {
      const withdrawal = withdrawalRaw || withdrawals.find(w => w.id === id) || { id };
      
      console.log(`Calling secure server endpoint for action ${action} on request:`, withdrawal.id);
      
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData?.session?.access_token;

      const response = await fetch('/api/admin/withdrawal/action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(accessToken ? { 'Authorization': `Bearer ${accessToken}` } : {})
        },
        body: JSON.stringify({
          withdrawalId: withdrawal.id,
          action: action
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'Erro ao processar acção no servidor.');
      }

      const resJson = await response.json();
      console.log('Action response from server:', resJson);

      const resolvedStatus = action === 'approve' ? 'approved' : 'rejected';

      // Update local state immediately for an instant response
      setWithdrawals(prev =>
        prev.map(w =>
          w.id === withdrawal.id
            ? { ...w, status: resolvedStatus }
            : w
        )
      );
      
      alert(`Pedido de levantamento ${action === 'approve' ? 'aprovado' : 'rejeitado'} com sucesso!`);
      await fetchWithdrawals();
    } catch (err: any) {
      console.error("Error performing withdrawal action:", err);
      alert("Erro ao processar levantamento: " + err.message);
    } finally {
      setActionLoading(null);
    }
  }

  console.log('REAL WITHDRAWALS:', withdrawals);
  console.log('APPROVE FUNCTION EXISTS:', typeof approveWithdrawal);

  return (
    <div className="p-8 bg-[#0B0B0F] min-h-screen text-white">
      <header className="mb-8">
        <h1 className="text-3xl font-black italic tracking-tighter uppercase">Painel <span className="text-orange-500">Financeiro</span></h1>
        <p className="text-gray-400 font-medium">Moderação de pedidos e análise de receita.</p>
      </header>

      {/* Platform Earnings Tracking Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white/5 border border-white/10 p-6 rounded-3xl hover:border-orange-500/20 transition duration-300">
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-400 text-[10px] uppercase font-black tracking-widest">Total Confirmed Revenue</span>
            <div className="p-2 bg-blue-500/10 rounded-2xl text-blue-400">
              <DollarSign size={16} />
            </div>
          </div>
          <p className="text-2xl font-black font-mono">
            {statsLoading ? '...' : `${stats.totalConfirmedRevenue.toLocaleString('pt-AO')} Kz`}
          </p>
          <p className="text-[10px] text-gray-500 font-medium mt-1">100% of paid orders</p>
        </div>

        <div className="bg-white/5 border border-white/10 p-6 rounded-3xl hover:border-orange-500/20 transition duration-300">
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-400 text-[10px] uppercase font-black tracking-widest">Total Platform Earnings</span>
            <div className="p-2 bg-orange-500/10 rounded-2xl text-orange-400">
              <span className="font-sans text-xs font-black">10%</span>
            </div>
          </div>
          <p className="text-2xl font-black font-mono text-orange-500">
            {statsLoading ? '...' : `${stats.totalPlatformEarnings.toLocaleString('pt-AO')} Kz`}
          </p>
          <p className="text-[10px] text-gray-500 font-medium mt-1">Accumulated platform fee</p>
        </div>

        <div className="bg-white/5 border border-white/10 p-6 rounded-3xl hover:border-orange-500/20 transition duration-300">
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-400 text-[10px] uppercase font-black tracking-widest">Total Producer Payouts</span>
            <div className="p-2 bg-emerald-500/10 rounded-2xl text-emerald-400">
              <Wallet size={16} />
            </div>
          </div>
          <p className="text-2xl font-black font-mono">
            {statsLoading ? '...' : `${stats.totalProducerPayouts.toLocaleString('pt-AO')} Kz`}
          </p>
          <p className="text-[10px] text-gray-500 font-medium mt-1">90% share to creators</p>
        </div>

        <div className="bg-white/5 border border-white/10 p-6 rounded-3xl hover:border-orange-500/20 transition duration-300">
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-400 text-[10px] uppercase font-black tracking-widest">Platform Net Profit</span>
            <div className="p-2 bg-orange-500/10 rounded-2xl text-orange-400">
              <Receipt size={16} />
            </div>
          </div>
          <p className="text-2xl font-black font-mono text-orange-400">
            {statsLoading ? '...' : `${stats.platformNetProfit.toLocaleString('pt-AO')} Kz`}
          </p>
          <p className="text-[10px] text-gray-500 font-medium mt-1">Confirmed platform commission</p>
        </div>
      </div>

      <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto w-full">
          <table className="w-full min-w-[1100px] text-left table-auto">
            <thead className="bg-white/10 border-b border-white/10 text-gray-400 text-[10px] uppercase tracking-widest font-black">
              <tr>
                <th className="px-10 py-8">Produtor / Contacto</th>
                <th className="px-10 py-8">Dados Bancários / IBAN</th>
                <th className="px-10 py-8">Método / Data</th>
                <th className="px-10 py-8">Valor</th>
                <th className="px-10 py-8">Status</th>
                <th className="px-10 py-8 min-w-[240px]" style={{ minWidth: '240px' }}>Ações</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-gray-400 font-sans">
                    <div className="flex justify-center items-center gap-2">
                      <Loader2 className="animate-spin text-orange-500" size={18} />
                      <span>A carregar pedidos de levantamento...</span>
                    </div>
                  </td>
                </tr>
              ) : withdrawals.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-gray-400 font-sans">
                    <div className="flex flex-col items-center justify-center gap-1 py-4">
                      <AlertTriangle className="text-amber-500/80 mb-1" size={24} />
                      <span className="text-sm font-bold text-gray-200">Nenhum pedido de levantamento encontrado</span>
                      <span className="text-xs text-gray-500">Não existem pedidos de levantamento registados na base de dados no momento.</span>
                    </div>
                  </td>
                </tr>
              ) : (
                withdrawals.map(w => {
                  const withdrawal = w;
                  const producerBankData = w.bank_info;

                  // REQUIRED DEBUG LOGS FOR AUDITING DYNAMIC DATA FLOW:
                  console.log('WITHDRAWAL REQUEST:', withdrawal);
                  console.log('BANK DATA:', producerBankData);
                  console.log('RENDERING APPROVE BUTTON:', withdrawal.id);
                  console.log('BUTTON AREA RENDERED');

                  const requestDate = w.created_at ? new Date(w.created_at).toLocaleDateString('pt-AO', {
                    day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'
                  }) : 'N/A';

                  return (
                    <tr key={w.id} style={{ position: 'relative', zIndex: 1 }} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="px-10 py-8">
                        <div className="font-bold text-white text-sm">{w.profiles?.display_name || 'N/A'}</div>
                        <div className="text-gray-400 text-xs mt-0.5">{w.profiles?.email || 'N/A'}</div>
                      </td>
                      <td className="px-10 py-8">
                        <div className="space-y-1">
                          <div className="text-xs text-white font-semibold flex items-center gap-1">
                            <span className="text-amber-500 font-bold uppercase text-[9px]">Banco:</span> {w.details?.bank_name || w.bank_info?.bank_name || 'N/A'}
                          </div>
                          <div className="text-xs text-gray-300">
                            <span className="text-gray-500 font-bold uppercase text-[9px]">Titular:</span> {w.details?.full_name || w.bank_info?.full_name || 'N/A'}
                          </div>
                          <div className="text-xs font-mono text-cyan-400 font-bold">
                            <span className="text-gray-500 font-bold uppercase text-[9px] font-sans">IBAN:</span> {w.details?.account_number || w.bank_info?.account_number || 'N/A'}
                          </div>
                          <div className="text-xs text-gray-400">
                            <span className="text-gray-500 font-bold uppercase text-[9px]">Tel:</span> {w.details?.phone || w.bank_info?.phone || 'N/A'}
                          </div>
                        </div>
                      </td>
                      <td className="px-10 py-8">
                        <div className="capitalize text-gray-200 text-xs font-medium">{w.method?.replace('_', ' ')}</div>
                        <div className="text-gray-500 text-[10px] mt-1 font-mono">{requestDate}</div>
                      </td>
                      <td className="px-10 py-8 font-mono font-bold text-blue-400">
                        {w.amount?.toLocaleString('pt-AO')} Kz
                      </td>
                      <td className="px-10 py-8">
                        <span className={`px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest inline-block ${
                          w.status === 'completed' || w.status === 'approved' 
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.15)] animate-pulse' 
                            : w.status === 'rejected' 
                              ? 'bg-red-500/20 text-red-400 border border-red-500/20' 
                              : 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/20'
                        }`}>
                          {w.status === 'approved' || w.status === 'completed' ? 'PAGO' : w.status === 'rejected' ? 'REJEITADO' : 'PENDENTE'}
                        </span>
                      </td>
                      <td className="px-10 py-8 min-w-[240px]" style={{ minWidth: '240px', overflow: 'visible' }}>
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3" style={{ display: 'flex', gap: '12px', flexWrap: 'nowrap', alignItems: 'center' }}>
                          
                          {w.status === 'pending' && (
                            <>
                              <button
                                type="button"
                                onClick={() => approveWithdrawal(w)}
                                className="flex-1 sm:flex-initial text-center justify-center bg-[#16A34A] hover:bg-[#22C55E] text-white font-bold text-xs uppercase tracking-wider px-4.5 py-2.5 rounded-xl transition-all duration-300 shadow-[0_0_15px_rgba(22,163,74,0.15)] hover:shadow-[0_0_20px_rgba(34,197,94,0.35)] hover:-translate-y-0.5 cursor-pointer whitespace-nowrap"
                                style={{ flexShrink: 0 }}
                              >
                                Aceitar
                              </button>

                              <button
                                type="button"
                                onClick={() => rejectWithdrawal(w)}
                                className="flex-1 sm:flex-initial text-center justify-center bg-[#991B1B] hover:bg-[#DC2626] text-white font-bold text-xs uppercase tracking-wider px-4.5 py-2.5 rounded-xl transition-all duration-300 shadow-[0_0_15px_rgba(153,27,27,0.15)] hover:shadow-[0_0_20px_rgba(220,38,38,0.35)] hover:-translate-y-0.5 cursor-pointer whitespace-nowrap"
                                style={{ flexShrink: 0 }}
                              >
                                Rejeitar
                              </button>
                            </>
                          )}

                          {(w.status === 'approved' || w.status === 'completed') && (
                            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wide whitespace-nowrap shadow-[0_0_12px_rgba(16,185,129,0.05)]">
                              Pago
                            </span>
                          )}

                          {w.status === 'rejected' && (
                            <span className="bg-red-500/10 text-red-400 border border-red-500/20 px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wide whitespace-nowrap">
                              Rejeitado
                            </span>
                          )}

                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
