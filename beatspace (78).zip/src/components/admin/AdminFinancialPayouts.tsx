import React, { useState, useEffect } from 'react';
import { getSupabase } from '@/src/lib/supabase';
import { Wallet, DollarSign, ArrowUpRight, CheckCircle2, Loader2, Search, ArrowRightLeft } from 'lucide-react';

export default function AdminFinancialPayouts() {
  const [producers, setProducers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const supabase = getSupabase();

  useEffect(() => {
    fetchBalances();
  }, [supabase]);

  async function fetchBalances() {
    if (!supabase) return;
    setLoading(true);
    try {
      // Fetch profiles that are producers or sellers
      const { data: profiles, error: pError } = await supabase
        .from('profiles')
        .select('*')
        .or('role.eq.producer,role.eq.seller');

      if (pError) console.error("Error fetching profiles:", pError);

      // Fetch wallets
      const { data: wallets, error: wError } = await supabase
        .from('wallets')
        .select('*');

      if (wError) console.error("Error fetching wallets:", wError);

      const walletMap = new Map((wallets || []).map(w => [w.producer_id, w]));

      const mapped = (profiles || []).map(p => {
        const w = walletMap.get(p.id) || {
          available_balance: p.wallet_available_balance || 0,
          pending_balance: p.wallet_pending_balance || 0,
          total_earned: p.wallet_total_earned || 0,
          total_withdrawn: p.wallet_total_withdrawn || 0,
        };

        return {
          ...p,
          available_balance: Number(w.available_balance || 0),
          pending_balance: Number(w.pending_balance || 0),
          total_earned: Number(w.total_earned || 0),
          total_withdrawn: Number(w.total_withdrawn || 0),
        };
      });

      setProducers(mapped);
    } catch (err) {
      console.error("Exception loading financial balances:", err);
    } finally {
      setLoading(false);
    }
  }

  async function releasePayout(producerId: string, pendingAmount: number) {
    if (!supabase || pendingAmount <= 0) return;
    setActionLoading(producerId);

    try {
      // 1. Fetch current wallet balances to be completely safe and avoid race conditions
      const { data: walletData, error: wError } = await supabase
        .from('wallets')
        .select('*')
        .eq('producer_id', producerId)
        .single();

      let currentPending = pendingAmount;
      let currentAvailable = 0;
      let currentEarned = pendingAmount;
      let currentWithdrawn = 0;

      if (!wError && walletData) {
        currentPending = Number(walletData.pending_balance || 0);
        currentAvailable = Number(walletData.available_balance || 0);
        currentEarned = Number(walletData.total_earned || 0);
        currentWithdrawn = Number(walletData.total_withdrawn || 0);
      }

      if (currentPending <= 0) {
        alert("O produtor não possui saldo pendente para liberar.");
        setActionLoading(null);
        return;
      }

      const newAvailable = currentAvailable + currentPending;

      // 2. Perform database update for 'wallets' table
      if (walletData) {
        await supabase
          .from('wallets')
          .update({
            pending_balance: 0,
            available_balance: newAvailable
          })
          .eq('producer_id', producerId);
      } else {
        await supabase
          .from('wallets')
          .insert({
            producer_id: producerId,
            pending_balance: 0,
            available_balance: newAvailable,
            total_earned: currentEarned,
            total_withdrawn: 0
          });
      }

      // 3. Keep 'profiles' table wallet column states in sync
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', producerId)
        .single();

      if (profileData) {
        await supabase
          .from('profiles')
          .update({
            wallet_pending_balance: 0,
            wallet_available_balance: newAvailable,
            wallet_total_earned: Number(profileData.wallet_total_earned || 0) || currentEarned,
            wallet_balance: newAvailable // support older fallback balances
          })
          .eq('id', producerId);
      }

      // 4. Log the release in transactions ledger
      await supabase.from('wallet_transactions').insert({
        producer_id: producerId,
        amount: currentPending,
        producer_amount: currentPending,
        platform_amount: 0,
        transaction_type: 'release',
        status: 'completed'
      });

      // Send payment confirmation notification to the producer
      try {
        await supabase.from('notifications').insert([
          {
            user_id: producerId,
            type: 'payment',
            title: 'Seu pagamento foi processado! 💳',
            message: `Olá! O teu levantamento no valor de ${currentPending.toLocaleString('pt-AO')} Kz foi aprovado e creditado com sucesso como saldo livre.`,
            read: false,
            created_at: new Date().toISOString()
          }
        ]);
        console.log('[NOTIFY PAYOUT] Payout notification dispatched to:', producerId);
      } catch (notifErr) {
        console.error('[NOTIFY PAYOUT] Failed to insert payout notification:', notifErr);
      }

      alert(`Pagamento de ${currentPending.toLocaleString('pt-AO')} Kz liberado com sucesso!`);
      await fetchBalances();
    } catch (e: any) {
      console.error("Error releasing payout:", e);
      alert("Erro ao liberar pagamento: " + e.message);
    } finally {
      setActionLoading(null);
    }
  }

  const filtered = producers.filter(p => 
    (p.display_name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
     p.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
     p.artistic_name?.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="flex justify-center p-20">
        <Loader2 className="animate-spin text-orange-500" size={32} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search Header */}
      <div className="bg-gray-905 border border-white/[0.08] rounded-3xl p-6 flex items-center gap-4 bg-gray-900/40 backdrop-blur-sm">
        <Search className="text-gray-500" size={20} />
        <input 
          type="text" 
          placeholder="Pesquisar produtores por nome ou email..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-transparent border-none outline-none text-white w-full text-sm placeholder:text-gray-600"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="bg-gray-900/50 backdrop-blur-sm border border-white/[0.08] rounded-3xl p-12 text-center text-gray-400">
          Nenhum produtor faturado encontrado.
        </div>
      ) : (
        <div className="bg-gray-900/50 backdrop-blur-sm border border-white/[0.08] rounded-3xl overflow-hidden shadow-xl">
          <table className="w-full text-left">
            <thead className="bg-white/[0.03] border-b border-white/[0.05] text-gray-500 text-[10px] uppercase tracking-widest font-black">
              <tr>
                <th className="p-6">Nome / Nome Artístico</th>
                <th className="p-6">Saldo Pendente</th>
                <th className="p-6">Saldo Disponível</th>
                <th className="p-6">Total Ganho</th>
                <th className="p-6">Total Levantado</th>
                <th className="p-6 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {filtered.map(p => (
                <tr key={p.id} className="border-b border-white/[0.05] hover:bg-white/[0.03] transition-colors">
                  <td className="p-6">
                    <div className="font-bold text-white">{p.display_name || p.full_name || 'Anonymous'}</div>
                    <div className="text-xs text-gray-500 font-medium mt-0.5">{p.artistic_name ? `@${p.artistic_name}` : p.email}</div>
                  </td>
                  <td className="p-6">
                    <span className="font-mono text-amber-500 font-bold">
                      {p.pending_balance.toLocaleString('pt-AO')} Kz
                    </span>
                  </td>
                  <td className="p-6">
                    <span className="font-mono text-emerald-500 font-bold">
                      {p.available_balance.toLocaleString('pt-AO')} Kz
                    </span>
                  </td>
                  <td className="p-6 text-gray-400 font-medium font-mono">{p.total_earned.toLocaleString('pt-AO')} Kz</td>
                  <td className="p-6 text-gray-500 font-medium font-mono">{p.total_withdrawn?.toLocaleString('pt-AO') || 0} Kz</td>
                  <td className="p-6 text-right">
                    {p.pending_balance > 0 ? (
                      <button
                        onClick={() => releasePayout(p.id, p.pending_balance)}
                        disabled={actionLoading === p.id}
                        className="bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-black px-4 py-2 rounded-xl text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer shadow-lg shadow-orange-600/20 active:scale-95 flex items-center justify-center gap-1.5 ml-auto"
                      >
                        {actionLoading === p.id ? (
                          <>
                            <Loader2 className="animate-spin" size={14} />
                            Processando
                          </>
                        ) : (
                          <>
                            <ArrowRightLeft size={14} />
                            Liberar Pagamento
                          </>
                        )}
                      </button>
                    ) : (
                      <span className="text-xs text-gray-600 uppercase tracking-widest font-black pr-2">Sem saldo pendente</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
