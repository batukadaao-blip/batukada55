import React, { useState, useEffect } from 'react';
import { getSupabase } from '@/src/lib/supabase';
import { Search, UserCheck, ShieldAlert, Cpu } from 'lucide-react';

export default function AdminCustomersManagement() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const supabase = getSupabase();

  useEffect(() => {
    fetchCustomers();
  }, [supabase]);

  async function fetchCustomers() {
    if (!supabase) return;
    setLoading(true);
    const { data, error } = await supabase.from('profiles').select('*'); 
    
    if (data) setCustomers(data);
    if (error) console.error("Error fetching customers:", error);
    setLoading(false);
  }

  const filteredCustomers = customers.filter(c => 
    (c.full_name?.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (c.display_name?.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (c.email?.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="p-16 text-center text-neutral-400 font-mono text-xs flex flex-col items-center justify-center gap-3">
        <Cpu className="w-5 h-5 animate-spin text-[#5865F2]" />
        CARREGANDO REGISTOS OPERACIONAIS...
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Subheader and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black uppercase italic tracking-tight text-white flex items-center gap-2">
            <UserCheck className="text-[#5865F2] w-5 h-5" />
            CONTROLO DE CLIENTES e CONTAS
          </h2>
          <p className="text-xs text-neutral-400 font-medium font-sans">Gestão e verificação de utilizadores registados na Base de Dados.</p>
        </div>

        {/* Minimal Search input */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500 w-4 h-4" />
          <input 
            type="text" 
            placeholder="Pesquisar por nome ou email..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#0a0a0f] border border-white/[0.05] hover:border-white/[0.10] focus:border-[#5865F2]/45 rounded-xl py-2.5 pl-10 pr-4 text-xs text-white placeholder-neutral-500 font-semibold focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all font-sans"
          />
        </div>
      </div>

      {filteredCustomers.length === 0 ? (
        <div className="bg-black/40 border border-white/[0.04] p-12 rounded-2xl text-center text-neutral-500">
          Nenhum cliente encontrado com os critérios de pesquisa.
        </div>
      ) : (
        <div className="bg-[#050505] border border-white/[0.04] rounded-2xl overflow-hidden shadow-2xl relative">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-[#09090C]/80 border-b border-white/[0.04] text-neutral-500 text-[10px] uppercase tracking-widest font-black font-mono">
                <tr>
                  <th className="p-5 pl-6">Nome Completo / Perfil</th>
                  <th className="p-5">E-mail</th>
                  <th className="p-5">Contacto telefónico</th>
                  <th className="p-5">Função</th>
                  <th className="p-5 text-right pr-6">CRIADO EM</th>
                </tr>
              </thead>
              <tbody className="text-xs font-semibold divide-y divide-white/[0.02]">
                {filteredCustomers.map(customer => (
                  <tr key={customer.id} className="hover:bg-white/[0.015] transition-colors border-b border-white/[0.02] last:border-0">
                    <td className="p-5 pl-6">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#5865F2]/10 to-transparent border border-white/5 flex items-center justify-center font-bold text-white uppercase text-[10px]">
                          {String(customer.full_name || customer.display_name || 'U').substring(0, 2)}
                        </div>
                        <div>
                          <p className="font-extrabold text-neutral-100 hover:text-white uppercase italic tracking-tight">
                            {customer.full_name || customer.display_name || 'Sem nome associado'}
                          </p>
                          <p className="text-[9px] text-neutral-500 font-mono mt-0.5">ID: {customer.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-5 text-neutral-300 font-mono text-[11px]">
                      {customer.email || 'Sem e-mail'}
                    </td>
                    <td className="p-5 text-neutral-400 font-mono">
                      {customer.phone || 'Sem contacto associado'}
                    </td>
                    <td className="p-5">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest border font-mono ${
                        customer.role === 'admin' ? 'bg-[#5865F2]/10 text-blue-400 border-[#5865F2]/20' : 
                        customer.role === 'producer' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' : 
                        'bg-white/5 text-neutral-400 border-white/5'
                      }`}>
                        {customer.role || 'cliente'}
                      </span>
                    </td>
                    <td className="p-5 text-right pr-6 text-neutral-500 font-mono text-[10px]">
                      {customer.created_at ? new Date(customer.created_at).toLocaleDateString() : 'N/D'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
