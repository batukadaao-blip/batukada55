import React, { useState } from 'react';
import { getSupabase } from '@/src/lib/supabase';
import { ShieldCheck, User, CheckCircle2, XCircle, Banknote, AlertTriangle, Cpu, Globe, Key } from 'lucide-react';
import AdminTabs from './AdminTabs';
import AdminDashboardOverview from './AdminDashboardOverview';
import AdminBeatsManagement from './AdminBeatsManagement';
import AdminOrdersManagement from './AdminOrdersManagement';
import AdminCustomersManagement from './AdminCustomersManagement';
import AdminProducersManagement from './AdminProducersManagement';
import AdminFinancialPayouts from './AdminFinancialPayouts';
import AdminFinancialDashboard from './AdminFinancialDashboard';
import AdminReportsManagement from './AdminReportsManagement';
import AdminFeaturedManagement from './AdminFeaturedManagement';
import AdminSystemLogs from './AdminSystemLogs';

export default function AdminPayoutManagement() {
  const [currentTab, setCurrentTab] = useState('overview');

  return (
    <div className="min-h-screen bg-[#050507] text-white p-4 sm:p-5 md:p-6 animate-in fade-in duration-300 relative overflow-x-hidden">
      {/* Majestic Premium Header */}
      <header className="relative mb-6 pb-4 border-b border-white/5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-1.5 mb-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-bold tracking-wider text-[#5865F2] uppercase">Admin Suite v2.0</span>
            </div>
            
            <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight">
              Painel de Controlo <span className="text-[#5865F2]">Geral</span>
            </h1>
            <p className="text-neutral-400 text-xs mt-0.5 leading-relaxed">
              Gestão centralizada e inteligência operacional da plataforma Batukada.
            </p>
          </div>

          {/* Premium Enterprise Mini Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded text-[9px] uppercase font-bold tracking-wider text-emerald-400 flex items-center gap-1">
              <Globe className="w-3 h-3" />
              SISTEMA ONLINE
            </span>
            <span className="bg-[#5865F2]/10 border border-[#5865F2]/20 px-2.5 py-1 rounded text-[9px] uppercase font-bold tracking-wider text-blue-400 flex items-center gap-1">
              <Cpu className="w-3 h-3" />
              SEGURANÇA ATIVA
            </span>
            <span className="bg-purple-500/10 border border-purple-500/20 px-2.5 py-1 rounded text-[9px] uppercase font-bold tracking-wider text-purple-400 flex items-center gap-1">
              <Key className="w-3 h-3" />
              TEMPO REAL
            </span>
          </div>
        </div>
      </header>

      {/* Main SaaS Responsive Grid */}
      <div className="flex flex-col lg:flex-row gap-6 items-start">
        {/* Sidebar container */}
        <AdminTabs currentTab={currentTab} setCurrentTab={setCurrentTab} />

        {/* Dynamic page container */}
        <main className="flex-1 w-full min-w-0 bg-[#0c0c12]/80 border border-white/5 rounded-xl p-5 md:p-6 transition-all duration-300 relative">
          <div className="absolute top-2 right-2 w-1 h-1 rounded-full bg-white/10" />
          
          {currentTab === 'overview' && <AdminDashboardOverview />}
          
          {currentTab === 'beats' && <AdminBeatsManagement />}

          {currentTab === 'orders' && <AdminOrdersManagement />}
          
          {currentTab === 'clientes' && <AdminCustomersManagement />}

          {currentTab === 'payouts' && <AdminProducersManagement />}

          {currentTab === 'financial' && <AdminFinancialPayouts />}

          {currentTab === 'withdrawals' && <AdminFinancialDashboard />}

          {currentTab === 'reports' && <AdminReportsManagement />}

          {currentTab === 'featured' && <AdminFeaturedManagement />}

          {currentTab === 'system-logs' && <AdminSystemLogs />}
        </main>
      </div>
    </div>
  );
}
