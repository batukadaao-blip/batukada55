import React, { useState, useEffect } from 'react';
import { getSupabase, getPublicUrl } from '@/src/lib/supabase';
import { Edit, Trash2, Eye, Search, Sparkles, Music, Star } from 'lucide-react';

export default function AdminBeatsManagement() {
  const [beats, setBeats] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const supabase = getSupabase();

  useEffect(() => {
    fetchBeats();
  }, [supabase]);

  async function fetchBeats() {
    if (!supabase) return;
    try {
      const { data: beatsData, error: beatsError } = await supabase.from('beats').select('*');
      if (beatsError) {
        console.error("Error fetching beats in AdminBeats:", beatsError);
      }
      if (beatsData) {
        const mapped = beatsData.map((b: any) => {
          let extractedKey = b.key;
          let extractedScale = b.scale;
          if (b.tags && Array.isArray(b.tags)) {
            const kt = b.tags.find((t: string) => t.startsWith('_key:'));
            if (kt) extractedKey = kt.split(':')[1];
            const st = b.tags.find((t: string) => t.startsWith('_scale:'));
            if (st) extractedScale = st.split(':')[1];
          }
          const cleanTags = b.tags ? b.tags.filter((t: string) => !t.startsWith('_key:') && !t.startsWith('_scale:')) : [];

          return {
            ...b,
            producer: b.producer_name || b.artist_name || b.username || 'Produtor',
            genre: b.genre || 'Afro House / Semba / Kuduro',
            key: extractedKey || 'C',
            scale: extractedScale || 'Maior',
            tags: cleanTags
          };
        });
        setBeats(mapped);
      }
    } catch (e) {
      console.error("Error in fetchBeats admin:", e);
    }
  }

  const getCoverUrl = (cover_url: string) => {
    if (!cover_url) return '';
    if (cover_url.startsWith('http://') || cover_url.startsWith('https://')) return cover_url;
    return getPublicUrl('beats', cover_url);
  };

  const renderBeatCover = (beat: any) => {
    const imgUrl = beat.cover_url ? getCoverUrl(beat.cover_url) : '';
    const fallbackEl = (
      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#5865F2]/20 to-neutral-900 border border-white/[0.08] flex flex-col items-center justify-center text-[7px] font-black tracking-wider text-[#5865F2] font-mono select-none shrink-0">
        <Music size={14} className="text-[#5865F2] mb-0.5" />
      </div>
    );

    if (!imgUrl) return fallbackEl;

    return (
      <div className="relative w-10 h-10 shrink-0 select-none">
        <img
          src={imgUrl}
          alt={beat.title}
          className="w-10 h-10 rounded-lg object-cover bg-neutral-950 border border-white/10"
          referrerPolicy="no-referrer"
          onError={(e) => {
            const target = e.currentTarget;
            target.style.display = 'none';
            const parent = target.parentElement;
            if (parent) {
              const fallback = parent.querySelector('.fallback-placeholder');
              if (fallback instanceof HTMLElement) {
                fallback.style.display = 'flex';
              }
            }
          }}
        />
        <div className="fallback-placeholder absolute inset-0 rounded-lg bg-gradient-to-br from-[#5865F2]/20 to-neutral-900 border border-white/[0.08] flex flex-col items-center justify-center text-[7px] font-black tracking-wider text-[#5865F2] font-mono" style={{ display: 'none' }}>
          <Music size={14} className="text-[#5865F2] mb-0.5" />
        </div>
      </div>
    );
  };

  const filteredBeats = beats.filter(beat => 
    beat.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    beat.producer?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    beat.id?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Subheader and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black uppercase italic tracking-tight text-white flex items-center gap-2">
            <Music className="text-[#5865F2] w-5 h-5" />
            CONTROLO DE BEATS
          </h2>
          <p className="text-xs text-neutral-400 font-medium">Histórico abrangente de instrumentais e soundkits registados.</p>
        </div>

        {/* Minimal Search Bar */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500 w-4 h-4" />
          <input 
            type="text"
            placeholder="Pesquisar beats por título ou produtor..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-[#0a0a0f] border border-white/[0.05] hover:border-white/[0.10] focus:border-[#5865F2]/40 rounded-xl py-2.5 pl-10 pr-4 text-xs text-white placeholder-neutral-500 font-semibold focus:outline-none focus:ring-1 focus:ring-[#5865F2]/20 transition-all font-sans"
          />
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-[#050505] border border-white/[0.04] rounded-2xl overflow-hidden shadow-2xl relative">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#09090C]/80 border-b border-white/[0.04] text-neutral-500 text-[10px] uppercase tracking-widest font-black font-mono">
              <tr>
                <th className="p-5 pl-6">Título / Beat</th>
                <th className="p-5">Produtor</th>
                <th className="p-5">GÉNERO / TOM</th>
                <th className="p-5">BPM</th>
                <th className="p-5">Preço Base</th>
                <th className="p-5 text-right pr-6">AÇÕES</th>
              </tr>
            </thead>
            <tbody className="text-xs font-semibold divide-y divide-white/[0.02]">
              {filteredBeats.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-10 text-center text-neutral-400">
                    Nenhum beat encontrado com os critérios de busca.
                  </td>
                </tr>
              ) : (
                filteredBeats.map(beat => (
                  <tr key={beat.id} className="hover:bg-white/[0.015] transition-colors border-b border-white/[0.02] last:border-0">
                    <td className="p-5 pl-6 flex items-center gap-3.5">
                      {renderBeatCover(beat)}
                      <div className="min-w-0">
                        <p className="font-extrabold text-neutral-100 hover:text-white truncate uppercase italic tracking-tight">{beat.title}</p>
                        <p className="text-[9px] text-neutral-500 font-mono mt-0.5">ID: {beat.id}</p>
                      </div>
                    </td>
                    <td className="p-5 text-neutral-300">
                      <span className="bg-white/5 py-1 px-2.5 rounded-lg border border-white/5 text-[10px] font-bold text-white uppercase font-sans">
                        {beat.producer}
                      </span>
                    </td>
                    <td className="p-5 text-neutral-400 font-mono text-[10px]">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-neutral-300 font-sans text-xs">{beat.genre}</span>
                        <span className="text-[9px] text-neutral-500 uppercase">{beat.key} {beat.scale}</span>
                      </div>
                    </td>
                    <td className="p-5 text-neutral-400 font-mono text-xs font-bold">
                      {beat.bpm} BPM
                    </td>
                    <td className="p-5 text-[#5865F2] font-mono font-extrabold text-xs">
                      {beat.price_basic?.toLocaleString() || '0'} Kz
                    </td>
                    <td className="p-5 text-right pr-6 text-neutral-400">
                      <div className="flex items-center justify-end gap-2.5">
                        <button className="p-2 bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white rounded-lg transition-colors cursor-pointer" title="Visualizar">
                          <Eye size={13} />
                        </button>
                        <button className="p-2 bg-[#5865F2]/5 hover:bg-[#5865F2]/10 text-blue-400 hover:text-blue-300 rounded-lg transition-colors cursor-pointer" title="Editar">
                          <Edit size={13} />
                        </button>
                        <button className="p-2 bg-rose-500/5 hover:bg-rose-500/10 text-rose-400 hover:text-rose-300 rounded-lg transition-colors cursor-pointer" title="Remover">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
