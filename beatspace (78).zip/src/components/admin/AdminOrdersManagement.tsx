import React, { useState, useEffect } from 'react';
import { getSupabase, normalizeBeatId } from '@/src/lib/supabase';

export default function AdminOrdersManagement() {
  const [orders, setOrders] = useState<any[]>([]);
  const [orderItems, setOrderItems] = useState<any[]>([]);
  const [beats, setBeats] = useState<any[]>([]);
  const [orderItemsMap, setOrderItemsMap] = useState<any>({});
  const [beatMap, setBeatMap] = useState<any>({});
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const supabase = getSupabase();

  useEffect(() => {
    fetchOrders();
  }, [supabase]);

  // Log active filters whenever they change
  useEffect(() => {
    console.log('--- ADMIN ORDERS ACTIVE FILTERS ---');
    console.log('statusFilter:', statusFilter);
  }, [statusFilter]);

  async function fetchOrders() {
    if (!supabase) return;
    console.log('--- FETCHING ADMIN ORDERS START ---');

    let orders: any[] = [];
    let orderItems: any[] = [];
    let beats: any[] = [];

    let loadedFromApi = false;
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      if (token) {
        console.log('[ADMIN ORDERS FETCH] Fetching RLS-bypassed data from backend api...');
        const response = await fetch('/api/admin/orders', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        if (response.ok) {
          const result = await response.json();
          if (result && result.success) {
            orders = result.orders || [];
            orderItems = result.orderItems || [];
            beats = result.beats || [];
            loadedFromApi = true;
            console.log('[ADMIN ORDERS FETCH] Successfully loaded orders using admin endpoint bypassing RLS:', {
              ordersCount: orders.length,
              orderItemsCount: orderItems.length,
              beatsCount: beats.length
            });
          }
        } else {
          console.warn('[ADMIN ORDERS FETCH] Admin endpoint returned status code:', response.status);
        }
      } else {
        console.warn('[ADMIN ORDERS FETCH] Admin user token is not available for backend proxy API call.');
      }
    } catch (apiErr) {
      console.error('[ADMIN ORDERS FETCH] Backend API proxy execution or parsing issue:', apiErr);
    }

    if (!loadedFromApi) {
      console.log('[ADMIN ORDERS FETCH] Falling back to standard direct client-side query (subject to RLS)...');
      try {
        // 1. Fetch ALL orders separately
        const { data, error } = await supabase.from('orders').select('*');
        if (error) {
          console.error('Error fetching base orders table:', error);
        }
        orders = data || [];
      } catch (e) {
        console.error('Failed to select from orders table:', e);
      }

      try {
        // 2. Fetch ALL order_items separately
        const { data, error } = await supabase.from('order_items').select('id, order_id, beat_id');
        if (error) {
          console.error('Error fetching order_items:', error);
        }
        orderItems = data || [];
      } catch (e) {
        console.error('Exception fetching order items mapping:', e);
      }

      try {
        // 3. Fetch ALL beats separately
        const { data, error } = await supabase.from('beats').select('id, title');
        if (error) {
          console.error('Error fetching beats table:', error);
        }
        beats = data || [];
      } catch (e) {
        console.error('Error fetching beats mapping:', e);
      }
    }

    // REQUIRED DEBUG LOGS
    console.log('ORDERS:', orders);
    console.log('ORDER ITEMS:', orderItems);
    console.log('BEATS:', beats);

    const baseOrders = orders;

    // Retrieve unique reference keys for profiles
    const profileIds = Array.from(new Set(
      baseOrders.map(o => o.customer_id || o.client_id || o.buyer_id).filter(Boolean)
    ));

    // Retrieve profiles mapping in bulk for referenced profiles only
    let profileMap = new Map();
    if (profileIds.length > 0) {
      try {
        const { data: profiles, error: pError } = await supabase
          .from('profiles')
          .select('id, display_name, artistic_name, email')
          .in('id', profileIds);
        
        if (!pError && profiles) {
          profileMap = new Map(profiles.map(p => [p.id, p]));
        } else {
          const { data: fallbackProfiles } = await supabase
            .from('profiles')
            .select('id, email')
            .in('id', profileIds);
          if (fallbackProfiles) {
            profileMap = new Map(fallbackProfiles.map(p => [p.id, p]));
          }
        }
      } catch (err) {
        console.error('Error fetching profiles mapping:', err);
      }
    }

    // Build order_items mapping in-memory
    let orderItemsMap: any = {};
    orderItems.forEach((item: any) => {
      if (item.order_id) {
        const key = String(item.order_id).trim().toLowerCase();
        console.log(
          'NORMALIZED MAP KEY:',
          key
        );
        console.log(
          'MAP BUILD:',
          item.order_id,
          item
        );
        if (!orderItemsMap[key]) {
          orderItemsMap[key] = [];
        }
        orderItemsMap[key].push(item);
      }
    });

    // Build beats mapping lookup table with consistent normalization
    const beatMap: any = {
      get: function(key: any) {
        if (key === undefined || key === null) return undefined;
        const cleanKey = String(key).trim().toLowerCase();
        return this[cleanKey] || this[String(key)] || this[Number(key)];
      },
      set: function(key: any, val: any) {
        if (key !== undefined && key !== null) {
          const cleanKey = String(key).trim().toLowerCase();
          this[cleanKey] = val;
          this[String(key)] = val;
          this[Number(key)] = val;
        }
      }
    };

    beats.forEach((b: any) => {
      if (b.id) {
        beatMap.set(b.id, b);
        beatMap.set(String(b.id).trim().toLowerCase(), b);
      }
      const normalizedId = normalizeBeatId(b.id);
      beatMap.set(normalizedId, b);
      beatMap.set(String(normalizedId), b);
      beatMap.set(Number(normalizedId), b);
    });

    console.log('BEAT MAP:', beatMap);

    const resolvedTitles: { order_id: string; titles: string }[] = [];

    // Now normalize ALL order objects to protect the UI and filter arrays
    const normalizedOrders = baseOrders.map((order: any) => {
      // Normalize Status
      const rawStatus = order.status;
      let status = 'null';
      if (rawStatus !== undefined && rawStatus !== null && String(rawStatus).trim() !== '') {
        const str = String(rawStatus).toLowerCase().trim();
        if (str === 'waiting' || str === 'waiting_confirmation' || str === 'waiting-confirmation' || str === 'aguardando') {
          status = 'waiting_confirmation';
        } else if (str === 'paid' || str === 'completed' || str === 'concluido' || str === 'sucesso') {
          status = 'paid';
        } else if (str === 'suspicious' || str === 'suspeito') {
          status = 'suspicious';
        } else if (str === 'expired' || str === 'expirado') {
          status = 'expired';
        } else if (str === 'pending' || str === 'pendente') {
          status = 'pending';
        } else if (str === 'null') {
          status = 'null';
        } else {
          status = str; // Keep precise state to not hide any custom statuses
        }
      } else {
        status = 'null'; // Support null or empty representation
      }

      // Safe customer mapping (resolving display names or actual names from profile, or default to customer name stored recursively)
      const profileId = order.customer_id || order.client_id || order.buyer_id;
      const profile = profileId ? profileMap.get(profileId) : null;
      const buyerName = profile 
        ? (profile.artistic_name || profile.display_name || profile.email || 'Anonymous') 
        : (order.customer_name || 'Anonymous / Legacy Customer');

      // Retrieve and resolve real beat titles strictly from relational data
      let finalBeatTitle = 'Beat não encontrado';
      const orderIdKey = order.id;
      
      const lookupKey = orderIdKey ? String(orderIdKey).trim().toLowerCase() : '';
      const relatedItems = lookupKey ? (orderItemsMap[lookupKey] || []) : [];
      
      console.log(
        'NORMALIZED LOOKUP:',
        lookupKey
      );
      console.log(
        'MATCH TEST:',
        order.id,
        orderItemsMap[lookupKey]
      );

      const uniqueBeatIds = new Set<string>();
      relatedItems.forEach((item: any) => {
        if (item.beat_id !== undefined && item.beat_id !== null) {
          const rawIdStr = String(item.beat_id).trim().toLowerCase();
          uniqueBeatIds.add(rawIdStr);
          uniqueBeatIds.add(String(normalizeBeatId(item.beat_id)));
        }
      });

      const itemTitles: string[] = [];
      uniqueBeatIds.forEach((bIdStr: string) => {
        console.log(
          'LOOKUP TEST:',
          bIdStr,
          beatMap.get(bIdStr)
        );

        const b = beatMap.get(bIdStr) || beatMap.get(Number(bIdStr)) || beatMap.get(String(bIdStr));
        if (b && b.title && !itemTitles.includes(b.title)) {
          itemTitles.push(b.title);
        }
      });

      if (itemTitles.length > 0) {
        finalBeatTitle = itemTitles.join(', ');
      }

      resolvedTitles.push({ order_id: order.id, titles: finalBeatTitle });

      // Safe price / amount mapping (handling both "amount" and "price" or "total_amount")
      const finalPrice = order.amount !== undefined && order.amount !== null 
        ? order.amount 
        : (order.price !== undefined && order.price !== null 
          ? order.price 
          : (order.total_amount !== undefined && order.total_amount !== null ? order.total_amount : 0));

      // Check for locally confirmed/cached status to prevent stale re-fetch overwrite
      const cachedStatus = typeof window !== 'undefined' ? sessionStorage.getItem(`order_status_${order.id}`) : null;
      const finalStatus = cachedStatus || status;

      return {
        ...order,
        id: order.id || 'legacy_' + Math.random().toString(36).substring(2, 9),
        status: finalStatus,
        price: finalPrice,
        beats: { title: finalBeatTitle },
        resolvedTitles: itemTitles,
        resolvedBeatTitles: itemTitles,
        relatedItems,
        profiles: { full_name: buyerName },
        created_at: order.created_at || order.timestamp || new Date().toISOString()
      };
    });

    console.log('BEAT LOOKUPS:', resolvedTitles);

    // Sort chronologically (newest first) but preserve ALL records (no range, limit or slice)
    const sortedOrders = normalizedOrders.sort((a, b) => {
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });

    console.log('FINAL STABILIZED COMPATIBLE ORDERS:', sortedOrders);
    console.log('RAW ORDERS:', sortedOrders);
    const fetchedOrders = sortedOrders;
    console.log(
      'REFETCHED ORDERS:',
      fetchedOrders
    );
    setOrders(fetchedOrders);
    setOrderItems(orderItems);
    setBeats(beats);
    setOrderItemsMap(orderItemsMap);
    setBeatMap(beatMap);
  }

  async function addPendingEarningsToProducer(producerId: string, rawAmount: number) {
    if (!supabase || !producerId) return;
    const earnedAmount = Number(rawAmount) * 0.9;
    console.log(`[PAYOUT ENGINE] Calculating earnings for producer ${producerId} on amount ${rawAmount}. Commissioned: ${earnedAmount}`);
    
    try {
      // 1. Ensure wallet exists in 'wallets' table
      const { data: walletData, error: walletFetchError } = await supabase
        .from('wallets')
        .select('*')
        .eq('producer_id', producerId)
        .single();
        
      if (!walletData || walletFetchError) {
        console.log(`[PAYOUT ENGINE] Creating wallet for producer ${producerId}...`);
        await supabase.from('wallets').insert({
          producer_id: producerId,
          available_balance: 0,
          pending_balance: earnedAmount,
          total_earned: earnedAmount,
          total_withdrawn: 0
        });
      } else {
        console.log(`[PAYOUT ENGINE] Updating wallet for producer ${producerId}...`);
        await supabase
          .from('wallets')
          .update({
            pending_balance: Number(walletData.pending_balance || 0) + earnedAmount,
            total_earned: Number(walletData.total_earned || 0) + earnedAmount
          })
          .eq('producer_id', producerId);
      }

      // 2. Update 'profiles' table to keep wallet_pending_balance and wallet_total_earned in sync
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', producerId)
        .single();

      if (profileData) {
        console.log(`[PAYOUT ENGINE] Updating profile columns for producer ${producerId}...`);
        await supabase
          .from('profiles')
          .update({
            wallet_pending_balance: Number(profileData.wallet_pending_balance || 0) + earnedAmount,
            wallet_total_earned: Number(profileData.wallet_total_earned || 0) + earnedAmount,
            wallet_balance: Number(profileData.wallet_balance || 0) + earnedAmount
          })
          .eq('id', producerId);
      }

      // 3. Insert transaction into 'wallet_transactions'
      console.log(`[PAYOUT ENGINE] Creating ledger transaction...`);
      await supabase.from('wallet_transactions').insert({
        producer_id: producerId,
        amount: rawAmount,
        producer_amount: earnedAmount,
        platform_amount: rawAmount - earnedAmount,
        transaction_type: 'sale',
        status: 'completed'
      });
      console.log(`[PAYOUT ENGINE] Successfully processed pending earnings for producer ${producerId}!`);
    } catch (err) {
      console.error("[PAYOUT ENGINE] Exception in addPendingEarningsToProducer workflow:", err);
    }
  }

  async function confirmOrder(order: any) {
    if (!supabase) return;
    
    console.log('CONFIRM CLICKED', order.id);

    try {
      // STEP 1: FIRST update the orders table
      console.log('UPDATING ORDER STATUS:', order.id);
      const updateResponse = await supabase.from('orders').update({ status: 'paid' }).eq('id', order.id);
      console.log('ORDER UPDATE RESPONSE:', updateResponse);

      if (updateResponse.error) {
        console.error("Error updating order status:", updateResponse.error);
        alert("Erro ao atualizar estado do pedido: " + updateResponse.error.message);
        return;
      }

      // STEP 2: Fetch the updated order
      const { data: refreshedOrder, error: fetchError } = await supabase
        .from('orders')
        .select('*')
        .eq('id', order.id)
        .single();
        
      console.log('FETCHED UPDATED ORDER:', refreshedOrder);
      console.log('FETCH ERROR:', fetchError);
      console.log('ORDER STATUS UPDATED FIRST');

      const confirmedOrder = refreshedOrder || { ...order, status: 'paid' };

      if (typeof window !== 'undefined') {
        sessionStorage.setItem(`order_status_${order.id}`, 'paid');
      }

      console.log('CONFIRMED ORDER:', confirmedOrder);

      // STEP 3: ONLY AFTER SUCCESS: run downstream operations
      try {
        console.log('[PAYOUT ENGINE] Initiating wallet pending earnings distribution...');
        // 1. Fetch order_items for the order
        const { data: fetchedOrderItems, error: itemsError } = await supabase
          .from('order_items')
          .select('*')
          .eq('order_id', order.id);

        let orderItems = fetchedOrderItems || [];

        // Legacy/Direct order support fallback
        if (orderItems.length === 0 && order.beat_id) {
          orderItems = [{
            beat_id: normalizeBeatId(order.beat_id),
            producer_id: order.producer_id || null,
            price: Number(order.price || order.amount || order.total_amount || 0)
          }];
        }

        console.log('ORDER ITEMS:', orderItems);

        // 2. Fetch producer_id from related beats if not present
        const producerIds: string[] = [];
        const producerEarningsMap: Record<string, number> = {};

        for (const item of orderItems) {
          let producerId = item.producer_id;
          if (!producerId && item.beat_id) {
            try {
              const { data: beatData } = await supabase
                .from('beats')
                .select('producer_id')
                .eq('id', item.beat_id)
                .single();
              if (beatData) {
                producerId = beatData.producer_id;
              }
            } catch (e) {
              console.error("Error fetching producer ID from beat:", e);
            }
          }

          if (producerId) {
            if (!producerIds.includes(producerId)) {
              producerIds.push(producerId);
            }
            const itemPrice = Number(item.price || 0);
            // Exclude platform commission - 10% commission means producer gets 90%
            const earned = itemPrice * 0.9;
            producerEarningsMap[producerId] = (producerEarningsMap[producerId] || 0) + earned;
          }
        }

        console.log('PRODUCER IDs:', producerIds);

        // 3. Update profiles and wallets
        for (const producerId of producerIds) {
          const producerAmount = producerEarningsMap[producerId] || 0;
          console.log('PRODUCER EARNINGS:', producerAmount);

          // Fetch current profile balances safely
          const { data: profileData } = await supabase
            .from('profiles')
            .select('wallet_pending_balance, wallet_available_balance, wallet_total_earned, wallet_balance')
            .eq('id', producerId)
            .single();

          const currentPendingBalance = Number(profileData?.wallet_pending_balance || 0);
          const currentAvailableBalance = Number(profileData?.wallet_available_balance || 0);
          const currentTotalEarned = Number(profileData?.wallet_total_earned || 0);
          const currentWalletBalance = Number(profileData?.wallet_balance || 0);

          // REQUIRED UPDATE
          const response = await supabase
            .from('profiles')
            .update({
              wallet_pending_balance: currentPendingBalance + producerAmount,
              wallet_available_balance: currentAvailableBalance + producerAmount,
              wallet_total_earned: currentTotalEarned + producerAmount,
              wallet_balance: currentWalletBalance + producerAmount
            })
            .eq('id', producerId);

          console.log('PENDING BALANCE UPDATE RESPONSE:', response);

          // Send notification to the producer of the beat purchased
          try {
            await supabase.from('notifications').insert([
              {
                user_id: producerId,
                type: 'purchase',
                title: 'Nova Venda Realizada! 💰',
                message: `Parabéns! Realizaste uma nova venda no valor líquido de ${producerAmount.toLocaleString('pt-AO')} Kz.`,
                read: false,
                created_at: new Date().toISOString()
              }
            ]);
            console.log('[NOTIFY SELLER] Dispatched purchase notification to producer:', producerId);
          } catch (notifError) {
            console.error('[NOTIFY SELLER] Error notifying producer of sale:', notifError);
          }

          // IMMEDIATELY RE-FETCH PRODUCER PROFILE
          const { data: refreshedProfile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', producerId)
            .single();

          console.log('UPDATED PRODUCER PROFILE:', refreshedProfile);

          // Keep wallets & ledger transactions synced
          try {
            const { data: walletData } = await supabase
              .from('wallets')
              .select('*')
              .eq('producer_id', producerId)
              .single();

            if (walletData) {
              await supabase
                .from('wallets')
                .update({
                  pending_balance: Number(walletData.pending_balance || 0) + producerAmount,
                  available_balance: Number(walletData.available_balance || 0) + producerAmount,
                  total_earned: Number(walletData.total_earned || 0) + producerAmount
                })
                .eq('producer_id', producerId);
            } else {
              await supabase.from('wallets').insert({
                producer_id: producerId,
                available_balance: producerAmount,
                pending_balance: producerAmount,
                total_earned: producerAmount,
                total_withdrawn: 0
              });
            }

            await supabase.from('wallet_transactions').insert({
              producer_id: producerId,
              amount: producerAmount / 0.9,
              producer_amount: producerAmount,
              platform_amount: (producerAmount / 0.9) - producerAmount,
              transaction_type: 'sale',
              status: 'completed'
            });
          } catch (walletSyncError) {
            console.error("Wallet synced error omitted:", walletSyncError);
          }
        }
      } catch (payoutErr) {
        console.error("Failed to distribute pending payout earnings:", payoutErr);
      }

      console.log('ACTIVATING LICENSE...');
      let licenseResponse: any = null;

      // 2. Unlock or create purchased_beats records for all items in this order
      if (order.beat_id) {
        // It's a single beat order
        const existingResponse = await supabase
          .from('purchased_beats')
          .select('*')
          .eq('order_id', order.id)
          .eq('beat_id', order.beat_id);

        const existingList = existingResponse.data || [];
        const existing = existingList.length > 0 ? existingList[0] : null;

        let licenseId = 1;
        if (order.license_type === 'premium') licenseId = 2;
        if (order.license_type === 'exclusive') licenseId = 3;

        if (!existing) {
          const payload = {
            customer_id: order.customer_id,
            beat_id: order.beat_id,
            order_id: order.id,
            license_id: licenseId
          };
          console.log('PURCHASED BEAT PAYLOAD:', payload);
          licenseResponse = await supabase.from('purchased_beats').insert(payload);
          if (licenseResponse.error) {
            console.error("Error inserting purchased_beats:", licenseResponse.error);
          }
        } else {
          const payload = {
            license_id: licenseId
          };
          console.log('PURCHASED BEAT PAYLOAD (UPDATE):', payload);
          licenseResponse = await supabase.from('purchased_beats')
            .update(payload)
            .eq('id', existing.id);
        }
      } else {
        // It's a Cart order
        const orderItemsResponse = await supabase
          .from('order_items')
          .select('*')
          .eq('order_id', order.id);

        const fetchedOrderItems = orderItemsResponse.data || [];
        const results = [];

        if (fetchedOrderItems && fetchedOrderItems.length > 0) {
          for (const item of fetchedOrderItems) {
            const existingResponse = await supabase
              .from('purchased_beats')
              .select('*')
              .eq('order_id', order.id)
              .eq('beat_id', item.beat_id);

            const existingList = existingResponse.data || [];
            const existing = existingList.length > 0 ? existingList[0] : null;

            const licenseIdIdx = Number(item.license_id) || 1;

            if (!existing) {
              const payload = {
                customer_id: order.customer_id,
                beat_id: item.beat_id,
                order_id: order.id,
                license_id: licenseIdIdx
              };
              console.log('PURCHASED BEAT PAYLOAD (CART ITEM):', payload);
              const res = await supabase.from('purchased_beats').insert(payload);
              results.push(res);
              if (res.error) console.error("Error inserting cart item raw access:", res.error);
            } else {
              const payload = {
                license_id: licenseIdIdx
              };
              console.log('PURCHASED BEAT PAYLOAD (CART ITEM UPDATE):', payload);
              const res = await supabase.from('purchased_beats')
                .update(payload)
                .eq('id', existing.id);
              results.push(res);
            }
          }
        }
        licenseResponse = results;
      }

      console.log('LICENSE ACTIVATION RESPONSE:', licenseResponse);

      console.log('CREATING NOTIFICATION...');
      const buyerId = order.customer_id || order.client_id || order.buyer_id;
      let notificationResponse: any = null;

      if (buyerId) {
        // Check for existing notification
        const { data: existingNotifications } = await supabase
          .from('notifications')
          .select('id')
          .eq('user_id', buyerId)
          .eq('order_id', order.id)
          .eq('type', 'purchase_confirmed')
          .limit(1);

        if (!existingNotifications || existingNotifications.length === 0) {
          notificationResponse = await supabase.from('notifications').insert([
            {
              user_id: buyerId,
              order_id: order.id,
              type: 'purchase_confirmed',
              title: 'Pagamento Confirmado',
              message: 'Seu pagamento foi confirmado.\nA sua licença já está disponível em "Licenças Ativas".',
              read: false,
              created_at: new Date().toISOString()
            }
          ]);
          if (notificationResponse.error) {
            console.error("Error inserting notification:", notificationResponse.error);
          } else {
            console.log("Notification created successfully for buyerId:", buyerId);
          }
        } else {
          console.log("Notification already exists for order", order.id, ", skipping.");
        }
      } else {
        console.warn("No buyerId found to notify for order:", order);
      }
      
      console.log('NOTIFICATION RESPONSE:', notificationResponse);
      console.log('CONFIRM FLOW COMPLETE');

      // Update the local orders state in-memory immediately
      setOrders(prev =>
        prev.map(o =>
          o.id === order.id
            ? { ...o, status: 'paid' }
            : o
        )
      );

      // Trigger instant update of financial metrics in the dashboard
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('financialMetricsChanged'));
        if ('BroadcastChannel' in window) {
          try {
            const bc = new BroadcastChannel('financial_updates');
            bc.postMessage('refresh');
            bc.close();
            console.log('[REALTIME] Broadcasted financial_updates refresh event');
          } catch (err) {
            console.error('[REALTIME] Error dispatching custom broadcast:', err);
          }
        }
      }

      alert("Pagamento confirmado com sucesso!");
      fetchOrders();

    } catch (err: any) {
      console.error("Error during confirmOrder flow execution:", err);
      alert("Erro na execução do fluxo de confirmação: " + err.message);
    }
  }

  async function rejectOrder(order: any) {
    if (!supabase) return;
    
    const { data: updatedData, error: updateError } = await supabase.from('orders').update({ status: 'suspicious' }).eq('id', order.id).select();
    if (updateError) {
      console.error("Error updating order status:", updateError);
      alert("Erro ao rejeitar o pedido: " + updateError.message);
      return;
    }

    const updatedOrder = updatedData && updatedData.length > 0 ? updatedData[0] : { ...order, status: 'suspicious' };
    console.log(
      'UPDATED ORDER STATUS:',
      updatedOrder
    );

    if (typeof window !== 'undefined') {
      sessionStorage.setItem(`order_status_${order.id}`, 'suspicious');
    }
    
    // Update the local orders state in-memory immediately
    setOrders(prev =>
      prev.map(o =>
        o.id === order.id
          ? { ...o, status: 'suspicious' }
          : o
      )
    );

    alert("Pagamento rejeitado/marcado como suspeito!");
    fetchOrders();
  }

  const filteredOrders = orders.filter(order => {
    if (statusFilter === 'all') return true;
    return order.status === statusFilter;
  });

  console.log('ORDERS:', orders);

  console.log('ORDER ITEMS:', orderItems);

  console.log('BEATS:', beats);

  console.log(
    'ORDER ITEM MAP:',
    orderItemsMap
  );

  console.log(
    'BEAT MAP:',
    beatMap
  );

  console.log('RENDERED ORDERS:', orders);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Subheader Title */}
      <div>
        <h2 className="text-xl font-black uppercase italic tracking-tight text-white">
          Gestão de Encomendas (Orders)
        </h2>
        <p className="text-xs text-neutral-400 font-medium">Controlo, validação e auditoria de recibos e pagamentos de licenças de beats.</p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1 rounded-xl bg-black border border-white/[0.04] w-fit">
        {['all', 'pending', 'waiting_confirmation', 'paid', 'suspicious', 'expired', 'null'].map(status => (
          <button
            key={status}
            onClick={() => setStatusFilter(status)}
            className={`px-3 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all duration-300 cursor-pointer ${
              statusFilter === status
                ? 'bg-[#5865F2]/10 border border-[#5865F2]/30 text-white shadow-xl shadow-[#5865F2]/5'
                : 'text-neutral-400 hover:bg-white/[0.03] hover:text-white border border-transparent'
            }`}
          >
            {status.replace('_', ' ')}
          </button>
        ))}
      </div>

      {filteredOrders.length === 0 ? (
        <div className="bg-black/40 border border-white/[0.04] rounded-2xl p-12 text-center text-neutral-400">
          Nenhum pedido registado com o estado "{statusFilter.replace('_', ' ')}".
        </div>
      ) : (
        <div className="bg-[#050505] border border-white/[0.04] rounded-2xl overflow-hidden shadow-2xl relative">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-[#09090C]/80 border-b border-white/[0.04] text-neutral-500 text-[10px] uppercase tracking-widest font-black font-mono">
                <tr>
                  <th className="p-5 pl-6">ID</th>
                  <th className="p-5">Beat</th>
                  <th className="p-5">Customer</th>
                  <th className="p-5">Price</th>
                  <th className="p-5">Status</th>
                  <th className="p-5 text-right pr-6">Ações</th>
                </tr>
              </thead>
              <tbody className="text-xs font-semibold divide-y divide-white/[0.02]">
                {filteredOrders.map(order => {
                  console.log(
                    'FINAL RENDER STATUS:',
                    order.id,
                    order.status
                  );

                  console.log(
                    'LIVE ORDER ID:',
                    order.id
                  );

                  console.log(
                    'LIVE ORDER ITEMS:',
                    orderItems
                  );

                  console.log(
                    'LIVE MAP OBJECT:',
                    orderItemsMap
                  );

                  const lookupKey =
                    String(order.id).trim().toLowerCase();

                  console.log(
                    'LIVE LOOKUP KEY:',
                    lookupKey
                  );

                  console.log(
                    'LIVE LOOKUP RESULT:',
                    orderItemsMap[lookupKey]
                  );

                  return (
                    <tr key={order.id} className="hover:bg-white/[0.015] transition-colors border-b border-white/[0.02] last:border-0">
                      <td className="p-5 pl-6 font-mono text-xs text-neutral-500">{String(order.id || '').substring(0, 8)}</td>
                      <td className="p-5 font-bold text-white uppercase italic tracking-tight">
                        {(() => {
                          const relatedItems = order.relatedItems || [];
                          const resolvedTitles = order.resolvedTitles || [];
                          console.log(
                            'MATCH TEST:',
                            {
                              orderId: order.id,
                              relatedItems,
                              beatIds: relatedItems?.map((i: any) => i.beat_id),
                              resolvedTitles
                            }
                          );
                          console.log(
                            'FINAL RENDER TITLES:',
                            order.id,
                            resolvedTitles
                          );
                          return resolvedTitles.length > 0 ? resolvedTitles.join(', ') : 'Beat não encontrado';
                        })()}
                      </td>
                      <td className="p-5 text-neutral-300">{order.profiles?.full_name || 'Anonymous'}</td>
                      <td className="p-5 text-[#5865F2] font-mono font-black text-xs">{order.price || order.total_amount || 0} Kz</td>
                      <td className="p-5">
                        <span className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border font-mono ${
                          order.status === 'paid' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 shadow-lg shadow-emerald-500/5' : 
                          order.status === 'waiting_confirmation' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20 shadow-lg shadow-amber-500/5' : 
                          order.status === 'pending' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' : 
                          order.status === 'suspicious' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' :
                          order.status === 'expired' ? 'bg-white/[0.03] text-neutral-400 border-white/[0.06]' :
                          order.status === 'null' ? 'bg-white/[0.03] text-neutral-400 border-white/[0.06]' :
                          'bg-white/[0.03] text-neutral-400 border-white/[0.06]'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="p-5 text-right pr-6">
                        {['pending', 'waiting_confirmation'].includes(order.status) && (
                          <div className="flex items-center justify-end gap-2 text-neutral-200">
                            <button 
                              onClick={() => confirmOrder(order)} 
                              className="bg-emerald-600 hover:bg-emerald-500 text-white font-black px-3.5 py-2 rounded-xl text-[10px] uppercase tracking-wider transition-all duration-300 cursor-pointer shadow-lg shadow-emerald-600/10"
                            >
                              Confirmar
                            </button>
                            <button 
                              onClick={() => rejectOrder(order)} 
                              className="bg-rose-600 hover:bg-rose-500 text-white font-black px-3.5 py-2 rounded-xl text-[10px] uppercase tracking-wider transition-all duration-300 cursor-pointer shadow-lg shadow-rose-600/10"
                            >
                              Rejeitar
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

