
import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Check, 
  X, 
  FileText, 
  HelpCircle, 
  ArrowLeft,
  Download,
  ShoppingCart,
  MessageCircle,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';

interface LicensingPageProps {
  onBack: () => void;
  onOpenAuth: (mode: 'login' | 'signup') => void;
}

export default function LicensingPage({ onBack, onOpenAuth }: LicensingPageProps) {
  const { user } = useAuth();
  const [showAuthAlert, setShowAuthAlert] = useState(false);

  const licenseTiers = [
    {
      name: 'Básica',
      price: '25.000 Kz',
      icon: FileText,
      color: 'blue',
      features: [
        { label: 'Formato MP3 (320kbps)', included: true },
        { label: 'Até 5.000 Streams', included: true },
        { label: 'Uso não lucrativo', included: true },
        { label: 'Direitos de Rádio', included: false },
        { label: 'Arquivos Stems/WAV', included: false },
        { label: 'Direitos Exclusivos', included: false },
      ]
    },
    {
      name: 'Premium',
      price: '75.000 Kz',
      icon: ShieldCheck,
      color: 'amber',
      recommended: true,
      features: [
        { label: 'Formato WAV + MP3', included: true },
        { label: 'Até 50.000 Streams', included: true },
        { label: 'Uso para Videoclipe', included: true },
        { label: 'Direitos de Rádio', included: true },
        { label: 'Arquivos Stems separated', included: false },
        { label: 'Direitos Exclusivos', included: false },
      ]
    },
    {
      name: 'Exclusiva',
      price: '250.000 Kz',
      icon: Check,
      color: 'purple',
      features: [
        { label: 'Arquivos de Produção (Stems)', included: true },
        { label: 'Streams Ilimitados', included: true },
        { label: 'Propriedade Total', included: true },
        { label: 'Contrato Vitalício', included: true },
        { label: 'Removido da Loja', included: true },
        { label: '100% dos Royalties (aprox.)', included: true },
      ]
    }
  ];

  const faqs = [
    {
      q: 'Posso usar o beat no YouTube?',
      a: 'Sim, todas as licenças permitem o uso no YouTube, respeitando os limites de visualizações e monetização de cada nível.'
    },
    {
      q: 'O que são Stems?',
      a: 'Stems são as pistas individuais do beat (apenas o kick, apenas o clap, etc.), essenciais para uma mixagem profissional na sua música.'
    },
    {
      q: 'Como recebo os ficheiros?',
      a: 'Imediatamente após a confirmação do pagamento, os links para download ficam disponíveis na sua conta e são enviados por email.'
    }
  ];

  const handleRestrictedAction = (actionName: string) => {
    if (!user) {
      setShowAuthAlert(true);
      setTimeout(() => setShowAuthAlert(false), 4000);
      return;
    }
    // Perform real action here if logged in
    alert(`Acção "${actionName}" simulada com sucesso!`);
  };

  return (
    <div className="min-h-screen bg-[#000000] pb-32 animate-in fade-in duration-700">
      {/* Auth Alert Overlay */}
      <AnimatePresence>
        {showAuthAlert && (
          <motion.div 
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-[110] w-full max-w-md px-4"
          >
            <div className="bg-red-500 text-white rounded-2xl p-4 shadow-2xl flex items-center gap-4 border border-red-400">
              <div className="bg-white/20 p-2 rounded-xl">
                <AlertCircle size={20} />
              </div>
              <div className="flex-grow">
                <p className="text-xs font-black uppercase tracking-widest">Acesso Restrito</p>
                <p className="text-[10px] font-bold opacity-90">Faça login ou crie uma conta para continuar.</p>
              </div>
              <button 
                onClick={() => onOpenAuth('login')}
                className="bg-white text-red-500 px-4 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-100 transition-colors"
              >
                Entrar
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <header className="py-20 flex flex-col md:flex-row justify-between items-start md:items-end gap-8">
          <div>
            {!user && (
              <button 
                onClick={onBack}
                className="flex items-center gap-2 text-gray-500 hover:text-white transition-colors mb-6 group"
              >
                <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
                <span className="text-[10px] font-black uppercase tracking-widest">Voltar ao Início</span>
              </button>
            )}
            <h1 className="text-5xl md:text-7xl font-black text-white italic tracking-tighter uppercase leading-none">
              Contratos & <span className="text-blue-500 block">Licenciamento</span>
            </h1>
            <p className="text-gray-500 font-bold uppercase tracking-widest text-xs mt-6 max-w-2xl leading-loose">
              Entenda exactamente o que podes e não podes fazer com os teus beats. Oferecemos transparência total para artistas e produtores.
            </p>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={() => handleRestrictedAction('Baixar Modelo PDF')}
              className="px-6 py-4 bg-white/5 border border-white/10 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-white/10 transition-all flex items-center gap-3"
            >
              <Download size={16} className="text-blue-500" />
              Baixar Modelo PDF
            </button>
          </div>
        </header>

        {/* Pricing Table */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 py-12">
          {licenseTiers.map((tier, i) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`relative bg-white/[0.02] border border-white/5 rounded-[2.5rem] p-8 flex flex-col h-full ${
                tier.recommended ? 'ring-2 ring-blue-500/50 shadow-2xl shadow-blue-500/10' : ''
              }`}
            >
              {tier.recommended && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-500 text-black px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-lg">
                  Mais Popular
                </div>
              )}

              <div className="mb-8">
                <div className={`w-12 h-12 rounded-2xl bg-${tier.color}-500/10 text-${tier.color}-500 flex items-center justify-center mb-6`}>
                  <tier.icon size={24} />
                </div>
                <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter mb-2">{tier.name}</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black text-white">{tier.price}</span>
                  <span className="text-[10px] text-gray-600 font-black uppercase tracking-widest">/ por beat</span>
                </div>
              </div>

              <div className="space-y-4 flex-grow mb-12">
                {tier.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <div className={`mt-1 p-0.5 rounded-full ${feature.included ? 'text-blue-500' : 'text-gray-800'}`}>
                      {feature.included ? <Check size={12} /> : <X size={12} />}
                    </div>
                    <span className={`text-xs font-bold uppercase tracking-widest ${feature.included ? 'text-gray-300' : 'text-gray-600 line-through'}`}>
                      {feature.label}
                    </span>
                  </div>
                ))}
              </div>

              <button 
                onClick={() => handleRestrictedAction(`Comprar ${tier.name}`)}
                className={`w-full py-5 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 ${
                  tier.recommended 
                  ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-xl shadow-blue-600/20 active:scale-95' 
                  : 'bg-white/5 border border-white/10 text-white hover:bg-white/10 active:scale-95'
                }`}
              >
                <ShoppingCart size={16} />
                Comprar Licença
              </button>
            </motion.div>
          ))}
        </div>

        {/* Footer Info Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-20 pt-20 border-t border-white/5">
          {/* FAQ */}
          <div className="space-y-12">
            <div>
              <h2 className="text-4xl font-black text-white italic uppercase tracking-tighter mb-2">Perguntas Frequentes</h2>
              <p className="text-gray-600 font-bold uppercase tracking-widest text-[10px]">As dúvidas mais comuns sobre licenças.</p>
            </div>
            
            <div className="space-y-6">
              {faqs.map((faq, idx) => (
                <div key={idx} className="bg-white/5 border border-white/10 p-8 rounded-3xl group hover:border-blue-500/30 transition-all">
                  <div className="flex items-center gap-3 mb-4">
                    <HelpCircle size={18} className="text-blue-500" />
                    <h4 className="text-sm font-black text-white uppercase tracking-widest">{faq.q}</h4>
                  </div>
                  <p className="text-gray-400 text-xs font-bold leading-relaxed">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Support / Contact */}
          <div className="space-y-12 h-full">
             <div className="bg-gradient-to-br from-blue-600/5 to-purple-600/5 border border-white/5 rounded-[3rem] p-12 flex flex-col items-center text-center h-full justify-center">
                <div className="w-20 h-20 rounded-3xl bg-blue-600/10 text-blue-500 flex items-center justify-center mb-8">
                  <MessageCircle size={40} />
                </div>
                <h3 className="text-3xl font-black text-white italic uppercase tracking-tighter mb-4">Ainda com dúvidas?</h3>
                <p className="text-gray-500 font-bold uppercase tracking-widest text-[10px] mb-8 max-w-sm leading-loose">
                  Nossa equipe jurídica e de suporte está pronta para te explicar cada detalhe dos nossos contratos.
                </p>
                <button 
                  onClick={() => handleRestrictedAction('Enviar Mensagem')}
                  className="bg-white text-black px-10 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-500 hover:text-white transition-all shadow-2xl active:scale-95"
                >
                  Contactar Suporte
                </button>
             </div>
          </div>
        </div>

        {/* Global Terms Summary */}
        <div className="mt-32 p-12 bg-white/[0.01] border border-white/5 rounded-[3rem] text-center">
            <h3 className="text-gray-600 font-black text-[10px] uppercase tracking-[0.4em] mb-4">Termos Gerais de Uso</h3>
            <p className="text-gray-500 text-[11px] font-bold max-w-3xl mx-auto leading-loose italic">
              * Todas as licenças são não-exclusivas por padrão, excepto a licença Exclusiva. O produtor mantém os direitos de autor (Copyright) originais da composição, enquanto o artista recebe os direitos de gravação (Master) sobre a sua nova obra musical conforme os limites adquiridos. Preços em Kwanza (Kz) sujeitos a alteração por parte de cada produtor.
            </p>
        </div>
      </div>
    </div>
  );
}
