import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  ShoppingBag, 
  Upload, 
  Zap, 
  Flame, 
  UserPlus, 
  Heart, 
  MessageSquare, 
  CheckCircle, 
  User, 
  CreditCard, 
  Shield, 
  X,
  Trash2,
  Check,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Layers,
  CheckCheck,
  Inbox,
  TrendingUp,
  Award,
  Radio,
  Share2,
  FolderDot,
  ArrowUpRight,
  CornerDownRight,
  Info
} from 'lucide-react';
import { getSupabase, getPublicUrl } from '../lib/supabase';
import { Notification } from '../types';
import InstagramLoader from './InstagramLoader';
import { playSubtleNotificationSound } from '../lib/notifications';
import NotificationDetailModal from './NotificationDetailModal';

// Helper functions for robust, real-route resolution on notifications
function slugify(text: string): string {
  if (!text) return '';
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD') // remove accents
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 -]/g, '') // remove invalid chars
    .replace(/\s+/g, '-') // collapse whitespace and replace by -
    .replace(/-+/g, '-'); // collapse dashes
}

function extractQuotedTitle(message: string): string {
  if (!message) return '';
  // Try to find text between escaped double quotes \"...\"
  let match = message.match(/\\"[^\\]+\\"/);
  if (match) {
    return match[0].replace(/\\"/g, '');
  }
  // Match standard double quotes but exclude comments split by colon
  const mainPart = message.split(':')[0];
  match = mainPart.match(/"([^"]+)"/);
  if (match) {
    return match[1];
  }
  // Try single quotes '...'
  match = mainPart.match(/'([^']+)'/);
  if (match) {
    return match[1];
  }
  return '';
}

function translateNotificationType(type: string): string {
  const mapping: Record<string, string> = {
    purchase: 'COMPRA',
    purchase_confirmed: 'COMPRA',
    payment: 'COMPRA',
    withdrawal_approved: 'FINANCEIRO',
    withdrawal_rejected: 'FINANCEIRO',
    upload: 'NOVO BEAT',
    featured_beat: 'DESTAQUE',
    editor_pick: 'DESTAQUE',
    beat_trending: 'TENDÊNCIA',
    flash_sale: 'PROMOÇÃO',
    follower: 'SEGUIDOR',
    like: 'GOSTEI',
    comment: 'COMENTÁRIO',
    reply_comment: 'COMENTÁRIO',
    repost: 'REPOST',
    playlist_add: 'PLAYLIST',
    playlist_inclusion: 'PLAYLIST',
    verified: 'VERIFICADO',
    account: 'CONTA',
    account_updated: 'CONTA',
    security: 'SEGURANÇA',
    platform_update: 'PLATAFORMA',
  };
  return mapping[type] || type.replace('_', ' ').toUpperCase();
}

interface NotificationDropdownProps {
  onClose: () => void;
  onViewAll: () => void;
  onMarkRead?: () => void;
  onNavigateToDashboard?: () => void;
  notifications: Notification[];
  setNotifications: React.Dispatch<React.SetStateAction<Notification[]>>;
}

const NOTIFICATION_ICONS: Record<string, any> = {
  purchase: ShoppingBag,
  upload: Upload,
  flash_sale: Zap,
  featured: Flame,
  follower: UserPlus,
  like: Heart,
  comment: MessageSquare,
  reply_comment: CornerDownRight,
  playlist_add: FolderDot,
  repost: Share2,
  beat_trending: TrendingUp,
  editor_pick: Award,
  featured_beat: Sparkles,
  playlist_inclusion: Radio,
  verified: CheckCircle,
  account: User,
  account_updated: User,
  payment: CreditCard,
  withdrawal_approved: ArrowUpRight,
  withdrawal_rejected: X,
  security: Shield,
  platform_update: Info,
  purchase_confirmed: CheckCircle
};

const NOTIFICATION_COLORS: Record<string, string> = {
  purchase: 'text-blue-400 bg-blue-500/5 border-blue-500/10 shadow-[0_0_12px_rgba(59,130,246,0.08)]',
  upload: 'text-indigo-400 bg-indigo-500/5 border-indigo-500/10 shadow-[0_0_12px_rgba(99,102,241,0.08)]',
  flash_sale: 'text-sky-400 bg-sky-500/5 border-sky-500/10 shadow-[0_0_12px_rgba(56,189,248,0.08)]',
  featured: 'text-blue-300 bg-blue-500/5 border-blue-500/10 shadow-[0_0_12px_rgba(147,197,253,0.08)]',
  follower: 'text-indigo-300 bg-indigo-500/5 border-indigo-450/10 shadow-[0_0_12px_rgba(165,180,252,0.08)]',
  like: 'text-blue-400 bg-blue-500/5 border-blue-500/10 shadow-[0_0_12px_rgba(59,130,246,0.08)]',
  comment: 'text-slate-300 bg-slate-500/5 border-slate-400/10 shadow-[0_0_12px_rgba(203,213,225,0.08)]',
  reply_comment: 'text-slate-400 bg-slate-500/5 border-slate-500/10 shadow-[0_0_12px_rgba(148,163,184,0.08)]',
  playlist_add: 'text-indigo-400 bg-indigo-500/5 border-indigo-500/10 shadow-[0_0_12px_rgba(99,102,241,0.08)]',
  repost: 'text-sky-400 bg-sky-500/5 border-sky-500/10 shadow-[0_0_12px_rgba(56,189,248,0.08)]',
  beat_trending: 'text-indigo-400 bg-indigo-500/5 border-indigo-500/10 shadow-[0_0_12px_rgba(99,102,241,0.08)]',
  editor_pick: 'text-blue-400 bg-blue-500/5 border-blue-500/10 shadow-[0_0_12px_rgba(59,130,246,0.08)]',
  featured_beat: 'text-indigo-300 bg-indigo-500/5 border-indigo-500/10 shadow-[0_0_12px_rgba(165,180,252,0.08)]',
  playlist_inclusion: 'text-sky-300 bg-sky-500/5 border-sky-500/10 shadow-[0_0_12px_rgba(125,211,252,0.08)]',
  verified: 'text-blue-400 bg-blue-500/5 border-blue-500/10 shadow-[0_0_12px_rgba(59,130,246,0.08)]',
  account: 'text-slate-400 bg-slate-500/5 border-slate-500/10 shadow-[0_0_12px_rgba(156,163,175,0.08)]',
  account_updated: 'text-slate-400 bg-slate-500/5 border-slate-500/10 shadow-[0_0_12px_rgba(156,163,175,0.08)]',
  payment: 'text-blue-400 bg-blue-500/5 border-blue-500/10 shadow-[0_0_12px_rgba(59,130,246,0.08)]',
  withdrawal_approved: 'text-blue-400 bg-blue-500/5 border-blue-500/10 shadow-[0_0_12px_rgba(59,130,246,0.08)]',
  withdrawal_rejected: 'text-slate-500 bg-slate-500/5 border-slate-500/10 shadow-[0_0_12px_rgba(148,163,184,0.08)]',
  security: 'text-blue-500 bg-blue-500/10 border-blue-500/25 shadow-[0_0_12px_rgba(59,130,246,0.08)]',
  platform_update: 'text-indigo-400 bg-indigo-500/5 border-indigo-500/10 shadow-[0_0_12px_rgba(99,102,241,0.08)]',
  purchase_confirmed: 'text-blue-400 bg-blue-500/5 border-blue-500/10 shadow-[0_0_12px_rgba(59,130,246,0.08)]'
};

const getInitials = (message: string, title?: string) => {
  const cleanMessage = message || '';
  const cleanTitle = title || '';
  
  const userMatch = cleanMessage.match(/@(\w+)/) || cleanMessage.match(/^([a-zA-Z0-9_\s]{2,20})/);
  let name = userMatch ? userMatch[1].trim() : '';
  
  if (!name && cleanTitle) {
    name = cleanTitle.replace(/Novo|Novo\sComentário!|💬|❤️|💰|👥|💳|Seu|Sua/gi, '').trim();
  }
  
  if (!name || name.length < 2) return 'BT';
  
  const words = name.split(/\s+/);
  if (words.length > 1 && words[1][0]) {
    return (words[0][0] + words[1][0]).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
};

const formatRelativeTime = (timeString: string) => {
  try {
    const elapsedMs = Date.now() - new Date(timeString).getTime();
    const secs = Math.floor(elapsedMs / 1000);
    if (secs < 30) return 'Agora';
    if (secs < 60) return 'Instantes';
    const mins = Math.floor(secs / 60);
    if (mins < 60) return `${mins}m`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h`;
    const days = Math.floor(hrs / 24);
    if (days === 1) return 'Ontem';
    if (days < 7) return `${days}d`;
    return new Date(timeString).toLocaleDateString('pt-AO', { day: '2-digit', month: '2-digit' });
  } catch (e) {
    return 'Recente';
  }
};

const stripEmojis = (text: string): string => {
  if (!text) return '';
  return text
    .replace(/[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD00-\uDFFF]|\uD83F[\uDC00-\uDFFF]|[\u2600-\u27BF]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
};

const renderNotificationAvatar = (item: any, styleClass: string, Icon: any, size = "w-9 h-9", profilesMap: Record<string, any> = {}) => {
  const isSystemType = [
    'purchase',
    'purchase_confirmed',
    'payment',
    'withdrawal_approved',
    'withdrawal_rejected',
    'verified',
    'account',
    'account_updated',
    'security',
    'platform_update'
  ].includes(item.type);

  if (isSystemType) {
    // Elegant BATUKADA Official Logo / avatar
    return (
      <div className={`${size} rounded-full bg-gradient-to-br from-blue-600 via-indigo-650 to-slate-950 border border-blue-500/30 flex items-center justify-center shadow-[0_0_10px_rgba(59,130,246,0.25)] shrink-0 overflow-hidden relative transition-all duration-300 group-hover:border-blue-400 group-hover:shadow-[0_0_15px_rgba(59,130,246,0.4)]`}>
        <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.15)_0%,rgba(255,255,255,0)_50%)] opacity-60" />
        <svg className="w-5 h-5 text-white/40 absolute" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M6 12V16M9 9V19M12 5V21M15 8V16M18 11V13" strokeLinecap="round" />
        </svg>
        <span className="text-white font-black text-[10px] italic tracking-tight relative z-10 select-none">B</span>
      </div>
    );
  }

  let meta = item.metadata;
  if (typeof meta === 'string') {
    try {
      meta = JSON.parse(meta);
    } catch {
      meta = {};
    }
  }

  // Check if there is a bulk-resolved avatar url first!
  const fId = meta?.follower_id || meta?.sender_id || meta?.actor_id;
  let bulkAvatarUrl = null;

  if (fId && profilesMap[fId]?.avatar_url) {
    bulkAvatarUrl = profilesMap[fId].avatar_url;
    console.log('LIVE PROFILE AVATAR BY ID:', bulkAvatarUrl, 'for profile ID:', fId);
  }

  // Check if there is a real avatar/image
  const rawAvatarUrl = bulkAvatarUrl || meta?.sender_avatar || meta?.avatar_url || item.avatar_url;

  console.log('RAW AVATAR URL FOR BUZZIN:', rawAvatarUrl);
  console.log('FULL ITEM:', item);

  if (rawAvatarUrl) {
    console.log('USING IMAGE BRANCH');
    const finalAvatarUrl = rawAvatarUrl.startsWith('http') || rawAvatarUrl.startsWith('/') || rawAvatarUrl.startsWith('data:')
      ? rawAvatarUrl
      : getPublicUrl('avatars', rawAvatarUrl);

    if (bulkAvatarUrl) {
      console.log('LIVE PROFILE AVATAR:', finalAvatarUrl);
    } else {
      console.log('HISTORICAL METADATA AVATAR FALLBACK:', finalAvatarUrl);
    }
    console.log('[NOTIFICATIONS DROPDOWN AUDIT] Rendering real avatar URL:', finalAvatarUrl, 'for item:', item.id);
    console.log('RENDERING IMG:', finalAvatarUrl);
    console.log('SIZE CLASS:', size);

    return (
      <div className={`${size} rounded-full border border-blue-500/20 shadow-inner overflow-hidden shrink-0 transition-transform group-hover:scale-105 duration-200`}>
        <img
          src={finalAvatarUrl || undefined}
          alt="Avatar"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          onLoad={() => console.log('IMAGE LOADED:', finalAvatarUrl)}
          onError={() => console.log('IMAGE FAILED:', finalAvatarUrl)}
        />
      </div>
    );
  }

  // If music related and has a cover_url, show the cover image circular
  const rawCoverUrl = meta?.cover_url || item.cover_url;
  if (rawCoverUrl && ['upload', 'featured_beat', 'editor_pick', 'beat_trending', 'flash_sale', 'playlist_add', 'playlist_inclusion', 'like', 'comment', 'reply_comment', 'repost'].includes(item.type)) {
    const finalCoverUrl = rawCoverUrl.startsWith('http') || rawCoverUrl.startsWith('/') || rawCoverUrl.startsWith('data:')
      ? rawCoverUrl
      : getPublicUrl('beats', rawCoverUrl);

    return (
      <div className={`${size} rounded-full border border-blue-500/20 shadow-inner overflow-hidden shrink-0 transition-transform group-hover:scale-105 duration-200`}>
        <img
          src={finalCoverUrl || undefined}
          alt="Cover"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          onError={() => console.log('[NOTIFICATIONS DROPDOWN AUDIT] IMAGE LOAD FAILED', finalCoverUrl)}
        />
      </div>
    );
  }

  // Custom initials fallback avatar (clean, minimalist, dark/blue, perfectly circular, subtle blue/slate border)
  const cleanInitials = getInitials(item.message, item.title);
  console.log('USING FALLBACK BRANCH');
  return (
    <div className={`${size} rounded-full flex items-center justify-center border border-blue-500/25 bg-gradient-to-br from-[#0a0f1d] to-[#05070d] text-blue-400 font-extrabold text-[10px] tracking-wide shrink-0 shadow-sm transition-all duration-200 group-hover:border-blue-400/40 group-hover:text-blue-300`}>
      {cleanInitials}
    </div>
  );
};

export default function NotificationDropdown({ 
  onClose, 
  onViewAll, 
  onMarkRead, 
  onNavigateToDashboard, 
  notifications, 
  setNotifications 
}: NotificationDropdownProps) {
  if (typeof window !== 'undefined') {
    console.count('NotificationDropdown render');
  }
  const [loading, setLoading] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'unread' | 'social' | 'music' | 'finance' | 'system'>('all');
  const [groupSimilar, setGroupSimilar] = useState(true);
  const [selectedNotification, setSelectedNotification] = useState<any | null>(null);
  const [profilesMap, setProfilesMap] = useState<Record<string, { avatar_url?: string; username?: string; display_name?: string }>>({});
  const containerRef = useRef<HTMLDivElement>(null);
  const supabase = getSupabase();

  useEffect(() => {
    if (notifications && notifications.length > 0) {
      resolveRelatedProfiles(notifications);
    }
  }, [notifications]);

  const resolveRelatedProfiles = async (items: any[]) => {
    if (!supabase || !items || items.length === 0) return;

    const followerIds = new Set<string>();

    items.forEach(n => {
      let meta = n.metadata;
      if (typeof meta === 'string') {
        try {
          meta = JSON.parse(meta);
        } catch {
          meta = {};
        }
      }
      const fId = meta?.follower_id || meta?.sender_id || meta?.actor_id;
      if (fId) {
        followerIds.add(fId);
      }
    });

    const idList = Array.from(followerIds);

    if (idList.length === 0) return;

    try {
      console.log('[NOTIFICATIONS DROPDOWN AUDIT] Resolving related profiles strictly by ID. ID List:', idList);
      let fetchedProfiles: any[] = [];

      if (idList.length > 0) {
        idList.forEach(finalResolvedId => {
          console.log('PROFILE LOOKUP ID:', finalResolvedId);
          console.log('QUERYING PROFILE WITH:', finalResolvedId);
        });

        const { data: byId, error: errId } = await supabase
          .from('profiles')
          .select('id, username, avatar_url, artistic_name, display_name')
          .in('id', idList);
        if (!errId && byId) {
          fetchedProfiles = [...fetchedProfiles, ...byId];
          console.log('[NOTIFICATIONS DROPDOWN AUDIT] Fetched profiles by ID:', byId);
        } else if (errId) {
          console.error('[NOTIFICATIONS DROPDOWN AUDIT] Error fetching by ID:', errId);
        }
      }

      if (fetchedProfiles.length > 0) {
        const map: Record<string, { avatar_url?: string; username?: string; display_name?: string }> = {};
        fetchedProfiles.forEach(p => {
          if (p.id) {
            map[p.id] = { 
              avatar_url: p.avatar_url, 
              username: p.username,
              display_name: p.artistic_name || p.display_name || p.username
            };
          }
        });
        console.log('[NOTIFICATIONS DROPDOWN SIGNATURE] Resulting Profiles Map (Strict ID-only):', map);
        setProfilesMap(prev => ({ ...prev, ...map }));
      }
    } catch (err) {
      console.error('[NOTIFICATIONS DROPDOWN] Error resolving related profiles in bulk:', err);
    }
  };

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', handleEsc);

    return () => {
      document.body.style.overflow = 'unset';
      document.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  useEffect(() => {
    const autoMarkOnOpen = async () => {
      if (!supabase) return;
      const unreads = notifications.filter(n => n.read === false);
      console.log(`NOTIFICATIONS OPENED: dropdown, count: ${notifications.length}, unread: ${unreads.length}`);

      if (unreads.length > 0) {
        console.log(`MARKING NOTIFICATIONS AS READ: Auto-marking ${unreads.length} unread notifications as read upon dropdown opening`);
        setNotifications(prev => prev.map(n => ({ ...n, read: true }) as Notification));
        console.log('UNREAD NOTIFICATIONS AFTER UPDATE: 0');

        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (!user) return;

          const res = await fetch("/api/notifications/read-all", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ userId: user.id })
          });

          if (!res.ok) {
            const errInfo = await res.json().catch(() => ({}));
            console.error('[NOTIFICATIONS] Error auto-marking read on dropdown open via proxy:', errInfo.error || res.statusText);
            console.log(`NOTIFICATION UPDATE RESULT: error - ${errInfo.error || res.statusText}`);
          } else {
            const result = await res.json();
            console.log(`NOTIFICATION UPDATE RESULT: success, updated entries: ${result.updated}`);
            window.dispatchEvent(new Event('new_notification_received'));
            setTimeout(() => {
              onMarkRead?.();
            }, 100);
          }
        } catch (err) {
          console.error('[NOTIFICATIONS] Severe error in dropdown auto-mark read:', err);
          console.log(`NOTIFICATION UPDATE RESULT: failed - ${String(err)}`);
        }
      }
    };

    autoMarkOnOpen();
  }, [supabase, onClose, onMarkRead]);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const markAllAsRead = async () => {
    if (!supabase || isUpdating || loading) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setIsUpdating(true);
    setLoading(true);
    
    console.log(`MARKING NOTIFICATIONS AS READ: manually mark all of them as read`);
    // Clean, direct optimistic update (overwrites state fully, no recursive merges)
    setNotifications(prev => prev.map(n => ({ ...n, read: true } as any)));
    console.log('UNREAD NOTIFICATIONS AFTER UPDATE: 0');
    
    try {
      console.log("[NOTIFICATIONS] Mark all read execution on server proxy...");
      const res = await fetch("/api/notifications/read-all", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ userId: user.id })
      });

      if (!res.ok) {
        const errInfo = await res.json().catch(() => ({}));
        console.error('[NOTIFICATIONS] Error marking all read via proxy:', errInfo.error || res.statusText);
        console.log(`NOTIFICATION UPDATE RESULT: error - ${errInfo.error || res.statusText}`);
      } else {
        const result = await res.json();
        console.log(`NOTIFICATION UPDATE RESULT: success, updated entries: ${result.updated}`);
        // Trigger parent state list reload after a tiny delay so Postgres transaction fully commits
        setTimeout(() => {
          onMarkRead?.();
        }, 120);
      }
    } catch (err) {
      console.error('[NOTIFICATIONS] Crash exception on mark all read:', err);
      console.log(`NOTIFICATION UPDATE RESULT: failed - ${String(err)}`);
    } finally {
      setLoading(false);
      setIsUpdating(false);
    }
  };

  const handleMarkItemRead = async (id: string, ids?: string[]) => {
    if (!supabase || isUpdating) return;
    
    setIsUpdating(true);
    const idsToMark = ids && ids.length > 0 ? ids : [id];
    
    const remainingCount = notifications.filter(n => !idsToMark.includes(n.id) && n.read === false).length;
    console.log(`MARKING NOTIFICATIONS AS READ: marked single notification ID ${id}`);
    // clean optimistic update
    setNotifications(prev => prev.map(n => idsToMark.includes(n.id) ? { ...n, read: true } as any : n));
    console.log(`UNREAD NOTIFICATIONS AFTER UPDATE: ${remainingCount}`);
    
    try {
      console.log("[NOTIFICATIONS] Mark item read execute via proxy...", idsToMark);
      const res = await fetch("/api/notifications/read", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ ids: idsToMark })
      });

      if (!res.ok) {
        const errInfo = await res.json().catch(() => ({}));
        console.error('[NOTIFICATIONS] Fail marking item read via proxy:', errInfo.error || res.statusText);
        console.log(`NOTIFICATION UPDATE RESULT: error - ${errInfo.error || res.statusText}`);
      } else {
        const result = await res.json();
        console.log(`NOTIFICATION UPDATE RESULT: success, updated entries: ${result.updated || idsToMark.length}`);
        // Delay parent trigger so Postgres completes its update before fetch
        setTimeout(() => {
          onMarkRead?.();
        }, 120);
      }
    } catch (err) {
      console.error('[NOTIFICATIONS] Crash marking item read:', err);
      console.log(`NOTIFICATION UPDATE RESULT: failed - ${String(err)}`);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDeleteItem = async (e: React.MouseEvent, id: string, ids?: string[]) => {
    e.stopPropagation();
    e.preventDefault();
    if (!supabase) return;

    const idsToDelete = ids && ids.length > 0 ? ids : [id];
    setNotifications(prev => prev.filter(n => !idsToDelete.includes(n.id)));

    try {
      const res = await fetch("/api/notifications/delete", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ ids: idsToDelete })
      });
      if (!res.ok) {
        const errInfo = await res.json().catch(() => ({}));
        console.error('[NOTIFICATIONS] Delete notification items via proxy failed:', errInfo.error || res.statusText);
      }
    } catch (err) {
       console.error('[NOTIFICATIONS] Delete notification items failed:', err);
    }
  };

  const getFilteredNotifications = () => {
    switch (activeTab) {
      case 'unread':
        return notifications.filter(n => n.read === false);
      case 'social':
        return notifications.filter(n => ['follower', 'like', 'comment', 'reply_comment', 'repost', 'playlist_add'].includes(n.type));
      case 'music':
        return notifications.filter(n => ['beat_trending', 'editor_pick', 'featured_beat', 'playlist_inclusion', 'featured', 'upload', 'flash_sale'].includes(n.type));
      case 'finance':
        return notifications.filter(n => ['purchase', 'purchase_confirmed', 'payment', 'withdrawal_approved', 'withdrawal_rejected'].includes(n.type));
      case 'system':
        return notifications.filter(n => ['verified', 'account', 'account_updated', 'security', 'platform_update'].includes(n.type));
      default:
        return notifications;
    }
  };

  const getRenderableNotifications = () => {
    const list = getFilteredNotifications();
    if (!groupSimilar) return list.map(n => ({ ...n, uIds: [n.id], groupCount: 1 }));

    const result: any[] = [];
    const likesByBeat = new Map<string, any>();
    const systemFollowers: any[] = [];

    list.forEach(n => {
      if (n.type === 'like') {
        const titleMatch = n.message.match(/"([^"]+)"/);
        const beatTitle = titleMatch ? titleMatch[1] : '';
        const userPrefix = n.message.split(' ')[0] || '';

        if (beatTitle) {
          if (likesByBeat.has(beatTitle)) {
            const existing = likesByBeat.get(beatTitle);
            existing.groupCount += 1;
            existing.uIds.push(n.id);
            if (!existing.senders.includes(userPrefix) && userPrefix) {
              existing.senders.push(userPrefix);
            }
            if (!n.read) existing.read = false; 
          } else {
            const newItem = {
              ...n,
              uIds: [n.id],
              groupCount: 1,
              beatTitle,
              senders: userPrefix ? [userPrefix] : []
            };
            likesByBeat.set(beatTitle, newItem);
            result.push(newItem);
          }
        } else {
          result.push({ ...n, uIds: [n.id], groupCount: 1 });
        }
      } 
      else if (n.type === 'follower') {
        const followerName = n.message.split(' ')[0] || '';
        if (systemFollowers.length > 0) {
          const mainFollowGroup = systemFollowers[0];
          mainFollowGroup.groupCount += 1;
          mainFollowGroup.uIds.push(n.id);
          if (!mainFollowGroup.senders.includes(followerName) && followerName) {
            mainFollowGroup.senders.push(followerName);
          }
          if (!n.read) mainFollowGroup.read = false;
        } else {
          const newItem = {
            ...n,
            uIds: [n.id],
            groupCount: 1,
            senders: followerName ? [followerName] : []
          };
          systemFollowers.push(newItem);
          result.push(newItem);
        }
      }
      else {
        result.push({ ...n, uIds: [n.id], groupCount: 1 });
      }
    });

    return result;
  };

  const renderableList = getRenderableNotifications();

  return createPortal(
    <>
      {/* Dimmed backdrop with micro blur */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-md z-[9998] cursor-default pointer-events-auto"
      />

      {/* Main Sidebar Dropdown panel */}
      <motion.div
        ref={containerRef}
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 26, stiffness: 220 }}
        onMouseEnter={() => console.log("[DEBUG HOVER] Mouse entered SIDEBAR PANEL")}
        onMouseDown={() => console.log("[DEBUG MOUSEDOWN] Mouse down on SIDEBAR PANEL")}
        className="fixed top-0 right-0 h-full w-full sm:max-w-[430px] bg-[#050508]/96 backdrop-blur-3xl border-l border-white/[0.04] flex flex-col shadow-[0_0_80px_rgba(59,130,246,0.03)] z-[9999] pointer-events-auto"
      >
          {/* Glowing gradient lights inside notifications panel */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/[0.03] rounded-full blur-[100px] pointer-events-none animate-pulse" style={{ animationDuration: '8s' }} />
          <div className="absolute bottom-16 left-0 w-60 h-60 bg-blue-600/[0.02] rounded-full blur-[90px] pointer-events-none animate-pulse" style={{ animationDuration: '10s' }} />

          {/* Core Panel Header */}
          <div className="p-6 border-b border-white/5 flex items-center justify-between relative bg-white/[0.005]">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-semibold text-white tracking-tight">Notificações</h3>
              </div>
              <p className="text-[10px] font-medium text-slate-400 leading-normal tracking-wide">Atualizações em tempo real</p>
            </div>

            <div className="flex items-center gap-2">
              {notifications.some(n => n.read === false) && (
                <button 
                  onClick={markAllAsRead}
                  disabled={loading}
                  className="py-1.5 px-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:text-white hover:bg-blue-500/25 transition-all duration-300 flex items-center gap-1.5 cursor-pointer text-[10px] font-bold uppercase tracking-wider"
                  title="Marcar todas como lidas"
                >
                  <CheckCheck size={13} />
                  <span className="hidden sm:inline">Lidas</span>
                </button>
              )}
              <button 
                onClick={onClose}
                className="p-2 rounded-lg bg-white/[0.02] border border-white/5 hover:border-blue-500/20 text-gray-400 hover:text-blue-400 hover:bg-blue-950/20 transition-all duration-300 cursor-pointer"
              >
                <X size={15} />
              </button>
            </div>
          </div>

          {/* Realtime Filters and Group Config */}
          <div className="px-6 py-4 border-b border-white/5 bg-white/[0.002] flex flex-col gap-3.5">
            {/* Scrollable categories bar for 6 Tabs */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none select-none scroll-smooth">
              {(['all', 'unread', 'social', 'music', 'finance', 'system'] as const).map((tab) => {
                const labels = { 
                  all: 'Todas', 
                  unread: 'Não Lidas', 
                  social: 'Social', 
                  music: 'Música', 
                  finance: 'Financeiro', 
                  system: 'Sistema' 
                };
                const isActive = activeTab === tab;
                return (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`py-1.5 px-3 text-[10px] font-semibold tracking-wide rounded-lg transition-all cursor-pointer whitespace-nowrap border shrink-0 ${
                      isActive 
                        ? 'bg-blue-600 border-blue-500/30 text-white shadow-[0_4px_12px_rgba(59,130,246,0.25)]' 
                        : 'bg-white/[0.02] hover:bg-white/[0.06] border-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    {labels[tab]}
                  </button>
                );
              })}
            </div>

            {/* Smart Group Aggregater toggle */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5 px-1 font-sans">
              <span className="font-medium flex items-center gap-1.5">
                <Layers size={11} className="text-slate-500" />
                Agrupar alertas similares
              </span>
              <button 
                onClick={() => setGroupSimilar(!groupSimilar)}
                className={`px-2 py-0.5 rounded-md text-[8px] font-bold uppercase tracking-widest border transition-all cursor-pointer ${
                  groupSimilar 
                    ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' 
                    : 'bg-white/5 text-slate-500 border-white/5'
                }`}
              >
                {groupSimilar ? 'ATIVADO' : 'DESATIVADO'}
              </button>
            </div>
          </div>

          {/* Core Notifications List body container */}
          <div className="flex-grow overflow-y-auto custom-scrollbar p-4 space-y-2">
            {loading && notifications.length === 0 ? (
              <div className="h-full flex items-center justify-center">
                <InstagramLoader label="Sincronizando feed..." />
              </div>
            ) : renderableList.length === 0 ? (
              // Premium empty alerts illustration
              <div className="h-full flex flex-col items-center justify-center text-center p-8">
                <div className="relative mb-6">
                  <div className="w-16 h-16 rounded-3xl bg-white/[0.01] border border-white/5 flex items-center justify-center text-slate-500 shadow-inner">
                    <Inbox size={26} className="text-slate-400 animate-pulse" />
                  </div>
                  <div className="absolute -inset-2 bg-blue-500/5 rounded-full blur-xl pointer-events-none" />
                </div>
                <h4 className="text-sm font-semibold text-white tracking-wide mb-2">Sem notificações</h4>
                <p className="text-slate-500 text-[11px] font-normal leading-relaxed max-w-[245px] mx-auto">
                  Silêncio absoluto. Avisaremos você em tempo real assim que novas vendas, favoritos ou curtidas forem registadas!
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                <AnimatePresence initial={false}>
                  {renderableList.map((item) => {
                    const isUnread = item.read === false;
                    const Icon = NOTIFICATION_ICONS[item.type] || Bell;
                    const styleClass = NOTIFICATION_COLORS[item.type] || 'text-gray-400 bg-gray-400/10 border-gray-500/10';
                    
                    // --- TEMPORARY MANDATORY DEBUG LOGS ---
                    let metaObj = item.metadata;
                    if (typeof metaObj === 'string') {
                      try {
                        metaObj = JSON.parse(metaObj);
                      } catch {
                        metaObj = {};
                      }
                    }
                    const notification = {
                      ...item,
                      user: item.user_id,
                      avatar: profilesMap[metaObj?.follower_id || '']?.avatar_url || metaObj?.sender_avatar || metaObj?.avatar_url || item.avatar_url,
                      follower: metaObj?.follower_id || null
                    };
                    if (item.type === 'follower') {
                      console.log('FULL FOLLOW NOTIFICATION:', item);
                      console.log('notification.user_id:', item.user_id);
                      console.log('metadata.follower_id:', metaObj?.follower_id);
                      console.log('metadata.sender_id:', metaObj?.sender_id);
                      console.log('metadata.actor_id:', metaObj?.actor_id);
                    }
                    console.log('FULL NOTIFICATION:', item);
                    console.log(notification.user);
                    console.log(notification.avatar);
                    console.log(notification.follower);
                    
                    const fId = metaObj?.follower_id || metaObj?.sender_id || metaObj?.actor_id;
                    let displayTitle = stripEmojis(item.title);
                    let displayMessage = stripEmojis(item.message);

                    if (fId && (!item.groupCount || item.groupCount <= 1)) {
                      const resolvedProfile = profilesMap[fId];
                      if (resolvedProfile) {
                        const profileName = resolvedProfile.display_name || resolvedProfile.username || 'Utilizador';
                        if (item.type === 'follower') {
                          displayMessage = `@${profileName} começou a seguir-te!`;
                        } else if (item.type === 'like') {
                          const beatTitleMatch = item.message.match(/gostou do teu beat "(.+)"/i);
                          if (beatTitleMatch) {
                            displayMessage = `${profileName} gostou do teu beat "${beatTitleMatch[1]}".`;
                          } else {
                            displayMessage = `${profileName} gostou do teu beat.`;
                          }
                        } else if (item.type === 'comment') {
                          const commentMatch = item.message.match(/comentou (no teu beat ".+"|aos .+ do teu beat ".+")/i);
                          if (commentMatch) {
                            displayMessage = `${profileName} ${commentMatch[0]}!`;
                          }
                        }
                      } else {
                        // Profile is designated but not found in the database (or deleted)
                        displayMessage = "Utilizador indisponível";
                      }
                    }

                    if (item.groupCount && item.groupCount > 1) {
                      if (item.type === 'like') {
                        const mainUser = item.senders[0] || 'Alguém';
                        displayTitle = 'Múltiplos Gostos';
                        displayMessage = `${mainUser} e mais ${item.groupCount - 1} artistas gostaram do teu beat "${item.beatTitle}"`;
                      } else if (item.type === 'follower') {
                        const mainUser = item.senders[0] || 'Um produtor';
                        displayTitle = 'Novas Conexões';
                        displayMessage = `${mainUser} e mais ${item.groupCount - 1} artistas começaram a seguir-te.`;
                      }
                    }

                    displayTitle = stripEmojis(displayTitle);
                    displayMessage = stripEmojis(displayMessage);

                    return (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 12, scale: 0.98 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, x: 50 }}
                        whileHover={{ y: -1 }}
                        whileTap={{ scale: 0.985 }}
                        onMouseEnter={() => console.log("[DEBUG HOVER] Mouse entered card ID:", item.id)}
                        onMouseDown={() => console.log("[DEBUG MOUSEDOWN] Mouse down on card ID:", item.id)}
                        onPointerDown={() => console.log("[DEBUG POINTERDOWN] Pointer down on card ID:", item.id)}
                        className={`group relative p-3.5 rounded-lg border transition-all duration-200 select-none cursor-pointer flex items-start gap-3 w-full text-left z-10 pointer-events-auto ${
                          isUnread 
                            ? 'bg-blue-500/[0.02] border-blue-500/10 hover:border-blue-500/30 shadow-[0_4px_24px_rgba(59,130,246,0.03)]' 
                            : 'bg-white/[0.012] border-white/[0.04] hover:bg-white/[0.025] hover:border-blue-500/20 opacity-90 hover:opacity-100 shadow-sm'
                        }`}
                        onClick={async (e) => {
                          console.log("[DEBUG] notification clicked. ID:", item.id, "Type:", item.type, "Title:", item.title);
                          e.stopPropagation();
                          if (isUpdating) return;

                          // 1. Mark as read
                          handleMarkItemRead(item.id, item.uIds);

                          let targetPath = '';

                          // 2. Identify the target path based on the notification type
                          switch (item.type) {
                            case 'purchase':
                            case 'purchase_confirmed':
                            case 'payment':
                              console.log("[DEBUG] route exists? Yes: /dashboard (Vendas ou Licenças Ativas)");
                              localStorage.setItem('producer_dashboard_tab', 'Vendas');
                              localStorage.setItem('artist_dashboard_tab', 'Licenças Ativas');
                              targetPath = '/dashboard';
                              break;

                            case 'withdrawal_approved':
                            case 'withdrawal_rejected':
                               console.log("[DEBUG] route exists? Yes: /dashboard (Carteira)");
                              localStorage.setItem('producer_dashboard_tab', 'Carteira');
                              targetPath = '/dashboard';
                              break;

                            case 'upload':
                            case 'featured_beat':
                            case 'editor_pick':
                            case 'beat_trending': {
                              const bId = item.metadata?.beat_id || item.metadata?.target_id || item.target_id;
                              console.log("[DEBUG] route exists? Yes: /beat/" + bId + " or /all-beats");
                              if (bId && bId !== item.id) {
                                targetPath = `/beat/${bId}`;
                              } else {
                                targetPath = '/all-beats';
                              }
                              break;
                            }

                            case 'flash_sale':
                              console.log("[DEBUG] route exists? Yes: /all-beats");
                              targetPath = '/all-beats';
                              break;

                            case 'follower': {
                              const targetActorId = item.metadata?.follower_id || item.metadata?.sender_id || item.metadata?.actor_id;
                              let fUsername = (targetActorId && profilesMap[targetActorId]?.username) || item.metadata?.follower_username || item.metadata?.username;
                              if (!fUsername && item.message && item.message.includes('@')) {
                                const match = item.message.match(/@([^ ]+(?:\s+[^ ]+)*?)(?=\s+começou|\s+comecou|\s+is\s+now|\s+started)/i);
                                let rawName = match ? match[1] : (item.message.match(/@([^ ]+)/)?.[1] || '');
                                if (rawName) {
                                  rawName = rawName.trim();
                                  const dbSupabase = getSupabase();
                                  if (dbSupabase) {
                                    try {
                                      const { data: p } = await dbSupabase
                                        .from('profiles')
                                        .select('username')
                                        .or(`username.eq.${rawName},display_name.eq.${rawName},artistic_name.eq.${rawName}`)
                                        .maybeSingle();
                                      if (p && p.username) {
                                        fUsername = p.username;
                                      }
                                    } catch (err) {
                                      console.warn("Failed to check profile via supabase query:", err);
                                    }
                                  }
                                  if (!fUsername) {
                                    fUsername = rawName.toLowerCase().replace(/[^a-z0-9_]/g, '');
                                  }
                                }
                              }
                              console.log("[DEBUG] route exists? Yes: /@" + fUsername + " or /feed");
                              if (fUsername) {
                                targetPath = `/@${fUsername}`;
                              } else {
                                const fId = item.metadata?.follower_id || item.metadata?.target_id || item.target_id;
                                if (fId && fId !== item.id) {
                                  targetPath = `/@${fId}`;
                                } else {
                                  targetPath = '/feed';
                                  if (onClose) onClose();
                                }
                              }
                              break;
                            }

                            case 'like':
                            case 'comment':
                            case 'reply_comment':
                            case 'repost': {
                              const bId = item.metadata?.beat_id || item.metadata?.target_id || item.target_id;
                              console.log("[DEBUG] route exists? Yes: /beat/" + bId + " or /all-beats");
                              if (bId && bId !== item.id) {
                                targetPath = `/beat/${bId}`;
                              } else {
                                targetPath = '/all-beats';
                              }
                              break;
                            }

                            case 'playlist_add':
                            case 'playlist_inclusion': {
                              const plId = item.metadata?.playlist_id || item.metadata?.target_id || item.target_id;
                              console.log("[DEBUG] route exists? Yes: /playlist/" + plId + " or /feed");
                              if (plId && plId !== item.id) {
                                targetPath = `/playlist/${plId}`;
                              } else {
                                targetPath = '/feed';
                              }
                              break;
                            }

                            case 'verified':
                            case 'account':
                            case 'account_updated':
                              console.log("[DEBUG] route exists? Yes: /dashboard (Definições ou Meu Perfil)");
                              localStorage.setItem('producer_dashboard_tab', 'Definições da Conta');
                              localStorage.setItem('artist_dashboard_tab', 'Meu Perfil');
                              targetPath = '/dashboard';
                              break;

                            case 'security':
                            case 'platform_update':
                              console.log("[DEBUG] route exists? Yes: /notifications");
                              targetPath = '/notifications';
                              break;

                            default:
                              console.log("[DEBUG] route exists? Yes (fallback): /notifications");
                              targetPath = '/notifications';
                              break;
                          }

                          console.log("[DEBUG] navigation target matched:", targetPath);

                          // 3. Execute navigation
                          const finalPath = targetPath || '/notifications';
                          setTimeout(() => {
                            window.history.pushState({}, '', finalPath);
                            window.dispatchEvent(new Event('popstate'));
                            console.log("[DEBUG] navigation executed to", finalPath);
                            onClose();
                          }, 180);
                        }}
                      >
                        {/* Elegant blue micro indicator for unreads */}
                        {isUnread && (
                          <div className="absolute left-0.5 top-3.5 bottom-3.5 w-[2.5px] bg-blue-500 rounded-full shadow-[0_0_8px_rgba(59,130,246,0.6)]" />
                        )}

                        {/* Custom Graphic Icon Column */}
                        <div className="shrink-0 relative">
                          {renderNotificationAvatar(item, styleClass, Icon, "w-9 h-9", profilesMap)}
                          
                          {/* Elegant tiny badge representing action icon */}
                          <div className={`absolute -bottom-1 -right-0.5 w-4.5 h-4.5 rounded-full border border-[#0d121c] flex items-center justify-center ${styleClass.split(' ')[0]} ${styleClass.split(' ')[1]} bg-[#09090D] shadow`}>
                            <Icon size={8} />
                          </div>

                          {item.groupCount > 1 && (
                            <div className="absolute -top-1.5 -left-1.5 bg-blue-600 text-white font-bold text-[8px] h-3.5 w-3.5 rounded-full flex items-center justify-center border border-black/40 shadow">
                              +{item.groupCount}
                            </div>
                          )}
                        </div>

                        {/* Notification content meta */}
                        <div className="flex-grow min-w-0 pr-6 space-y-0.5 mt-0.5">
                          <div className="flex items-center justify-between gap-1.5 leading-none mb-1">
                            <span className="text-[9px] font-bold uppercase tracking-wider text-blue-400/90 leading-none">
                              {translateNotificationType(item.type)}
                            </span>
                            
                            <span className="text-[10px] text-slate-500 font-medium shrink-0">
                              {formatRelativeTime(item.created_at)}
                            </span>
                          </div>

                          <h5 className={`text-xs font-semibold text-white tracking-tight leading-snug truncate ${isUnread ? 'text-blue-300' : 'text-slate-200'}`}>
                             {displayTitle}
                          </h5>

                          <p className="text-[11px] text-slate-400 font-normal leading-normal line-clamp-2 mt-0.5">
                            {displayMessage}
                          </p>

                          <div className="flex gap-2 pt-1.5">
                            <span 
                              onClick={async (e) => {
                                console.log('DETAIL CLICK WORKING');
                                e.stopPropagation();
                                if (isUpdating) return;

                                // Mark item as read immediately in DB (optimistic)
                                handleMarkItemRead(item.id, item.uIds);

                                // Set state to open the premium modal
                                setSelectedNotification(item);
                              }}
                              className="text-[10px] font-semibold text-blue-400 hover:text-blue-300 transition-all duration-200 flex items-center gap-0.5 cursor-pointer hover:underline decoration-blue-500/30"
                            >
                              Ver detalhes <ChevronRight size={10} className="transform group-hover:translate-x-0.5 transition-transform duration-200" />
                            </span>
                          </div>
                        </div>

                        {/* Hover garbage trash item details action */}
                        <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-auto z-20">
                           <button 
                             onClick={(e) => {
                               console.log("[DEBUG] Delete clicked for item ID:", item.id);
                               handleDeleteItem(e, item.id, item.uIds);
                             }}
                             className="p-1.5 rounded-lg bg-white/[0.04] text-slate-400 border border-white/5 hover:bg-slate-800 hover:text-white transition-all cursor-pointer pointer-events-auto relative z-20"
                             title="Remover"
                           >
                             <Trash2 size={10} />
                           </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>

          {/* Core Panel Actions Footer */}
          <div className="p-5 border-t border-white/5 bg-[#030305] space-y-3">
            <button 
              onClick={onViewAll}
              className="w-full py-3 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-650 hover:from-blue-500 hover:to-indigo-600 text-white text-[11px] font-bold uppercase tracking-wider transition-all scale-100 active:scale-95 shadow-lg shadow-indigo-950/25 flex items-center justify-center gap-2 group cursor-pointer"
            >
              <span>Ver painel completo</span>
              <ExternalLink size={12} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
            <div className="text-center">
              <span className="text-[8px] font-medium text-slate-600 uppercase tracking-widest">Batukada Studio Alerts 2.0</span>
            </div>
          </div>
        </motion.div>

        <AnimatePresence>
          {selectedNotification && (
            <NotificationDetailModal
              notification={selectedNotification}
              onClose={() => setSelectedNotification(null)}
              onDropdownClose={onClose}
            />
          )}
        </AnimatePresence>
      </> ,
      document.body
  );
}
