/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, lazy, Suspense, ErrorInfo, ReactNode } from 'react';
import { Beat, Producer } from './types';
import Navbar from './components/Navbar';
import BeatCard from './components/BeatCard';
import Player from './components/Player';
import Cart from './components/Cart';
import WhyChooseSection from './components/WhyChooseSection';
import ExploreSection from './components/ExploreSection';
import Footer from './components/Footer';
import { useAuth } from './context/AuthContext';
import { useChat } from './hooks/useChat';
import AuthModal from './components/AuthModal';
import CheckoutModal from './components/CheckoutModal';
import AddToPlaylistModal from './components/AddToPlaylistModal';
import { Search, AlertTriangle, RefreshCw, Sparkles, Play, Disc, CheckCircle2 } from 'lucide-react';
import { getSupabase, getPublicUrl } from './lib/supabase';
import { useToast } from './context/ToastContext';
import InstagramLoader from './components/InstagramLoader';
import { slugify } from './lib/slugify';
import { adminStore } from './lib/adminStore';
import { playlistStore, Playlist } from './lib/playlistStore';
import { getProducersRankings, calculatePremiumProducerStats } from './lib/rankingSystem';
import { playService } from './lib/playService';

import Hero from './components/Hero';
import FeaturedBeats from './components/FeaturedBeats';
import MusicCategories from './components/MusicCategories';
import MarketplaceKitCard from './components/MarketplaceKitCard';
import VerifiedBadge from './components/VerifiedBadge';
import SmartDiscoverySection from './components/SmartDiscoverySection';

// Premium Page-Level Skeleton and lazy loaders
import { PremiumPageSkeleton } from './components/SkeletonLoader';

import AllBeatsPage from './components/AllBeatsPage';

// Robust safety retry-mechanism for loading lazy components (prevents dynamic import/chunk loading network or stale caching crashes)
const lazyWithRetry = <T extends { default: React.ComponentType<any> }>(
  importFn: () => Promise<T>
): Promise<T> => {
  return new Promise((resolve, reject) => {
    importFn()
      .then(resolve)
      .catch((error) => {
        console.warn("Dynamic chunk loading failed. Retrying in 1.5 seconds...", error);
        setTimeout(() => {
          importFn()
            .then(resolve)
            .catch((err2) => {
              console.error("Ultimate chunk load attempt failed. Force reloading latest client assets...");
              if (typeof window !== 'undefined') {
                window.location.reload();
              }
              reject(err2);
            });
        }, 1500);
      });
  });
};

const ProducersPage = lazy(() => lazyWithRetry(() => import('./components/ProducersPage')));
const ProducersRankingPage = lazy(() => lazyWithRetry(() => import('./components/ProducersRankingPage')));
const ProducerProfilePage = lazy(() => lazyWithRetry(() => import('./components/ProducerProfilePage')));
const FeedPage = lazy(() => lazyWithRetry(() => import('./components/FeedPage')));
const DashboardPage = lazy(() => lazyWithRetry(() => import('./components/dashboards/DashboardPage')));
const MessagesPage = lazy(() => lazyWithRetry(() => import('./components/MessagesPage')));
const NotificationsPage = lazy(() => lazyWithRetry(() => import('./components/NotificationsPage')));
const LicensingPage = lazy(() => lazyWithRetry(() => import('./components/LicensingPage')));
const TermosPage = lazy(() => lazyWithRetry(() => import('./components/TermosPage')));
const BeatDetailsPage = lazy(() => lazyWithRetry(() => import('./components/BeatDetailsPage')));
const AdminPayoutManagement = lazy(() => lazyWithRetry(() => import('./components/admin/AdminPayoutManagement')));
const AdminFinancialDashboard = lazy(() => lazyWithRetry(() => import('./components/admin/AdminFinancialDashboard')));
const PlaylistDetailsPage = lazy(() => lazyWithRetry(() => import('./components/PlaylistDetailsPage')));
const PaymentSuccessPage = lazy(() => lazyWithRetry(() => import('./components/PaymentSuccessPage')));
const PaymentCancelledPage = lazy(() => lazyWithRetry(() => import('./components/PaymentCancelledPage')));

class ErrorBoundary extends React.Component<{
  children: ReactNode;
  fallback?: ReactNode;
  name?: string;
}, {
  hasError: boolean;
  error: Error | null;
}> {
  constructor(props: { children: ReactNode; fallback?: ReactNode; name?: string }) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  public static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error(`[ErrorBoundary - ${this.props.name || 'Component'}] Error:`, error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  public render(): ReactNode {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return (
        <div id={`error-boundary-${this.props.name || 'global'}`} className="p-8 my-4 rounded-3xl bg-red-500/5 border border-red-500/10 backdrop-blur-md flex flex-col items-center justify-center text-center max-w-xl mx-auto text-white/95">
          <div className="w-12 h-12 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 mb-4 animate-pulse">
            <AlertTriangle size={24} />
          </div>
          <h3 className="text-white font-black text-sm uppercase tracking-widest mb-1.5">
            Recuperação de Erro
          </h3>
          <p className="text-gray-400 text-xs leading-relaxed max-w-sm mb-5">
            Ocorreu um erro ao carregar o módulo <span className="text-gray-200 font-bold font-mono">{this.props.name || 'principal'}</span>.
          </p>
          <div className="text-[10px] font-mono text-red-400/80 bg-black/40 px-3 py-2 rounded-xl mb-5 max-w-full overflow-x-auto border border-white/[0.04]">
            {this.state.error?.message || 'Erro de rede ou conexão'}
          </div>
          <button
            onClick={this.handleReset}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] text-white text-[10px] font-black uppercase tracking-widest transition-all hover:scale-105 active:scale-95 border border-white/[0.05]"
          >
            <RefreshCw size={12} />
            Recarregar Módulo
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

function HomeContent({ 
  beats, 
  producers = [],
  handlePlay, 
  addToCart, 
  currentBeat, 
  isPlaying, 
  onExplore, 
  onSelectProducer, 
  onStartSelling, 
  onSelectBeat,
  onSelectPlaylist,
  onRankings
}: { 
  beats: Beat[], 
  producers?: Producer[],
  handlePlay: (beat: Beat) => void, 
  addToCart: (beat: Beat) => void, 
  currentBeat: Beat | null, 
  isPlaying: boolean, 
  onExplore: (genreId?: string) => void, 
  onSelectProducer: (producerName: string) => void, 
  onStartSelling: () => void, 
  onSelectBeat?: (beat: Beat) => void,
  onSelectPlaylist: (playlistId: string) => void,
  onRankings: () => void
}) {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [dbPlaylists, setDbPlaylists] = useState<Playlist[]>([]);
  
  // Compute creator metrics and curation channels
  const rankedProducers = getProducersRankings(producers, beats);
  const topProducers = rankedProducers.slice(0, 3);
  const finalRisingStars = rankedProducers.filter(p => p.premium.rank > 3).slice(0, 3);
  const verifiedCreators = rankedProducers.filter(p => p.isVerified || (p as any).is_verified).slice(0, 3);

  const filteredBeats = beats.filter(beat => 
    beat.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    beat.producer.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (beat.genre && beat.genre.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  useEffect(() => {
    const loadPublicPlaylists = async () => {
      try {
        const searchUserId = user?.id || 'guest-visitor';
        const list = await playlistStore.fetchPlaylists(searchUserId);
        const publics = list.filter(p => p.is_public);
        setDbPlaylists(publics);
      } catch (err) {
        console.warn('[HOMEPLAYLISTS] Could not gather public playlists:', err);
      }
    };
    loadPublicPlaylists();
  }, [user]);
  
  return (
    <>
      <Hero 
        onExplore={onExplore} 
        onStartSelling={onStartSelling} 
        beats={beats}
        currentBeat={currentBeat}
        isPlaying={isPlaying}
        onPlay={handlePlay}
      />

      {/* SEÇÃO PREMIUM DE PLAYLISTS - SPOTIFY/APPLE MUSIC STYLE */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 mb-16 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-3 border-b border-white/5 pb-4">
          <div className="space-y-1">
            <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <Sparkles className="text-[#5865F2]" size={18} /> 
              Curadorias da Comunidade
            </h2>
            <p className="text-gray-400 text-xs">
              Músicas e seleções partilhadas publicamente pelos produtores e utilizadores da nossa comunidade.
            </p>
          </div>
        </div>

        {/* PLAYLISTS LISTING */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Playlists Recentes</span>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {dbPlaylists.length === 0 ? (
              <div className="col-span-full border border-dashed border-white/5 rounded-xl p-10 text-center text-gray-500 text-xs font-semibold bg-[#0c0c12]/40">
                <Disc size={28} className="mx-auto text-gray-650 mb-3 animate-spin animate-duration-3000" />
                Ainda não existem playlists públicas criadas na plataforma. Cria uma na tua Dashboard e partilha as tuas batidas!
              </div>
            ) : (
              dbPlaylists.map((p) => (
                <div 
                  key={p.id}
                  onClick={() => onSelectPlaylist(p.id)}
                  className="group bg-[#0c0c12]/80 border border-white/5 p-4 rounded-xl hover:border-white/10 hover:bg-[#12121c] transition-colors cursor-pointer relative overflow-hidden"
                >
                  <div className="aspect-square w-full rounded-lg overflow-hidden mb-3 relative bg-neutral-900">
                    {p.cover_image ? (
                      <img 
                        src={p.cover_image} 
                        alt="" 
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-[#5865F2]/10 p-4">
                        <Disc size={36} className="text-[#5865F2] opacity-70" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Play size={18} className="text-white fill-white scale-95 group-hover:scale-105 transition-transform bg-[#5865F2] p-2.5 rounded-full w-10 h-10 flex items-center justify-center shadow-lg" />
                    </div>
                  </div>
                  <h4 className="font-bold text-xs text-white group-hover:text-[#5865F2] transition-colors truncate">{p.title}</h4>
                  <p className="text-[10px] text-gray-500 mt-1 line-clamp-2">{p.description || "Criada por um membro ou DJ no ecossistema."}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* SEÇÃO PREMIUM: DISCOVER THE FINEST CREATORS */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 mb-12 space-y-6">
        <div className="flex flex-col md:flex-row md:items-baseline justify-between gap-2 border-b border-white/5 pb-3">
          <div>
            <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider">Curadoria de Elite</span>
            <h3 className="text-xl md:text-2xl font-black text-white tracking-tight">Criadores Relevantes</h3>
          </div>
          <button 
            onClick={onRankings}
            className="text-[11px] font-bold text-[#5865F2] hover:text-[#4752C4] transition-all flex items-center gap-1 cursor-pointer hover:underline"
          >
            Ver Leaderboard Completo →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          
          {/* Column 1: Top Produtores (Podium) */}
          <div className="bg-[#0c0c12]/80 border border-white/5 rounded-xl p-5 space-y-3.5">
            <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
              <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider">👑 Top Produtores</span>
              <span className="text-[9px] font-bold text-neutral-500">Pódium Semanal</span>
            </div>

            <div className="space-y-2.5">
              {topProducers.length === 0 ? (
                <p className="text-xs text-neutral-500 italic">Carregando lista...</p>
              ) : topProducers.map((prod, idx) => {
                const initials = prod.name ? prod.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'P';
                return (
                  <div 
                    key={prod.id} 
                    onClick={() => onSelectProducer(prod.username || prod.name)}
                    className="flex items-center gap-3 bg-neutral-900/40 hover:bg-neutral-800/60 p-2.5 rounded-lg border border-white/[0.02] cursor-pointer transition-colors group"
                  >
                    <span className="text-xs font-bold text-amber-500 w-4">#{idx + 1}</span>
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#12121A] to-[#1F1F2E] flex items-center justify-center border border-white/5 select-none text-[10px] font-bold shrink-0 overflow-hidden">
                      {prod.avatar ? (
                        <img src={prod.avatar} alt="" className="w-full h-full object-cover" />
                      ) : initials}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h4 className="font-bold text-xs text-white group-hover:text-amber-500 transition-colors truncate">{prod.name}</h4>
                      <p className="text-[9px] text-neutral-500">@{prod.username || 'producer'}</p>
                    </div>
                    <span className="text-[9px] font-bold text-rose-400 bg-rose-500/5 px-2 py-0.5 rounded uppercase tracking-wide">
                      {Math.round(prod.score).toLocaleString()} PTS
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Column 2: Rising Stars */}
          <div className="bg-[#0c0c12]/80 border border-white/5 rounded-xl p-5 space-y-3.5">
            <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">⚡ Estrelas Em Ascensão</span>
              <span className="text-[9px] font-bold text-neutral-500">Surgindo Agora</span>
            </div>

            <div className="space-y-2.5">
              {finalRisingStars.length === 0 ? (
                <p className="text-xs text-neutral-500 italic">Carregando lista...</p>
              ) : finalRisingStars.map((prod) => {
                const initials = prod.name ? prod.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'P';
                return (
                  <div 
                    key={prod.id} 
                    onClick={() => onSelectProducer(prod.username || prod.name)}
                    className="flex items-center gap-3 bg-neutral-900/40 hover:bg-neutral-800/60 p-2.5 rounded-lg border border-white/[0.02] cursor-pointer transition-colors group"
                  >
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#12121A] to-[#1F1F2E] flex items-center justify-center border border-white/5 select-none text-[10px] font-bold shrink-0 overflow-hidden">
                      {prod.avatar ? (
                        <img src={prod.avatar} alt="" className="w-full h-full object-cover" />
                      ) : initials}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h4 className="font-bold text-xs text-white group-hover:text-blue-400 transition-colors truncate">{prod.name}</h4>
                      <p className="text-[9px] text-neutral-500">@{prod.username || 'producer'}</p>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-400">
                      +{Math.round(25 + (prod.score % 20))}%
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Column 3: Verified Creators */}
          <div className="bg-[#0c0c12]/80 border border-white/5 rounded-xl p-5 space-y-3.5">
            <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">🛡 Produtores de Elite</span>
              <span className="text-[9px] font-bold text-neutral-500">Validados Oficiais</span>
            </div>

            <div className="space-y-2.5">
              {verifiedCreators.length === 0 ? (
                <p className="text-xs text-neutral-500 italic">Carregando lista...</p>
              ) : verifiedCreators.map((prod) => {
                const initials = prod.name ? prod.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'P';
                return (
                  <div 
                    key={prod.id} 
                    onClick={() => onSelectProducer(prod.username || prod.name)}
                    className="flex items-center gap-3 bg-neutral-900/40 hover:bg-neutral-800/60 p-2.5 rounded-lg border border-white/[0.02] cursor-pointer transition-colors group"
                  >
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#12121A] to-[#1F1F2E] flex items-center justify-center border border-white/5 select-none text-[10px] font-bold shrink-0 overflow-hidden">
                      {prod.avatar ? (
                        <img src={prod.avatar} alt="" className="w-full h-full object-cover" />
                      ) : initials}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <h4 className="font-bold text-xs text-white group-hover:text-indigo-400 transition-colors truncate">{prod.name}</h4>
                        <VerifiedBadge size="sm" />
                      </div>
                      <p className="text-[9px] text-neutral-500">@{prod.username || 'producer'}</p>
                    </div>
                    <span className="text-[8px] font-bold text-[#5865F2] bg-[#5865F2]/5 px-2 py-0.5 rounded uppercase tracking-wide">
                      OFICIAL
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>

      {/* SMART DISCOVERY, TRENDING CHARTS, & CULTURAL ROADMAP SYSTEM */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 mb-12">
        <SmartDiscoverySection 
          beats={beats}
          producers={producers}
          currentBeat={currentBeat}
          isPlaying={isPlaying}
          onPlay={handlePlay}
          onAddToCart={addToCart}
          onSelectProducer={onSelectProducer}
          onSelectBeat={onSelectBeat || (() => {})}
          onExploreGenre={(genreId) => onExplore(genreId)}
        />
      </div>

      <FeaturedBeats 
        beats={filteredBeats}
        currentBeat={currentBeat}
        isPlaying={isPlaying}
        onPlay={handlePlay}
        onAddToCart={addToCart}
        onSelectProducer={onSelectProducer}
        onViewAll={onExplore}
        onSelectBeat={onSelectBeat}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 mb-24">
        <MusicCategories onSelectCategory={(categoryId) => onExplore(categoryId)} />
      </div>

      <WhyChooseSection />
      <ExploreSection 
        beats={beats} 
        onExplore={onExplore} 
        currentBeat={currentBeat} 
        isPlaying={isPlaying} 
        onPlay={handlePlay} 
      />
    </>
  );
}

export default function App() {
  const [globalBeats, setGlobalBeats] = useState<Beat[]>([]);
  const [cart, setCart] = useState<Beat[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [activeProducers, setActiveProducers] = useState<Producer[]>([]);
  const [messageRecipientId, setMessageRecipientId] = useState<string | null>(null);
  const [heroBgLoaded, setHeroBgLoaded] = useState(false);

  useEffect(() => {
    const img = new Image();
    img.src = '/hero-bg.webp';
    img.onload = () => setHeroBgLoaded(true);
  }, []);
  
  const { user, profile, loading } = useAuth();
  const { showToast } = useToast();

  useEffect(() => {
    console.log('[BOOT] App mounted');
    console.log('[BOOT] Language loaded');
  }, []);

  useEffect(() => {
    console.log('[BOOT] Render complete');
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('paypal_success') === 'true') {
        showToast('Pagamento confirmado via PayPal! O download e as licenças já estão libertadas no teu Painel em "Licenças Ativas".', 'success', 'Pagamento Confirmado');
        
        // Clean URL params to prevent re-triggering upon reload
        params.delete('paypal_success');
        params.delete('orderId');
        const newSearch = params.toString();
        const cleanUrl = newSearch ? `${window.location.pathname}?${newSearch}` : window.location.pathname;
        window.history.replaceState({}, '', cleanUrl);
      } else if (params.get('paypal_cancel') === 'true') {
        showToast('O pagamento com o PayPal foi cancelado pelo utilizador.', 'info', 'Pagamento Cancelado');
        
        params.delete('paypal_cancel');
        params.delete('orderId');
        const newSearch = params.toString();
        const cleanUrl = newSearch ? `${window.location.pathname}?${newSearch}` : window.location.pathname;
        window.history.replaceState({}, '', cleanUrl);
      } else if (params.get('paypal_error') === 'true') {
        showToast('Erro ao processar pagamento PayPal. Se o valor foi cobrado, contacte suporte ou tente novamente.', 'error', 'Falha no Pagamento');
        
        params.delete('paypal_error');
        params.delete('orderId');
        const newSearch = params.toString();
        const cleanUrl = newSearch ? `${window.location.pathname}?${newSearch}` : window.location.pathname;
        window.history.replaceState({}, '', cleanUrl);
      }
    }
  }, [showToast]);

  const emailNormalized = user?.email?.toLowerCase()?.trim() || '';
  const isAdmin = 
    profile?.role === 'admin' || 
    user?.user_metadata?.role === 'admin' || 
    user?.app_metadata?.role === 'admin' || 
    user?.user_metadata?.account_type === 'admin' || 
    localStorage.getItem('beatangola_user_role') === 'admin' ||
    emailNormalized === 'dieluxpista@gmail.com' ||
    emailNormalized === 'miguelfranciscoalfredo24@gmail.com' ||
    emailNormalized === 'domingosdejesusk@gmail.com';

  console.log("APP: Resolved isAdmin status:", isAdmin, "user:", user?.email, "profile role:", profile?.role);
  
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  
  const initialRouteChecked = React.useRef(false);
  const lastFetchRef = React.useRef<number>(0);

  const [currentPage, setCurrentPage] = useState<'home' | 'all-beats' | 'producer-rankings' | 'producers' | 'producer-profile' | 'dashboard' | 'messages' | 'notifications' | 'licensing' | 'admin-payouts' | 'admin-finance' | 'termos' | 'beat-details' | 'playlist-details' | 'feed' | 'payment-success' | 'payment-cancelled'>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname;
      if (path === '/payment/success') return 'payment-success';
      if (path === '/payment/cancelled') return 'payment-cancelled';
      if (path === '/rankings') return 'producer-rankings';
      if (path.startsWith('/beat/')) {
        return 'beat-details';
      }
      if (path.startsWith('/producer/') || path.startsWith('/@') || path.startsWith('/user/') || path.startsWith('/profile/')) {
        return 'producer-profile';
      }
      if (path.startsWith('/playlist/')) {
        return 'playlist-details';
      }
      if (path === '/all-beats') return 'all-beats';
      if (path === '/producers') return 'producers';
      if (path === '/feed') return 'feed';
      if (path === '/licensing') return 'licensing';
      if (path === '/termos') return 'termos';
      if (path === '/dashboard') return 'dashboard';
      if (path === '/messages') return 'messages';
      if (path === '/notifications') return 'notifications';
      if (path === '/admin-payouts') return 'admin-payouts';
      if (path === '/admin-finance') return 'admin-finance';

      const params = new URLSearchParams(window.location.search);
      if (params.get('genre')) {
        return 'all-beats';
      }
      if (params.get('beat')) return 'beat-details';
      if (params.get('producer')) return 'producer-profile';
      if (params.get('playlist')) return 'playlist-details';
    }
    return 'home';
  });
  
  const { unreadCount } = useChat(user?.id);
  const [selectedBeat, setSelectedBeat] = useState<Beat | null>(null);
  const [previousPage, setPreviousPage] = useState<string>('home');
  const [selectedProducer, setSelectedProducer] = useState<Producer | null>(null);
  const [producerSourceHistory, setProducerSourceHistory] = useState<{
    page: 'home' | 'all-beats' | 'producer-rankings' | 'producers' | 'producer-profile' | 'dashboard' | 'messages' | 'notifications' | 'licensing' | 'admin-payouts' | 'admin-finance' | 'termos' | 'beat-details' | 'playlist-details' | 'feed' | 'payment-success' | 'payment-cancelled';
    selectedBeat: Beat | null;
    selectedPlaylistId: string | null;
  } | null>(null);

  // Dynamic Browser-level and OpenGraph Dynamic Metadata Alignment
  useEffect(() => {
    try {
      let title = "BATUKADA | A Maior Plataforma Angolana de Beats e Kits";
      let desc = "Submete, compra e vende Beats, Soundkits, Kizomba, Afro-Trap, Semba, Kuduro e mais na BATUKADA.";

      if (currentPage === 'beat-details' && selectedBeat) {
        title = `${selectedBeat.title} | Drill / Kizomba / Hip-Hop Type Beat | BATUKADA`;
        desc = `Download e Licenciamento Profissional para "${selectedBeat.title}" por ${selectedBeat.producer} na BATUKADA.`;
      } else if (currentPage === 'producer-profile' && selectedProducer) {
        title = `${selectedProducer.name} | Produtor Musical Oficial | BATUKADA`;
        desc = `Ouça e compre beats e soundkits exclusivos produzidos por ${selectedProducer.name} na BATUKADA.`;
      } else if (currentPage === 'all-beats') {
        title = "Explorar Beats e Ritmos | BATUKADA";
      } else if (currentPage === 'producers') {
        title = "Produtores Musicais Oficiais | BATUKADA";
      } else if (currentPage === 'licensing') {
        title = "Licenciamento de Beats e Contratos | BATUKADA";
      } else if (currentPage === 'termos') {
        title = "Termos e Condições e Políticas | BATUKADA";
      } else if (currentPage === 'playlist-details' && selectedPlaylistId) {
        title = `Playlist Especial | BATUKADA`;
      }

      document.title = title;

      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute('content', desc);
      }
    } catch (e) {
      console.warn("Client SEO update failed:", e);
    }
  }, [currentPage, selectedBeat, selectedProducer, selectedPlaylistId]);

  const handleSelectProducer = (producerName: string) => {
    const cleanSearchName = producerName.replace(/^@/, '').toLowerCase().trim();
    let producer = activeProducers.find(p => 
      p.name.toLowerCase() === cleanSearchName || 
      (p.username && p.username.toLowerCase() === cleanSearchName) ||
      p.id === producerName
    );

    if (!producer) {
      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(cleanSearchName);
      const matchingBeat = globalBeats.find(b => 
        (b.producer && b.producer.toLowerCase() === cleanSearchName) || 
        (b.producer_name && b.producer_name.toLowerCase() === cleanSearchName)
      );
      const producerId = isUUID ? cleanSearchName : (matchingBeat?.producer_id || cleanSearchName);
      
      producer = {
        id: producerId,
        name: producerName,
        username: producerName.replace(/^@/, '').toLowerCase().trim().replace(/\s+/g, ''),
        tagline: '',
        bio: '',
        avatar: '',
        banner: '',
        followers: 0,
        totalBeats: 0,
        totalPlays: '0',
        isVerified: false,
        location: 'Luanda, Angola',
        joinDate: '',
        genres: []
      };
    }

    // Capture the state we came from
    if (currentPage !== 'producer-profile') {
      setProducerSourceHistory({
        page: currentPage,
        selectedBeat: selectedBeat,
        selectedPlaylistId: selectedPlaylistId
      });
    }

    const usernamePart = producer.username || producer.name.toLowerCase().replace(/\s+/g, '');
    setSelectedProducer(producer);
    setCurrentPage('producer-profile');
    window.history.pushState({}, '', `/@${usernamePart}`);

    // Track professional analytics profile_click event
    try {
      import('@/src/lib/analytics').then(m => {
        m.trackAnalyticsEvent('profile_click', {
          producerId: producer.id,
          userId: user?.id || undefined
        });
      });
    } catch (err) {
      console.error("[ANALYTICS] Profile click tracking error:", err);
    }
  };

  const handleBackFromProducer = () => {
    if (producerSourceHistory) {
      const { page, selectedBeat: prevBeat, selectedPlaylistId: prevPlaylistId } = producerSourceHistory;
      setCurrentPage(page);
      
      if (page === 'beat-details' && prevBeat) {
        setSelectedBeat(prevBeat);
        window.history.pushState({}, '', `/beat/${slugify(prevBeat.title) || prevBeat.id}`);
      } else if (page === 'playlist-details' && prevPlaylistId) {
        setSelectedPlaylistId(prevPlaylistId);
        window.history.pushState({}, '', `/playlist/${prevPlaylistId}`);
      } else if (page === 'all-beats') {
        window.history.pushState({}, '', '/all-beats');
      } else if (page === 'producers') {
        window.history.pushState({}, '', '/producers');
      } else if (page === 'licensing') {
        window.history.pushState({}, '', '/licensing');
      } else if (page === 'termos') {
        window.history.pushState({}, '', '/termos');
      } else {
        window.history.pushState({}, '', '/');
      }
      setProducerSourceHistory(null);
    } else {
      setCurrentPage('producers');
      window.history.pushState({}, '', '/producers');
    }
  };

  const handleSelectBeat = (beat: Beat) => {
    setSelectedBeat(beat);
    setPreviousPage(currentPage);
    setCurrentPage('beat-details');
    window.history.pushState({}, '', `/beat/${slugify(beat.title) || beat.id}`);

    // Track professional analytics beat_click event
    try {
      import('@/src/lib/analytics').then(m => {
        m.trackAnalyticsEvent('beat_click', {
          producerId: beat.producer_id,
          beatId: beat.id,
          userId: user?.id || undefined
        });
      });
    } catch (err) {
      console.error("[ANALYTICS] Beat click tracking error:", err);
    }
  };

  const handleBackFromBeatDetails = () => {
    setCurrentPage(previousPage as any || 'home');
    window.history.pushState({}, '', '/');
  };

  const changePage = (pageName: typeof currentPage) => {
    let path = '/';
    if (pageName === 'all-beats') path = '/all-beats';
    else if (pageName === 'producers') path = '/producers';
    else if (pageName === 'producer-rankings') path = '/rankings';
    else if (pageName === 'feed') path = '/feed';
    else if (pageName === 'licensing') path = '/licensing';
    else if (pageName === 'termos') path = '/termos';
    else if (pageName === 'dashboard') path = '/dashboard';
    else if (pageName === 'messages') path = '/messages';
    else if (pageName === 'notifications') path = '/notifications';
    else if (pageName === 'admin-payouts') path = '/admin-payouts';
    else if (pageName === 'admin-finance') path = '/admin-finance';
    
    setCurrentPage(pageName);
    window.history.pushState({}, '', path);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  useEffect(() => {
    if (globalBeats.length === 0) return;
    const handleUrlChange = () => {
      const path = window.location.pathname;
      if (path.startsWith('/beat/')) {
        const beatIdParam = decodeURIComponent(path.split('/')[2]);
        const foundBeat = globalBeats.find(b => 
          ((b as any).slug && (b as any).slug === beatIdParam) ||
          slugify(b.title) === beatIdParam ||
          String(b.id) === beatIdParam
        );
        if (foundBeat) {
          setSelectedBeat(foundBeat);
          setCurrentPage('beat-details');
          return;
        }
      }
      if (path.startsWith('/@')) {
        const usernameParam = decodeURIComponent(path.substring(2));
        handleSelectProducer(usernameParam);
        return;
      }
      if (path.startsWith('/producer/')) {
        const pName = decodeURIComponent(path.split('/')[2]);
        const cleanName = pName.replace(/^@/, '').toLowerCase().trim();
        const found = activeProducers.find(p => p.name.toLowerCase() === cleanName || (p.username && p.username.toLowerCase() === cleanName));
        const finalUsername = found?.username || cleanName;
        window.history.replaceState({}, '', `/@${finalUsername}`);
        handleSelectProducer(finalUsername);
        return;
      }
      if (path.startsWith('/user/')) {
        const pName = decodeURIComponent(path.split('/')[2]);
        const cleanName = pName.replace(/^@/, '').toLowerCase().trim();
        window.history.replaceState({}, '', `/@${cleanName}`);
        handleSelectProducer(cleanName);
        return;
      }
      if (path.startsWith('/profile/')) {
        const pName = decodeURIComponent(path.split('/')[2]);
        const cleanName = pName.replace(/^@/, '').toLowerCase().trim();
        window.history.replaceState({}, '', `/@${cleanName}`);
        handleSelectProducer(cleanName);
        return;
      }
      if (path.startsWith('/playlist/')) {
        const plId = path.split('/')[2];
        setSelectedPlaylistId(plId);
        setCurrentPage('playlist-details');
        return;
      }
      if (path === '/payment/success') {
        setCurrentPage('payment-success');
        return;
      }
      if (path === '/payment/cancelled') {
        setCurrentPage('payment-cancelled');
        return;
      }
      if (path === '/all-beats') {
        setCurrentPage('all-beats');
        return;
      }
      if (path === '/producers') {
        setCurrentPage('producers');
        return;
      }
      if (path === '/rankings') {
        setCurrentPage('producer-rankings');
        return;
      }
      if (path === '/feed') {
        setCurrentPage('feed');
        return;
      }
      if (path === '/licensing') {
        setCurrentPage('licensing');
        return;
      }
      if (path === '/termos') {
        setCurrentPage('termos');
        return;
      }
      if (path === '/dashboard') {
        setCurrentPage('dashboard');
        return;
      }
      if (path === '/messages') {
        setCurrentPage('messages');
        return;
      }
      if (path === '/notifications') {
        setCurrentPage('notifications');
        return;
      }
      if (path === '/') {
        setCurrentPage('home');
        return;
      }

      // Query parameter fallbacks
      const params = new URLSearchParams(window.location.search);
      const beatIdParam = params.get('beat');
      if (beatIdParam) {
        const decodedParam = decodeURIComponent(beatIdParam);
        const foundBeat = globalBeats.find(b => 
          ((b as any).slug && (b as any).slug === decodedParam) ||
          slugify(b.title) === decodedParam ||
          String(b.id) === decodedParam
        );
        if (foundBeat) {
          setSelectedBeat(foundBeat);
          setCurrentPage('beat-details');
          return;
        }
      }

      const producerParam = params.get('producer');
      if (producerParam) {
        const decodedParam = decodeURIComponent(producerParam).replace(/^@/, '').toLowerCase().trim();
        const found = activeProducers.find(p => p.name.toLowerCase() === decodedParam || (p.username && p.username.toLowerCase() === decodedParam));
        const finalUsername = found?.username || decodedParam;
        window.history.replaceState({}, '', `/@${finalUsername}`);
        handleSelectProducer(finalUsername);
        return;
      }

      const playlistParam = params.get('playlist');
      if (playlistParam) {
        setSelectedPlaylistId(playlistParam);
        setCurrentPage('playlist-details');
        return;
      }
    };

    if (!initialRouteChecked.current) {
      handleUrlChange();
      initialRouteChecked.current = true;
    }

    window.addEventListener('popstate', handleUrlChange);
    return () => window.removeEventListener('popstate', handleUrlChange);
  }, [globalBeats, activeProducers]);

  const refreshBeats = async (forceBypass = false) => {
    // High stability session caching: limit API re-fetches during page navigation within 30 seconds
    if (!forceBypass && globalBeats.length > 0 && (Date.now() - lastFetchRef.current < 30000)) {
      console.log('Using active memory cache for beats (throttled within 30s)');
      return;
    }
    console.log('FETCH START');
    const supabase = getSupabase();
    if (!supabase) {
      console.warn('Supabase not configured during global fetch - initializing with empty listings');
      setGlobalBeats([]);
      lastFetchRef.current = Date.now();
      refreshProducers([]);
      return;
    }
    try {
      const { data: beatsDataRaw, error: beatsError } = await supabase.from('beats').select('id, producer_id, title, category, bpm, genre, tags, price_basic, price_premium, price_exclusive, cover_url, demo_url, status, artist_name, plays_count, created_at, updated_at, featured, featured_at, featured_priority');
      const beatsData = beatsDataRaw as any[] | null;
      const { data: profilesData } = await supabase.from('profiles').select('id, display_name, artistic_name, username, avatar_url');
      
      // Fetch persistent live play counts from local Node server memory/disk cache
      let backendPlaysMap: Record<string, number> = {};
      try {
        backendPlaysMap = await playService.loadPlayCounts();
        console.log('[APP PLAY SYNC] Loaded up-to-date play counts:', backendPlaysMap);
      } catch (playFetchErr) {
        console.warn('Could not fetch plays count from backend:', playFetchErr);
      }

      const profileMap = new Map((profilesData || []).map(p => [
        p.id,
        {
          name: p.artistic_name || p.display_name || 'Produtor',
          username: p.username || '',
          avatar_url: p.avatar_url || ''
        }
      ]));
      
      console.log('SUPABASE DATA:', beatsData);
      console.log('SUPABASE ERROR:', beatsError);
      
      if (beatsError || !beatsData || beatsData.length === 0) {
        if (beatsError) {
          console.error('Error fetching global beats:', beatsError);
        } else {
          console.log('Database returned empty beats list');
        }
        setGlobalBeats([]);
        refreshProducers([]);
      } else {
        // Fetch auxiliary data for trending/popular score calculations safely
        let orderItems: any[] = [];
        let orders: any[] = [];
        let favorites: any[] = [];

        try {
          const { data: oItems } = await supabase.from('order_items').select('beat_id, order_id, orders(status)');
          if (oItems) {
            orderItems = oItems.filter((item: any) => 
              ['paid', 'completed', 'concluido', 'sucesso'].includes(String(item.orders?.status || '').toLowerCase())
            );
          }
        } catch (e) {
          console.warn('Could not fetch order_items for ranking:', e);
        }

        try {
          const { data: ords } = await supabase.from('orders').select('id, created_at');
          if (ords) orders = ords;
        } catch (e) {
          console.warn('Could not fetch orders for ranking:', e);
        }

        try {
          const { data: favs } = await supabase.from('favorites').select('beat_id');
          if (favs) favorites = favs;
        } catch (e) {
          console.warn('Could not fetch favorites for ranking:', e);
        }

        // Get local interaction stats from localStorage
        let localPlays: any[] = [];
        let localCartAdds: any[] = [];
        try {
          const storedPlays = localStorage.getItem('beatangola_beat_plays');
          if (storedPlays) localPlays = JSON.parse(storedPlays);
        } catch (e) {}
        try {
          const storedAdds = localStorage.getItem('beatangola_cart_additions');
          if (storedAdds) localCartAdds = JSON.parse(storedAdds);
        } catch (e) {}

        const now = Date.now();
        const orderDateMap = new Map(orders.map(o => [o.id, new Date(o.created_at).getTime()]));

        // Compile mapped beats with rich statistics & score
        const mapped = (beatsData || []).map(b => {
          const profileInfo = profileMap.get(b.producer_id);
          let producerName = typeof profileInfo === 'object' && profileInfo !== null ? profileInfo.name : (b.producer_name || b.artist_name || 'Produtor');
          const producerUsername = typeof profileInfo === 'object' && profileInfo !== null ? profileInfo.username : '';
          const producerAvatarUrl = typeof profileInfo === 'object' && profileInfo !== null ? profileInfo.avatar_url : '';
          
          if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producerName)) {
            producerName = 'Produtor';
          }

          // 1. Likes/Favorites score: +10 points per favorite
          const beatFavsCount = favorites.filter(f => {
            const fId = String(f.beat_id);
            const bId = String(b.id);
            if (fId === bId) return true;
            if (fId.startsWith('00000000-0000-0000-0000-')) {
              const cleaned = fId.split('-')[4].replace(/^0+/, '');
              return cleaned === bId;
            }
            return false;
          }).length;
          const likesScore = beatFavsCount * 10;

          // 2. Sales Score: +30 points per sale. Recent weighting: +20 for last 7d, +10 for last 30d
          const beatSales = orderItems.filter(item => item.beat_id === b.id || item.beat_id === Number(b.id));
          let salesScore = beatSales.length * 30;
          beatSales.forEach(sale => {
            const ordTime = orderDateMap.get(sale.order_id);
            if (ordTime) {
              const ageMs = now - ordTime;
              if (ageMs <= 7 * 24 * 3600 * 1000) {
                salesScore += 20;
              } else if (ageMs <= 30 * 24 * 3600 * 1000) {
                salesScore += 10;
              }
            }
          });

          // 3. Play Score: +5 points for within 7 days, +1 point for older plays
          const beatPlays = localPlays.filter(play => play.id === b.id);
          let playScore = 0;
          beatPlays.forEach(play => {
            const time = play.playedAt || play.time || 0;
            if (now - time <= 7 * 24 * 3600 * 1000) {
              playScore += 5;
            } else {
              playScore += 1;
            }
          });

          // 4. Cart Additions Score: +15 points for within 7 days, +5 points for older additions
          const beatAdds = localCartAdds.filter(add => add.id === b.id);
          let cartScore = 0;
          beatAdds.forEach(add => {
            const time = add.addedAt || add.time || 0;
            if (now - time <= 7 * 24 * 3600 * 1000) {
              cartScore += 15;
            } else {
              cartScore += 5;
            }
          });

          // 5. Upload Recency / Freshness Score:
          let recencyScore = 0;
          const uploadTime = b.created_at ? new Date(b.created_at).getTime() : 0;
          if (uploadTime > 0) {
            const ageDays = (now - uploadTime) / (24 * 3600 * 1000);
            if (ageDays <= 3) {
              recencyScore += 40;
            } else if (ageDays <= 7) {
              recencyScore += 25;
            } else if (ageDays <= 30) {
              recencyScore += 10;
            }
          }

          const totalScore = likesScore + salesScore + playScore + cartScore + recencyScore;

          let extractedKey = b.key;
          let extractedScale = b.scale;
          if (b.tags && Array.isArray(b.tags)) {
            const kt = b.tags.find((t: string) => t.startsWith('_key:'));
            if (kt) extractedKey = kt.split(':')[1];
            const st = b.tags.find((t: string) => t.startsWith('_scale:'));
            if (st) extractedScale = st.split(':')[1];
          }
          const cleanTags = b.tags ? b.tags.filter((t: string) => !t.startsWith('_key:') && !t.startsWith('_scale:')) : [];

          return {
            id: b.id,
            title: b.title,
            producer: producerName,
            producer_name: producerName,
            producer_id: b.producer_id,
            producer_username: producerUsername,
            producer_avatar: producerAvatarUrl || '',
            genre: b.genre,
            price: {
              basic: b.price_basic || 0,
              premium: b.price_premium || 0,
              exclusive: b.price_exclusive || 0
            },
            is_free_download: b.is_free_download || b.price_basic === 0 || b.price_basic === null || b.price_basic === undefined,
            demo_url: b.demo_url ? (b.demo_url.startsWith('http') ? b.demo_url : getPublicUrl('beats', b.demo_url)) : '',
            master_url: b.master_url ? (b.master_url.startsWith('http') ? b.master_url : getPublicUrl('beats', b.master_url)) : '',
            image: b.cover_url ? (b.cover_url.startsWith('http') ? b.cover_url : getPublicUrl('beats', b.cover_url)) : '',
            audioUrl: b.demo_url ? (b.demo_url.startsWith('http') ? b.demo_url : getPublicUrl('beats', b.demo_url)) : (b.master_url ? (b.master_url.startsWith('http') ? b.master_url : getPublicUrl('beats', b.master_url)) : ''),
            audio_url: b.demo_url ? (b.demo_url.startsWith('http') ? b.demo_url : getPublicUrl('beats', b.demo_url)) : (b.master_url ? (b.master_url.startsWith('http') ? b.master_url : getPublicUrl('beats', b.master_url)) : ''),
            bpm: b.bpm || 0,
            type: b.category && (
              b.category === 'Drum Kit' || 
              b.category === 'Loop Kit' || 
              b.category === 'drum-kit' || 
              b.category === 'loop-kit' || 
              b.category === 'sample-pack' || 
              b.category.toLowerCase().includes('kit') || 
              b.category.toLowerCase().includes('pack')
            ) ? 'kit' : (b.type || 'beat'),
            category: b.category,
            plays_count: backendPlaysMap[String(b.id)] || b.plays_count || 0,
            created_at: b.created_at,
            score: totalScore,
            key: extractedKey || 'C',
            scale: extractedScale || 'Maior',
            tags: cleanTags,
            featured: b.featured === true || adminStore.isFeatured('beat', String(b.id)),
            featured_at: b.featured_at || null,
            featured_priority: b.featured_priority || 0
          };
        });

        // Sort descending by score to highlight Trending Beats first!
        const sortedBeats = mapped.sort((a, b) => (b.score || 0) - (a.score || 0));

        console.log('SETTING BEATS (RANKED):', sortedBeats);
        setGlobalBeats(sortedBeats);
        lastFetchRef.current = Date.now();
        refreshProducers(sortedBeats);
      }
    } catch (err) {
      console.error('Failed to load global beats:', err);
    }
  };

  const refreshProducers = async (currentBeats = globalBeats) => {
    const supabase = getSupabase();
    if (!supabase) {
      console.warn('Supabase not configured during producers fetch');
      setActiveProducers([]);
      return;
    }
    try {
      // Query profiles table
      const { data: rawData, error } = await supabase
        .from('profiles')
        .select('id, username, display_name, artistic_name, full_name, role, is_producer, avatar_url, banner_url, socials, city, bio, updated_at, phone, is_featured, featured, is_verified');

      if (error) {
        console.error('Error fetching dynamic producers:', error);
        setActiveProducers([]);
        return;
      }

      // Filter profiles representing producers: strictly require seller/producer/admin role or is_producer, excluding clients, empty accounts, and email names.
      console.log("====================================================");
      console.log("📊 [LOGS TEMPORÁRIOS - SEPARAÇÃO DE CONTAS - PRODUTORES CARREGADOS (APP)]");
      (rawData || []).forEach((p: any) => {
        const pBeats = (currentBeats || []).filter((b: any) => b.producer_id === p.id);
        const totalBeats = pBeats.length;

        const displayName = p.display_name || p.artistic_name || p.full_name || '';
        const hasEmailName = displayName.includes('@') || (p.username && p.username.includes('@'));

        let isMatched = false;
        let rejectReason = "";

        if (hasEmailName) {
          rejectReason = "Nome de email genérico";
        } else if (totalBeats === 0) {
          rejectReason = "Sem beats publicados";
        } else if (p.role === 'client' || p.role === 'artist' || p.role === 'admin' || !p.role) {
          rejectReason = `Role inválido (${p.role || 'vazio'}) para produtores`;
        } else {
          isMatched = p.role === 'seller' || p.role === 'producer' || p.is_producer === true;
          if (!isMatched) {
            rejectReason = `Não é produtor oficial (${p.role})`;
          }
        }

        console.log(`👤 ID: ${p.id} | USERNAME: ${p.username || 'n/a'} | ROLE: ${p.role || 'n/a'} | TOTAL BEATS: ${totalBeats} | DECISÃO: ${isMatched ? '✅ INCLUÍDO' : '❌ EXCLUÍDO (' + rejectReason + ')'}`);
      });
      console.log("====================================================");

      const data = (rawData || []).filter((p: any) => {
        const pBeats = (currentBeats || []).filter((b: any) => b.producer_id === p.id);
        const totalBeats = pBeats.length;

        // 1. Must have at least 1 beat published
        if (totalBeats === 0) {
          return false;
        }

        // 2. Must not be empty account (without public display name / artistic name / username / full name)
        const displayName = (p.display_name || p.artistic_name || p.full_name || '').trim();
        const username = p.username || '';
        if (!displayName && !username) {
          return false;
        }

        // 3. Must not show emails as public names
        const mainName = p.artistic_name || p.display_name || p.full_name || p.username || '';
        const hasEmailName = mainName.includes('@') || username.includes('@');
        if (hasEmailName) {
          return false;
        }

        // Any profile that has at least 1 published beat is a producer regardless of their role
        return true;
      });

      if (data && data.length > 0) {
        // Fetch auxiliary data for producer ranking safely and concurrently
        let orderItems: any[] = [];
        let favorites: any[] = [];
        let databaseFollowers: any[] = [];
        let databasePlays: any[] = [];

        try {
          const { data: oItems } = await supabase.from('order_items').select('id, producer_id, beat_id, orders(status)');
          if (oItems) {
            orderItems = oItems.filter((item: any) => 
              ['paid', 'completed', 'concluido', 'sucesso'].includes(String(item.orders?.status || '').toLowerCase())
            );
          }
        } catch (e) {
          console.warn('Could not fetch order_items for producer ranking:', e);
        }

        try {
          const { data: favs } = await supabase.from('favorites').select('beat_id');
          if (favs) favorites = favs;
        } catch (e) {
          console.warn('Could not fetch favorites for producer ranking:', e);
        }

        try {
          const { data: fDB } = await supabase.from('followers').select('follower_id, following_id');
          if (fDB) databaseFollowers = fDB;
        } catch (e) {
          console.warn('Could not fetch followers relationship table:', e);
        }

        try {
          const { data: playsDB } = await supabase.from('beat_plays').select('beat_id');
          if (playsDB) databasePlays = playsDB;
        } catch (e) {
          console.warn('Could not fetch beat_plays relationship table:', e);
        }

        let databasePlaylists: any[] = [];
        let databasePlaylistBeats: any[] = [];
        let rPlayEvents: any[] = [];

        try {
          const { data: playlistsDB } = await supabase.from('playlists').select('id, title');
          if (playlistsDB) databasePlaylists = playlistsDB;
        } catch (e) {
          console.warn('Could not fetch playlists:', e);
        }

        try {
          const { data: playlistBeatsDB } = await supabase.from('playlist_beats').select('playlist_id, beat_id');
          if (playlistBeatsDB) databasePlaylistBeats = playlistBeatsDB;
        } catch (e) {
          console.warn('Could not fetch playlist_beats:', e);
        }

        try {
          const { data: peDB } = await supabase.from('play_events').select('producer_id, created_at');
          if (peDB) rPlayEvents = peDB;
        } catch (e) {
          console.warn('Could not fetch play_events:', e);
        }

        const now = Date.now();
        const dateSeed = new Date().getDate(); // soft rotation seed updates daily

        const mapped: Producer[] = data.map(p => {
          // Find beats uploaded by this producer
          const pBeats = currentBeats.filter(b => b.producer_id === p.id);
          const pBeatIds = pBeats.map(b => b.id);
          // Extract unique genres
          const genres = Array.from(new Set(pBeats.map(b => b.genre))).filter(Boolean) as string[];
 
          // Format premium Portuguese dates: e.g. "Julho de 2024" or "Janeiro de 2024"
          let formattedJoin = 'Janeiro 2024';
          if (p.updated_at) {
            try {
              const dt = new Date(p.updated_at);
              const mName = dt.toLocaleDateString('pt-AO', { month: 'long' });
              const capitalizedMName = mName.charAt(0).toUpperCase() + mName.slice(1);
              formattedJoin = `${capitalizedMName} de ${dt.getFullYear()}`;
            } catch (err) {
              console.error('Date parsing err:', err);
            }
          }

          let ext: any = {};
          if (p.phone && p.phone.startsWith('{')) {
            try {
              ext = JSON.parse(p.phone);
            } catch (err) {
              console.error('Failed to parse dynamic features metadata on mount', err);
            }
          }

          const nameValue = p.artistic_name || p.display_name || p.full_name || p.username || 'Produtor';
          const bioValue = ext.bio || p.bio || '';
          const taglineValue = '';
          const bannerValue = ext.banner_url || '';
          const genresValue = ext.genres && ext.genres.length > 0 ? ext.genres : (genres.length > 0 ? genres : ['Beats']);
          const locationValue = p.city || ext.location || 'Luanda, Angola';

          // --- RANKING SYSTEM CALCULATIONS ---
          
          // 1. Sales count points (+20 points per sale)
          const producerSalesCount = orderItems.filter(item => item.producer_id === p.id).length;
          const salesScore = producerSalesCount * 20;

          // 2. Followers count points (+10 points per follower)
          // Look up followers of this specific seller/producer inside the followers relationship table or fall back to follow notifications
          const followersCount = databaseFollowers.filter(item => item.following_id === p.id).length;
          const followersScore = followersCount * 10;

          // 3. Beat likes points (+5 points per favorite on any of their beats)
          const stringBeatIds = pBeatIds.map(String);
          const totalLikesCount = favorites.filter(fav => {
            const favId = String(fav.beat_id);
            if (stringBeatIds.includes(String(favId))) return true;
            if (favId.startsWith('00000000-0000-0000-0000-')) {
              const cleaned = favId.split('-')[4].replace(/^0+/, '');
              return stringBeatIds.includes(String(cleaned));
            }
            return false;
          }).length;
          const likesScore = totalLikesCount * 5;

          // 4. Beat play counts from database plays table (+0.5 points per play)
          // Filter beat plays records which are matching this producer's uploaded beats list
          const playsCount = databasePlays.filter(play => pBeatIds.includes(play.beat_id)).length;
          const playsScore = playsCount * 0.5;

          // 5. Upload count inventory points (+2 points per uploaded beat)
          const inventoryScore = pBeats.length * 2;

          // 6. Recent activity/upload freshness
          let uploadRecencyScore = 0;
          pBeats.forEach(beat => {
            if (beat.created_at) {
              const ageMs = now - new Date(beat.created_at).getTime();
              if (ageMs <= 7 * 24 * 3600 * 1000) {
                uploadRecencyScore = Math.max(uploadRecencyScore, 15);
              } else if (ageMs <= 30 * 24 * 3600 * 1000) {
                uploadRecencyScore = Math.max(uploadRecencyScore, 8);
              }
            }
          });

          // 7. Profile completeness checklist boost (up to 25 points total)
          let completenessScore = 0;
          // Custom Avatar uploaded (not missing or generic default)
          if (p.avatar_url && !p.avatar_url.includes('placeholder') && !p.avatar_url.includes('default')) {
            completenessScore += 5;
          }
          // Custom Banner uploaded (not default unsplash placeholder)
          if (ext.banner_url || (p.banner_url && !p.banner_url.includes('photo-1598488035139'))) {
            completenessScore += 5;
          }
          // Custom Bio is filled and not default string
          if (p.bio && p.bio.trim() !== '') {
            completenessScore += 10;
          }
          // Custom Social channels
          if (ext.instagram_url || ext.youtube_url || ext.twitter_url || ext.website_url) {
            completenessScore += 5;
          }

          // 8. Admin manual feature prioritization support (+1000 priority score)
          const isAdminFeatured = p.is_featured === true || p.featured === true || ext.is_featured === true || adminStore.isFeatured('producer', p.id);
          const adminFeaturedScore = isAdminFeatured ? 1000 : 0;

          // 9. Freshness cycle rotation offset (0 to 14 points, changes daily per producer)
          const idNum = parseInt(String(p.id).substring(0, 8), 16) || 0;
          const dailyRotationScore = (idNum + dateSeed) % 15;

          const totalProducerScore = salesScore + followersScore + likesScore + playsScore + inventoryScore + uploadRecencyScore + completenessScore + adminFeaturedScore + dailyRotationScore;

          const usernameValue = p.username || `user${String(p.id).replace(/[^a-z0-9]/gi, '').toLowerCase().substring(0, 6)}`;

          // A: Compute real weekly and monthly growth using play_events!
          const pPlayEvents = rPlayEvents.filter(pe => pe.producer_id === p.id);
          const totalPeCount = pPlayEvents.length;
          const sevenDaysAgo = now - 7 * 24 * 3600 * 1000;
          const thirtyDaysAgo = now - 30 * 24 * 3600 * 1000;

          const weeklyRealPlays = pPlayEvents.filter(pe => new Date(pe.created_at).getTime() > sevenDaysAgo).length;
          const monthlyRealPlays = pPlayEvents.filter(pe => new Date(pe.created_at).getTime() > thirtyDaysAgo).length;

          const prevWeekly = totalPeCount - weeklyRealPlays;
          const prevMonthly = totalPeCount - monthlyRealPlays;

          let computedWeeklyGrowth = 0;
          if (prevWeekly > 0) {
            computedWeeklyGrowth = +((weeklyRealPlays / prevWeekly) * 100).toFixed(1);
          } else if (weeklyRealPlays > 0) {
            computedWeeklyGrowth = 100.0;
          }

          let computedMonthlyGrowth = 0;
          if (prevMonthly > 0) {
            computedMonthlyGrowth = +((monthlyRealPlays / prevMonthly) * 100).toFixed(1);
          } else if (monthlyRealPlays > 0) {
            computedMonthlyGrowth = 100.0;
          }

           // B: Compute real top playlist title by joining playlist_beats & playlists
          let computedTopPlaylistTitle = 'Nenhuma Playlist';
          const associatedPlaylistIds = databasePlaylistBeats
            .filter(pb => pBeatIds.includes(pb.beat_id))
            .map(pb => pb.playlist_id);

          const playlistInclusionsCount = new Set(associatedPlaylistIds).size;

          const pbCounts: { [key: string]: number } = {};
          associatedPlaylistIds.forEach(id => {
            pbCounts[id] = (pbCounts[id] || 0) + 1;
          });

          let bestPlId = '';
          let maxCount = 0;
          Object.entries(pbCounts).forEach(([id, count]) => {
            if (count > maxCount) {
              maxCount = count;
              bestPlId = id;
            }
          });

          const foundPl = databasePlaylists.find(pl => pl.id === bestPlId);
          if (foundPl) {
            computedTopPlaylistTitle = foundPl.title;
          }

          const producerObj: Producer = {
            id: p.id,
            name: nameValue,
            username: usernameValue,
            tagline: taglineValue,
            bio: bioValue,
            avatar: p.avatar_url || '',
            banner: bannerValue,
            followers: followersCount,
            totalBeats: pBeats.length,
            totalPlays: String(playsCount),
            isVerified: p.is_verified === true,
            location: locationValue,
            joinDate: formattedJoin,
            genres: genresValue,
            score: totalProducerScore,
            is_featured: isAdminFeatured,
            salesCount: producerSalesCount,
            topPlaylistTitle: computedTopPlaylistTitle,
            weeklyGrowth: computedWeeklyGrowth,
            monthlyPlaysGrowth: computedMonthlyGrowth,
            playlistCount: playlistInclusionsCount,
            socials: {
              instagram: ext.instagram_url || '',
              youtube: ext.youtube_url || '',
              twitter: ext.twitter_url || '',
              web: ext.website_url || ''
            }
          };

          const stats = calculatePremiumProducerStats(producerObj, currentBeats);
          producerObj.score = stats.score;
          return producerObj;
        });

        // Dynamic sorting: unified global ranking logic. Sort strictly by premium system score DESC.
        const sorted = mapped.sort((a, b) => {
          return (b.score || 0) - (a.score || 0);
        });
        setActiveProducers(sorted);
      } else {
        console.log('No seller profiles found in database');
        setActiveProducers([]);
      }
    } catch (err) {
      console.error('Failed to load sellers dynamically:', err);
      setActiveProducers([]);
    }
  };

  useEffect(() => {
    refreshBeats();
  }, [user]);

  useEffect(() => {
    const handleForceRefresh = () => {
      console.log('[APP] Custom event "beatangola_force_refresh_beats" received. Triggering forced, cache-bypass refetch of all beats/kits.');
      refreshBeats(true);
    };
    window.addEventListener('beatangola_force_refresh_beats', handleForceRefresh);
    return () => {
      window.removeEventListener('beatangola_force_refresh_beats', handleForceRefresh);
    };
  }, []);

  useEffect(() => {
    if (currentPage === 'home' || currentPage === 'all-beats' || currentPage === 'producers') {
      refreshBeats();
    }
  }, [currentPage]);

  useEffect(() => {
    console.log('CURRENT STATE:', globalBeats);
  }, [globalBeats]);

  // Redirect logged in users from home page to their respective dashboard/explore page
  useEffect(() => {
    if (user && !loading && currentPage === 'home') {
      const activeRole = profile?.role || 'buyer';
      if (activeRole === 'buyer' || activeRole === 'buy' || activeRole === 'client' || activeRole === 'artist') {
        setCurrentPage('all-beats');
      } else {
        setCurrentPage('dashboard');
      }
    }
  }, [user, profile, loading, currentPage]);

  // Basic connectivity check - only run once on mount to check server status
  useEffect(() => {
    const checkServerHealth = async (retries = 3) => {
      try {
        const origin = window.location.origin && window.location.origin !== 'null' ? window.location.origin : '';
        const url = `${origin}/api/health?_t=${Date.now()}`;
        console.log(`Checking server health status at: ${url}`);
        const res = await fetch(url, { cache: 'no-store' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        console.log('Server health check successful:', data);
      } catch (err: any) {
        if (retries > 0) {
          console.log(`Server health check status: temporary failure, retrying in 2s... (${retries} retries left)`);
          setTimeout(() => checkServerHealth(retries - 1), 2000);
        } else {
          console.groupCollapsed('Server Health Status (Note)');
          console.info('Server check status inactive. This is normal in sandboxed previews:', err.message);
          console.groupEnd();
        }
      }
    };

    // Wait 1.5 seconds after launch to ensure server is fully initialized and listening
    const timer = setTimeout(() => {
      checkServerHealth();
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const handleStartSelling = () => {
    if (user) {
      setCurrentPage('dashboard');
    } else {
      openAuth('signup');
    }
  };

  const openAuth = (mode: 'login' | 'signup') => {
    console.log("App: openAuth called with mode:", mode);
    setAuthMode(mode);
    setIsAuthOpen(true);
  };
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentBeat, setCurrentBeat] = useState<Beat | null>(null);
  const [audio] = useState(new Audio());
  const [trackedPlays, setTrackedPlays] = useState<Set<string>>(new Set());

  // Listen to secure play-tracking updates broadcasted globally
  useEffect(() => {
    const handleBeatPlayTracked = (e: any) => {
      const { beatId, playsCount } = e.detail || {};
      if (!beatId) return;

      console.log(`[APP PLAY TRACKING SYNC] Synced plays count for beat ${beatId} to: ${playsCount}`);
      
      // Keep playService cache in visual sync
      playService.forceSetPlayCount(beatId, playsCount);

      setGlobalBeats(prev => 
        prev.map(b => b.id === beatId ? { ...b, plays_count: playsCount } : b)
      );
      
      setCurrentBeat(prev => 
        prev && prev.id === beatId ? { ...prev, plays_count: playsCount } : prev
      );
    };

    window.addEventListener('beatPlayTracked' as any, handleBeatPlayTracked);
    return () => {
      window.removeEventListener('beatPlayTracked' as any, handleBeatPlayTracked);
    };
  }, []);

  // Listen for live activity play requests from the SocialActivityFeed
  useEffect(() => {
    const handleSelectBeatPlay = (e: any) => {
      const targetId = String(e.detail?.beatId);
      if (!targetId || !globalBeats || globalBeats.length === 0) return;
      
      const targetBeat = globalBeats.find((b: any) => String(b.id) === targetId || String(b.raw_id) === targetId || String(b.beat_id) === targetId);
      if (targetBeat) {
        console.log('[SOCIAL ACTIVITY FEED] Triggering automatic play for beat:', targetBeat.title);
        handlePlay(targetBeat);
      }
    };

    window.addEventListener('selectBeatPlay' as any, handleSelectBeatPlay as any);
    return () => {
      window.removeEventListener('selectBeatPlay' as any, handleSelectBeatPlay as any);
    };
  }, [globalBeats, isPlaying]);

  const handlePlay = (beat: Beat) => {
    // Debug mandatory logging
    console.log('AUDIO URL:', beat.audio_url || beat.audioUrl);

    const isKit = beat.type === 'kit' || (beat.category && (beat.category === 'Drum Kit' || beat.category === 'Loop Kit' || beat.category === 'drum-kit' || beat.category === 'loop-kit' || beat.category === 'sample-pack' || beat.category.toLowerCase().includes('kit') || beat.category.toLowerCase().includes('pack')));
    if (isKit) {
      console.warn('Skipping playback: Kits do not have audio preview.');
      return;
    }

    if (currentBeat?.id === beat.id) {
      if (isPlaying) {
        audio.pause();
        setIsPlaying(false);
      } else {
        audio.play().catch(e => console.warn("Playback interrupted:", e));
        setIsPlaying(true);
      }
    } else {
      audio.src = beat.audio_url || beat.audioUrl;
      audio.play().catch(e => console.warn("Playback interrupted:", e));
      setCurrentBeat(beat);
      setIsPlaying(true);
    }
  };

  const handleClosePlayer = () => {
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    audio.currentTime = 0;
    setCurrentBeat(null);
    setIsPlaying(false);
  };



  const addToCart = (beat: Beat) => {
    if (cart.find(item => item.id === beat.id)) {
      showToast('Este item já está no teu carrinho.', 'info', 'Carrinho');
      return;
    }

    // Record cart addition for trending score
    try {
      const stored = localStorage.getItem('beatangola_cart_additions');
      const additions = stored ? JSON.parse(stored) : [];
      additions.push({ id: beat.id, addedAt: Date.now() });
      if (additions.length > 500) additions.shift();
      localStorage.setItem('beatangola_cart_additions', JSON.stringify(additions));
      
      setTimeout(() => {
        refreshBeats();
      }, 500);
    } catch (e) {
      console.warn('Failed tracking cart addition:', e);
    }

    // Track professional analytics add_to_cart event
    try {
      import('@/src/lib/analytics').then(m => {
        m.trackAnalyticsEvent('add_to_cart', {
          producerId: beat.producer_id,
          beatId: beat.id,
          userId: user?.id || undefined,
          amount: Number((beat as any).price_basic || (beat as any).price_premium || (beat as any).price_exclusive || beat.price || 0)
        });
      });
    } catch (err) {
      console.error("[ANALYTICS] Add to cart tracking error:", err);
    }

    setCart([...cart, beat]);
    showToast(`"${beat.title}" foi adicionado ao teu carrinho.`, 'success', 'Item Adicionado');
  };

  const removeFromCart = (beatId: string) => {
    setCart(cart.filter(item => item.id !== beatId));
  };

  if (loading) {
    return <InstagramLoader fullScreen />;
  }

  return (
    <div className="min-h-screen bg-[#000000] text-slate-100 relative overflow-x-hidden">
        {/* Cinematic & Premium Afro-inspired Music Studio Background Atmosphere */}
        {currentPage === 'home' && (
          <div className="absolute top-0 left-0 right-0 h-[100vh] z-0 pointer-events-none select-none overflow-hidden" id="homepage-premium-atmos-bg">
            {/* LAYER 1: Full-screen Studio Image - Visually clear mixing board with warm, golden studio lights */}
            <div 
              className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000 ${
                heroBgLoaded ? 'opacity-[0.40]' : 'opacity-0'
              }`}
              style={{ 
                backgroundImage: "url('/hero-bg.webp')",
                filter: 'brightness(0.92) contrast(1.05) saturate(0.80)'
              }}
            />
            
            {/* LAYER 2: Airbit-style High-Contrast Left-to-Right Dark Overlay (perfect text contrast on the left, open window on the right) */}
            <div 
              className="absolute inset-0" 
              style={{
                background: 'linear-gradient(to right, rgba(0, 0, 0, 0.82) 0%, rgba(0, 0, 0, 0.65) 50%, rgba(0, 0, 0, 0.48) 100%)'
              }}
            />
            
            {/* LAYER 3: Discrete subtle glow highlight */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(217,119,6,0.03),transparent_50%)] pointer-events-none" />
            
            {/* LAYER 4: Smooth transition fading down to pitch-black to seamlessly merge with body sections */}
            <div className="absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-black via-black/80 to-transparent" />
          </div>
        )}

        {!isAuthOpen && (
            <Navbar 
              cartCount={cart.length} 
              onOpenCart={() => setIsCartOpen(true)} 
              onOpenAuth={openAuth} 
              onExplore={() => changePage('all-beats')} 
              onProducers={() => changePage('producers')} 
              onFeed={() => changePage('feed')}
              onGoDashboard={() => changePage('dashboard')} 
              onGoAdmin={() => changePage('admin-payouts')}
              onSignOut={() => changePage('home')}
              onHome={() => changePage('home')}
              onOpenMessages={() => changePage('messages')}
              onOpenNotifications={() => changePage('notifications')}
              onOpenLicensing={() => changePage('licensing')}
              onRankings={() => changePage('producer-rankings')}
              unreadCount={unreadCount}
              currentPage={currentPage}
            />
        )}
        
        <main className={`${currentPage === 'dashboard' ? 'w-full max-w-none px-0' : 'max-w-7xl mx-auto px-4'} ${isAuthOpen ? '' : currentPage === 'dashboard' ? 'pb-0' : 'pt-32 pb-12'} relative z-10`}>
          {!isAuthOpen ? (
            <Suspense fallback={<PremiumPageSkeleton />}>
              {currentPage === 'home' ? (
                <HomeContent 
                  beats={globalBeats}
                  producers={activeProducers}
                  handlePlay={handlePlay} 
                  addToCart={addToCart} 
                  currentBeat={currentBeat} 
                  isPlaying={isPlaying} 
                  onExplore={(genreId) => {
                    const params = new URLSearchParams(window.location.search);
                    if (genreId && typeof genreId === 'string') {
                      params.set('genre', genreId);
                      window.history.pushState({}, '', `${window.location.pathname}?${params.toString()}`);
                    } else {
                      params.delete('genre');
                      const newSearch = params.toString();
                      const cleanUrl = newSearch ? `${window.location.pathname}?${newSearch}` : window.location.pathname;
                      window.history.pushState({}, '', cleanUrl);
                    }
                    setCurrentPage('all-beats');
                  }}
                  onSelectProducer={handleSelectProducer}
                  onStartSelling={handleStartSelling}
                  onSelectBeat={handleSelectBeat}
                  onSelectPlaylist={(pId) => {
                    setSelectedPlaylistId(pId);
                    setCurrentPage('playlist-details');
                    window.history.pushState({}, '', `/playlist/${pId}`);
                  }}
                  onRankings={() => changePage('producer-rankings')}
                />
              ) : currentPage === 'producer-rankings' ? (
                <ErrorBoundary name="Rankings de Produtores">
                  <ProducersRankingPage 
                    producers={activeProducers}
                    beats={globalBeats}
                    onSelectProducer={(pName) => handleSelectProducer(pName)}
                    onBack={() => changePage('home')}
                  />
                </ErrorBoundary>
              ) : currentPage === 'admin-payouts' ? (
                (loading) ? <div>A carregar...</div>
                : (() => {
                    console.log('ADMIN CHECK:', {
                      isAdmin,
                      user,
                      role: user?.role,
                      email: user?.email
                    });
                    return (
                      <ErrorBoundary name="Administração de Payouts">
                        <AdminPayoutManagement />
                      </ErrorBoundary>
                    );
                  })()
              ) : currentPage === 'admin-finance' ? (
                (loading) ? <div>A carregar...</div>
                : (() => {
                    console.log('ADMIN CHECK:', {
                      isAdmin,
                      user,
                      role: user?.role,
                      email: user?.email
                    });
                    return (
                      <ErrorBoundary name="Painel Financeiro Admin">
                        <AdminFinancialDashboard />
                      </ErrorBoundary>
                    );
                  })()
              ) : currentPage === 'dashboard' ? (
                <ErrorBoundary name="Painel de Controlo do Produtor">
                  <DashboardPage 
                    beats={globalBeats}
                    handlePlay={handlePlay}
                    addToCart={addToCart}
                    currentBeat={currentBeat}
                    isPlaying={isPlaying}
                    onSelectProducer={handleSelectProducer}
                    onSelectBeat={handleSelectBeat}
                  />
                </ErrorBoundary>
              ) : currentPage === 'all-beats' ? (
                <ErrorBoundary name="Catálogo de Beats">
                  <AllBeatsPage 
                    beats={globalBeats}
                    producers={activeProducers}
                    handlePlay={handlePlay} 
                    addToCart={addToCart} 
                    currentBeat={currentBeat} 
                    isPlaying={isPlaying} 
                    onBack={() => changePage('home')}
                    onSelectProducer={handleSelectProducer}
                    onSelectBeat={handleSelectBeat}
                  />
                </ErrorBoundary>
              ) : currentPage === 'producers' ? (
                <ErrorBoundary name="Diretório de Produtores">
                  <ProducersPage 
                    producers={activeProducers}
                    onSelectProducer={(p) => handleSelectProducer(p.username || p.name)}
                  />
                </ErrorBoundary>
              ) : currentPage === 'feed' ? (
                <ErrorBoundary name="Feed do Usuário">
                  <FeedPage 
                    onExplore={() => changePage('all-beats')}
                    onProducers={() => changePage('producers')}
                    onOpenAuth={openAuth}
                    beats={globalBeats}
                    handlePlay={handlePlay}
                    currentBeat={currentBeat}
                    isPlaying={isPlaying}
                    onSelectProducer={handleSelectProducer}
                    onSelectBeat={handleSelectBeat}
                  />
                </ErrorBoundary>
              ) : currentPage === 'producer-profile' ? (
                <ErrorBoundary name="Perfil do Produtor">
                  <ProducerProfilePage
                    producer={selectedProducer!}
                    beats={globalBeats}
                    onBack={handleBackFromProducer}
                    onBackDashboard={() => changePage('dashboard')}
                    onPlay={handlePlay}
                    isPlaying={isPlaying}
                    currentBeat={currentBeat}
                    onOpenAuth={openAuth}
                    onMessage={(recipientId) => {
                      console.log("[APP DEBUG] onMessage callback invoked from ProducerProfilePage. Recipient (Producer) ID:", recipientId);
                      setMessageRecipientId(recipientId);
                      changePage('messages');
                    }}
                    onAddToCart={addToCart}
                    onUpdateProducer={(updated) => {
                      setSelectedProducer(updated);
                      setActiveProducers(prev => prev.map(p => p.id === updated.id ? updated : p));
                    }}
                    onSelectBeat={handleSelectBeat}
                  />
                </ErrorBoundary>
              ) : currentPage === 'beat-details' ? (
                <ErrorBoundary name="Detalhes do Beat">
                  <BeatDetailsPage
                    beat={selectedBeat!}
                    beats={globalBeats}
                    isPlaying={isPlaying}
                    currentBeat={currentBeat}
                    onPlay={handlePlay}
                    onAddToCart={addToCart}
                    onSelectProducer={handleSelectProducer}
                    onSelectBeat={handleSelectBeat}
                    onBack={handleBackFromBeatDetails}
                  />
                </ErrorBoundary>
              ) : currentPage === 'playlist-details' ? (
                <div className="bg-white/[0.01] border border-white/5 rounded-[2rem] p-6 backdrop-blur-3xl min-h-[400px]">
                  <ErrorBoundary name="Playlist Digital">
                    <PlaylistDetailsPage
                      playlistId={selectedPlaylistId!}
                      beats={globalBeats}
                      onBack={() => {
                        changePage('home');
                      }}
                      onPlay={handlePlay}
                      isPlaying={isPlaying}
                      currentBeat={currentBeat}
                      onAddToCart={addToCart}
                    />
                  </ErrorBoundary>
                </div>
              ) : currentPage === 'messages' ? (
                <ErrorBoundary name="Chat de Mensagens">
                  <MessagesPage 
                    onBack={() => changePage('home')} 
                    targetUserId={messageRecipientId}
                    clearTargetUserId={() => setMessageRecipientId(null)}
                    onSelectUser={(userId) => {
                      console.log("[MESSAGES NAVIGATION] Loading profile for clicked user ID:", userId);
                      handleSelectProducer(userId);
                    }}
                  />
                </ErrorBoundary>
              ) : currentPage === 'notifications' ? (
                <ErrorBoundary name="Notificações">
                  <NotificationsPage />
                </ErrorBoundary>
              ) : currentPage === 'licensing' ? (
                <ErrorBoundary name="Licenciamento">
                  <LicensingPage onBack={() => changePage('home')} onOpenAuth={openAuth} />
                </ErrorBoundary>
              ) : currentPage === 'payment-success' ? (
                <ErrorBoundary name="Página de Sucesso">
                  <PaymentSuccessPage 
                    onGoToLibrary={() => {
                      if (typeof window !== 'undefined') {
                        localStorage.setItem('artist_dashboard_tab', 'Biblioteca');
                      }
                      changePage('dashboard');
                    }}
                    onGoToDashboard={() => changePage('dashboard')}
                  />
                </ErrorBoundary>
              ) : currentPage === 'payment-cancelled' ? (
                <ErrorBoundary name="Página de Cancelamento">
                  <PaymentCancelledPage 
                    onGoToExplore={() => changePage('all-beats')}
                    onGoToDashboard={() => changePage('dashboard')}
                  />
                </ErrorBoundary>
              ) : currentPage === 'termos' ? (
                <ErrorBoundary name="Termos de Uso">
                  <TermosPage onBack={() => changePage('home')} />
                </ErrorBoundary>
              ) : (
                <div />
              )}
            </Suspense>
          ) : null}
        </main>

        {!isAuthOpen && (
          <>
            <Player 
              currentBeat={currentBeat} 
              isPlaying={isPlaying} 
              onTogglePlay={() => handlePlay(currentBeat!)} 
              audioElement={audio}
              onClose={handleClosePlayer}
              globalBeats={globalBeats}
              onPlayBeat={handlePlay}
            />
            <Cart 
              isOpen={isCartOpen} 
              onClose={() => setIsCartOpen(false)} 
              cartItems={cart} 
              onRemoveItem={removeFromCart} 
              isAuthenticated={!!user}
              onOpenAuth={openAuth}
              onCheckoutSuccess={() => {
                setCart([]);
                setCurrentPage('dashboard');
              }}
            />
            <Footer />
          </>
        )}
        
        <CheckoutModal />
        <AddToPlaylistModal />
        
        <AuthModal 
          isOpen={isAuthOpen} 
          onClose={() => setIsAuthOpen(false)} 
          initialMode={authMode} 
          onNavigateToTerms={() => {
            setIsAuthOpen(false);
            setCurrentPage('termos');
          }}
          onAuthSuccess={(role) => {
            console.log("App: onAuthSuccess received with role:", role);
            if (role === 'buyer' || role === 'buy') {
              console.log("App: Redirecting to all-beats");
              setCurrentPage('all-beats');
            } else {
              console.log("App: Redirecting to dashboard");
              setCurrentPage('dashboard');
            }
            setIsAuthOpen(false); // Explicitly close just in case
          }} 
        />
      </div>
  );
}

