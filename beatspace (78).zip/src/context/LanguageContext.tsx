import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'pt' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, defaultText?: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  pt: {
    // Navbar
    'nav.explore': 'Explorar',
    'nav.trending': 'Trending',
    'nav.rankings': 'Rankings',
    'nav.producers': 'Produtores',
    'nav.upload': 'Upload',
    'nav.dashboard': 'Dashboard',
    'nav.adminPanel': 'Painel Admin',
    'nav.logout': 'Sair',
    'nav.login': 'Entrar',
    'nav.signup': 'Criar Conta',
    'nav.navigation': 'Navegação',
    'nav.accountAndUtils': 'Conta & Utilitários',
    'nav.myCart': 'Meu Carrinho',
    'nav.notifications': 'Notificações',
    'nav.messages': 'Mensagens',
    'nav.logoutLong': 'Sair da Conta',
    'nav.producerPortal': 'PORTAL DO PRODUTOR',
    'nav.artistDashboard': 'DASHBOARD DO ARTISTA',
  },
  en: {
    // Navbar
    'nav.explore': 'Explore',
    'nav.trending': 'Trending',
    'nav.rankings': 'Rankings',
    'nav.producers': 'Producers',
    'nav.upload': 'Upload',
    'nav.dashboard': 'Dashboard',
    'nav.adminPanel': 'Admin Panel',
    'nav.logout': 'Logout',
    'nav.login': 'Login',
    'nav.signup': 'Sign Up',
    'nav.navigation': 'Navigation',
    'nav.accountAndUtils': 'Account & Utilities',
    'nav.myCart': 'My Cart',
    'nav.notifications': 'Notifications',
    'nav.messages': 'Messages',
    'nav.logoutLong': 'Logout Account',
    'nav.producerPortal': 'PRODUCER PORTAL',
    'nav.artistDashboard': 'ARTIST DASHBOARD',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('beatangola_language') as Language;
      if (stored === 'pt' || stored === 'en') {
        return stored;
      }
    }
    return 'pt';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('beatangola_language', lang);
    console.log('[LANGUAGE] Changed to:', lang);
    // Dispatch a custom event for any non-context listeners
    window.dispatchEvent(new CustomEvent('language_changed', { detail: lang }));
  };

  const t = (key: string, defaultText?: string): string => {
    const translation = translations[language]?.[key];
    return translation || defaultText || key;
  };

  useEffect(() => {
    console.log('[BOOT] Language loaded (active:', language, ')');
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
