import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { X, CheckCircle, AlertCircle, Info, Bell, AlertTriangle, Loader2 } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info' | 'notification' | 'warning' | 'loading';

interface Toast {
  id: string;
  message: string;
  type: ToastType;
  title?: string;
  duration?: number;
}

interface ToastContextType {
  showToast: (message: string, type: ToastType, title?: string, duration?: number) => void;
  dismissToast: (id: string) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback((message: string, type: ToastType, title?: string, duration?: number) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type, title, duration }]);
    
    // Default duration is 5000ms, except for loading which defaults to 10000ms unless customized
    const finalDuration = duration || (type === 'loading' ? 10000 : 5000);
    
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, finalDuration);
  }, []);

  return (
    <ToastContext.Provider value={{ showToast, dismissToast }}>
      {children}
      <div className="fixed bottom-32 md:bottom-10 right-6 z-[200] flex flex-col gap-3 pointer-events-none w-full max-w-sm">
        <AnimatePresence mode="popLayout">
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              layout
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9, transition: { duration: 0.2 } }}
              className="pointer-events-auto"
            >
              <ToastItem toast={toast} onRemove={() => dismissToast(toast.id)} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used within a ToastProvider');
  return context;
}

function ToastItem({ toast, onRemove }: { toast: Toast; onRemove: () => void }) {
  const icons = {
    success: <CheckCircle className="text-emerald-400" size={20} />,
    error: <AlertCircle className="text-rose-400" size={20} />,
    info: <Info className="text-blue-400" size={20} />,
    notification: <Bell className="text-indigo-400" size={20} />,
    warning: <AlertTriangle className="text-amber-500" size={20} />,
    loading: <Loader2 className="text-indigo-500 animate-spin" size={20} />
  };

  const bgColors = {
    success: 'bg-[#000000]/95 border-emerald-500/25 shadow-[0_4px_30px_rgba(16,185,129,0.06)]',
    error: 'bg-[#000000]/95 border-rose-500/25 shadow-[0_4px_30px_rgba(244,63,94,0.06)]',
    info: 'bg-[#000000]/95 border-blue-500/25 shadow-[0_4px_30px_rgba(59,130,246,0.06)]',
    notification: 'bg-[#000000]/95 border-indigo-500/25 shadow-[0_4px_30px_rgba(99,102,241,0.06)]',
    warning: 'bg-[#000000]/95 border-amber-500/25 shadow-[0_4px_30px_rgba(245,158,11,0.06)]',
    loading: 'bg-[#000000]/95 border-indigo-500/25 shadow-[0_4px_30px_rgba(99,102,241,0.06)]'
  };

  const durationSec = (toast.duration || (toast.type === 'loading' ? 10000 : 5000)) / 1000;

  return (
    <div className={`relative flex items-start gap-4 p-5 rounded-[1.5rem] border backdrop-blur-3xl shadow-2xl ${bgColors[toast.type]} group overflow-hidden`}>
      {/* Dynamic Background Radial Glow */}
      <div className={`absolute top-0 right-0 w-32 h-32 blur-[50px] opacity-25 -z-10 transition-opacity duration-300 ${
        toast.type === 'success' ? 'bg-emerald-500' : 
        toast.type === 'error' ? 'bg-rose-500' : 
        toast.type === 'info' ? 'bg-blue-500' : 
        toast.type === 'warning' ? 'bg-amber-500' : 
        'bg-indigo-500'
      }`} />
      
      <div className="flex-shrink-0 mt-0.5">
        {icons[toast.type]}
      </div>
      
      <div className="flex-grow pr-5">
        {toast.title && (
          <h4 className="text-xs font-black text-white italic uppercase tracking-widest mb-1.5 font-sans">
            {toast.title}
          </h4>
        )}
        <p className="text-xs text-gray-300 font-semibold leading-relaxed">
          {toast.message}
        </p>
      </div>

      <button 
        onClick={onRemove}
        className="absolute top-5 right-5 text-gray-500 hover:text-white transition-colors cursor-pointer"
      >
        <X size={14} />
      </button>

      {/* Progress Bar timer animation */}
      {toast.type !== 'loading' && (
        <motion.div 
          initial={{ width: '100%' }}
          animate={{ width: '0%' }}
          transition={{ duration: durationSec, ease: 'linear' }}
          className={`absolute bottom-0 left-0 h-[3px] ${
            toast.type === 'success' ? 'bg-emerald-500 animate-pulse' : 
            toast.type === 'error' ? 'bg-rose-500 animate-pulse' : 
            toast.type === 'info' ? 'bg-blue-500 animate-pulse' : 
            toast.type === 'warning' ? 'bg-amber-500 animate-pulse' : 
            'bg-indigo-500'
          }`}
        />
      )}
    </div>
  );
}
