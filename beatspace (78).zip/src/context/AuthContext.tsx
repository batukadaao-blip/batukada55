import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { getSupabase } from '../lib/supabase';
import { mapDbToClient } from '../lib/profileMapper';

interface Profile {
  id: string;
  role: string;
  display_name: string;
  artistic_name?: string | null;
  username?: string | null;
  avatar_url?: string | null;
  city?: string | null;
  bio?: string | null;
  phone?: string | null;
  created_at?: string | null;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  refreshProfile: () => Promise<void>;
  setProfile: React.Dispatch<React.SetStateAction<Profile | null>>;
}

const AuthContext = createContext<AuthContextType>({ 
  user: null, 
  session: null, 
  profile: null, 
  loading: true, 
  refreshProfile: async () => {},
  setProfile: () => {}
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, _setProfile] = useState<Profile | null>(null);
  const setProfile = React.useCallback((value: React.SetStateAction<Profile | null>) => {
    _setProfile((prev) => {
      const resolved = typeof value === 'function' ? (value as any)(prev) : value;
      console.log("AUTH SETPROFILE CALLED:", resolved);
      return resolved;
    });
  }, []);

  useEffect(() => {
    console.log("AUTH PROFILE STATE:", profile);
    console.log("BIO AUTHCONTEXT VALUE:", profile?.bio);
  }, [profile]);

  const [loading, setLoading] = useState(true);

  const fetchProfile = async (userId: string, userEmail?: string | null, authUser?: any) => {
    const supabase = getSupabase();
    if (!supabase) return;
    
    console.log('[AUTH] Fetching profile...');
    console.log("AUTH CONTEXT: Fetching profile for", userId, "with email", userEmail);
    console.log("AUTH CONTEXT: Raw authUser metadata:", authUser?.user_metadata, "app_metadata:", authUser?.app_metadata);
    try {
      console.log("AUTH CONTEXT: Querying profiles table...");
      let { data: profileData, error } = await supabase
        .from('profiles')
        .select('id, role, display_name, artistic_name, username, avatar_url, city, bio, phone, created_at')
        .eq('id', userId)
        .maybeSingle();

      if (error && (error.message?.includes('bio') || error.message?.includes('schema cache') || error.hint?.includes('bio') || error.code === 'PGRST204' || error.code === 'PGRST100')) {
        console.warn("AUTH CONTEXT: Missing 'bio' column or schema cache mismatch. Retrying select query without 'bio'...");
        const retryResult = await supabase
          .from('profiles')
          .select('id, role, display_name, artistic_name, username, avatar_url, city, phone, created_at')
          .eq('id', userId)
          .maybeSingle();
        profileData = retryResult.data as any;
        error = retryResult.error;
        if (profileData) {
          (profileData as any).bio = null;
        }
      }

      if (error) throw error;
      console.log("AUTH CONTEXT: Raw Supabase profiles query result:", profileData);

      let finalProfile = profileData as Profile | null;
      if (!finalProfile) {
        const metadataRole = authUser?.user_metadata?.account_type || authUser?.user_metadata?.role || authUser?.app_metadata?.role || 'buyer';
        console.log("AUTH CONTEXT: Profile does not exist inside profiles table, using fallback metadataRole:", metadataRole);
        finalProfile = {
          id: userId,
          role: metadataRole,
          display_name: userEmail?.split('@')[0] || 'Utilizador',
          artistic_name: null,
          username: null
        };
      } else {
        // Unpack bio from phone JSON field if direct bio property is empty/null/missing
        if (finalProfile.phone && finalProfile.phone.startsWith('{')) {
          try {
            const parsed = JSON.parse(finalProfile.phone);
            if (parsed && parsed.bio && !finalProfile.bio) {
              finalProfile.bio = parsed.bio;
              console.log("AUTH CONTEXT: Successfully unpacked bio from packed phone metadata JSON:", finalProfile.bio);
            }
          } catch (e) {
            console.error("AUTH CONTEXT: XML/JSON parse error in fallback unpacking:", e);
          }
        }

        // Safe check: if display_name is empty, null, or contains an email address, sanitize it
        const namePart = finalProfile.artistic_name || finalProfile.display_name;
        if (!namePart || namePart.includes('@')) {
          const fallbackName = (finalProfile.username && !finalProfile.username.includes('@')) 
            ? finalProfile.username 
            : (userEmail?.split('@')[0] || 'Utilizador');
          finalProfile.display_name = fallbackName;
        }
      }

      // Extremely robust: prioritize admin fallback if metadata displays role as admin, or user is in official admin list
      const emailLower = userEmail?.toLowerCase()?.trim() || '';
      const metaRole = authUser?.user_metadata?.account_type || authUser?.user_metadata?.role || authUser?.app_metadata?.role;
      if (
        metaRole === 'admin' || 
        emailLower === 'dieluxpista@gmail.com' ||
        emailLower === 'miguelfranciscoalfredo24@gmail.com' ||
        emailLower === 'domingosdejesusk@gmail.com' ||
        finalProfile.role === 'admin'
      ) {
        console.log("AUTH CONTEXT: Ensuring finalProfile role is set to admin");
        finalProfile.role = 'admin';

        // SELF-HEALING DB SYNC: If the database role is not 'admin' yet, sync it so RLS permits queries
        if (profileData && profileData.role !== 'admin') {
          console.log("AUTH CONTEXT [SELF-HEALING]: DB role is mismatching, promoting to admin in database...");
          supabase
            .from('profiles')
            .update({ role: 'admin' })
            .eq('id', userId)
            .then(({ error: syncErr }) => {
              if (syncErr) {
                console.error("AUTH CONTEXT [SELF-HEALING]: Could not update database profiles role:", syncErr);
              } else {
                console.log("AUTH CONTEXT [SELF-HEALING]: DB role promoted and synchronized!");
              }
            });
        }
      }

      const activeRole = finalProfile?.role;
      console.log("AUTH CONTEXT: Final resolved user role:", activeRole);
      
      if (activeRole) {
        localStorage.setItem('beatangola_user_role', activeRole);
      }

      if (error) {
        console.error("AUTH CONTEXT: Error fetching profile", error);
        console.log('[AUTH] Profile fetch failed:', error);
      } else {
        console.log("AUTH CONTEXT: Profile loaded", finalProfile);
        console.log('[AUTH] Profile fetch success');
      }
      setProfile(finalProfile);
    } catch (e) {
      console.error("AUTH CONTEXT: Network or client runtime crash fetching profile:", e);
      console.log('[AUTH] Profile fetch failed:', e);
      const fallbackRole = authUser?.user_metadata?.account_type || authUser?.user_metadata?.role || authUser?.app_metadata?.role || localStorage.getItem('beatangola_user_role') || 'buyer';
      // Fallback profile if database suffers a structural or server failure
      setProfile({
        id: userId,
        role: fallbackRole,
        display_name: userEmail?.split('@')[0] || 'Utilizador'
      });
    }
  };

  useEffect(() => {
    const handleAuthChange = () => {
      const supabase = getSupabase();
      if (!supabase) {
        try {
          const demoSessionStr = localStorage.getItem('beatangola_demo_session');
          if (demoSessionStr) {
            const demoData = JSON.parse(demoSessionStr);
            setUser(demoData.user);
            setSession(demoData.session);
            
            let demoProfile = demoData.profile;
            setProfile(demoProfile);
          } else {
            setUser(null);
            setSession(null);
            setProfile(null);
          }
        } catch (e) {
          console.error("Failed to load local sandbox session:", e);
        }
        setLoading(false);
      }
    };

    const supabase = getSupabase();
    if (!supabase) {
      handleAuthChange();
      window.addEventListener('auth_state_change', handleAuthChange);
      return () => {
        window.removeEventListener('auth_state_change', handleAuthChange);
      };
    }

    // Race getSession with a timeout to catch and prevent getting stuck in a pending promise during network/iframe blocks
    const sessionPromise = supabase.auth.getSession();
    const timeoutPromise = new Promise<{ data: { session: null }, error: Error }>((resolve) => {
      setTimeout(() => {
        resolve({ 
          data: { session: null }, 
          error: new Error('Auth session recovery timed out (Failed to fetch / network block)') 
        });
      }, 2500);
    });

    console.log('[AUTH] Initiating Auth Session recovery...');
    Promise.race([sessionPromise, timeoutPromise])
      .then(async ({ data: { session }, error }) => {
        if (error) {
          console.error("AuthContext: Error or timeout from getSession:", error);
          const errStr = error.message?.toLowerCase() || '';
          if (
            errStr.includes('refresh_token') ||
            errStr.includes('refresh token') ||
            errStr.includes('not found') ||
            errStr.includes('invalid_grant') ||
            errStr.includes('timeout') ||
            errStr.includes('fetch') ||
            (error as any).status === 400
          ) {
            console.warn("AuthContext: Resetting state due to auth token mismatch, network block, or timeout.");
            // Clear all auth-token and session storage keys manually to prevent future loops or corruption
            for (const key of Object.keys(localStorage)) {
              if (key.includes('auth-token') || key.includes('sb-') || key.includes('beatangola_')) {
                localStorage.removeItem(key);
              }
            }
            setSession(null);
            setUser(null);
            setProfile(null);
            setLoading(false);
            return;
          }
        }

        console.log('[AUTH] Session:', session);
        console.log('[AUTH] User:', session?.user ?? null);

        setSession(session);
        setUser(session?.user ?? null);
        if (session?.user) {
          await fetchProfile(session.user.id, session.user.email, session.user);
        } else {
          setProfile(null);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching Supabase session (top-level):', err);
        console.log('[AUTH] Session: null');
        console.log('[AUTH] User: null');
        setLoading(false);
      });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log("AuthContext: onAuthStateChange event:", event);
      console.log('[AUTH] Session:', session);
      console.log('[AUTH] User:', session?.user ?? null);
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id, session.user.email, session.user);
      } else {
        setProfile(null);
        localStorage.removeItem('beatangola_user_role');
      }

      // Handle custom local notification triggered when session is terminated or updated
      if (event === 'SIGNED_OUT') {
        console.warn("User has logged out. Ensuring tab states are pruned.");
        // Notify other components
        window.dispatchEvent(new Event('user_session_expired'));
      }
    });

    // Multi-tab Session Sync Safety: handle changes to the auth token in local storage from other tabs
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key && e.key.includes('auth-token')) {
        console.log("Multi-tab auth state update detected, syncing active session.");
        supabase.auth.getSession().then(({ data: { session: freshSession }, error }) => {
          if (error) {
            console.error("Multi-tab session retrieval error:", error);
            return;
          }
          setSession(freshSession);
          setUser(freshSession?.user ?? null);
          if (freshSession?.user) {
            fetchProfile(freshSession.user.id, freshSession.user.email, freshSession.user);
          } else {
            setProfile(null);
          }
        });
      }
    };
    window.addEventListener('storage', handleStorageChange);

    return () => {
      subscription.unsubscribe();
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id, user.email, user);
    }
  };

  // Keep localStorage caches updated automatically from the single source of truth (profile)
  useEffect(() => {
    if (profile) {
      try {
        const clientProfile = mapDbToClient(profile as any);
        localStorage.setItem('user_profile', JSON.stringify(clientProfile));
        localStorage.setItem('artistProfile', JSON.stringify(clientProfile));
        localStorage.setItem('producerProfile', JSON.stringify(clientProfile));
      } catch (e) {
        console.warn("AuthContext profile sync error:", e);
      }
    } else {
      localStorage.removeItem('user_profile');
      localStorage.removeItem('artistProfile');
      localStorage.removeItem('producerProfile');
    }
  }, [profile]);

  useEffect(() => {
    if (!loading) {
      console.log('[BOOT] Auth loaded');
    }
  }, [loading]);

  useEffect(() => {
    console.log('[BOOT] User resolved', user?.id || 'null');
  }, [user]);

  return <AuthContext.Provider value={{ user, session, profile, loading, refreshProfile, setProfile }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
