/**
 * Conversor de texto para slugs amigáveis de URL (SEO-friendly slugs).
 * Exemplo: "Origins Loop Kit" -> "origins-loop-kit"
 */
export function slugify(text: string | null | undefined): string {
  if (!text) return '';
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD') // Normaliza acentuações (ex: é -> e, ã -> a)
    .replace(/[\u0300-\u036f]/g, '') // Remove marcas de diacríticos
    .trim()
    .replace(/[^\w\s-]/g, '') // Remove caracteres especiais não alfanuméricos
    .replace(/\s+/g, '-') // Substitui espaços por hífen
    .replace(/--+/g, '-'); // Remove hífens duplicados
}
