import { Beat, Producer } from '../types';
import { getSupabase } from './supabase';

/**
 * Robust, highly performant Smart Discovery and Recommendation Engine for Batukada.
 * Avoids heavy backend queries by operating on smart array matches, caching,
 * and lightweight in-memory scoring.
 */

export interface InteractionEvent {
  id: string;
  type: 'click' | 'play' | 'favorite' | 'download' | 'purchase';
  beat_id: string;
  user_id?: string;
  timestamp: string;
}

const LOCAL_FAVORITES_KEY = 'batukada_local_favorites';
const RECOMMENDER_TRACKING_KEY = 'batukada_recommendation_analytics';

export const recommendationService = {
  // --------------------------------------------------
  // SCORING LOGIC & ENGAGEMENT RANKING
  // --------------------------------------------------
  
  /**
   * Calculates a granular engagement score for a beat.
   * This is used to drive the Trending, Hot, and Recommended feeds.
   */
  calculateEngagementScore(beat: Beat): number {
    const plays = beat.plays_count || 0;
    const isFeatured = beat.featured ? 500 : 0;
    const priority = beat.featured_priority || 0;
    
    // Score weight formulas
    const playPoints = plays * 1.5;
    const priorityPoints = priority * 3.0;
    
    // Support and conversion multiplier (if free download, extra engagement)
    const downloadBonus = beat.is_free_download ? 150 : 0;
    
    return Math.round(100 + playPoints + priorityPoints + isFeatured + downloadBonus);
  },

  /**
   * Sorts and returns beats by calculated engagement scores
   */
  getEngagementRankedBeats(beats: Beat[]): Beat[] {
    return [...beats].map(beat => ({
      ...beat,
      score: this.calculateEngagementScore(beat)
    })).sort((a, b) => (b.score || 0) - (a.score || 0));
  },

  // --------------------------------------------------
  // TRENDING SERVICE
  // --------------------------------------------------

  /**
   * Retrieves high-velocity beats trending today. Adds organic volatility filters focusing on last 24h.
   */
  getTrendingToday(beats: Beat[]): Beat[] {
    const now = Date.now();
    const scoredBeats = [...beats].map(beat => {
      const rawDate = (beat as any).last_played_at || (beat as any).updated_at || beat.created_at;
      const beatDate = rawDate ? new Date(rawDate) : new Date(now - 3 * 24 * 3600 * 1000);
      const diffMs = now - beatDate.getTime();
      const diffHours = Math.max(0, diffMs / (1000 * 60 * 60));
      
      const baseScore = this.calculateEngagementScore(beat);
      const plays = beat.plays_count || 0;
      const likes = (beat as any).likes_count || 0;
      const engagement = plays * 1.5 + likes * 4.0;
      
      // Strict 24h decay: high importance on beats posted today
      const recencyToday = Math.exp(-diffHours / 24.0);
      const trendingScore = (baseScore + engagement) * (1.0 + recencyToday * 3.0);
      
      return { beat, score: trendingScore };
    });

    return scoredBeats
      .sort((a, b) => b.score - a.score)
      .map(item => item.beat)
      .slice(0, 6);
  },

  /**
   * Retrieves high-velocity beats trending this week focusing on last 7 days.
   */
  getTrendingThisWeek(beats: Beat[]): Beat[] {
    const now = Date.now();
    const scoredBeats = [...beats].map(beat => {
      const rawDate = (beat as any).last_played_at || (beat as any).updated_at || beat.created_at;
      const beatDate = rawDate ? new Date(rawDate) : new Date(now - 7 * 24 * 3600 * 1000);
      const diffMs = now - beatDate.getTime();
      const diffDays = Math.max(0, diffMs / (1000 * 60 * 60 * 24));
      
      const baseScore = this.calculateEngagementScore(beat);
      const plays = beat.plays_count || 0;
      const likes = (beat as any).likes_count || 0;
      const engagement = plays * 1.5 + likes * 4.0;
      
      // 7 days decay: wider window decay
      const recencyWeek = Math.exp(-diffDays / 7.0);
      const trendingScore = (baseScore + engagement) * (1.0 + recencyWeek * 1.5);
      
      return { beat, score: trendingScore };
    });

    return scoredBeats
      .sort((a, b) => b.score - a.score)
      .map(item => item.beat)
      .slice(0, 6);
  },

  /**
   * Most Played Beats
   */
  getMostPlayed(beats: Beat[]): Beat[] {
    return [...beats]
      .sort((a, b) => (b.plays_count || 0) - (a.plays_count || 0))
      .slice(0, 8);
  },

  /**
   * Most Saved Beats - uses a mix of scoring, local storage, and database features
   */
  getMostSaved(beats: Beat[]): Beat[] {
    // Incorporates score & featured priorities
    return [...beats]
      .sort((a, b) => {
        const scoreA = (a.score || 0) + (a.featured ? 100 : 0);
        const scoreB = (b.score || 0) + (b.featured ? 100 : 0);
        return scoreB - scoreA;
      })
      .slice(0, 8);
  },

  /**
   * Renders the hot producers list with high activity score, calculated over their tracks
   */
  getHotProducers(producers: Producer[], beats: Beat[]): Array<Producer & { score: number; trendRating: number }> {
    return producers.map(p => {
      const pBeats = beats.filter(b => 
        b.producer_id === p.id || 
        (b.producer && b.producer.toLowerCase() === p.name.toLowerCase())
      );
      
      // Calculate average and sum metrics
      const totalPlays = pBeats.reduce((sum, b) => sum + (b.plays_count || 0), 0);
      const avgScore = pBeats.length > 0 
        ? pBeats.reduce((sum, b) => sum + this.calculateEngagementScore(b), 0) / pBeats.length
        : 100;
        
      const followersBoost = (p.followers || 0) * 15;
      const combinedScore = Math.round(avgScore + (totalPlays * 0.5) + followersBoost);
      
      return {
        ...p,
        score: combinedScore,
        trendRating: 0
      };
    }).sort((a, b) => b.score - a.score);
  },

  // --------------------------------------------------
  // CUSTOMER PERSONALIZATION & SMART DISCOVERY
  // --------------------------------------------------

  /**
   * Get user preferences dynamically: reads local storage of favorite beats and likes
   */
  getUserPreferences(beats: Beat[]): { genres: string[]; bpms: number[]; producers: string[] } {
    try {
      // 1. Local likes
      const localLikesRaw = localStorage.getItem(LOCAL_FAVORITES_KEY) || '[]';
      const likedIds: string[] = JSON.parse(localLikesRaw);
      
      // 2. Local play history
      const localHistoryRaw = localStorage.getItem('batukada_recently_played') || '[]';
      const playedIds: string[] = JSON.parse(localHistoryRaw);
      
      const seedIds = Array.from(new Set([...likedIds, ...playedIds]));
      const userBeats = beats.filter(b => seedIds.includes(String(b.id)));
      
      if (userBeats.length === 0) {
        // Return popular defaults as preferences
        return {
          genres: ['Afrobeat', 'Amapiano', 'Kizomba', 'Semba', 'Drill'],
          bpms: [100, 110, 120, 130, 140],
          producers: []
        };
      }
      
      const genres = Array.from(new Set(userBeats.map(b => b.genre).filter(Boolean)));
      const bpms = Array.from(new Set(userBeats.map(b => b.bpm).filter(Boolean)));
      const producers = Array.from(new Set(userBeats.map(b => b.producer).filter(Boolean)));
      
      return { genres, bpms, producers };
    } catch (e) {
      return {
        genres: ['Afrobeat', 'Amapiano', 'Kizomba', 'Semba', 'Drill'],
        bpms: [100, 110, 120, 130, 140],
        producers: []
      };
    }
  },

  /**
   * Recommended Beats: matches user liked genres, tempo, other producers, with high engagement fallback
   */
  getRecommendedBeats(beats: Beat[], limit = 6): Beat[] {
    const prefs = this.getUserPreferences(beats);
    const ranked = this.getEngagementRankedBeats(beats);
    
    // Score matches
    const scored = ranked.map(b => {
      let matchPoints = 0;
      
      // Genre match
      if (prefs.genres.includes(b.genre)) {
        matchPoints += 300;
      }
      
      // BPM similarity matched: +/- 15 BPM
      const bpmMatch = prefs.bpms.some(userBpm => Math.abs(userBpm - b.bpm) <= 15);
      if (bpmMatch) {
        matchPoints += 150;
      }
      
      // Producer match
      if (prefs.producers.includes(b.producer)) {
        matchPoints += 200;
      }
      
      // Add raw engagement score scale
      const totalScore = (b.score || 100) + matchPoints;
      
      return {
        beat: b,
        totalScore
      };
    });
    
    return scored
      .sort((a, b) => b.totalScore - a.totalScore)
      .map(item => item.beat)
      .slice(0, limit);
  },

  /**
   * Similar Beats: Same Genre, BPM proximity (+/- 10), excluding current, with high-quality fallback
   */
  getSimilarBeats(currentBeat: Beat, beats: Beat[], limit = 5): Beat[] {
    const matches = beats.filter(b => String(b.id) !== String(currentBeat.id));
    
    const scored = matches.map(b => {
      let scoreAndMatch = this.calculateEngagementScore(b);
      
      // same genre premium points
      if (b.genre && currentBeat.genre && b.genre.toLowerCase() === currentBeat.genre.toLowerCase()) {
        scoreAndMatch += 500;
      }
      
      // BPM proximity points
      if (b.bpm && currentBeat.bpm) {
        const diff = Math.abs(b.bpm - currentBeat.bpm);
        if (diff <= 8) {
          scoreAndMatch += 300;
        } else if (diff <= 15) {
          scoreAndMatch += 150;
        }
      }
      
      // Same producer points
      if (b.producer && currentBeat.producer && b.producer.toLowerCase() === currentBeat.producer.toLowerCase()) {
        scoreAndMatch += 200;
      }
      
      return { beat: b, score: scoreAndMatch };
    });
    
    return scored
      .sort((a, b) => b.score - a.score)
      .map(item => item.beat)
      .slice(0, limit);
  },

  /**
   * You May Also Like: general recommendation mix
   */
  getYouMayAlsoLike(beats: Beat[], currentPlayingBeat: Beat | null, limit = 6): Beat[] {
    if (currentPlayingBeat) {
      return this.getSimilarBeats(currentPlayingBeat, beats, limit);
    }
    const ranked = this.getEngagementRankedBeats(beats);
    return ranked.slice(0, limit);
  },

  /**
   * More From This Producer: filter other tracks of the same artist
   */
  getMoreFromThisProducer(producerName: string, beats: Beat[], excludeBeatId?: string, limit = 4): Beat[] {
    const cleanProducerName = producerName.toLowerCase().trim();
    
    const producerBeats = beats.filter(b => {
      const isExclude = excludeBeatId && String(b.id) === String(excludeBeatId);
      const matchName = b.producer && b.producer.toLowerCase().includes(cleanProducerName);
      const matchNameAlt = b.producer_name && b.producer_name.toLowerCase().includes(cleanProducerName);
      return !isExclude && (matchName || matchNameAlt);
    });
    
    // Fallback if the producer only has 1 beat: match the same genre
    if (producerBeats.length === 0 && excludeBeatId) {
      const firstBeat = beats.find(b => String(b.id) === String(excludeBeatId));
      if (firstBeat) {
        return beats
          .filter(b => String(b.id) !== String(excludeBeatId) && b.genre === firstBeat.genre)
          .slice(0, limit);
      }
    }
    
    return producerBeats.slice(0, limit);
  },

  /**
   * Discovery Carousele filter: group beats by exact categories for the home dynamic reels
   */
  getCarouselByCategory(beats: Beat[], categoryName: string, limit = 6): Beat[] {
    const cleanCat = categoryName.toLowerCase().trim();
    const matches = beats.filter(b => {
      const matchGenre = b.genre && b.genre.toLowerCase().includes(cleanCat);
      const matchCat = b.category && b.category.toLowerCase().includes(cleanCat);
      return matchGenre || matchCat;
    });
    
    // Sort matching ones by high quality engagement
    return this.getEngagementRankedBeats(matches).slice(0, limit);
  },

  // --------------------------------------------------
  // ANALYTICS TRACKING - PREPARED & EMBEDDED
  // --------------------------------------------------

  trackClick(beatId: string, source: string, userId?: string) {
    try {
      const key = RECOMMENDER_TRACKING_KEY;
      const historyRaw = localStorage.getItem(key) || '[]';
      const history: InteractionEvent[] = JSON.parse(historyRaw);
      
      const event: InteractionEvent = {
        id: 'ev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        type: 'click',
        beat_id: beatId,
        user_id: userId,
        timestamp: new Date().toISOString()
      };
      
      history.push(event);
      if (history.length > 500) history.shift(); // rotate queue
      localStorage.setItem(key, JSON.stringify(history));
      
      // Dispatch analytics tracking natively
      window.dispatchEvent(new CustomEvent('batukada_analytics', {
        detail: { event: 'discovery_interaction', data: { beatId, source, type: 'click' } }
      }));
      
      console.log(`[RECOMMENDER ANALYTICS] Logged engagement tracker: ${source} click for Beat ${beatId}`);
    } catch (e) {
      // safe bypass
    }
  },

  trackConversion(beatId: string, type: 'download' | 'purchase', userId?: string) {
    try {
      const key = RECOMMENDER_TRACKING_KEY;
      const historyRaw = localStorage.getItem(key) || '[]';
      const history: InteractionEvent[] = JSON.parse(historyRaw);
      
      const event: InteractionEvent = {
        id: 'ev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        type: type === 'download' ? 'download' : 'purchase',
        beat_id: beatId,
        user_id: userId,
        timestamp: new Date().toISOString()
      };
      
      history.push(event);
      localStorage.setItem(key, JSON.stringify(history));
      
      window.dispatchEvent(new CustomEvent('batukada_analytics', {
        detail: { event: 'recommendation_conversion', data: { beatId, conversionType: type } }
      }));
    } catch (e) {
      // safe bypass
    }
  }
};
