import { getSupabase } from './supabase';
import { Beat } from '../types';

export interface Playlist {
  id: string;
  user_id: string;
  title: string;
  description: string;
  cover_image?: string;
  is_public: boolean;
  created_at?: string;
  beat_ids?: string[]; // handy local list
}

export interface PlaylistBeat {
  id: string;
  playlist_id: string;
  beat_id: string;
  created_at?: string;
}

// Keep a constant for storage keys
const RECENTLY_PLAYED_KEY = 'batukada_recently_played';
const LOCAL_PLAYLISTS_KEY = 'batukada_local_playlists';
const LOCAL_PLAYLIST_BEATS_KEY = 'batukada_local_playlist_beats';

export const playlistStore = {
  // --- RECENTLY PLAYED ---
  getRecentlyPlayed(): string[] {
    try {
      const stored = localStorage.getItem(RECENTLY_PLAYED_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      console.error('Error reading recently played:', e);
      return [];
    }
  },

  addRecentlyPlayed(beatId: string | number) {
    try {
      const cleanId = String(beatId);
      const list = this.getRecentlyPlayed();
      const updated = [cleanId, ...list.filter(id => id !== cleanId)].slice(0, 10); // limit to last 10
      localStorage.setItem(RECENTLY_PLAYED_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('Error saving recently played:', e);
    }
  },

  // --- PLAYLIST OPERATIONS ---
  async fetchPlaylists(userId: string): Promise<Playlist[]> {
    const supabase = getSupabase();
    if (!supabase) {
      return this.getLocalPlaylists(userId);
    }

    try {
      // 1. Fetch playlists
      const { data: dbPlaylists, error: plError } = await supabase
        .from('playlists')
        .select('*')
        .or(`user_id.eq.${userId},is_public.eq.true`)
        .order('created_at', { ascending: false });

      if (plError) throw plError;

      // 2. Fetch playlist beats mapping
      const { data: dbBeats, error: pbError } = await supabase
        .from('playlist_beats')
        .select('*');

      if (pbError) throw pbError;

      const playlists: Playlist[] = (dbPlaylists || []).map(pl => {
        const beat_ids = (dbBeats || [])
          .filter(b => b.playlist_id === pl.id)
          .map(b => String(b.beat_id));

        return {
          id: String(pl.id),
          user_id: pl.user_id,
          title: pl.title,
          description: pl.description || '',
          cover_image: pl.cover_image || '',
          is_public: pl.is_public,
          created_at: pl.created_at,
          beat_ids
        };
      });

      return playlists;
    } catch (err) {
      console.warn('[PLAYLIST] Supabase query failed. Falling back to clean local playlists:', err);
      return this.getLocalPlaylists(userId);
    }
  },

  getLocalPlaylists(userId: string): Playlist[] {
    try {
      const storedPl = localStorage.getItem(LOCAL_PLAYLISTS_KEY);
      const storedPb = localStorage.getItem(LOCAL_PLAYLIST_BEATS_KEY);

      const playlists: Playlist[] = storedPl ? JSON.parse(storedPl) : [];
      const beats: PlaylistBeat[] = storedPb ? JSON.parse(storedPb) : [];

      // Filter playlists by current user or public ones
      const userPlaylists = playlists.filter(p => p.user_id === userId || p.is_public);

      return userPlaylists.map(pl => {
        const beat_ids = beats
          .filter(b => b.playlist_id === pl.id)
          .map(b => String(b.beat_id));

        return { ...pl, beat_ids };
      });
    } catch (e) {
      console.error('[PLAYLIST] Fail reading local storage:', e);
      return [];
    }
  },

  async createPlaylist(userId: string, title: string, description: string, isPublic: boolean, coverImage?: string): Promise<Playlist> {
    const newId = 'pl_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    const newPlaylist: Playlist = {
      id: newId,
      user_id: userId,
      title,
      description,
      cover_image: coverImage || '',
      is_public: isPublic,
      created_at: new Date().toISOString(),
      beat_ids: []
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('playlists')
          .insert([{
            user_id: userId,
            title,
            description,
            cover_image: coverImage || '',
            is_public: isPublic
          }])
          .select()
          .single();

        if (error) throw error;
        if (data) {
          return {
            id: String(data.id),
            user_id: data.user_id,
            title: data.title,
            description: data.description || '',
            cover_image: data.cover_image || '',
            is_public: data.is_public,
            created_at: data.created_at,
            beat_ids: []
          };
        }
      } catch (e) {
        console.warn('[PLAYLIST] Could not insert playlist in Supabase, using local:', e);
      }
    }

    // fallback / save local
    try {
      const stored = localStorage.getItem(LOCAL_PLAYLISTS_KEY);
      const list: Playlist[] = stored ? JSON.parse(stored) : [];
      list.push(newPlaylist);
      localStorage.setItem(LOCAL_PLAYLISTS_KEY, JSON.stringify(list));
    } catch (e) {
      console.error(e);
    }

    // Register playlist_created social activity
    try {
      const authorProf = JSON.parse(localStorage.getItem('user_profile') || '{}');
      const pName = authorProf.artisticName || authorProf.artistic_name || authorProf.display_name || 'Utilizador';
      const pUsername = authorProf.username || 'utilizador';
      const pAvatar = authorProf.avatarUrl || authorProf.avatar_url || null;

      fetch('/api/activity/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          type: 'playlist_created',
          actor_name: pName,
          actor_username: pUsername,
          actor_avatar: pAvatar,
          target_id: newPlaylist.id,
          target_title: title,
          target_cover: coverImage || '',
          metadata: {
            description
          }
        })
      }).catch(() => {});
    } catch (actErr) {
      console.warn('[PLAYLISTSTORE] Bypassed playlist activity log:', actErr);
    }

    return newPlaylist;
  },

  async updatePlaylist(playlistId: string, title: string, description: string, isPublic: boolean, coverImage?: string): Promise<boolean> {
    const supabase = getSupabase();
    let dbSuccess = false;

    if (supabase) {
      try {
        const numericId = parseInt(playlistId, 10);
        const queryId = isNaN(numericId) ? playlistId : numericId;

        const { error } = await supabase
          .from('playlists')
          .update({
            title,
            description,
            is_public: isPublic,
            cover_image: coverImage || ''
          })
          .eq('id', queryId);

        if (!error) dbSuccess = true;
      } catch (e) {
        console.warn('[PLAYLIST] Supabase update playlist failed:', e);
      }
    }

    // fallback / save local
    try {
      const storedPl = localStorage.getItem(LOCAL_PLAYLISTS_KEY);
      if (storedPl) {
        const list: Playlist[] = JSON.parse(storedPl);
        const updated = list.map(p => {
          if (String(p.id) === String(playlistId)) {
            return {
              ...p,
              title,
              description,
              is_public: isPublic,
              cover_image: coverImage || p.cover_image
            };
          }
          return p;
        });
        localStorage.setItem(LOCAL_PLAYLISTS_KEY, JSON.stringify(updated));
      }
      return true;
    } catch (e) {
      console.error(e);
    }

    return dbSuccess;
  },

  async reorderPlaylistBeats(playlistId: string, beatIds: string[]): Promise<boolean> {
    const supabase = getSupabase();
    let dbSuccess = false;

    if (supabase) {
      try {
        const numericId = parseInt(playlistId, 10);
        const queryId = isNaN(numericId) ? playlistId : numericId;

        // In a rich implementation, we can batch update positions or clean and insert.
        // A simple robust approach is to delete all existing mappings and re-insert in order.
        await supabase.from('playlist_beats').delete().eq('playlist_id', queryId);
        
        const insertData = beatIds.map((bId, idx) => {
          const numericBId = parseInt(bId, 10);
          return {
            playlist_id: queryId,
            beat_id: isNaN(numericBId) ? bId : numericBId,
            position: idx
          };
        });

        const { error } = await supabase
          .from('playlist_beats')
          .insert(insertData);

        if (!error) dbSuccess = true;
      } catch (e) {
        console.warn('[PLAYLIST] Supabase reorder beats failed, will use local sorting fallback:', e);
      }
    }

    // Always sync locally
    try {
      const storedPb = localStorage.getItem(LOCAL_PLAYLIST_BEATS_KEY);
      if (storedPb) {
        let list: PlaylistBeat[] = JSON.parse(storedPb);
        // Remove existing beads of this playlist
        list = list.filter(item => String(item.playlist_id) !== String(playlistId));
        // Add them back in the new sorted order
        const timeOffset = Date.now();
        beatIds.forEach((bId, index) => {
          list.push({
            id: 'pb_' + (timeOffset + index) + '_' + Math.random().toString(36).substr(2, 5),
            playlist_id: playlistId,
            beat_id: bId,
            created_at: new Date().toISOString()
          });
        });
        localStorage.setItem(LOCAL_PLAYLIST_BEATS_KEY, JSON.stringify(list));
      }
      return true;
    } catch (e) {
      console.error(e);
    }

    return dbSuccess;
  },

  async deletePlaylist(playlistId: string): Promise<boolean> {
    const supabase = getSupabase();
    let dbSuccess = false;
    if (supabase) {
      try {
        // Safe cast to number if playlistId is a Database integer id
        const numericId = parseInt(playlistId, 10);
        const queryId = isNaN(numericId) ? playlistId : numericId;

        // Auto backup safety before deleting playlist and mappings
        try {
          const { data: plData } = await supabase.from('playlists').select('*').eq('id', queryId).maybeSingle();
          const { data: beatsData } = await supabase.from('playlist_beats').select('*').eq('playlist_id', queryId);
          if (plData) {
            await fetch('/api/system/backup/playlist', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ playlist: plData, beats: beatsData || [] })
            });
            console.log('[PLAYLIST BACKUP] Created safety backup for playlist:', queryId);
          }
        } catch (bkErr) {
          console.error('[PLAYLIST BACKUP] Failed taking safety backup:', bkErr);
        }

        // Delete dependencies first
        await supabase.from('playlist_beats').delete().eq('playlist_id', queryId);

        const { error } = await supabase
          .from('playlists')
          .delete()
          .eq('id', queryId);

        if (!error) dbSuccess = true;
      } catch (e) {
        console.warn('[PLAYLIST] Supabase delete playlist failed:', e);
      }
    }

    // Always sync locally
    try {
      const storedPl = localStorage.getItem(LOCAL_PLAYLISTS_KEY);
      if (storedPl) {
        const list: Playlist[] = JSON.parse(storedPl);
        const filtered = list.filter(p => String(p.id) !== String(playlistId));
        localStorage.setItem(LOCAL_PLAYLISTS_KEY, JSON.stringify(filtered));
      }

      const storedPb = localStorage.getItem(LOCAL_PLAYLIST_BEATS_KEY);
      if (storedPb) {
        const list: PlaylistBeat[] = JSON.parse(storedPb);
        const filtered = list.filter(b => String(b.playlist_id) !== String(playlistId));
        localStorage.setItem(LOCAL_PLAYLIST_BEATS_KEY, JSON.stringify(filtered));
      }
      return true;
    } catch (e) {
      console.error(e);
    }

    return dbSuccess;
  },

  async addBeatToPlaylist(playlistId: string, beatId: string | number): Promise<boolean> {
    const sBeatId = String(beatId);
    const supabase = getSupabase();
    let dbSuccess = false;

    if (supabase) {
      try {
        const numericPlId = parseInt(playlistId, 10);
        const finalPlId = isNaN(numericPlId) ? playlistId : numericPlId;

        const numericBeatId = parseInt(sBeatId, 10);
        const finalBeatId = isNaN(numericBeatId) ? sBeatId : numericBeatId;

        const { error } = await supabase
          .from('playlist_beats')
          .insert([{
            playlist_id: finalPlId,
            beat_id: finalBeatId
          }]);

        if (!error) dbSuccess = true;
      } catch (e) {
        console.warn('[PLAYLIST] Supabase add beat to playlist failed:', e);
      }
    }

    // fallback/local sync
    try {
      const stored = localStorage.getItem(LOCAL_PLAYLIST_BEATS_KEY);
      const list: PlaylistBeat[] = stored ? JSON.parse(stored) : [];
      
      // Check duplicate
      const hasDuplicate = list.some(item => String(item.playlist_id) === String(playlistId) && String(item.beat_id) === sBeatId);
      if (!hasDuplicate) {
        list.push({
          id: 'pb_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
          playlist_id: playlistId,
          beat_id: sBeatId,
          created_at: new Date().toISOString()
        });
        localStorage.setItem(LOCAL_PLAYLIST_BEATS_KEY, JSON.stringify(list));
      }
      return true;
    } catch (e) {
      console.error(e);
    }

    return dbSuccess;
  },

  async removeBeatFromPlaylist(playlistId: string, beatId: string | number): Promise<boolean> {
    const sBeatId = String(beatId);
    const supabase = getSupabase();
    let dbSuccess = false;

    if (supabase) {
      try {
        const numericPlId = parseInt(playlistId, 10);
        const finalPlId = isNaN(numericPlId) ? playlistId : numericPlId;

        const numericBeatId = parseInt(sBeatId, 10);
        const finalBeatId = isNaN(numericBeatId) ? sBeatId : numericBeatId;

        const { error } = await supabase
          .from('playlist_beats')
          .delete()
          .eq('playlist_id', finalPlId)
          .eq('beat_id', finalBeatId);

        if (!error) dbSuccess = true;
      } catch (e) {
        console.warn('[PLAYLIST] Supabase remove beat from playlist failed:', e);
      }
    }

    // fallback/local sync
    try {
      const stored = localStorage.getItem(LOCAL_PLAYLIST_BEATS_KEY);
      if (stored) {
        const list: PlaylistBeat[] = JSON.parse(stored);
        const filtered = list.filter(item => !(String(item.playlist_id) === String(playlistId) && String(item.beat_id) === sBeatId));
        localStorage.setItem(LOCAL_PLAYLIST_BEATS_KEY, JSON.stringify(filtered));
      }
      return true;
    } catch (e) {
      console.error(e);
    }

    return dbSuccess;
  },

  // --- SMART DISCOVERY SYSTEM & RECOMMENDATIONS ---
  async getSmartDiscovery(globalBeats: Beat[], userId?: string): Promise<{
    trendingNow: Beat[];
    mostPlayed: Beat[];
    newUploads: Beat[];
    recommended: Beat[];
    basedOnLikes: Beat[];
  }> {
    // Sort logic based on actual metrics from our beats scoring algorithm and timestamps
    const sortedByScore = [...globalBeats].sort((a, b) => (b.score || 0) - (a.score || 0));
    
    // 1. Trending Now: Beats with high score, limited to max 6
    const trendingNow = sortedByScore.slice(0, 6);

    // 2. Most Played: Highest score or dynamic sort
    const mostPlayed = [...trendingNow].reverse().slice(0, 6);

    // 3. New Uploads: Sorted by date created
    const newUploads = [...globalBeats].sort((a, b) => {
      const aTime = a.created_at ? new Date(a.created_at).getTime() : 0;
      const bTime = b.created_at ? new Date(b.created_at).getTime() : 0;
      return bTime - aTime;
    }).slice(0, 6);

    // 4. Recommended (highest quality beats sorted by actual ranking scores and plays count)
    const recommended = [...globalBeats].sort((a, b) => {
      const aPlays = a.plays_count || 0;
      const bPlays = b.plays_count || 0;
      if (bPlays !== aPlays) return bPlays - aPlays;
      return (b.score || 0) - (a.score || 0);
    }).slice(0, 6);

    // 5. Based on likes or favorites helper
    let userLikedGenres: string[] = [];
    if (userId) {
      try {
        const supabase = getSupabase();
        if (supabase) {
          const { data: dbFavs } = await supabase.from('favorites').select('beat_id').eq('user_id', userId);
          if (dbFavs && dbFavs.length > 0) {
            const likedIds = dbFavs.map(f => String(f.beat_id));
            const likedBeats = globalBeats.filter(b => likedIds.includes(String(b.id)));
            userLikedGenres = Array.from(new Set(likedBeats.map(b => b.genre).filter(Boolean))) as string[];
          }
        }
      } catch (e) {
        console.warn('Liked recommendation build failed:', e);
      }
    }

    const basedOnLikes = globalBeats.filter(b => {
      if (userLikedGenres.length > 0) {
        return userLikedGenres.includes(b.genre || '');
      }
      // default: highest scoring genres
      return ['Afro-Trap', 'Kizomba', 'Hip Hop'].includes(b.genre || '');
    }).slice(0, 6);

    return {
      trendingNow,
      mostPlayed,
      newUploads,
      recommended: recommended.length > 0 ? recommended : globalBeats.slice(0, 6),
      basedOnLikes: basedOnLikes.length > 0 ? basedOnLikes : globalBeats.slice(3, 9)
    };
  }
};
