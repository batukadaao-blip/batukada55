export interface DbProfile {
  id?: string;
  role?: string;
  display_name?: string | null;
  artistic_name?: string | null;
  username?: string | null;
  avatar_url?: string | null;
  city?: string | null;
  bio?: string | null;
  phone?: string | null;
  created_at?: string | null;
}

export interface ClientProfile {
  id?: string;
  role?: string;
  displayName: string;
  artisticName: string;
  username: string;
  avatarUrl: string;
  profilePhotoUrl?: string; // backwards compatibility
  city: string;
  bio: string;
  phone: string;
  createdAt?: string | null;
  yearsExp?: string;
  bannerUrl?: string;
  bannerPhotoUrl?: string; // backwards compatibility
  genres?: string[];
  socials?: {
    ig: string;
    tw: string;
    yt: string;
    web: string;
    tiktok: string;
  };
  themeAccent?: string;
}

export function mapDbToClient(db: DbProfile): ClientProfile {
  let phoneStr = db.phone || '';
  let bioStr = db.bio || '';
  let bannerPhotoUrl = '';
  let instagram = '';
  let youtube = '';
  let twitter = '';
  let website = '';
  let genresList: string[] = [];
  let yearsExpVal = '3';
  let themeAccent = '';

  if (phoneStr && phoneStr.startsWith('{')) {
    try {
      const parsed = JSON.parse(phoneStr);
      phoneStr = parsed.phone || '';
      bioStr = parsed.bio || bioStr || '';
      bannerPhotoUrl = parsed.banner_url || '';
      instagram = parsed.instagram_url || '';
      youtube = parsed.youtube_url || '';
      twitter = parsed.twitter_url || '';
      website = parsed.website_url || '';
      genresList = parsed.genres || [];
      yearsExpVal = parsed.years_exp || parsed.yearsExp || '3';
      themeAccent = parsed.theme_accent || '';
    } catch (err) {
      console.error('Json parse err in mapDbToClient:', err);
    }
  }

  const avatarVal = db.avatar_url || '';

  return {
    id: db.id,
    role: db.role,
    displayName: db.display_name || db.artistic_name || '',
    artisticName: db.artistic_name || db.display_name || '',
    username: db.username || '',
    avatarUrl: avatarVal,
    profilePhotoUrl: avatarVal,
    city: db.city || '',
    bio: bioStr || db.bio || '',
    phone: phoneStr,
    createdAt: db.created_at,
    yearsExp: yearsExpVal,
    bannerUrl: bannerPhotoUrl,
    bannerPhotoUrl: bannerPhotoUrl,
    genres: genresList,
    socials: {
      ig: instagram,
      tw: twitter,
      yt: youtube,
      web: website,
      tiktok: ''
    },
    themeAccent
  };
}

export function mapClientToDb(client: ClientProfile): DbProfile {
  const avatarVal = client.avatarUrl || client.profilePhotoUrl || '';
  const bannerVal = client.bannerUrl || client.bannerPhotoUrl || '';
  
  const packedMetadata = JSON.stringify({
    phone: client.phone,
    bio: client.bio,
    banner_url: bannerVal,
    instagram_url: client.socials?.ig || '',
    youtube_url: client.socials?.yt || '',
    twitter_url: client.socials?.tw || '',
    website_url: client.socials?.web || '',
    genres: client.genres || [],
    years_exp: client.yearsExp || '3',
    theme_accent: client.themeAccent || ''
  });

  return {
    id: client.id,
    role: client.role,
    display_name: client.artisticName || client.displayName,
    artistic_name: client.artisticName || client.displayName,
    username: client.username ? client.username.toLowerCase().trim().replace(/\s+/g, '') : '',
    avatar_url: avatarVal,
    city: client.city,
    bio: client.bio,
    phone: packedMetadata
  };
}
