import { trackAnalyticsEvent } from './analytics';

interface PlayCacheEntry {
  timestamp: number;
}

const PLAY_COOLDOWN_MS = 30 * 1000; // 30 seconds client-side anti-spam cooldown lock

class PlayService {
  private sessionPlayLocks: Set<string> = new Set();
  private localPrefix = 'batukada_play_cooldown_';
  private cachedCounts: Record<string, number> = {};

  /**
   * Loads up-to-date play counts directly from the backend disk/memory persistent cache
   */
  public async loadPlayCounts(): Promise<Record<string, number>> {
    try {
      const res = await fetch('/api/plays/counts');
      if (res.ok) {
        this.cachedCounts = await res.json();
      }
    } catch (e) {
      console.warn('[PLAY SERVICE] Error loading play counts from backend api:', e);
    }
    return this.cachedCounts;
  }

  /**
   * Retrieves the play count for a beat, defaulting to a fallback (e.g. database column value) if not loaded
   */
  public getPlayCount(beatId: string | number, fallbackCount: number = 0): number {
    const key = String(beatId);
    return this.cachedCounts[key] !== undefined ? this.cachedCounts[key] : fallbackCount;
  }

  /**
   * Explicitly sets/updates the play count inside our global singleton cache
   */
  public forceSetPlayCount(beatId: string | number, count: number) {
    this.cachedCounts[String(beatId)] = count;
  }

  /**
   * Generates or retrieves a unique session identifier for guest users
   */
  public getSessionId(): string {
    let guestSessionId = sessionStorage.getItem('batukada_play_session');
    if (!guestSessionId) {
      guestSessionId = 'session_' + Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
      sessionStorage.setItem('batukada_play_session', guestSessionId);
    }
    return guestSessionId;
  }

  /**
   * Validates if a beat play is allowed (checks anti-spam cooldown cache)
   */
  public validatePlay(beatId: string): boolean {
    const cacheKey = `${this.localPrefix}${beatId}`;
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const entry: PlayCacheEntry = JSON.parse(cached);
        const elapsed = Date.now() - entry.timestamp;
        if (elapsed < PLAY_COOLDOWN_MS) {
          const remainingSecs = Math.ceil((PLAY_COOLDOWN_MS - elapsed) / 1000);
          console.log(`[PLAY SERVICE] Beat ${beatId} throttled. Cooldown remaining: ${remainingSecs} second(s).`);
          return false;
        }
      }
    } catch (e) {
      console.warn('[PLAY SERVICE] Error reading custom local storage:', e);
    }
    
    // Check in-session deduplication lock
    if (this.sessionPlayLocks.has(beatId)) {
      console.log(`[PLAY SERVICE] Beat ${beatId} has already been tracked in this session.`);
      return false;
    }

    return true;
  }

  /**
   * Acquires a session lock to prevent multiple simultaneous inputs/requests for the same beat
   */
  public deduplicatePlay(beatId: string): boolean {
    if (this.sessionPlayLocks.has(beatId)) {
      return false;
    }
    this.sessionPlayLocks.add(beatId);
    return true;
  }

  /**
   * Clear session lock (useful for debugging or reset contexts)
   */
  public clearSessionLock(beatId: string) {
    this.sessionPlayLocks.delete(beatId);
  }

  /**
   * Persists a successful play in local storage cooldown registry
   */
  private persistCooldown(beatId: string) {
    const cacheKey = `${this.localPrefix}${beatId}`;
    const entry: PlayCacheEntry = { timestamp: Date.now() };
    try {
      localStorage.setItem(cacheKey, JSON.stringify(entry));
    } catch (e) {
      console.warn('[PLAY SERVICE] Failed to persist play cooldown:', e);
    }
  }

  /**
   * Sends play registration to database backend after passing all heuristics
   */
  public async trackPlay(
    beatId: string, 
    playedSeconds: number, 
    userId: string | null = null,
    beatTitle: string = 'Beat'
  ): Promise<{ success: boolean; plays_count?: number; ignored?: boolean; error?: string }> {
    
    // 1. Verify Client-Side Anti-Spam Heuristics
    if (!this.validatePlay(beatId)) {
      return { success: true, ignored: true };
    }

    // 2. Lock the Beat Play Event
    this.deduplicatePlay(beatId);

    // 3. Fallback tracking logic mirroring existing behaviour
    let localPlays = [];
    try {
      const stored = localStorage.getItem('beatangola_beat_plays');
      localPlays = stored ? JSON.parse(stored) : [];
      localPlays.push({
        id: 'play_' + Math.random().toString(36).substring(2, 9),
        beat_id: beatId,
        created_at: new Date().toISOString()
      });
      localStorage.setItem('beatangola_beat_plays', JSON.stringify(localPlays));
    } catch (err) {
      console.warn('[PLAY SERVICE] Error logging to local playback list fallback:', err);
    }

    // Analytics framework call
    try {
      trackAnalyticsEvent('play', {
        beatId: beatId,
        userId: userId || undefined
      });
    } catch (err) {
      console.warn('[PLAY SERVICE ANALYTICS] Track error:', err);
    }

    // 4. Send API POST Request
    try {
      const guestSessionId = this.getSessionId();
      console.log(`[PLAY ENGINE] Initiating secure backend register for beat: "${beatTitle}" (${beatId})`);
      
      const response = await fetch('/api/plays/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          beat_id: beatId,
          played_seconds: Math.round(playedSeconds),
          session_id: guestSessionId,
          userId: userId
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP status code errored with: ${response.status}`);
      }

      const data = await response.json();
      console.log('[PLAY ENGINE] API Response received:', data);

      if (data.success) {
        if (!data.ignored) {
          // Play was fully accepted and incremented in backend!
          this.persistCooldown(beatId);
        }
        if (data.plays_count !== undefined) {
          this.forceSetPlayCount(beatId, data.plays_count);
        }
        return { 
          success: true, 
          plays_count: data.plays_count, 
          ignored: !!data.ignored 
        };
      } else {
        return { 
          success: false, 
          error: data.error || 'Unknown endpoint error' 
        };
      }
    } catch (err: any) {
      console.error('[PLAY ENGINE] Exception in trackPlay API request:', err);
      // Release deduction lock on hard network failures to allow retries
      this.clearSessionLock(beatId);
      return { success: false, error: err.message || String(err) };
    }
  }
}

export const playService = new PlayService();
export default playService;
