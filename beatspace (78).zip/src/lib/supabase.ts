import { createClient, SupabaseClient } from '@supabase/supabase-js';

let supabaseClient: SupabaseClient | null = null;
let storageDirectDisabled = false;

export const isStorageDirectDisabled = () => storageDirectDisabled;
export const setStorageDirectDisabled = (value: boolean) => {
  storageDirectDisabled = value;
  console.log('[STORAGE CONFIG] storageDirectDisabled set to:', value);
};

export const getSupabase = () => {
  if (!supabaseClient) {
    let supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    let supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    // Clean up strings (strip quotes if they were added in .env)
    if (supabaseUrl) supabaseUrl = supabaseUrl.trim().replace(/^["'](.+)["']$/, '$1');
    if (supabaseAnonKey) supabaseAnonKey = supabaseAnonKey.trim().replace(/^["'](.+)["']$/, '$1');

    if (!supabaseUrl || !supabaseAnonKey || supabaseUrl === 'REPLACE_ME' || supabaseUrl.includes('your-project-url') || supabaseUrl === '') {
      console.warn('Supabase URL or Anon Key is missing or using placeholder values. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your secrets.');
      return null;
    }

    // Normalize URL: Ensure it starts with https:// and remove trailing slashes.
    // Also ensure we only take the origin (no path).
    if (supabaseUrl) {
      if (!supabaseUrl.startsWith('http')) {
        supabaseUrl = `https://${supabaseUrl}`;
      }
      try {
        const urlObj = new URL(supabaseUrl);
        supabaseUrl = urlObj.origin;
      } catch (e) {
        // Fallback to simple cleanup if URL parsing fails
        supabaseUrl = supabaseUrl.replace(/\/+$/, '');
      }
    }

    console.log('Initializing Supabase with URL:', supabaseUrl);
    
    // Check if URL is potentially invalid (e.g. missing .supabase.co)
    if (supabaseUrl && !supabaseUrl.includes('.') && !supabaseUrl.includes('localhost')) {
      console.warn('Supabase URL looks incomplete. It should normally look like https://xyz.supabase.co');
    }

    try {
      if (supabaseUrl) {
        supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
          auth: {
            persistSession: true,
            autoRefreshToken: true,
            detectSessionInUrl: true,
          },
          global: {
            fetch: async (url, options) => {
              const urlStr = typeof url === 'string' ? url : (url && 'url' in url ? (url as any).url : '');
              try {
                const res = await fetch(url, options);
                return res;
              } catch (err: any) {
                // If direct connection fails (TypeError: Failed to fetch or general error), fallback to local proxy routing
                if (urlStr && urlStr.includes('supabase.co')) {
                  console.warn('[SUPABASE FAILSAFE] Direct call to supabase failed (network block/adblock/CORS/iframe). Re-routing via server proxy...', err);
                  try {
                    // Replace the remote host prefix with the local proxy prefix
                    const proxyPath = urlStr.replace(/^https:\/\/[^/]+/, '/api/supabase-proxy');
                    console.log('[SUPABASE FAILSAFE] Routing proxy request to:', proxyPath);
                    const proxyRes = await fetch(proxyPath, options);
                    return proxyRes;
                  } catch (proxyErr) {
                    console.error('[SUPABASE FAILSAFE] Proxy call failed:', proxyErr);
                    throw err;
                  }
                }
                throw err;
              }
            }
          }
        });
      }
    } catch (error) {
      console.error('Failed to create Supabase client:', error);
      return null;
    }
  }
  return supabaseClient;
};

export const getPublicUrl = (bucket: string, path: string) => {
  if (!path) return '';
  // Defense-in-depth: Never generate public URLs for protected stems, masters, kits, and zip/rar files
  const lowercasePath = path.toLowerCase();
  if (
    bucket === 'beats-private' || 
    lowercasePath.includes('beats-private') ||
    lowercasePath.includes('.zip') ||
    lowercasePath.includes('.rar') ||
    lowercasePath.includes('master') ||
    lowercasePath.includes('stems') ||
    lowercasePath.includes('kit') ||
    lowercasePath.includes('bundle')
  ) {
    // Exception: Allow preview mp3 files even if they contain the word "master" (e.g. "preview-master.mp3" or similar)
    if (lowercasePath.endsWith('.mp3') && !lowercasePath.includes('beats-private')) {
      // safe preview
    } else {
      console.warn('[SECURITY] Blocked public URL generation for protected premium resource:', path, 'bucket:', bucket);
      return '';
    }
  }
  if (path.startsWith('http') || path.startsWith('/api') || path.startsWith('api')) {
    return path.startsWith('api') ? `/${path}` : path;
  }
  const supabase = getSupabase();
  if (!supabase) return '';
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
};

export const getBeatSignedUrl = async (beatId: number | string, fileType: 'master' | 'stems'): Promise<string> => {
  const supabase = getSupabase();
  if (!supabase) return '';
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const token = session?.access_token;
    if (!token) {
      console.warn('No active session found when requesting signed URL');
      return '';
    }
    
    const response = await fetch('/api/beats/signed-url', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ beatId, fileType })
    });
    
    if (response.ok) {
      const result = await response.json();
      if (result.success && result.signedUrl) {
        return result.signedUrl;
      }
    } else {
      const errRes = await response.json().catch(() => ({}));
      console.error('Failed to retrieve signed URL:', errRes.error || response.statusText);
    }
  } catch (err) {
    console.error('Exception fetching signed URL:', err);
  }
  return '';
};

export const normalizeBeatId = (id: string | number): number => {
  if (typeof id === 'string' && id.includes('-')) {
    const parts = id.split('-');
    return parseInt(parts[parts.length - 1] || '0', 10);
  }
  return typeof id === 'string' ? parseInt(id, 10) : (id as number);
};
