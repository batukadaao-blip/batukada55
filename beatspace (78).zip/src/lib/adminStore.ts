import { getSupabase } from './supabase';

export interface Report {
  id: string;
  reporter_id: string;
  reporter_name: string;
  target_id: string;
  target_type: 'beat' | 'comment' | 'profile';
  target_name: string;
  reason: 'copyright' | 'spam' | 'inappropriate' | 'scam' | 'stolen_beat' | 'other';
  details: string;
  status: 'pending' | 'resolved' | 'ignored';
  created_at: string;
}

export interface AdminLog {
  id: string;
  admin_id: string;
  admin_name: string;
  action: string;
  target_id: string;
  target_type: string;
  details: string;
  created_at: string;
}

export interface FeaturedContent {
  id: string;
  type: 'producer' | 'playlist' | 'beat';
  target_id: string;
  title: string;
  subtitle?: string;
  image?: string;
  created_at: string;
}

class AdminStore {
  private reportsKey = 'batukada_admin_reports';
  private logsKey = 'batukada_admin_logs';
  private featuredKey = 'batukada_admin_featured';
  private suspensionsKey = 'batukada_admin_suspensions';
  private hiddenBeatsKey = 'batukada_admin_hidden_beats';
  private hiddenCommentsKey = 'batukada_admin_hidden_comments';

  constructor() {
    this.init();
  }

  private init() {
    if (typeof window === 'undefined') return;

    // Filter or initialize logs — always remove existing mock logs for a clean database state
    let logs: AdminLog[] = [];
    try {
      const stored = localStorage.getItem(this.logsKey);
      if (stored) {
        logs = JSON.parse(stored);
      }
    } catch {}
    logs = logs.filter(log => log.id !== 'log-1' && log.id !== 'log-2' && !log.details.includes('Jesus Belchior') && !log.details.includes('DJ Habias'));
    localStorage.setItem(this.logsKey, JSON.stringify(logs));

    // Filter or initialize reports — always remove existing mock reports for a clean database state
    let reports: Report[] = [];
    try {
      const stored = localStorage.getItem(this.reportsKey);
      if (stored) {
        reports = JSON.parse(stored);
      }
    } catch {}
    reports = reports.filter(rep => rep.id !== 'rep-1' && rep.id !== 'rep-2' && rep.reporter_name !== 'Carlos Santos' && rep.reporter_name !== 'Marta Dias');
    localStorage.setItem(this.reportsKey, JSON.stringify(reports));

    // Filter or initialize featured content — always remove existing mock items for a clean database state
    let featured: FeaturedContent[] = [];
    try {
      const stored = localStorage.getItem(this.featuredKey);
      if (stored) {
        featured = JSON.parse(stored);
      }
    } catch {}
    featured = featured.filter(feat => feat.id !== 'feat-1' && feat.title !== 'Azura');
    localStorage.setItem(this.featuredKey, JSON.stringify(featured));
  }

  // --- Reports ---
  public getReports(): Report[] {
    if (typeof window === 'undefined') return [];
    try {
      return JSON.parse(localStorage.getItem(this.reportsKey) || '[]');
    } catch {
      return [];
    }
  }

  public addReport(report: Omit<Report, 'id' | 'status' | 'created_at'>) {
    const reports = this.getReports();
    const newRep: Report = {
      ...report,
      id: `rep-${Date.now()}`,
      status: 'pending',
      created_at: new Date().toISOString()
    };
    reports.unshift(newRep);
    localStorage.setItem(this.reportsKey, JSON.stringify(reports));
    return newRep;
  }

  public updateReportStatus(reportId: string, status: 'resolved' | 'ignored', adminName: string) {
    const reports = this.getReports();
    const reportIndex = reports.findIndex(r => r.id === reportId);
    if (reportIndex !== -1) {
      const report = reports[reportIndex];
      report.status = status;
      localStorage.setItem(this.reportsKey, JSON.stringify(reports));
      
      this.addLog(
        adminName,
        status === 'resolved' ? 'Resolver Denúncia' : 'Ignorar Denúncia',
        report.target_id,
        report.target_type,
        `Denúncia ID: ${reportId} marcada como ${status === 'resolved' ? 'Resolvida' : 'Ignorada'}. Motivo original: ${report.reason}.`
      );
    }
  }

  // --- Audit Logs ---
  public getLogs(): AdminLog[] {
    if (typeof window === 'undefined') return [];
    try {
      return JSON.parse(localStorage.getItem(this.logsKey) || '[]');
    } catch {
      return [];
    }
  }

  public addLog(adminName: string, action: string, targetId: string, targetType: string, details: string) {
    const logs = this.getLogs();
    const newLog: AdminLog = {
      id: `log-${Date.now()}`,
      admin_id: 'admin-001',
      admin_name: adminName,
      action,
      target_id: String(targetId),
      target_type: targetType,
      details,
      created_at: new Date().toISOString()
    };
    logs.unshift(newLog);
    localStorage.setItem(this.logsKey, JSON.stringify(logs));
  }

  // --- Suspensions & Bans ---
  public getSuspensions(): Record<string, 'active' | 'suspended' | 'banned_temp' | 'banned_perm'> {
    if (typeof window === 'undefined') return {};
    try {
      return JSON.parse(localStorage.getItem(this.suspensionsKey) || '{}');
    } catch {
      return {};
    }
  }

  public getUserStatus(userId: string): 'active' | 'suspended' | 'banned_temp' | 'banned_perm' {
    const suspensions = this.getSuspensions();
    return suspensions[userId] || 'active';
  }

  public updateUserStatus(userId: string, status: 'active' | 'suspended' | 'banned_temp' | 'banned_perm', adminName: string, reason: string) {
    const suspensions = this.getSuspensions();
    suspensions[userId] = status;
    localStorage.setItem(this.suspensionsKey, JSON.stringify(suspensions));

    const statusMap = {
      active: 'Ativar Conta / Reativar',
      suspended: 'Suspender Conta',
      banned_temp: 'Banimento Temporário',
      banned_perm: 'Banimento Permanente'
    };

    this.addLog(
      adminName,
      statusMap[status],
      userId,
      'profile',
      `Estado da conta alterado para: ${status.toUpperCase()}. Motivo: ${reason}`
    );
  }

  // --- Hidden / Moderated Beats ---
  public getHiddenBeats(): string[] {
    if (typeof window === 'undefined') return [];
    try {
      return JSON.parse(localStorage.getItem(this.hiddenBeatsKey) || '[]');
    } catch {
      return [];
    }
  }

  public isBeatHidden(beatId: string): boolean {
    return this.getHiddenBeats().includes(String(beatId));
  }

  public setBeatHiddenStatus(beatId: string, isHidden: boolean, adminName: string, reason: string) {
    const hidden = this.getHiddenBeats();
    const strId = String(beatId);
    
    if (isHidden) {
      if (!hidden.includes(strId)) {
        hidden.push(strId);
        this.addLog(adminName, 'Ocultar Beat', strId, 'beat', `Beat ocultado por violação. Motivo: ${reason}`);
      }
    } else {
      const idx = hidden.indexOf(strId);
      if (idx !== -1) {
        hidden.splice(idx, 1);
        this.addLog(adminName, 'Restaurar Beat', strId, 'beat', `Beat restaurado ao catálogo. Justificação: ${reason}`);
      }
    }
    localStorage.setItem(this.hiddenBeatsKey, JSON.stringify(hidden));
  }

  // --- Hidden / Moderated Comments ---
  public getHiddenComments(): string[] {
    if (typeof window === 'undefined') return [];
    try {
      return JSON.parse(localStorage.getItem(this.hiddenCommentsKey) || '[]');
    } catch {
      return [];
    }
  }

  public isCommentHidden(commentId: string): boolean {
    return this.getHiddenComments().includes(String(commentId));
  }

  public hideComment(commentId: string, adminName: string, reason: string) {
    const hidden = this.getHiddenComments();
    const strId = String(commentId);
    if (!hidden.includes(strId)) {
      hidden.push(strId);
      localStorage.setItem(this.hiddenCommentsKey, JSON.stringify(hidden));
      
      // Also remove of standard comments inside various pools if needed
      this.addLog(adminName, 'Excluir Comentário', strId, 'comment', `Comentário id: ${commentId} removido por moderação. Motivo: ${reason}`);
    }
  }

  // --- Featured Content ---
  public getFeaturedItems(): FeaturedContent[] {
    if (typeof window === 'undefined') return [];
    try {
      return JSON.parse(localStorage.getItem(this.featuredKey) || '[]');
    } catch {
      return [];
    }
  }

  public toggleFeatureItem(type: 'producer' | 'playlist' | 'beat', targetId: string, title: string, isFeatured: boolean, image?: string) {
    const featured = this.getFeaturedItems();
    const strId = String(targetId);
    const existingIdx = featured.findIndex(f => f.type === type && f.target_id === strId);

    if (isFeatured) {
      if (existingIdx === -1) {
        featured.push({
          id: `feat-${Date.now()}`,
          type,
          target_id: strId,
          title,
          image: image || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=300&auto=format&fit=crop',
          created_at: new Date().toISOString()
        });
        this.addLog('António (Root)', 'Destacar Conteúdo', strId, type, `Conteúdo do tipo ${type} (${title}) adicionado aos destaques.`);
      }
    } else {
      if (existingIdx !== -1) {
        featured.splice(existingIdx, 1);
        this.addLog('António (Root)', 'Remover Destaque', strId, type, `Destaque removido de ${type} (${title}).`);
      }
    }
    localStorage.setItem(this.featuredKey, JSON.stringify(featured));
  }

  public isFeatured(type: 'producer' | 'playlist' | 'beat', targetId: string): boolean {
    return this.getFeaturedItems().some(f => f.type === type && f.target_id === String(targetId));
  }
}

export const adminStore = new AdminStore();
