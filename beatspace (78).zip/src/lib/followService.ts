import { getSupabase } from './supabase';

/**
 * Centered, professional, robust, and highly reliable follow persistence service for Batukada.
 * Prevents race conditions, handles client-side caching to resolve RLS selectivity gaps, 
 * implements optimistic state synchronization, and broadcasts global state changes.
 */

const FOLLOW_CACHE_KEY = 'batukada_is_following_cache';

interface FollowCache {
  // Key format: "followerId:followingId" -> boolean status
  [key: string]: {
    isFollowing: boolean;
    timestamp: number;
  };
}

export const followService = {
  /**
   * Reads from localStorage cache with fallback safety
   */
  getCache(): FollowCache {
    try {
      const stored = localStorage.getItem(FOLLOW_CACHE_KEY);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  },

  /**
   * Saves to localStorage cache
   */
  saveCache(cache: FollowCache) {
    try {
      localStorage.setItem(FOLLOW_CACHE_KEY, JSON.stringify(cache));
    } catch (e) {
      console.error('[FOLLOW SERVICE] Cache write error', e);
    }
  },

  /**
   * Sets the optimistic follow state in local memory immediately
   */
  setFollowStateInCache(followerId: string, followingId: string, isFollowing: boolean) {
    const cache = this.getCache();
    const cacheKey = `${followerId}:${followingId}`;
    
    cache[cacheKey] = {
      isFollowing,
      timestamp: Date.now()
    };
    
    this.saveCache(cache);
    console.log(`[FOLLOW SERVICE] Cached state updated: ${cacheKey} => ${isFollowing}`);

    // Broadcast change globally so other rendered elements / hooks can update immediately
    window.dispatchEvent(new CustomEvent('followStatusChanged', {
      detail: { followerId, followingId, isFollowing }
    }));
  },

  /**
   * Checks following status with immediate optimistic cache priority.
   * Then queries the backend securely, updates cache, and returns result.
   */
  async checkIsFollowing(followerId: string, followingId: string): Promise<boolean> {
    const cacheKey = `${followerId}:${followingId}`;
    const cache = this.getCache();
    
    // Optimistic fallback: if updated in the last 15 minutes, trust the cache to avoid backend lag overrides
    if (cache[cacheKey]) {
      const ageMs = Date.now() - cache[cacheKey].timestamp;
      if (ageMs < 15 * 60 * 1000) {
        console.log(`[FOLLOW SERVICE] Returning fresh cached state for ${cacheKey}: ${cache[cacheKey].isFollowing}`);
        console.log(`FOLLOW SOURCE USED: client-side localStorage cache`);
        console.log(`FOLLOW CACHE RESULT: ${cache[cacheKey].isFollowing}`);
        
        // Silently revalidate in background to confirm consistency
        this.revalidateFollowState(followerId, followingId);
        return cache[cacheKey].isFollowing;
      }
    }

    // Otherwise load from backend directly
    try {
      console.log(`FOLLOW SOURCE USED: Server Database Query API`);
      const isFollowing = await this.fetchFollowStateFromServer(followerId, followingId);
      console.log(`FOLLOW DATABASE RESULT: ${isFollowing}`);
      this.setFollowStateInCache(followerId, followingId, isFollowing);
      return isFollowing;
    } catch (err) {
      console.warn(`[FOLLOW SERVICE] Fetch failed for keys, defaulting to cached/false`, err);
      console.log(`FOLLOW SOURCE USED: local cache fallback on error`);
      console.log(`FOLLOW CACHE RESULT: ${cache[cacheKey]?.isFollowing ?? false}`);
      return cache[cacheKey]?.isFollowing ?? false;
    }
  },

  /**
   * Raw backend query handler. Uses API endpoint which bypasses RLS securely or falls back.
   */
  async fetchFollowStateFromServer(followerId: string, followingId: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/social/is-following?followerId=${followerId}&followingId=${followingId}`);
      if (res.ok) {
        const resData = await res.json();
        console.log(`FOLLOW DATABASE RESULT: /api/social/is-following returned = ${resData.isFollowing}`);
        return !!resData.isFollowing;
      }
    } catch (err) {
      console.warn('[FOLLOW SERVICE] API check error, checking direct Supabase client fallback:', err);
    }

    // Direct Supabase fallback
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('followers')
          .select('*')
          .eq('follower_id', followerId)
          .eq('following_id', followingId)
          .maybeSingle();
        
        if (!error) {
          console.log(`FOLLOW DATABASE RESULT (direct query callback): ${!!data}`);
          return !!data;
        } else {
          console.warn('[FOLLOW SERVICE] Direct Supabase checks returned error:', error);
          // Return the cached state instead of false to prevent reverting
          const cache = this.getCache();
          const cacheKey = `${followerId}:${followingId}`;
          if (cache[cacheKey]) {
            console.log(`FOLLOW CACHE RESULT (on DB check failure): ${cache[cacheKey].isFollowing}`);
            return cache[cacheKey].isFollowing;
          }
        }
      } catch (ex) {
        console.warn('[FOLLOW SERVICE] Direct Supabase query exception:', ex);
      }
    }

    const cache = this.getCache();
    const cacheKey = `${followerId}:${followingId}`;
    console.log(`FOLLOW CACHE RESULT (last fallback): ${cache[cacheKey]?.isFollowing ?? false}`);
    return cache[cacheKey]?.isFollowing ?? false;
  },

  /**
   * Background revalidator to ensure consistency
   */
  async revalidateFollowState(followerId: string, followingId: string) {
    try {
      const serverState = await this.fetchFollowStateFromServer(followerId, followingId);
      const cache = this.getCache();
      const cacheKey = `${followerId}:${followingId}`;
      const currentChachedObj = cache[cacheKey];

      // Only update cache and dispatch if the server has a newer or conflicting real state,
      // and the cached state isn't a extremely fresh block (less than 20 seconds old - which indicates active user edit)
      if (currentChachedObj) {
        const elapsedSinceWrite = Date.now() - currentChachedObj.timestamp;
        if (elapsedSinceWrite > 20 * 1000 && currentChachedObj.isFollowing !== serverState) {
          console.log(`[FOLLOW SERVICE] Revalidation mismatch: Server reports ${serverState}, but cache had ${currentChachedObj.isFollowing}. Correcting cached view...`);
          this.setFollowStateInCache(followerId, followingId, serverState);
        }
      } else {
        this.setFollowStateInCache(followerId, followingId, serverState);
      }
    } catch (err) {
      console.warn('[FOLLOW SERVICE] Revalidation failed silently:', err);
    }
  },

  /**
   * Performs follow action with optimistic updates and secure API/DB failovers
   */
  async follow(followerId: string, followingId: string, followerName: string): Promise<boolean> {
    // 1. Set optimistic state immediately
    this.setFollowStateInCache(followerId, followingId, true);

    try {
      const response = await fetch('/api/social/follow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          followerId,
          followingId,
          followerName
        })
      });
      
      if (!response.ok) {
        const resData = await response.json();
        throw new Error(resData.error || 'API follow command failed');
      }
      return true;
    } catch (err) {
      console.error('[FOLLOW SERVICE] Critical follow failure, rolling back UI state:', err);
      this.setFollowStateInCache(followerId, followingId, false);
      throw err;
    }
  },

  /**
   * Performs unfollow action with optimistic updates and API/DB proxy fallback
   */
  async unfollow(followerId: string, followingId: string): Promise<boolean> {
    // 1. Set optimistic state immediately
    this.setFollowStateInCache(followerId, followingId, false);

    try {
      const response = await fetch('/api/social/unfollow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          followerId,
          followingId
        })
      });

      if (!response.ok) {
        const resData = await response.json();
        throw new Error(resData.error || 'API unfollow command failed');
      }
      return true;
    } catch (err) {
      console.error('[FOLLOW SERVICE] Critical unfollow failed, rolling back:', err);
      this.setFollowStateInCache(followerId, followingId, true);
      throw err;
    }
  }
};
