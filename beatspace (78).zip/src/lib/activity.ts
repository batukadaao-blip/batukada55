export interface CreateActivityPayload {
  user_id?: string | null;
  type: 'beat_upload' | 'kit_upload' | 'follow' | 'like' | 'comment' | 'playlist_created' | 'featured' | 'verified';
  actor_name: string;
  actor_username: string;
  actor_avatar?: string | null;
  target_id?: string | null;
  target_title?: string | null;
  target_cover?: string | null;
  metadata?: any;
}

export async function createSocialActivity(payload: CreateActivityPayload) {
  try {
    const res = await fetch('/api/activity/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });
    return await res.json();
  } catch (err) {
    console.warn('Silent issue registering social activity:', err);
    return null;
  }
}
