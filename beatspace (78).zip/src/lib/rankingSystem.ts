import { Producer, Beat } from '../types';
import { getSupabase } from './supabase';

export type PremiumBadgeType = 'verified' | 'trending' | 'top_producer' | 'elite_seller' | 'rising_star';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  unlocked: boolean;
  icon: string;
}

export interface PremiumProducerStats {
  score: number;
  badge: PremiumBadgeType | null;
  rank: number;
  weeklyGrowth: number; // percentage, e.g. 12%
  monthlyPlaysGrowth: number; // percentage, e.g. 45%
  engagementRate: number; // e.g. 7.4%
  fanConversion: number; // e.g. 3.2%
  topBeatTitle: string;
  topPlaylistTitle: string;
  points: number;
  achievements: Achievement[];
}

// System achievements definitions
const ALL_ACHIEVEMENTS_DEFINITION = [
  { id: '1k_plays', title: '🔥 1K Plays', description: 'Alcançou mais de 1.000 reproduções acumuladas.', icon: '🎵' },
  { id: '10k_plays', title: '🔥 10K Plays', description: 'Superou a barreira das 10.000 reproduções!', icon: '👑' },
  { id: '100_followers', title: '🔥 100 Followers', description: 'Construiu uma base sólida com mais de 100 seguidores.', icon: '👥' },
  { id: 'top_trending', title: '🔥 Top Trending', description: 'Entrou na elite dos algoritmos da semana.', icon: '⚡' },
  { id: 'viral_beat', title: '🔥 Viral Beat', description: 'Tem um instrumental selecionado em alta reprodução.', icon: '🚀' },
  { id: 'playlist_master', title: '🔥 Playlist Master', description: 'Inclusão em mais de 5 curadorias premium de música.', icon: '🎧' },
  { id: 'elite_seller', title: '💎 Elite Seller', description: 'Alcançou a marca de mais de 5 vendas efetuadas com sucesso.', icon: '💎' },
  { id: 'top_producer', title: '👑 Top Producer', description: 'Atuou no topo de mercado com mais de 15 vendas concluídas!', icon: '👑' },
];

/**
 * Calculates a producer's ranking points and premium metrics dynamically
 * incorporating plays, downloads, followers, and beats structure.
 */
export function calculatePremiumProducerStats(
  producer: Producer,
  beats: Beat[] = []
): PremiumProducerStats {
  const producerBeats = beats.filter(
    b => b.producer_id === producer.id || (b.producer && b.producer.toLowerCase() === producer.name.toLowerCase())
  );
  
  // 1. Gather counts
  const beatsCount = producerBeats.length || producer.totalBeats || 0;
  const followersCount = producer.followers || 0;
  
  // Calculate total plays across all beats
  let playsCount = 0;
  producerBeats.forEach(b => {
    playsCount += b.plays_count || 0;
  });
  // If no beats but default plays string exists
  if (playsCount === 0 && producer.totalPlays) {
    const rawNum = parseInt(producer.totalPlays.replace(/[^0-9]/g, ''), 10);
    if (!isNaN(rawNum)) playsCount = rawNum;
  }

  // 2. Ranking Algorithm Formulas (Cumulative Score Points)
  // Each play = 1 pts
  // Each follower = 15 pts
  // Each beat quality upload = 50 pts
  // Verified boost = +200 pts
  const points = (playsCount * 1.5) + (followersCount * 18) + (beatsCount * 40) + (producer.isVerified ? 300 : 0);

  // 3. Growth rates mapped directly from database timeline analytics (defaulting to 0 if not yet loaded)
  const weeklyGrowth = producer.weeklyGrowth || 0;
  const monthlyPlaysGrowth = producer.monthlyPlaysGrowth || 0;
  
  // Engagement percentage = ((plays + followers) / 100) trimmed
  const engagementRate = +(((followersCount * 5 + playsCount * 0.1) / (playsCount || 50)) * 10 + 2.5).toFixed(1);
  const fanConversion = +((followersCount / (playsCount || 100)) * 100 + 1.2).toFixed(1);

  // 4. Derive Top Track & Playlist details
  const sortedBeats = [...producerBeats].sort((a, b) => (b.plays_count || 0) - (a.plays_count || 0));
  const topBeatTitle = sortedBeats[0]?.title || (beatsCount > 0 ? 'Instrumental Ativo' : 'Batida em Produção');
  
  const topPlaylistTitle = producer.topPlaylistTitle || 'Nenhuma Playlist';

  // 5. Parse custom dynamic or administrative badge defined in profile metadata (or phone JSON column)
  let assignedBadge: PremiumBadgeType | null = null;
  
  const pAny = producer as any;
  const salesCount = producer.salesCount || 0;
  if (pAny.premium_badge) {
    assignedBadge = pAny.premium_badge;
  } else {
    // Prioritize programmatic assignments by stats, even if the producer is verified.
    if (salesCount >= 15) {
      assignedBadge = 'top_producer';
    } else if (salesCount >= 5) {
      assignedBadge = 'elite_seller';
    } else if (playsCount >= 500 && followersCount >= 15) {
      assignedBadge = 'trending';
    } else if (playsCount >= 100 && followersCount >= 5) {
      assignedBadge = 'rising_star';
    } else if (producer.isVerified) {
      assignedBadge = 'verified';
    }
  }

  // Handle custom profiles that are authenticated
  const achievements = ALL_ACHIEVEMENTS_DEFINITION.map(def => {
    let unlocked = false;
    if (def.id === '1k_plays') unlocked = playsCount >= 1000;
    else if (def.id === '10k_plays') unlocked = playsCount >= 10000;
    else if (def.id === '100_followers') unlocked = followersCount >= 100;
    else if (def.id === 'top_trending') unlocked = assignedBadge === 'trending' || assignedBadge === 'top_producer' || (producer.weeklyGrowth || 0) >= 15 || points >= 1200;
    else if (def.id === 'viral_beat') unlocked = playsCount > 5000 || sortedBeats.some(b => (b.plays_count || 0) > 1000);
    else if (def.id === 'playlist_master') unlocked = (producer.playlistCount || 0) >= 5;
    else if (def.id === 'elite_seller') unlocked = salesCount >= 5;
    else if (def.id === 'top_producer') unlocked = salesCount >= 15;

    return {
      ...def,
      unlocked
    };
  });

  return {
    score: Math.round(points),
    badge: assignedBadge,
    rank: 1, // Will be computed in bulk group
    weeklyGrowth,
    monthlyPlaysGrowth,
    engagementRate,
    fanConversion,
    topBeatTitle,
    topPlaylistTitle,
    points: Math.round(points),
    achievements
  };
}

/**
 * Bulk ranks all producers by points.
 */
export function getProducersRankings(
  producers: Producer[],
  beats: Beat[] = []
): Array<Producer & { premium: PremiumProducerStats }> {
  const list = producers.map(p => {
    // Check if custom override from phone JSON exists
    let customBadge: PremiumBadgeType | null = null;
    let location = p.location;
    if (p.location && p.location.includes('{')) {
      // Sometimes info was serialized as fallback, let's look in p.location
    }
    
    const stats = calculatePremiumProducerStats(p, beats);
    
    // Explicit database badge setting if present in a custom field
    const pAny = p as any;
    if (pAny.premium_badge) {
      stats.badge = pAny.premium_badge;
    }

    return {
      ...p,
      premium: stats
    };
  });

  // Sort by points desc
  const sorted = list.sort((a, b) => b.premium.score - a.premium.score);
  
  // Assign ranking numbers
  return sorted.map((p, idx) => {
    p.premium.rank = idx + 1;
    return p;
  });
}

/**
 * Helper to update a producer profile's social status/badge in Supabase
 * by storing it securely inside the metadata JSON in 'phone' column.
 */
export async function persistProducerPremiumSettings(
  producerId: string,
  settings: {
    isVerified?: boolean;
    premiumBadge?: PremiumBadgeType | null;
    isFeatured?: boolean;
  }
) {
  const supabase = getSupabase();
  if (!supabase) return false;

  try {
    // 1. Fetch current profile
    const { data: profile } = await supabase
      .from('profiles')
      .select('id, phone, is_verified')
      .eq('id', producerId)
      .maybeSingle();

    if (!profile) return false;

    // 2. Parse current JSON stored in 'phone' column
    let ext: any = {};
    if (profile.phone && profile.phone.startsWith('{')) {
      try {
        ext = JSON.parse(profile.phone);
      } catch {}
    }

    // 3. Update the fields
    if (settings.premiumBadge !== undefined) {
      ext.premium_badge = settings.premiumBadge;
    }
    if (settings.isFeatured !== undefined) {
      ext.is_featured = settings.isFeatured;
    }

    // Prepare update body
    const updateBody: any = {
      phone: JSON.stringify(ext)
    };

    if (settings.isVerified !== undefined) {
      updateBody.is_verified = settings.isVerified;
    }

    // 4. Save back to Supabase
    const { error } = await supabase
      .from('profiles')
      .update(updateBody)
      .eq('id', producerId);

    if (error) {
      console.error('[RANKINGSYSTEM] Error updating premium configurations:', error);
      return false;
    }

    return true;
  } catch (err) {
    console.error('[RANKINGSYSTEM] Exception in persistProducerPremiumSettings:', err);
    return false;
  }
}

/**
 * Render details helper for badges
 */
export function getBadgeDetails(type: PremiumBadgeType | null) {
  if (!type) return null;
  switch (type) {
    case 'verified':
      return {
        label: 'Verified ✔',
        labelColor: 'bg-[#5865F2]/10 text-[#5865F2] border-[#5865F2]/20',
        textColor: 'text-[#5865F2]',
        glowColor: 'shadow-[0_0_15px_rgba(88,101,242,0.15)] shadow-[#5865F2]/20',
        bullet: '✔ VERIFIED',
        gradient: 'from-[#5865F2]/20 to-[#4752C4]/20',
        borderColor: 'border-[#5865F2]/30',
        description: 'Produtor validado e reconhecido oficialmente pela curadoria Batukada.'
      };
    case 'trending':
      return {
        label: 'Trending⚡',
        labelColor: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
        textColor: 'text-amber-500',
        glowColor: 'shadow-[0_0_15px_rgba(245,158,11,0.15)] shadow-amber-500/20',
        bullet: '🔥 TRENDING',
        gradient: 'from-amber-500/20 to-orange-500/20',
        borderColor: 'border-amber-500/30',
        description: 'Vendas e plays a disparar! Está na mira das principais rimas do país.'
      };
    case 'top_producer':
      return {
        label: 'Top Producer 👑',
        labelColor: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
        textColor: 'text-purple-400',
        glowColor: 'shadow-[0_0_15px_rgba(168,85,247,0.15)] shadow-purple-500/20',
        bullet: '👑 TOP PRODUCER',
        gradient: 'from-purple-500/20 to-indigo-500/20',
        borderColor: 'border-purple-500/30',
        description: 'Fez o maior número de parcerias e volumes de streaming este mês.'
      };
    case 'elite_seller':
      return {
        label: 'Elite Seller 💎',
        labelColor: 'bg-teal-500/10 text-teal-400 border-teal-500/20',
        textColor: 'text-teal-400',
        glowColor: 'shadow-[0_0_15px_rgba(20,184,166,0.15)] shadow-teal-500/20',
        bullet: '💎 ELITE SELLER',
        gradient: 'from-teal-500/20 to-emerald-500/20',
        borderColor: 'border-teal-500/30',
        description: 'Altíssima taxa de conversão comercial com licenças exclusivas ativas.'
      };
    case 'rising_star':
      return {
        label: 'Rising Star 🚀',
        labelColor: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
        textColor: 'text-blue-400',
        glowColor: 'shadow-[0_0_15px_rgba(59,130,246,0.15)] shadow-blue-500/20',
        bullet: '🚀 RISING STAR',
        gradient: 'from-blue-500/20 to-cyan-500/20',
        borderColor: 'border-blue-500/30',
        description: 'Revelação recente do beatmaking nacional com crescimento acelerado.'
      };
  }
}
