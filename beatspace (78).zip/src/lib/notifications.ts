import { getSupabase } from './supabase';
import { NotificationType } from '../types';

/**
 * Plays a warm, high-fidelity UI chime synthesized dynamically
 * using the browser's Web Audio API. Silent execution on fallback.
 */
export function playSubtleNotificationSound() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    
    const ctx = new AudioContextClass();
    
    // First high tone (gentle notification pop)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc1.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12); // A5
    
    gain1.gain.setValueAtTime(0.06, ctx.currentTime);
    gain1.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
    
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    
    osc1.start();
    osc1.stop(ctx.currentTime + 0.25);

    // Complementary ambient overlay
    setTimeout(() => {
      try {
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(880, ctx.currentTime);
        gain2.gain.setValueAtTime(0.02, ctx.currentTime);
        gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start();
        osc2.stop(ctx.currentTime + 0.15);
      } catch (e) {}
    }, 80);

  } catch (err) {
    console.warn("[CHIME] Synthesia sound playback suppressed/unsupported:", err);
  }
}

interface NotificationPayload {
  userId: string;
  actorId?: string;
  type: NotificationType;
  title: string;
  message: string;
  metadata?: Record<string, any>;
}

/**
 * Safely inserts a notification record into Supabase in a non-blocking manner.
 * If Supabase inserts fail, it intercepts errors silently so that normal checkout/follow/sales activities
 * can complete successfully. It also dispatches a custom window event for instant client-side updates.
 */
export async function sendPremiumNotification(payload: NotificationPayload) {
  const supabase = getSupabase();
  if (!supabase) return null;

  try {
    const { userId, actorId, type, title, message, metadata } = payload;
    
    // Custom payload with fields mapping to avoid Schema mismatch
    const record: Record<string, any> = {
      user_id: userId,
      type,
      title,
      message,
      read: false,
      created_at: new Date().toISOString()
    };

    if (actorId) {
      record.actor_id = actorId;
    }
    
    if (metadata) {
      record.metadata = metadata;
    }

    // Attempt standard insert
    const { data, error } = await supabase
      .from('notifications')
      .insert([record])
      .select();

    if (error) {
      console.warn("[NOTIFICATIONS] Insert failed:", error.message);
    }

    // Trigger local application window events for instant in-tab update synchronization
    try {
      window.dispatchEvent(new CustomEvent('new_notification_received', { detail: payload }));
    } catch (evtErr) {
      console.warn("[EVENT DISPATCH] Local dispatch failed:", evtErr);
    }

    return true;
  } catch (fatalErr) {
    // SILENT FAIL - NON-BLOCKING DO NOT DISRUPT USER CRITICAL FLOWS
    console.error("[NOTIFICATIONS SYSTEM] Safely intercepted error insert:", fatalErr);
    return false;
  }
}

/**
 * Backward compatible wrapper for legacy sendNotification calls.
 */
export async function sendNotification(userId: string, type: any, title: string, message: string) {
  return sendPremiumNotification({
    userId,
    type,
    title,
    message
  });
}

/**
 * Backward compatible helper to notify a user that they're verified.
 */
export async function notifyVerified(userId: string) {
  return sendPremiumNotification({
    userId,
    type: 'verified' as any,
    title: 'Selo Oficial de Verificação! ✨',
    message: 'Parabéns! O teu perfil foi verificado oficialmente pela equipa BATUKADA. O selo azul de prestígio foi activado no teu perfil!'
  });
}
