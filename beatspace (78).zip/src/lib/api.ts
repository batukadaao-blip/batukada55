/**
 * Safe and Resilient Network Fetch Wrapper (safeFetch)
 * Implements retry mechanism, exponential backoff, timeout protection,
 * and automated telemetry logging of network/API errors without overriding `window.fetch`.
 */

export interface SafeFetchOptions extends RequestInit {
  timeoutMs?: number;
  maxRetries?: number;
  retryDelay?: number;
}

export async function safeFetch(
  input: RequestInfo | URL,
  options?: SafeFetchOptions
): Promise<Response> {
  const {
    timeoutMs = 15000,
    maxRetries = 3,
    retryDelay = 1000,
    ...fetchOptions
  } = options || {};

  const url = typeof input === 'string' ? input : (input && 'url' in input ? (input as any).url : '');
  let currentDelay = retryDelay;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const controller = new AbortController();
    const timerId = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(input, {
        ...fetchOptions,
        signal: controller.signal,
      });
      clearTimeout(timerId);

      // Automatically log status errors (>= 400) to the error tracking database system
      if (response.status >= 400 && url && !url.includes('/api/system/logs/add')) {
        fetch('/api/system/logs/add', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'api_error',
            message: `API returned status ${response.status} on fetch`,
            severity: 'error',
            route: url,
            details: { status: response.status, attempt: attempt + 1 }
          })
        }).catch(() => {});
      }

      return response;
    } catch (err: any) {
      clearTimeout(timerId);
      const isTimeout = err.name === 'AbortError';
      const isNetwork = err instanceof TypeError; // typical browser TypeError for failed network requests

      if ((isTimeout || isNetwork) && attempt < maxRetries - 1) {
        console.warn(
          `[NETWORK RESILIENCE] Retrying request on '${url}' (${attempt + 1}/${maxRetries}) due to: ${err.message || String(err)}. Retrying in ${currentDelay}ms`
        );
        await new Promise((resolve) => setTimeout(resolve, currentDelay));
        currentDelay *= 2; // exponential backoff
        continue;
      }

      // Log critical client/network failures to tracker
      if (url && !url.includes('/api/system/logs/add')) {
        fetch('/api/system/logs/add', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: isTimeout ? 'timeout_failure' : 'network_failure',
            message: `Safe fetch failure on '${url}': ${err.message || String(err)}`,
            severity: 'error',
            route: url,
            stack: err.stack,
            details: { isTimeout, attempt: attempt + 1 }
          })
        }).catch(() => {});
      }

      throw err;
    }
  }

  throw new Error(`Request to ${url} timed out or failed after ${maxRetries} attempts.`);
}
