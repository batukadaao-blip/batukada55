import { getSupabase } from './supabase';

export type AnalyticsEventType = 
  | 'play' 
  | 'like' 
  | 'download' 
  | 'purchase' 
  | 'follow' 
  | 'profile_visit' 
  | 'beat_click' 
  | 'profile_click' 
  | 'add_to_cart' 
  | 'checkout_start' 
  | 'message_sent' 
  | 'search_performed';

export interface AnalyticsEvent {
  id: string;
  producer_id: string;
  beat_id?: string;
  event_type: AnalyticsEventType;
  user_id?: string;
  amount?: number;
  created_at: string;
  metadata?: Record<string, any>;
}

// Anti-spam tracker to prevent duplicate tracking of certain events in the same session
const throttledEvents = new Map<string, number>();

/**
 * Robust analytics event tracker with throttling, anti-spam, 
 * clean event logging, visual console tracing, and future-proofing
 * for third-party integrations (Google Analytics, Mixpanel, PostHog, Meta Pixel, TikTok Pixel)
 */
export async function trackAnalyticsEvent(
  eventType: AnalyticsEventType,
  payload: {
    producerId?: string;
    beatId?: string;
    userId?: string;
    amount?: number;
    force?: boolean;
    metadata?: Record<string, any>;
  }
) {
  const { producerId, beatId, userId, amount, force, metadata } = payload;
  
  // Guard clause for missing parameters
  let finalProducerId = producerId;
  if (!finalProducerId) {
    if (eventType === 'search_performed') {
      // Searches don't belong to any producer specifically, let's use a system broadcast ID
      finalProducerId = '00000000-0000-0000-0000-000000000000';
    } else {
      return;
    }
  }

  const now = Date.now();
  
  // Throttling key to prevent double clicks, spam play count, profile refresh-farming
  const throttleKey = `${eventType}:${finalProducerId}:${beatId || 'no-beat'}:${userId || 'anon'}`;
  const lastTracked = throttledEvents.get(throttleKey);
  
  // Throttling duration: 15s for messages/clicks, 30s for play/views/follows/downloads to align with Spotify/SaaS standards
  const throttleDuration = (eventType === 'play' || eventType === 'profile_visit' || eventType === 'download') ? 30000 : 10000;

  if (!force && lastTracked && now - lastTracked < throttleDuration) {
    console.log(`%c[ANALYTICS] ⏳ Throttled Event to prevent spam: ${eventType} (Key: ${throttleKey})`, "color: #ff9800; font-weight: bold;");
    return;
  }

  throttledEvents.set(throttleKey, now);

  const eventItem: AnalyticsEvent = {
    id: 'evt_' + Math.random().toString(36).substring(2, 11) + '_' + Math.random().toString(36).substring(2, 11),
    producer_id: finalProducerId,
    beat_id: beatId,
    event_type: eventType,
    user_id: userId,
    amount: amount,
    created_at: new Date().toISOString(),
    metadata: metadata
  };

  // Structured Logging for easy system debugging (Spotify/Stripe Insights console format)
  console.log(
    `%c[BATUKADA ANALYTICS] 📊 Event Tracked: ${eventType.toUpperCase()}`,
    "color: #10B981; font-weight: bold; background: #10B9811A; padding: 2px 5px; border-radius: 4px;",
    eventItem
  );

  // --- FUTURE INTEGRATION PLUGINS (FUTURE-PROOFING HOOKS) ---
  dispatchThirdPartyTrackers(eventType, eventItem);

  // 1. Save to localStorage to guarantee instant UI rendering and fallback offline support
  try {
    const rawLocal = localStorage.getItem('beatangola_analytics_events');
    const localEvents: AnalyticsEvent[] = rawLocal ? JSON.parse(rawLocal) : [];
    localEvents.push(eventItem);
    // Keep local logs bounded to prevent bloated storage
    if (localEvents.length > 5000) {
      localEvents.shift();
    }
    localStorage.setItem('beatangola_analytics_events', JSON.stringify(localEvents));
  } catch (err) {
    console.error('[ANALYTICS] LocalStorage serialization failure:', err);
  }

  // 1.5 Write download to postgres download_events table if it's a download event
  if (eventType === 'download' && beatId) {
    try {
      const supabase = getSupabase();
      if (supabase) {
        const isUUID = (v: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
        const cleanProdId = finalProducerId && isUUID(finalProducerId) ? finalProducerId : null;
        const cleanBeatId = beatId && isUUID(beatId) ? beatId : null;
        const cleanUserId = userId && isUUID(userId) ? userId : null;
        
        if (cleanBeatId && cleanProdId) {
          supabase.from('download_events').insert([{
            beat_id: cleanBeatId,
            producer_id: cleanProdId,
            user_id: cleanUserId,
            created_at: eventItem.created_at
          }]).then(({ error }) => {
            if (error && !error.message.includes('not find the table') && !error.message.includes('schema cache')) {
              console.warn('[ANALYTICS] Database log download failed:', error.message);
            }
          });
        }
      }
    } catch (err) {
      console.warn('[ANALYTICS] Direct db register download error:', err);
    }
  }

  // 2. Report to backend API endpoint so the database retains the metrics
  try {
    const response = await fetch('/api/analytics/event', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(eventItem)
    });
    
    if (!response.ok) {
      throw new Error(`Server returned status code ${response.status}`);
    }
  } catch (err) {
    console.warn('[ANALYTICS] Server API connection issue, logged locally only:', err);
  }
}

/**
 * Hook to inject third-party metrics dynamically
 */
function dispatchThirdPartyTrackers(eventType: string, event: AnalyticsEvent) {
  // 1. Google Analytics (gtag) hook
  if (typeof window !== 'undefined' && (window as any).gtag) {
    try {
      (window as any).gtag('event', eventType, {
        producer_id: event.producer_id,
        beat_id: event.beat_id,
        value: event.amount,
        currency: 'AOA',
        ...event.metadata
      });
    } catch (e) {
      console.warn('[ANALYTICS PLUGIN] Google Analytics failed to dispatch:', e);
    }
  }

  // 2. Mixpanel Pixel wrapper
  if (typeof window !== 'undefined' && (window as any).mixpanel) {
    try {
      (window as any).mixpanel.track(`Batukada ${eventType}`, {
        distinct_id: event.user_id || 'anonymous_visitor',
        producer_id: event.producer_id,
        beat_id: event.beat_id,
        revenue: event.amount,
        ...event.metadata
      });
    } catch (e) {
      console.warn('[ANALYTICS PLUGIN] Mixpanel failed to dispatch:', e);
    }
  }

  // 3. PostHog Tracking script
  if (typeof window !== 'undefined' && (window as any).posthog) {
    try {
      (window as any).posthog.capture(`batukada_${eventType}`, {
        producer_id: event.producer_id,
        beat_id: event.beat_id,
        amount: event.amount,
        ...event.metadata
      });
    } catch (e) {
      console.warn('[ANALYTICS PLUGIN] PostHog failed to dispatch:', e);
    }
  }

  // 4. Meta Pixel (Facebook event conversions)
  if (typeof window !== 'undefined' && (window as any).fbq) {
    try {
      const fbEventMap: Record<string, string> = {
        'purchase': 'Purchase',
        'checkout_start': 'InitiateCheckout',
        'add_to_cart': 'AddToCart',
        'profile_visit': 'ViewContent'
      };
      const metaName = fbEventMap[eventType];
      if (metaName) {
        (window as any).fbq('track', metaName, {
          content_name: event.beat_id || 'Beat Instrumental',
          value: event.amount || 0,
          currency: 'AOA'
        });
      }
    } catch (e) {
      console.warn('[ANALYTICS PLUGIN] Meta Pixel failed to dispatch:', e);
    }
  }

  // 5. TikTok Pixel tracking
  if (typeof window !== 'undefined' && (window as any).ttq) {
    try {
      const ttEventMap: Record<string, string> = {
        'purchase': 'CompletePayment',
        'checkout_start': 'InitiateCheckout',
        'add_to_cart': 'AddToCart'
      };
      const ttName = ttEventMap[eventType];
      if (ttName) {
        (window as any).ttq.track(ttName, {
          contents: [{ id: event.beat_id, quantity: 1 }],
          value: event.amount || 0,
          currency: 'AOA'
        });
      }
    } catch (e) {
      console.warn('[ANALYTICS PLUGIN] TikTok Pixel failed to dispatch:', e);
    }
  }
}

/**
 * Retrieve clean analytics report for a producer over a given filter window
 */
export function getLocalAnalyticsReport(producerId: string, filterDays: 'today' | '7' | '30' | '90' | 'lifetime') {
  try {
    const rawLocal = localStorage.getItem('beatangola_analytics_events');
    const localEvents: AnalyticsEvent[] = rawLocal ? JSON.parse(rawLocal) : [];
    
    // Filter by producer (or allow all if system broadcast)
    let filtered = localEvents.filter(e => e.producer_id === producerId);

    // Apply date window filters
    const now = new Date();
    if (filterDays !== 'lifetime') {
      const cutOff = new Date();
      if (filterDays === 'today') {
        cutOff.setHours(0, 0, 0, 0);
      } else {
        const days = parseInt(filterDays);
        cutOff.setDate(now.getDate() - days);
      }
      filtered = filtered.filter(e => new Date(e.created_at) >= cutOff);
    }

    return filtered;
  } catch (err) {
    console.error('Error computing local analytics report:', err);
    return [];
  }
}
