import { Beat, Promotion, CartEvaluationResult } from '../types';

/**
 * Normalizes beat IDs for accurate lookups.
 */
export function normalizeId(id: string | number | undefined): string {
  if (id === undefined || id === null) return '';
  return String(id).trim().toLowerCase();
}

/**
 * Resolves the unit price of a cart item based on its selected license.
 */
export function getCartItemPrice(item: any): number {
  const lic = String(item.selectedLicense || item.license_type || 'basic').toLowerCase().trim();
  if (lic === 'premium' || lic === 'wav' || lic === 'trackout') {
    return Number(item.price?.premium !== undefined ? item.price.premium : 75000);
  } else if (lic === 'exclusive' || lic === 'unlimited') {
    return Number(item.price?.exclusive !== undefined ? item.price.exclusive : 250000);
  }
  return Number(item.price?.basic !== undefined ? item.price.basic : 25000);
}

/**
 * Checks if a beat matches specific promotion target requirements.
 */
export function checkBeatEligibility(beat: Beat, target_type: string, target_value: string | null): boolean {
  const normValue = target_value ? target_value.trim().toLowerCase() : '';
  
  switch (target_type) {
    case 'all_beats':
      return true;
      
    case 'beat':
      return normalizeId(beat.id) === normValue;
      
    case 'genre':
      return (beat.genre || '').trim().toLowerCase() === normValue;
      
    case 'collection':
      // Check if beat's tags contain the collection name
      return (beat.tags || []).some(t => t.trim().toLowerCase() === normValue);
      
    default:
      return false;
  }
}

/**
 * Evaluates the cart against a list of active promotions.
 * Returns the best promotion applied, the total discount, and an updated items list.
 */
export function evaluateCartPromotions(
  cart: any[],
  activePromotions: Promotion[]
): CartEvaluationResult {
  const subtotal = cart.reduce((acc, item) => acc + getCartItemPrice(item), 0);
  
  if (cart.length === 0 || !activePromotions || activePromotions.length === 0) {
    return {
      applicablePromotion: null,
      discountApplied: 0,
      cartItems: cart.map(item => ({
        ...item,
        originalPrice: getCartItemPrice(item),
        discountApplied: 0,
        isFree: false
      })),
      isEligible: false,
      subtotal,
      total: subtotal,
      savingsMessage: '',
      pendingRequirements: ''
    };
  }

  // Active promotions can be producer-specific or platform-wide (where producer_id === 'platform' or empty)
  // We will run the evaluation for EACH qualifyable promotion, and select the one that yields the GREATEST discount.
  // We do NOT stack promotions.
  
  let bestPromotion: Promotion | null = null;
  let maxDiscount = 0;
  let bestCartItems: any[] = [];
  let bestSavingsMessage = '';
  let bestPendingMessage = '';

  // Process each promotion
  for (const promo of activePromotions) {
    if (promo.status !== 'active') continue;

    // Filter cart items that match this promotion's producer scope
    // Note: If promo.producer_id is 'platform', it matches any beat. Otherwise, matches item.producer_id.
    const producerScopeItems = cart.filter(item => {
      const pId = normalizeId(item.producer_id);
      const promoPId = normalizeId(promo.producer_id);
      return promoPId === 'platform' || pId === promoPId;
    });

    if (producerScopeItems.length === 0) continue;

    // Filter items based on targets and exclude exclusive/unlimited licenses from key rewards
    const targets = promo.targets || [];
    let eligibleItems: Beat[] = [];

    const baseEligible = producerScopeItems.filter(beat => {
      const lic = String(beat.selectedLicense || beat.license_type || 'basic').toLowerCase().trim();
      const isExclusive = lic === 'exclusive' || lic === 'unlimited';
      // Exclusive and Unlimited licenses can NEVER become free or get promotion discounts
      if (isExclusive) return false;

      if (targets.length === 0) return true;
      return targets.some(target => checkBeatEligibility(beat, target.target_type, target.target_value));
    });

    eligibleItems = baseEligible;

    let calculatedDiscount = 0;
    let promoSavingsMessage = '';
    let promoPendingMessage = '';
    let tempItems = cart.map(item => {
      const priceVal = getCartItemPrice(item);
      return {
        ...item,
        isFree: false,
        originalPrice: priceVal,
        discountApplied: 0
      };
    });

    // Evaluate promotion type
    if (promo.promo_type === 'buy_x_get_y') {
      const buyQty = promo.buy_qty || 2;
      const getQty = promo.get_qty || 1;
      const threshold = buyQty + getQty; // For Buy 2 Get 1, threshold is 3

      if (eligibleItems.length >= threshold) {
        // Calculate number of multiples of free item batches
        // e.g. 3 items = 1 free, 6 items = 2 free
        const batches = Math.floor(eligibleItems.length / threshold);
        
        // Sort eligible items by actual current price ASC to make the cheapest ones free
        const sortedEligible = [...eligibleItems].sort((a, b) => getCartItemPrice(a) - getCartItemPrice(b));
        
        // Take the cheapest 'batches * getQty' items to make them free
        const freeItemsToMark = sortedEligible.slice(0, batches * getQty);

        // Mark them as free in tempItems, matching one by one (respecting duplicates if multiple same beats are in cart)
        tempItems = tempItems.map(item => {
          const lic = String(item.selectedLicense || item.license_type || 'basic').toLowerCase().trim();
          if (lic === 'exclusive' || lic === 'unlimited') {
            return item; // exclusive can never be free
          }

          const matchingFreeItemIdx = freeItemsToMark.findIndex((f, idx) => {
            // Find a free item with same id, that we haven't checked off yet
            return normalizeId(f.id) === normalizeId(item.id) && !(f as any).hasBeenApplied;
          });

          if (matchingFreeItemIdx !== -1) {
            // Mark as applied so we don't double count
            freeItemsToMark[matchingFreeItemIdx].hasBeenApplied = true;
            const originalItemPrice = getCartItemPrice(item);
            calculatedDiscount += originalItemPrice;
            
            // Set prices to 0 in mapped price object to retain consistency
            const updatedPrice = { ...item.price };
            if (lic === 'premium' || lic === 'wav' || lic === 'trackout') {
              updatedPrice.premium = 0;
            } else {
              updatedPrice.basic = 0;
            }

            return {
              ...item,
              isFree: true,
              price: updatedPrice,
              discountApplied: originalItemPrice
            };
          }
          return item;
        });

        promoSavingsMessage = `🔥 Promoção ativa [${promo.name}]: Adicionou ${eligibleItems.length} beats e recebeu ${batches * getQty} grátis! Economiza ${calculatedDiscount.toLocaleString()} Kz.`;
      } else {
        // Promotion exists, but user didn't hit threshold
        const needed = threshold - eligibleItems.length;
        if (needed > 0 && needed <= 1) { // Suggest when exactly 1 beat short
          promoSavingsMessage = '';
          const producerName = eligibleItems[0]?.producer || 'mesmo produtor';
          promoPendingMessage = `💡 Dica: Adicione mais ${needed} beat do produtor @${producerName} para ativar a promoção "${promo.name}" e levar o ${threshold}º Grátis!`;
        }
      }
    } else if (promo.promo_type === 'percentage') {
      // Future-ready: Apply percentage discount to all eligible items
      const pct = (promo.discount_value || 0) / 100;
      tempItems = tempItems.map(item => {
        const isEligible = eligibleItems.some(e => normalizeId(e.id) === normalizeId(item.id));
        if (isEligible) {
          const originalItemPrice = getCartItemPrice(item);
          const savings = Math.round(originalItemPrice * pct);
          calculatedDiscount += savings;

          const updatedPrice = { ...item.price };
          const lic = String(item.selectedLicense || item.license_type || 'basic').toLowerCase().trim();
          if (lic === 'premium' || lic === 'wav' || lic === 'trackout') {
            updatedPrice.premium = Math.max(0, (item.price?.premium ?? 75000) - savings);
          } else {
            updatedPrice.basic = Math.max(0, (item.price?.basic ?? 25000) - savings);
          }

          return {
            ...item,
            price: updatedPrice,
            discountApplied: savings
          };
        }
        return item;
      });
      promoSavingsMessage = `🔥 Cupão [${promo.name}] aplicado: ${promo.discount_value}% de desconto nos itens elegíveis. Economiza ${calculatedDiscount.toLocaleString()} Kz!`;
    } else if (promo.promo_type === 'fixed_amount') {
      // Future-ready: Fixed flat amount discount distrib type
      const flatDiscount = promo.discount_value || 0;
      if (flatDiscount > 0 && eligibleItems.length > 0) {
        const eligibleSubtotal = eligibleItems.reduce((sum, e) => sum + getCartItemPrice(e), 0);
        calculatedDiscount = Math.min(flatDiscount, eligibleSubtotal);

        // Distribute discount proportionally across eligible items
        tempItems = tempItems.map(item => {
          const isEligible = eligibleItems.some(e => normalizeId(e.id) === normalizeId(item.id));
          if (isEligible) {
            const originalItemPrice = getCartItemPrice(item);
            const ratio = eligibleSubtotal > 0 ? originalItemPrice / eligibleSubtotal : 0;
            const itemDiscount = Math.round(calculatedDiscount * ratio);

            const updatedPrice = { ...item.price };
            const lic = String(item.selectedLicense || item.license_type || 'basic').toLowerCase().trim();
            if (lic === 'premium' || lic === 'wav' || lic === 'trackout') {
              updatedPrice.premium = Math.max(0, (item.price?.premium ?? 75000) - itemDiscount);
            } else {
              updatedPrice.basic = Math.max(0, (item.price?.basic ?? 25000) - itemDiscount);
            }

            return {
              ...item,
              price: updatedPrice,
              discountApplied: itemDiscount
            };
          }
          return item;
        });
        promoSavingsMessage = `🔥 Desconto Flat [${promo.name}]: Desconto direto de ${calculatedDiscount.toLocaleString()} Kz aplicado!`;
      }
    }

    // Keep the promotion with the highest overall discount
    if (calculatedDiscount > maxDiscount) {
      maxDiscount = calculatedDiscount;
      bestPromotion = promo;
      bestCartItems = tempItems;
      bestSavingsMessage = promoSavingsMessage;
      bestPendingMessage = promoPendingMessage;
    } else if (promoPendingMessage && !bestPendingMessage) {
      // Carry over a pending helper tip if no promotion has been applied yet
      bestPendingMessage = promoPendingMessage;
    }
  }

  // If no promotion applied successfully, fallback to basic cart mapping
  if (maxDiscount === 0) {
    return {
      applicablePromotion: null,
      discountApplied: 0,
      cartItems: cart.map(item => ({
        ...item,
        originalPrice: getCartItemPrice(item),
        discountApplied: 0,
        isFree: false
      })),
      isEligible: false,
      subtotal,
      total: subtotal,
      savingsMessage: '',
      pendingRequirements: bestPendingMessage
    };
  }

  return {
    applicablePromotion: bestPromotion,
    discountApplied: maxDiscount,
    cartItems: bestCartItems,
    isEligible: true,
    subtotal,
    total: Math.max(0, subtotal - maxDiscount),
    savingsMessage: bestSavingsMessage,
    pendingRequirements: bestPendingMessage
  };
}
