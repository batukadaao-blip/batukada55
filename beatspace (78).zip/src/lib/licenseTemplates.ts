export interface LicenseData {
  beatTitle: string;
  licenseType: string;
  buyerName: string;
  producerName: string;
  orderId: string;
  date: string;
  bpm?: string | number;
  genre?: string;
  price?: string;
}

export function generateLicensePDF(doc: any, data: LicenseData) {
  const {
    beatTitle = 'Instrumental Sem Nome',
    licenseType = 'Basic',
    buyerName = 'Artista Licenciado',
    producerName = 'Produtor Autorizado',
    orderId = 'N/A',
    date = 'Maio de 2026',
    bpm = '120',
    genre = 'Kizomba / Semba / Afro House',
    price = 'N/A'
  } = data;

  const orderHex = orderId.substring(0, 8).toUpperCase();
  const typeLower = licenseType.toLowerCase();

  // 1. Determine parameters based on license tier
  let formatText = "Ficheiro de Áudio em formato MP3 (alta qualidade 320kbps).";
  let streamLimit = "5.000 (Cinco Mil) streams monetizados";
  let salesLimit = "Distribuição física limitada a 50 unidades.";
  let audioVideoLimits = "Permitido apenas para vídeos promocionais de caráter não monetizado.";
  let exclusivityClause = "NÃO-EXCLUSIVO. O Produtor retém o direito absoluto de continuar a licenciar e comercializar este instrumental para terceiros sem qualquer restrição.";
  let licensingRights = "O Licenciado adquire uma licença não-exclusiva temporária e revogável de reprodução de áudio. Todas as masters originais e composições subjacentes permanecem propriedade do Produtor.";

  if (typeLower === 'premium') {
    formatText = "Ficheiros de Áudio em formato MP3 (320kbps) e WAV (24-bit de alta definição estúdio).";
    streamLimit = "50.000 (Cinquenta Mil) streams monetizados acumulados.";
    salesLimit = "Distribuição física limitada a 500 unidades.";
    audioVideoLimits = "Permitido o sincronismo em 1 (um) videoclipe oficial monetizado no YouTube com limite de 50.000 visualizações.";
    exclusivityClause = "NÃO-EXCLUSIVO. Esta licença estende direitos de transmissão e uso em rádios locais e regionais de âmbito nacional angolano. O instrumental permanece no catálogo para novos compradores.";
  } else if (typeLower === 'exclusive' || typeLower === 'exclusiva') {
    formatText = "Ficheiros de Alta Definição: Master WAV (24-bit), ficheiro MP3 e ficheiros de faixas separadas (STEMS/TRACKOUTS individuais de produção).";
    streamLimit = "ILIMITADO (Canais de streaming digitais como Spotify, Apple Music, YouTube Music sem qualquer barreira ou teto).";
    salesLimit = "Distribuição física ILIMITADA (LPs, CDs, Cassetes, Pen Drives promocionais).";
    audioVideoLimits = "Videoclipes ilimitados com monetização ativa sem restrição de reproduções.";
    exclusivityClause = "EXCLUSIVIDADE ABSOLUTA E VITALÍCIA. A partir da data de assinatura deste contrato, o instrumental é permanentemente retirado do catálogo da plataforma BATUKADA. Nenhuma nova licença para este instrumental será concedida. Todas as licenças pré-existentes concedidas a terceiros antes desta transação permanecerão no status original de não-exclusivas e ativas, não anuláveis.";
    licensingRights = "O Licenciado obtém a propriedade exclusiva da Gravação Master contendo a nova canção vocalizada, incluindo o direito total de exploração comercial, reprodução e gravação. O Produtor retém 50% dos direitos de composição de autoria intelectual da melodia original do instrumental (Publisher/Direitos Autorais de Execução), devendo o Licenciado declarar as devidas filiações na SADIA ou órgão competente correspondente de direitos de representação geográfica em Angola.";
  }

  // Margins & Dimensions
  const margin = 20;
  const pageWidth = 210;
  const pageHeight = 297;
  const contentWidth = pageWidth - (margin * 2);
  let y = 30;

  // Helper function to draw header and decorative lines
  const drawPageHeaderAndBorder = (pageNum: number) => {
    // Elegant border frame (subtle warm-slate color)
    doc.setDrawColor(245, 158, 11); // Gold/Orange accent border
    doc.setLineWidth(0.5);
    doc.rect(10, 10, pageWidth - 20, pageHeight - 20);

    doc.setDrawColor(30, 41, 59); // Dark slate
    doc.setLineWidth(0.3);
    doc.line(15, 15, pageWidth - 15, 15);
    doc.line(15, pageHeight - 15, pageWidth - 15, pageHeight - 15);

    // Page Number
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(`BATUKADA LICENÇA DIGITAL • PÁGINA ${pageNum}`, pageWidth / 2, pageHeight - 18, { align: "center" });

    // Mini Top Brand label
    doc.text("REGISTRY SECURE DOCUMENT VERIFIED REAL-TIME", pageWidth - 20, 13, { align: "right" });
    doc.text(`CONTRATO DE LICENCIAMENTO LIC-${orderHex}`, 20, 13);
  };

  const checkPageBreak = (needed: number) => {
    if (y + needed > pageHeight - 25) {
      doc.addPage();
      currentPage++;
      drawPageHeaderAndBorder(currentPage);
      y = 25; // Reset coordinates on new page
    }
  };

  let currentPage = 1;
  drawPageHeaderAndBorder(currentPage);

  // --- TOP LOGO & HEADER ---
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(24);
  doc.setTextColor(245, 158, 11); // Logo primary orange
  doc.text("▲ BATUKADA", pageWidth / 2, y, { align: "center" });
  y += 7;

  doc.setFontSize(9);
  doc.setTextColor(115, 115, 115);
  doc.text("THE DEFINITIVE ANGOLAN MUSIC LICENSING MARKETPLACE", pageWidth / 2, y, { align: "center" });
  y += 10;

  // Line Separator
  doc.setDrawColor(245, 158, 11);
  doc.setLineWidth(1);
  doc.line(20, y, pageWidth - 20, y);
  y += 8;

  // Document Title Box
  doc.setFillColor(15, 23, 42); // Navy Slate dark box
  doc.rect(20, y, contentWidth, 14, "F");
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text("CONTRATO OFICIAL DE LICENÇA DE USO MUSICAL", pageWidth / 2, y + 9, { align: "center" });
  y += 22;

  // Metadata block (BENTO STYLE)
  doc.setDrawColor(226, 232, 240);
  doc.setFillColor(248, 250, 252);
  doc.rect(20, y, contentWidth, 38, "FD");

  doc.setFont("Helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);

  // Left Column Metadata
  doc.text(`REGISTO DIGITAL: LIC-${orderHex}`, 25, y + 8);
  doc.text(`TIPO DE LICENÇA: ${licenseType.toUpperCase()} LICENSE`, 25, y + 16);
  doc.text(`DATA DA COMPRA: ${date}`, 25, y + 24);
  doc.text(`CUSTO DE ADQUISIÇÃO: ${price}`, 25, y + 32);

  // Right Column Metadata
  doc.text(`BPM COGNITIVO: ${bpm}`, 115, y + 8);
  doc.text(`GÉNERO / ESTILO: ${genre}`, 115, y + 16);
  doc.text(`SITUAÇÃO DO REGISTO: ATIVO & REGISTADO`, 115, y + 24);
  doc.text(`AMBIENTE: LUANDA, ANGOLA`, 115, y + 32);

  y += 48;

  // Sections definitions
  const sections = [
    {
      title: "1. IDENTIFICAÇÃO FORMAL DAS PARTES JURÍDICAS",
      text: `O presente acordo de licença constitui um contrato civil e comercial de natureza irrevogável e definitiva estabelecido de harmonia mútua entre:
• LICENCIADOR (PRODUTOR): ${producerName}, doravante designado para todos os efeitos legais como "AUTOR/PRODUTOR".
• LICENCIADO (ARTISTA COMPRADOR): ${buyerName}, doravante designado para todos os efeitos como "ARTISTA LICENCIADO".
• OBRA DE COMPOSIÇÃO: O instrumental original e master produzidos inteiramente por ${producerName} intitulado originalmente "${beatTitle}".
A celebração e compensação deste contrato de faturamento sob a ordem ID ${orderId} garante a legitimidade dos termos abaixo descritos.`
    },
    {
      title: "2. ESPECIFICAÇÃO DOS DIREITOS DE USO CONCEDIDOS",
      text: `O Produtor concede por meio deste instrumento jurídico ao Artista Licenciado uma autorização expressa para gravar obras vocais (letras, vozes e canções suplementares) sobrepostas à faixa masterizada, com escopo geral de mixagem e masterização.
• Formatos Entregues e Qualidade Garantida: ${formatText}
• Territorialidade Absoluta: A presente licença de uso garante validade vitalícia em âmbito geográfico Global e Universal.`
    },
    {
      title: "3. RESTRIÇÕES ESPECÍFICAS E LIMITAÇÕES DE USO",
      text: "Fica expressa e formalmente proibido ao Artista Licenciado: Isolar samples, arranjar loops de bateria de forma separada sob alegação de autoria própria para comercialização em pacotes de terceiros. Também não é permitido registrar o instrumental limpo (sem vocais) no sistema Content ID do YouTube ou no ecossistema Meta, sob pena de encerramento imediato de canais, perda de monetização e pedidos judiciais por danos intelectuais combinados."
    },
    {
      title: "4. LIMITARES DE REPRODUÇÃO - STREAMS DIGITAIS",
      text: `As transmissões nos maiores distribuidores da indústria musical mundial (tais como Spotify, Apple Music, Tidal, Deezer, Amazon Music e YouTube) estão rigidamente vinculadas ao teto desta licença:
• Transmissões Autorizadas: ${streamLimit}
Caso este volume acumulado seja atingido ou ultrapassado, o Licenciado concorda voluntariamente em entrar em contato com o Produtor para efetuar um upgrade contratual sob pena de suspensão de exibições do master.`
    },
    {
      title: "5. LIMITES DE DISTRIBUIÇÃO E VENDAS FÍSICAS REAIS",
      text: `• Teto de Cópias Físicas Permitido: ${salesLimit}
Estas vendas compreendem a autopromoção de mixtapes, compilações físicas, cassetes ou discos físicos de distribuição independente no mercado de rua ou espectáculos angolanos.`
    },
    {
      title: "6. UTILIZAÇÃO PARA ÁUDIO-VISUAL, CINEMA E SINCRONISMO",
      text: `• Limitação de Sincronismo Vídeo-Clipes: ${audioVideoLimits}
Estes direitos destinam-se a upload no canal oficial de artista do comprador. Qualquer uso corporativo secundário para redes de TV comerciais por satélite ou campanhas de marketing milionárias obriga à celebração de um contrato comercial anexo assinado mutuamente.`
    },
    {
      title: "7. COPYRIGHT, DIREITOS PATRIMONIAIS E ROYALTY SPLIT",
      text: `Toda a estrutura intelectual, ondas geradas e arranjos harmónicos do instrumental "${beatTitle}" são de exclusiva autoria e direito conexo permanente do Produtor. 
Para efeitos de registo na Sociedade de Autores e conexos como a SADIA (ou similares correspondentes geográficos globais), o split de direitos de COMPOSIÇÃO MUSICAL deverá ser assinalado obrigatoriamente na partilha de 50% (cinquenta por cento) para o Produtor e 50% (cinquenta por cento) para o Autor dos Vocais (Artista Licenciado), resguardando os devidos benefícios das partes.`
    },
    {
      title: "8. CRÉDITOS OBRIGATÓRIOS DO PRODUTOR",
      text: `O Artista Licenciado assume a obrigação essencial de expor publicamente a autoria e os devidos louvores de produção musical em todas as mídias sociais e distribuidoras que façam o upload desta composição integrada.
• Formatos Oficiais Exigidos: "Produzido por ${producerName}" ou "Prod. ${producerName}".`
    },
    {
      title: "9. CLÁUSULA DE IRREVOGABILIDADE E NÃO-REVENDA",
      text: "A presente licença é estritamente pessoal, individual e intransferível de qualquer forma. O Artista Licenciado não possui permissão jurídica de revender, fundar pacotes promocionais de faturamento, sublicenciar ou alugar os ficheiros de áudio individuais para qualquer amigo, banda ou colega sem o consentimento formal expresso por escrito do Produtor."
    },
    {
      title: "10. PROIBIÇÃO DE PIRATARIA OU ARQUIVAMENTO COMPARTILHADO",
      text: "Os ficheiros fornecidos destinam-se ao uso de trabalho de estúdio do Licenciado. O compartilhamento público de links diretos em postagens de fóruns de distribuição digital ou hospedagem descentralizada sem controlo de acessos privados configura facilitação e incentivo à pirataria digital, acarretando penalizações e rescisão imediata desta licença."
    },
    {
      title: "11. CLÁUSULAS ADICIONAIS DE EXCLUSIVIDADE (EXCLUSIVE RIGHTS)",
      text: `• Do Status de Exclusividade e Comercialização: ${exclusivityClause}
• Direitos e Garantia de Ownership: ${licensingRights}`
    },
    {
      title: "12. CONSEQUÊNCIAS DE VIOLAÇÕES DOS TERMOS LEGAIS",
      text: "Qualquer transgressão aos termos pactuados, inclusive a falta de atribuição correta dos créditos ao Produtor ou estouro intencional dos limites de streaming sem upgrade de licença, será interpretada como uso não autorizado sob as diretrizes da Lei sobre os Direitos de Autor e Conexos de Angola (Lei n.º 15/14, de 31 de Julho), conferindo ao Produtor o direito de remover judicialmente a canção das plataformas e buscar devidas indenizações pecuniárias."
    },
    {
      title: "13. REEMBOLSOS E POLÍTICA DE FATURAMENTO",
      text: "Pelo fato de tratar-se de conteúdos inteiramente digitais e de download instantâneo pós-aquisição, todas as faturas são consideradas conclusivas, permanentes e não elegíveis para cancelamento, estorno bancário ou qualquer outra modalidade de reembolso voluntário fora do âmbito legal do marketplace."
    },
    {
      title: "14. RESCISÃO DE DIREITOS JURÍDICOS CONTRATUAIS",
      text: "A licença será terminada de pleno direito caso seja comprovada qualquer fraude de faturamento por cartão ou referências Multicaixa, ou difamação sistemática intencional contra o Produtor, obrigando à destruição irreversível dos masters originais gravados em estúdio."
    },
    {
      title: "15. JURISDIÇÃO ELEITA E LEGISLACÃO VINCULADA",
      text: "Este contrato é exclusivamente regido, interpretado e tutelado de acordo com a legislação e tribunais em vigor na República de Angola. As partes conferem de comum acordo o Foro da Comarca de Luanda como único foro e instância judicial cabível para decidir pendências de interpretação ou litígio comercial relativos ao mesmo."
    },
    {
      title: "16. ASSINATURA DIGITAL, ASSENTIMENTO E VALIDAÇÃO",
      text: "A validade e eficácia deste instrumento jurídico dão-se de forma estritamente eletrónica. Ao preencher os seus dados no portal BATUKADA, assinalar formalmente a concordância integral com as Políticas de Uso e concluir o pagamento da fatura designada, o Artista Licenciado e o Produtor chancelam de forma definitiva o seu assentimento às 16 cláusulas deste documento."
    }
  ];

  // Draw sections sequentially
  sections.forEach((sec) => {
    checkPageBreak(30);

    // Section title
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42); // slate navy
    doc.text(sec.title, 20, y);
    y += 5;

    // Split text and write paragraphs
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85); // dark gray readable text

    const lines = doc.splitTextToSize(sec.text, contentWidth);
    lines.forEach((line: string) => {
      checkPageBreak(4.5);
      doc.text(line, 20, y);
      y += 4.5;
    });

    y += 4; // Spacing between sections
  });

  // Visually pleasing Digital Sign-off area on last page
  checkPageBreak(50);

  y += 6;
  doc.setLineWidth(0.3);
  doc.setDrawColor(203, 213, 225);
  doc.line(20, y, pageWidth - 20, y);
  y += 8;

  doc.setFont("Helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text("CHANCELA DE VERIFICAÇÃO ELETRÓNICA E ASSINATURA", 20, y);
  y += 10;

  // Signature Block Columns
  doc.setFont("Helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);

  const signY = y;
  
  // Produtor signature
  doc.text("ASSINATURA DIGITAL DO PRODUTOR:", 20, signY);
  doc.setFont("Courier", "bolditalic");
  doc.setFontSize(11);
  doc.setTextColor(245, 158, 11);
  doc.text(`[SIGNED: ${producerName.toUpperCase()}]`, 20, signY + 6);
  
  // Comprador signature
  doc.setFont("Helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text("ASSINATURA DIGITAL DO ARTISTA COMPRADOR:", 110, signY);
  doc.setFont("Courier", "bolditalic");
  doc.setFontSize(11);
  doc.setTextColor(59, 130, 246);
  doc.text(`[SIGNED: ${buyerName.toUpperCase()}]`, 110, signY + 6);

  y += 18;

  // Crypto status bar
  doc.setFillColor(241, 245, 249);
  doc.rect(20, y, contentWidth, 12, "F");
  
  doc.setFont("Courier", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(30, 41, 59);
  doc.text(`BATUKADA VERIFICATION DECENTRALIZED ID: BAT-ID-${orderHex}-VERIFIED-${date.replace(/\s+/g, '')}`, 23, y + 8);

  // Save PDF output
  doc.save(`Contrato_Licenca_BAT-${orderHex}_${beatTitle.replace(/\s+/g, '_')}.pdf`);
}
