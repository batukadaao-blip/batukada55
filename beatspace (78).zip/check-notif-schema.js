import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

async function check() {
  const url = `${process.env.VITE_SUPABASE_URL || ''}/rest/v1/`;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';
  const response = await fetch(url, {
    headers: {
      'apikey': key,
      'Authorization': `Bearer ${key}`
    }
  });
  const json = await response.json();
  console.log('notifications columns:', Object.keys(json?.definitions?.notifications?.properties || {}));
}

check();
