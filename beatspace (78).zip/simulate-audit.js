import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const anonKey = process.env.VITE_SUPABASE_ANON_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
  try {
    const urlObj = new URL(url);
    url = urlObj.origin;
  } catch (e) {
    url = url.replace(/\/+$/, '');
  }
}

async function run() {
  if (!url || !serviceRoleKey) {
    console.log("No URL or Service Role Key found!");
    return;
  }
  
  // Create an admin/service_role client which bypasses RLS to check/setup initial values
  const adminClient = createClient(url, serviceRoleKey);
  const targetId = '6e4c1b73-32b3-4252-85bc-d74f0a6f6adb'; // ID for prodjaymbeats@gmail.com
  
  console.log(`\n--- [1] INITIAL DB STATE (USING SERVICE_ROLE) ---`);
  const { data: initialProfile, error: getErr } = await adminClient
    .from('profiles')
    .select('*')
    .eq('id', targetId)
    .maybeSingle();
    
  if (getErr) {
    console.error("Error reading initial state:", getErr);
    return;
  }
  
  console.log("Initial state of profiles table for", targetId, ":");
  console.log(JSON.stringify(initialProfile, null, 2));

  // Let's list the available columns on the table:
  const columnNames = initialProfile ? Object.keys(initialProfile) : [];
  console.log("\nActual Columns on the 'profiles' Table:");
  console.log(columnNames);

  console.log("\n--- [2] ANALYZING RECENT FRONTEND INPUT v. DATABASE MAP ---");
  console.log("When hitting save, the system sends:");
  console.log({
    display_name: "Artistic/Display Name input field value",
    username: "Username input field value",
    city: "Location input field value",
    avatar_url: "Avatar URL",
    phone: "JSON string containing contact phone, bio, banner_url, social_links..."
  });
  
  console.log("\nDoes the table have profiles.username?", columnNames.includes('username'));
  console.log("Does the table have profiles.display_name?", columnNames.includes('display_name'));
  console.log("Does the table have profiles.artistic_name?", columnNames.includes('artistic_name'));
  console.log("Does the table have profiles.avatar_url?", columnNames.includes('avatar_url'));
  console.log("Does the table have profiles.city?", columnNames.includes('city'));
  console.log("Does the table have profiles.phone?", columnNames.includes('phone'));
  console.log("Does the table have profiles.bio?", columnNames.includes('bio'));
}

run().catch(console.error);
