import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL || '', process.env.SUPABASE_SERVICE_ROLE_KEY || '');

async function checkColumns() {
  const { data, error } = await supabase.from('order_items').select('id, producer_earnings, platform_fee').limit(1);
  if (error) {
    console.error('Columns do NOT exist or error occurred:', error);
  } else {
    console.log('Columns EXIST! Data:', data);
  }
}

checkColumns();
