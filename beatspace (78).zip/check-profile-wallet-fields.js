import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
  try {
    const urlObj = new URL(url);
    url = urlObj.origin;
  } catch (e) {
    url = url.replace(/\/+$/, '');
  }
}
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

async function check() {
  const supabase = createClient(url, key);
  const { data, error } = await supabase.from('profiles').select('id, display_name, artistic_name, role, wallet_pending_balance, wallet_available_balance, wallet_total_earned, wallet_total_withdrawn, wallet_balance');
  if (error) {
    console.error('Error:', error);
  } else {
    console.log('Profiles data:', JSON.stringify(data, null, 2));
  }
}

check();
