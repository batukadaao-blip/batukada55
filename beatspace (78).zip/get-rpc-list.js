import dotenv from 'dotenv';
dotenv.config();

const url = process.env.VITE_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY;

if (url && key) {
  try {
    let apiEndpoint = url;
    if (!apiEndpoint.includes('/rest/v1')) {
      apiEndpoint = `${apiEndpoint.replace(/\/$/, '')}/rest/v1/`;
    }
    const res = await fetch(apiEndpoint, {
      headers: {
        'apikey': key,
        'Authorization': `Bearer ${key}`
      }
    });
    const spec = await res.json();
    console.log('All paths in OpenAPI spec:', Object.keys(spec.paths || {}));
  } catch (err) {
    console.error('Error fetching spec:', err);
  }
} else {
  console.log('Missing credentials');
}
