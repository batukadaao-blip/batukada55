-- ==============================================================================
-- BeatAngola: Order Processor RPC
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.process_order(
  p_customer_id UUID,
  p_items JSONB,
  p_total_amount NUMERIC
)
RETURNS UUID AS $$
DECLARE
  v_order_id UUID;
  v_item JSONB;
  v_beat_id INTEGER;
  v_producer_id UUID;
  v_license_id INTEGER;
  v_price NUMERIC;
BEGIN
  -- 1. Create Order using correct column names from public.orders table
  INSERT INTO public.orders (customer_id, amount, status)
  VALUES (p_customer_id, p_total_amount, 'pending')
  RETURNING id INTO v_order_id;

  -- 2. Process Items
  FOR v_item IN SELECT * FROM jsonb_array_elements(p_items)
  LOOP
    v_beat_id := (v_item->>'beat_id')::INTEGER;
    v_producer_id := (v_item->>'producer_id')::UUID;
    v_license_id := (v_item->>'license_id')::INTEGER;
    v_price := (v_item->>'price')::NUMERIC;

    -- Add Order Item (using correct INTEGER beat_id and license_id)
    INSERT INTO public.order_items (order_id, beat_id, license_id, price, producer_id)
    VALUES (v_order_id, v_beat_id, v_license_id, v_price, v_producer_id);

    -- Grant Access
    INSERT INTO public.purchased_beats (customer_id, beat_id, license_id, order_id)
    VALUES (p_customer_id, v_beat_id, v_license_id, v_order_id);

    -- Update Producer's wallet balance directly in public.profiles:
    UPDATE public.profiles
    SET wallet_balance = COALESCE(wallet_balance, 0) + (v_price * 0.9)
    WHERE id = v_producer_id;
  END LOOP;

  RETURN v_order_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
