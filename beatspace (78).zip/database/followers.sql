-- ==========================================
-- BeatAngola: followers Table setup
-- ==========================================

CREATE TABLE IF NOT EXISTS public.followers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Unique index to prevent duplicate followers
CREATE UNIQUE INDEX IF NOT EXISTS unique_follow_relationship
ON public.followers (follower_id, following_id);

-- Enable Row Level Security (RLS)
ALTER TABLE public.followers ENABLE ROW LEVEL SECURITY;

-- 1. Select policy: Anyone can see who follows whom
DROP POLICY IF EXISTS "Followers are viewable by everyone" ON public.followers;
CREATE POLICY "Followers are viewable by everyone"
ON public.followers
FOR SELECT
USING (true);

-- 2. Insert policy: Authenticated users can follow others as themselves
DROP POLICY IF EXISTS "Authenticated users can follow" ON public.followers;
CREATE POLICY "Authenticated users can follow"
ON public.followers
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = follower_id);

-- 3. Delete policy: Authenticated users can unfollow others
DROP POLICY IF EXISTS "Users can unfollow" ON public.followers;
CREATE POLICY "Users can unfollow"
ON public.followers
FOR DELETE
TO authenticated
USING (auth.uid() = follower_id);

-- Grant privileges to authenticated users and service_role
GRANT ALL ON public.followers TO authenticated;
GRANT ALL ON public.followers TO service_role;
