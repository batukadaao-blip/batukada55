-- ==============================================================================
-- BeatSpace: Promotions System Database Schema
-- ==============================================================================

-- 1. Promotions Table
CREATE TABLE IF NOT EXISTS public.promotions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    producer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE DEFAULT NULL, -- NULL for automatic cart promotions
    promo_type VARCHAR(50) NOT NULL, -- 'buy_x_get_y', 'percentage', 'fixed_amount', 'flash_sale', 'bundle'
    buy_qty INTEGER DEFAULT 0, -- For buy_x_get_y (e.g., 2)
    get_qty INTEGER DEFAULT 0, -- For buy_x_get_y (e.g., 1)
    discount_value NUMERIC DEFAULT 0, -- Percentage or fixed amount discount, if applicable
    start_date TIMESTAMPTZ DEFAULT NULL,
    end_date TIMESTAMPTZ DEFAULT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'scheduled'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast status and date querying
CREATE INDEX IF NOT EXISTS idx_promotions_status_dates ON public.promotions(status, start_date, end_date);
-- Index for producer mapping
CREATE INDEX IF NOT EXISTS idx_promotions_producer ON public.promotions(producer_id);

-- 2. Promotion Targets Table (Determines what beats / categories are eligible)
CREATE TABLE IF NOT EXISTS public.promotion_targets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    promotion_id UUID NOT NULL REFERENCES public.promotions(id) ON DELETE CASCADE,
    target_type VARCHAR(50) NOT NULL, -- 'all_beats', 'beat', 'genre', 'collection'
    target_value VARCHAR(255) DEFAULT NULL, -- UUID string of beat_id, name of genre, or collection tag
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_promotion_targets_promo ON public.promotion_targets(promotion_id);
CREATE INDEX IF NOT EXISTS idx_promotion_targets_lookup ON public.promotion_targets(target_type, target_value);

-- 3. Promotion Usage / History Table (For tracking redemptions and analytics)
CREATE TABLE IF NOT EXISTS public.promotion_usage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    promotion_id UUID NOT NULL REFERENCES public.promotions(id) ON DELETE CASCADE,
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    customer_id UUID DEFAULT NULL, -- From profiles/auth, can be public
    discount_applied NUMERIC NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_promotion_usage_promo ON public.promotion_usage(promotion_id);
CREATE INDEX IF NOT EXISTS idx_promotion_usage_order ON public.promotion_usage(order_id);
CREATE INDEX IF NOT EXISTS idx_promotion_usage_customer ON public.promotion_usage(customer_id);

-- Enable RLS
ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotion_targets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotion_usage ENABLE ROW LEVEL SECURITY;

-- Simple permissive policies for demonstration (normally scoped to specific producers)
CREATE POLICY "Allow public read-only access to promotions" ON public.promotions
    FOR SELECT TO public USING (status = 'active');

CREATE POLICY "Allow producers full access to their promotions" ON public.promotions
    FOR ALL TO authenticated USING (producer_id = auth.uid());

CREATE POLICY "Allow public read-only access to promotion targets" ON public.promotion_targets
    FOR SELECT TO public USING (true);

CREATE POLICY "Allow producers full access to their promotion targets" ON public.promotion_targets
    FOR ALL TO authenticated USING (
        EXISTS (
            SELECT 1 FROM public.promotions p 
            WHERE p.id = promotion_targets.promotion_id AND p.producer_id = auth.uid()
        )
    );

CREATE POLICY "Allow reading promotion usages" ON public.promotion_usage
    FOR SELECT TO public USING (true);

CREATE POLICY "Allow inserting promotion usages" ON public.promotion_usage
    FOR INSERT TO public WITH CHECK (true);
