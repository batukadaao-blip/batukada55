-- ==============================================================================
-- BATUKADA Marketplace: Smart Link & Short URL System DB Schema
-- ==============================================================================

-- 1. Short Links Table
CREATE TABLE IF NOT EXISTS public.short_links (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(100) UNIQUE NOT NULL, -- The short code/slug (e.g., 'azura', 'azura-x7f2')
    type VARCHAR(50) NOT NULL, -- 'beat', 'kit', 'profile', 'promotion'
    target_id UUID DEFAULT NULL, -- UUID of the target resource (beat_id, profile_id, promotion_id)
    target_url TEXT NOT NULL, -- Full target redirection URL
    producer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    clicks_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for code lookup (extremely fast redirects)
CREATE INDEX IF NOT EXISTS idx_short_links_code ON public.short_links(code);
-- Index for producer ownership and retrieval
CREATE INDEX IF NOT EXISTS idx_short_links_producer ON public.short_links(producer_id);
-- Index for target tracking
CREATE INDEX IF NOT EXISTS idx_short_links_target ON public.short_links(type, target_id);

-- 2. Short Link Clicks Table (Detailed Analytics)
CREATE TABLE IF NOT EXISTS public.short_link_clicks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    short_link_id UUID NOT NULL REFERENCES public.short_links(id) ON DELETE CASCADE,
    ip_hash VARCHAR(64) DEFAULT NULL, -- SHA-256 of IP for unique click tracking
    country VARCHAR(100) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    device_type VARCHAR(50) DEFAULT NULL, -- 'desktop', 'mobile', 'tablet'
    browser VARCHAR(150) DEFAULT NULL, -- 'Chrome', 'Firefox', Safari, etc.
    referrer VARCHAR(255) DEFAULT NULL, -- 'YouTube', 'Instagram', 'TikTok', 'WhatsApp', 'Direct', etc.
    user_agent TEXT DEFAULT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for click aggregation
CREATE INDEX IF NOT EXISTS idx_short_link_clicks_link ON public.short_link_clicks(short_link_id);
-- Index for time range performance
CREATE INDEX IF NOT EXISTS idx_short_link_clicks_created ON public.short_link_clicks(created_at);

-- Enable RLS
ALTER TABLE public.short_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.short_link_clicks ENABLE ROW LEVEL SECURITY;

-- Dynamic Policy Rules
CREATE POLICY "Allow public read-only access to short links" ON public.short_links
    FOR SELECT TO public USING (true);

CREATE POLICY "Allow producers full access to their short links" ON public.short_links
    FOR ALL TO authenticated USING (producer_id = auth.uid());

CREATE POLICY "Allow public select of clicks" ON public.short_link_clicks
    FOR SELECT TO public USING (true);

CREATE POLICY "Allow public insertion of clicks" ON public.short_link_clicks
    FOR INSERT TO public WITH CHECK (true);

CREATE POLICY "Allow producers to view clicks of their short links" ON public.short_link_clicks
    FOR SELECT TO authenticated USING (
        EXISTS (
            SELECT 1 FROM public.short_links sl
            WHERE sl.id = short_link_clicks.short_link_id AND sl.producer_id = auth.uid()
        )
    );

-- 3. Short Link Daily Summaries Table (Scalable Permanent Aggregation)
CREATE TABLE IF NOT EXISTS public.short_link_daily_summaries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    short_link_id UUID NOT NULL REFERENCES public.short_links(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    clicks_count INTEGER NOT NULL DEFAULT 0,
    referrers_breakdown JSONB NOT NULL DEFAULT '{}'::jsonb,
    countries_breakdown JSONB NOT NULL DEFAULT '{}'::jsonb,
    devices_breakdown JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (short_link_id, date)
);

-- Index for scalable quick analytics
CREATE INDEX IF NOT EXISTS idx_short_link_daily_summaries_link ON public.short_link_daily_summaries(short_link_id);
CREATE INDEX IF NOT EXISTS idx_short_link_daily_summaries_date ON public.short_link_daily_summaries(date);

-- Enable RLS
ALTER TABLE public.short_link_daily_summaries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public select of summaries" ON public.short_link_daily_summaries
    FOR SELECT TO public USING (true);

CREATE POLICY "Allow public inserts/updates on summaries" ON public.short_link_daily_summaries
    FOR ALL TO public USING (true);

