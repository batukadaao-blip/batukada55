-- ==============================================================================
-- Batukada: Beat Collaborators Schema
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.beat_collaborators (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    beat_id INTEGER REFERENCES public.beats(id) ON DELETE CASCADE,
    producer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    split_percentage NUMERIC NOT NULL CHECK (split_percentage >= 0 AND split_percentage <= 100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Enable RLS
ALTER TABLE public.beat_collaborators ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Public beat_collaborators are viewable by everyone" 
ON public.beat_collaborators FOR SELECT USING (true);

CREATE POLICY "Producers can insert their own collab splits" 
ON public.beat_collaborators FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.beats 
        WHERE id = beat_collaborators.beat_id 
        AND producer_id = auth.uid()
    )
);

CREATE POLICY "Producers can update their own collab splits" 
ON public.beat_collaborators FOR UPDATE USING (
    EXISTS (
        SELECT 1 FROM public.beats 
        WHERE id = beat_collaborators.beat_id 
        AND producer_id = auth.uid()
    )
);

CREATE POLICY "Producers can delete their own collab splits" 
ON public.beat_collaborators FOR DELETE USING (
    EXISTS (
        SELECT 1 FROM public.beats 
        WHERE id = beat_collaborators.beat_id 
        AND producer_id = auth.uid()
    )
);
