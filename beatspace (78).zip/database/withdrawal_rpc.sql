-- Migration: Atomic Race-Condition Protected Withdrawal Request Processing
CREATE OR REPLACE FUNCTION public.process_withdrawal_request(
  p_withdrawal_id UUID,
  p_action TEXT -- 'approve' or 'reject'
)
RETURNS JSONB AS $$
DECLARE
  v_rec RECORD;
  v_profile RECORD;
  v_new_status TEXT;
  v_withdraw_amount NUMERIC;
  v_producer_id UUID;
  v_current_available NUMERIC;
  v_current_withdrawn NUMERIC;
  v_current_balance NUMERIC;
  v_new_available NUMERIC;
  v_new_withdrawn NUMERIC;
  v_new_balance NUMERIC;
BEGIN
  -- 1. Lock and fetch withdrawal request USING FOR UPDATE to prevent race condition
  SELECT * INTO v_rec
  FROM public.withdrawal_requests
  WHERE id = p_withdrawal_id
  FOR UPDATE;

  IF v_rec IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'Pedido de levantamento não encontrado.');
  END IF;

  IF v_rec.status IS DISTINCT FROM 'pending' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Este pedido já está ' || v_rec.status);
  END IF;

  IF p_action = 'reject' THEN
    v_new_status := 'rejected';
    
    UPDATE public.withdrawal_requests
    SET status = v_new_status,
        updated_at = NOW()
    WHERE id = p_withdrawal_id;

    RETURN jsonb_build_object('success', true, 'status', v_new_status, 'amount', v_rec.amount, 'producer_id', v_rec.producer_id);
  ELSIF p_action = 'approve' THEN
    v_new_status := 'approved';
    v_withdraw_amount := v_rec.amount;
    v_producer_id := v_rec.producer_id;

    -- 2. Lock and fetch producer profile USING FOR UPDATE to prevent race conditions
    SELECT wallet_available_balance, wallet_total_withdrawn, wallet_balance
    INTO v_profile
    FROM public.profiles
    WHERE id = v_producer_id
    FOR UPDATE;

    IF v_profile IS NULL THEN
      RETURN jsonb_build_object('success', false, 'error', 'Perfil do produtor não encontrado.');
    END IF;

    v_current_available := COALESCE(v_profile.wallet_available_balance, 0);
    v_current_withdrawn := COALESCE(v_profile.wallet_total_withdrawn, 0);
    v_current_balance := COALESCE(v_profile.wallet_balance, 0);

    IF v_current_available < v_withdraw_amount THEN
      RETURN jsonb_build_object('success', false, 'error', 'Saldo disponível insuficiente.');
    END IF;

    -- Calculate new balance values safely
    v_new_available := GREATEST(0, v_current_available - v_withdraw_amount);
    v_new_withdrawn := v_current_withdrawn + v_withdraw_amount;
    v_new_balance := GREATEST(0, v_current_balance - v_withdraw_amount);

    -- 3. Update profile balances atomically
    UPDATE public.profiles
    SET wallet_available_balance = v_new_available,
        wallet_total_withdrawn = v_new_withdrawn,
        wallet_balance = v_new_balance
    WHERE id = v_producer_id;

    -- Also update wallets table to prevent WALLET DRIFT
    UPDATE public.wallets
    SET available_balance = v_new_available,
        total_withdrawn = v_new_withdrawn
    WHERE producer_id = v_producer_id;

    -- 4. Update withdrawal request status
    UPDATE public.withdrawal_requests
    SET status = v_new_status,
        updated_at = NOW()
    WHERE id = p_withdrawal_id;

    RETURN jsonb_build_object('success', true, 'status', v_new_status, 'amount', v_withdraw_amount, 'producer_id', v_producer_id);
  ELSE
    RETURN jsonb_build_object('success', false, 'error', 'Ação inválida.');
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
