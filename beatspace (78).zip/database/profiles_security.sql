-- Migration: Prevent profile.role self-elevation for non-admin users
CREATE OR REPLACE FUNCTION public.prevent_profile_role_self_elevation()
RETURNS TRIGGER AS $$
BEGIN
  -- If the user is updating their own profile and they are not an admin, preserve OLD.role
  IF auth.uid() = NEW.id THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    ) THEN
      NEW.role := OLD.role;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_prevent_profile_role_self_elevation ON public.profiles;

CREATE TRIGGER trigger_prevent_profile_role_self_elevation
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_profile_role_self_elevation();
