-- ==============================================================================
-- BeatAngola: Royalty Reversals & Debt Tracking Schema
-- Compatibility: PostgreSQL (Supabase)
-- ==============================================================================

-- 1. Add order_id column to wallet_transactions
ALTER TABLE public.wallet_transactions ADD COLUMN IF NOT EXISTS order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL;

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_order_id ON public.wallet_transactions(order_id);

-- 2. Create royalty_reversals table
CREATE TABLE IF NOT EXISTS public.royalty_reversals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
  reversal_amount NUMERIC(15, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
  CONSTRAINT unique_order_id_reversal UNIQUE (order_id)
);

-- RLS Policy: Only admins can view/manage reversals
ALTER TABLE public.royalty_reversals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage royalty reversals" ON public.royalty_reversals
  FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- 3. Add pending debt columns to profiles and wallets
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS wallet_pending_debt NUMERIC(15, 2) DEFAULT 0;
ALTER TABLE public.wallets ADD COLUMN IF NOT EXISTS pending_debt NUMERIC(15, 2) DEFAULT 0;
