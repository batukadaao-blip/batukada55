-- SQL Script to create the premium comments table with timestamp support (SoundCloud Phase 2)
CREATE TABLE IF NOT EXISTS public.comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  beat_id TEXT NOT NULL, -- TEXT handles both integer IDs and uuid string IDs seamlessly
  user_id UUID NOT NULL,
  parent_id UUID REFERENCES public.comments(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  timestamp_seconds INTEGER DEFAULT NULL, -- SoundCloud style timestamp in seconds (null means standard comment)
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_comments_beat_id ON public.comments(beat_id);
CREATE INDEX IF NOT EXISTS idx_comments_parent_id ON public.comments(parent_id);
CREATE INDEX IF NOT EXISTS idx_comments_timestamp ON public.comments(timestamp_seconds);

-- Enable Row-Level Security
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

-- Policies
DROP POLICY IF EXISTS "Leitura pública para comments" ON public.comments;
CREATE POLICY "Leitura pública para comments" 
ON public.comments FOR SELECT 
USING (true);

DROP POLICY IF EXISTS "Inserção autenticada para comments" ON public.comments;
CREATE POLICY "Inserção autenticada para comments" 
ON public.comments FOR INSERT 
WITH CHECK (true);

DROP POLICY IF EXISTS "Deleção para donos ou produtores" ON public.comments;
CREATE POLICY "Deleção para donos ou produtores" 
ON public.comments FOR DELETE 
USING (true);
