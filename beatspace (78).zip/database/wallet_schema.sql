-- ==============================================================================
-- BeatAngola: Wallet & Revenue Management System Schema
-- Compatibility: PostgreSQL (Supabase)
-- ==============================================================================

-- Enable required extension if not present
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==============================================================================
-- 1. Platform Wallet
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.platform_wallet (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  total_commission_earnings NUMERIC(15, 2) DEFAULT 0,
  net_profit NUMERIC(15, 2) DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- RLS Policy: Only admins can view/update platform wallet
ALTER TABLE public.platform_wallet ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage platform wallet" ON public.platform_wallet
  FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Initialize one row for platform wallet if empty
INSERT INTO public.platform_wallet (id, total_commission_earnings, net_profit)
SELECT gen_random_uuid(), 0, 0
WHERE NOT EXISTS (SELECT 1 FROM public.platform_wallet);

-- ==============================================================================
-- 2. Producer Wallets
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.wallets (
  producer_id UUID REFERENCES public.profiles(id) PRIMARY KEY,
  available_balance NUMERIC(15, 2) DEFAULT 0 CHECK (available_balance >= 0),
  pending_balance NUMERIC(15, 2) DEFAULT 0 CHECK (pending_balance >= 0),
  total_earned NUMERIC(15, 2) DEFAULT 0,
  total_withdrawn NUMERIC(15, 2) DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own wallet and admins all" ON public.wallets
  FOR SELECT USING (producer_id = auth.uid() OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- ==============================================================================
-- 3. Wallet Transactions (Ledger)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  producer_id UUID REFERENCES public.profiles(id) NOT NULL,
  amount NUMERIC(15, 2) NOT NULL,
  producer_amount NUMERIC(15, 2) NOT NULL, 
  platform_amount NUMERIC(15, 2) NOT NULL, 
  transaction_type TEXT NOT NULL,          -- 'sale', 'withdrawal', 'commission'
  status TEXT DEFAULT 'completed',         -- 'pending', 'completed', 'rejected'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

CREATE INDEX idx_transactions_producer ON public.wallet_transactions(producer_id);

ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own transactions and admins all" ON public.wallet_transactions
  FOR SELECT USING (producer_id = auth.uid() OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- ==============================================================================
-- 4. Withdrawal Requests
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.withdrawal_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  producer_id UUID REFERENCES public.profiles(id) NOT NULL,
  amount NUMERIC(15, 2) NOT NULL CHECK (amount > 0),
  status TEXT DEFAULT 'pending',           -- 'pending', 'approved', 'rejected'
  method TEXT NOT NULL,                    -- 'bank', 'unitel_money'
  details JSONB NOT NULL,                  -- Store bank info
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.withdrawal_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own requests and admins all" ON public.withdrawal_requests
  FOR SELECT USING (producer_id = auth.uid() OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));
CREATE POLICY "Users can create own requests" ON public.withdrawal_requests
  FOR INSERT WITH CHECK (producer_id = auth.uid());

-- Triggers for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_withdrawal_requests_modtime 
  BEFORE UPDATE ON public.withdrawal_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ==============================================================================
-- 5. Automation: Automatic Wallet Creation
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.handle_new_producer_wallet()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role = 'producer' THEN
    INSERT INTO public.wallets (producer_id)
    VALUES (NEW.id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_producer_created ON public.profiles;
CREATE TRIGGER on_producer_created
AFTER INSERT ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.handle_new_producer_wallet();
