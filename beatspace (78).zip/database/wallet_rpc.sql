-- ==============================================================================
-- BeatAngola: Wallet RPC Functions (Atomic Operations)
-- ==============================================================================

-- 1. Process Beat Sale
-- 90% Producer (Pending), 10% Platform
CREATE OR REPLACE FUNCTION public.process_beat_sale(p_producer_id UUID, p_amount NUMERIC)
RETURNS void AS $$
DECLARE
    v_producer_amount NUMERIC;
    v_platform_amount NUMERIC;
BEGIN
    v_producer_amount := p_amount * 0.9;
    v_platform_amount := p_amount * 0.1;

    -- 1. Regista transação
    INSERT INTO public.wallet_transactions (producer_id, amount, producer_amount, platform_amount, transaction_type)
    VALUES (p_producer_id, p_amount, v_producer_amount, v_platform_amount, 'sale');

    -- 2. Atualiza carteira do produtor (pending)
    UPDATE public.wallets 
    SET pending_balance = pending_balance + v_producer_amount,
        total_earned = total_earned + v_producer_amount
    WHERE producer_id = p_producer_id;

    -- 3. Atualiza carteira da plataforma
    UPDATE public.platform_wallet
    SET total_commission_earnings = total_commission_earnings + v_platform_amount,
        net_profit = net_profit + v_platform_amount;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Approve Withdrawal
CREATE OR REPLACE FUNCTION public.approve_withdrawal(p_withdrawal_id UUID)
RETURNS void AS $$
DECLARE
    v_producer_id UUID;
    v_amount NUMERIC;
BEGIN
    -- Obter detalhes do pedido
    SELECT producer_id, amount INTO v_producer_id, v_amount
    FROM public.withdrawal_requests
    WHERE id = p_withdrawal_id AND status = 'pending';

    IF NOT FOUND THEN RAISE EXCEPTION 'Pedido não encontrado ou já processado'; END IF;

    -- Atualiza pedido
    UPDATE public.withdrawal_requests SET status = 'approved', updated_at = NOW() WHERE id = p_withdrawal_id;

    -- Atualiza saldo e histórico
    UPDATE public.wallets 
    SET available_balance = available_balance - v_amount,
        total_withdrawn = total_withdrawn + v_amount
    WHERE producer_id = v_producer_id;

    -- Regista transação de levantamento
    INSERT INTO public.wallet_transactions (producer_id, amount, producer_amount, platform_amount, transaction_type)
    VALUES (v_producer_id, v_amount, v_amount, 0, 'withdrawal');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Release Pending Funds
CREATE OR REPLACE FUNCTION public.release_pending_funds(p_producer_id UUID, p_amount NUMERIC)
RETURNS void AS $$
BEGIN
    UPDATE public.wallets 
    SET pending_balance = pending_balance - p_amount,
        available_balance = available_balance + p_amount
    WHERE producer_id = p_producer_id AND pending_balance >= p_amount;
    
    IF NOT FOUND THEN RAISE EXCEPTION 'Fundos insuficientes ou produtor não encontrado'; END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Increment Producer Wallet (Atomic update)
CREATE OR REPLACE FUNCTION public.increment_producer_wallet(p_producer_id UUID, p_amount NUMERIC)
RETURNS void AS $$
BEGIN
    -- Update profiles table atomically
    UPDATE public.profiles
    SET 
        wallet_pending_balance = COALESCE(wallet_pending_balance, 0) + p_amount,
        wallet_available_balance = COALESCE(wallet_available_balance, 0) + p_amount,
        wallet_total_earned = COALESCE(wallet_total_earned, 0) + p_amount,
        wallet_balance = COALESCE(wallet_balance, 0) + p_amount
    WHERE id = p_producer_id;

    -- Update wallets table if it exists
    UPDATE public.wallets
    SET 
        pending_balance = COALESCE(pending_balance, 0) + p_amount,
        available_balance = COALESCE(available_balance, 0) + p_amount,
        total_earned = COALESCE(total_earned, 0) + p_amount
    WHERE producer_id = p_producer_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
