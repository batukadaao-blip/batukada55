-- SQL Script to create the simplified, stable activity_feed table
CREATE TABLE IF NOT EXISTS public.activity_feed (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  username TEXT,
  avatar_url TEXT,
  type TEXT,
  target_id TEXT,
  target_title TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_activity_feed_created_at ON public.activity_feed(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_feed_user_id ON public.activity_feed(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_feed_type ON public.activity_feed(type);

-- Row-Level Security
ALTER TABLE public.activity_feed ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Leitura pública para activity_feed" ON public.activity_feed;
CREATE POLICY "Leitura pública para activity_feed" 
ON public.activity_feed FOR SELECT 
USING (true);

DROP POLICY IF EXISTS "Insert autenticado para activity_feed" ON public.activity_feed;
CREATE POLICY "Insert autenticado para activity_feed" 
ON public.activity_feed FOR INSERT 
WITH CHECK (true);
