-- ==============================================================================
-- BeatAngola: Order & License System Schema
-- ==============================================================================

-- 1. Licenses
CREATE TABLE IF NOT EXISTS public.licenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(15, 2) NOT NULL,
  usage_rights JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 2. Orders
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID REFERENCES public.profiles(id) NOT NULL,
  total_amount NUMERIC(15, 2) NOT NULL,
  status TEXT DEFAULT 'completed',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 3. Order Items
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
  beat_id UUID NOT NULL, -- references public.beats(id)
  license_id UUID REFERENCES public.licenses(id) NOT NULL,
  price NUMERIC(15, 2) NOT NULL,
  producer_id UUID REFERENCES public.profiles(id) NOT NULL
);

-- 4. Purchased Beats Access
CREATE TABLE IF NOT EXISTS public.purchased_beats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID REFERENCES public.profiles(id) NOT NULL,
  beat_id UUID NOT NULL,
  license_id UUID REFERENCES public.licenses(id) NOT NULL,
  order_id UUID REFERENCES public.orders(id),
  download_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- RLS
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchased_beats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own orders" ON public.orders FOR SELECT USING (buyer_id = auth.uid());
CREATE POLICY "Users can view own purchases" ON public.purchased_beats FOR SELECT USING (buyer_id = auth.uid());
