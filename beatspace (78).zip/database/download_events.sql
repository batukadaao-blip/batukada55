-- Create Table download_events for tracking digital and free beat/kit downloads
CREATE TABLE IF NOT EXISTS public.download_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  beat_id UUID NOT NULL REFERENCES public.beats(id) ON DELETE CASCADE,
  producer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.download_events ENABLE ROW LEVEL SECURITY;

-- Select policy: viewable by anyone
DROP POLICY IF EXISTS "Download events are viewable by everyone" ON public.download_events;
CREATE POLICY "Download events are viewable by everyone" ON public.download_events
FOR SELECT USING (true);

-- Insert policy: insertable by anyone
DROP POLICY IF EXISTS "Anyone can insert download event" ON public.download_events;
CREATE POLICY "Anyone can insert download event" ON public.download_events
FOR INSERT WITH CHECK (true);

-- Grant privileges to roles
GRANT ALL ON public.download_events TO authenticated;
GRANT ALL ON public.download_events TO anon;
GRANT ALL ON public.download_events TO service_role;
