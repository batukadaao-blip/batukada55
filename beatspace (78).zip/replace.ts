import fs from 'fs';
import path from 'path';

const filePath = path.join(process.cwd(), 'src', 'components', 'NotificationDropdown.tsx');
let content = fs.readFileSync(filePath, 'utf-8');

// 1. Replace first const bId (inside case upload/featured_beat)
const originalUploadBIdStr = '                              const bId = item.metadata?.beat_id || item.metadata?.target_id || item.target_id;';
const targetUploadBIdStr = `                              let bId = item.metadata?.beat_id || item.metadata?.target_id || item.target_id;
                              if (!bId || bId === item.id) {
                                const parsedTitle = extractQuotedTitle(item.message);
                                if (parsedTitle) bId = slugify(parsedTitle);
                              }`;

if (content.includes(originalUploadBIdStr)) {
  content = content.replace(originalUploadBIdStr, targetUploadBIdStr);
  console.log("Success! Replaced upload bId declaration.");
} else {
  // Try normal spacing / tabs
  const re = /const bId = item\.metadata\?\.beat_id || item\.metadata\?\.target_id || item\.target_id;/;
  console.log("Did not find exact string match 1. Trying regex check...");
}

// 2. Replace case follower
const originalFollowerStr = `                            case 'follower': {
                              const fUsername = item.metadata?.follower_username || item.metadata?.username || (item.message && item.message.includes('@') ? (item.message.match(/@(\\w+)/)?.[1] || '') : '');`;

// Let's use string.replace with some flexible spacing or regexes, or find it by exact lines
// Since fUsername is long, let's do a direct replacement of follower case block:
const followerMatch = `                              const fUsername = item.metadata?.follower_username || item.metadata?.username || (item.message && item.message.includes('@') ? (item.message.match(/@(\\w+)/)?.[1] || '') : '');
                              console.log("[DEBUG] route exists? Yes: /@" + fUsername + " or /feed");
                              if (fUsername) {
                                targetPath = \`/@\${fUsername}\`;
                              }`;

const followerReplacement = `                              let fUsername = item.metadata?.follower_username || item.metadata?.username;
                              if (!fUsername && item.message && item.message.includes('@')) {
                                const match = item.message.match(/@([^ ]+(?:\\s+[^ ]+)*?)(?=\\s+começou|\\s+comecou|\\s+is\\s+now|\\s+started)/i);
                                const rawName = match ? match[1] : (item.message.match(/@([^ ]+)/)?.[1] || '');
                                if (rawName) {
                                  fUsername = rawName.toLowerCase().replace(/[^a-z0-9_]/g, '');
                                }
                              }
                              console.log("[DEBUG] follower notification resolved username:", fUsername);
                              if (fUsername) {
                                targetPath = \`/@\${fUsername}\`;
                              }`;

if (content.includes(followerMatch)) {
  content = content.replace(followerMatch, followerReplacement);
  console.log("Success! Replaced follower matching block.");
} else {
  console.log("Did not find exact follower match.");
}

// 3. Replace second const bId (inside case comment/like)
const commentMatch = `                            case 'like':
                            case 'comment':
                            case 'reply_comment':
                            case 'repost': {
                              const bId = item.metadata?.beat_id || item.metadata?.target_id || item.target_id;`;

const commentReplacement = `                            case 'like':
                            case 'comment':
                            case 'reply_comment':
                            case 'repost': {
                              let bId = item.metadata?.beat_id || item.metadata?.target_id || item.target_id;
                              if (!bId || bId === item.id) {
                                const parsedTitle = extractQuotedTitle(item.message);
                                if (parsedTitle) bId = slugify(parsedTitle);
                              }`;

if (content.includes(commentMatch)) {
  content = content.replace(commentMatch, commentReplacement);
  console.log("Success! Replaced comment bId declaration.");
} else {
  console.log("Did not find exact comment match.");
}

fs.writeFileSync(filePath, content, 'utf-8');
console.log("Write completed successfully!");
