import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

async function run() {
  const supabase = createClient(url, key);
  
  console.log('--- WITHDRAWAL REQUESTS ---');
  const { data: withdrawals, error: wError } = await supabase
    .from('withdrawal_requests')
    .select('*')
    .order('created_at', { ascending: false });
    
  if (wError) {
    console.error('Error fetching withdrawals:', wError);
  } else {
    console.log(JSON.stringify(withdrawals, null, 2));
  }

  console.log('\n--- BANKING INFO ---');
  const { data: bankInfo, error: bError } = await supabase
    .from('producer_banking_info')
    .select('*');
    
  if (bError) {
    console.error('Error fetching banking info:', bError);
  } else {
    console.log(JSON.stringify(bankInfo, null, 2));
  }

  console.log('\n--- PROFILES WALLET STATUS ---');
  const { data: profiles, error: pError } = await supabase
    .from('profiles')
    .select('id, display_name, email, wallet_available_balance, wallet_total_withdrawn');
    
  if (pError) {
    console.error('Error fetching profiles:', pError);
  } else {
    console.log(JSON.stringify(profiles, null, 2));
  }
}

run();
