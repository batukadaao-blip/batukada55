import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let supabaseUrl = process.env.VITE_SUPABASE_URL || '';
let serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !serviceKey) {
  console.error("Missing config!");
} else {
  // Clean up and extract origin as the real client does
  supabaseUrl = supabaseUrl.trim().replace(/^["'](.+)["']$/, '$1');
  if (supabaseUrl.startsWith('http')) {
    try {
      const urlObj = new URL(supabaseUrl);
      supabaseUrl = urlObj.origin;
    } catch (e) {
      supabaseUrl = supabaseUrl.replace(/\/+$/, '');
    }
  }
  
  console.log("Using cleaned Supabase URL:", supabaseUrl);
  const supabase = createClient(supabaseUrl, serviceKey);
  
  async function check() {
    console.log("Checking notifications table...");
    const { data, error } = await supabase.from('notifications').select('*').limit(30);
    if (error) {
      console.log('Error querying notifications table:', error.code, error.message);
    } else {
      console.log('Success! Count:', data?.length);
      console.log('Top notifications:');
      console.log(JSON.stringify(data, null, 2));
    }
  }
  check();
}
