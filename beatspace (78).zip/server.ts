import express from "express";
import path from "path";
import fs from "fs";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
import cors from "cors";
import crypto from "crypto";

import { 
  getPromotionsFromDB, 
  createPromotionInDB, 
  updatePromotionStatusInDB, 
  deletePromotionFromDB, 
  getPromotionAnalytics,
  savePromotionUsageInDB
} from "./server/promotions-store";
import { 
  createShortLink,
  lookupShortLinkByCode,
  lookupShortLinkByCodeAndType,
  logClick,
  getShortLinkAnalytics,
  syncSmartLinks
} from "./server/short-links-store";
import { evaluateCartPromotions } from "./src/lib/promotions-engine";


dotenv.config();

// Helper to determine the secure, domain-respecting site URL dynamically.
// This supports dev, container preview, sandbox, and active production environments without hardcoding.
function getExpandedSiteUrl(req: any): string {
  if (process.env.APP_URL && process.env.APP_URL !== "MY_APP_URL" && process.env.APP_URL.trim() !== "") {
    return process.env.APP_URL.trim().replace(/\/$/, "");
  }
  if (process.env.FRONTEND_URL && process.env.FRONTEND_URL.trim() !== "") {
    return process.env.FRONTEND_URL.trim().replace(/\/$/, "");
  }

  const referer = req.headers.referer;
  if (referer) {
    try {
      const parsedReferer = new URL(referer);
      return `${parsedReferer.protocol}//${parsedReferer.host}`;
    } catch (e) {
      // Ignore URL parse error
    }
  }

  const origin = req.headers.origin;
  if (origin) {
    try {
      const parsedOrigin = new URL(origin);
      return `${parsedOrigin.protocol}//${parsedOrigin.host}`;
    } catch (e) {
      // Ignore
    }
  }

  const protocol = req.secure || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  
  const forwardedHost = req.headers["x-forwarded-host"];
  if (forwardedHost) {
    const mainHost = typeof forwardedHost === "string" ? forwardedHost.split(",")[0].trim() : forwardedHost[0];
    if (mainHost) {
      return `${protocol}://${mainHost}`;
    }
  }

  const host = req.headers.host || "batukada.ao";
  return `${protocol}://${host}`;
}

let supabaseClient: any = null;

function getSupabase() {
  if (!supabaseClient) {
    let SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
    let SUPABASE_ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY;
    let SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
    
    // Clean up strings
    if (SUPABASE_URL) SUPABASE_URL = SUPABASE_URL.trim().replace(/^["'](.+)["']$/, '$1');
    if (SUPABASE_ANON_KEY) SUPABASE_ANON_KEY = SUPABASE_ANON_KEY.trim().replace(/^["'](.+)["']$/, '$1');
    if (SUPABASE_SERVICE_ROLE_KEY) SUPABASE_SERVICE_ROLE_KEY = SUPABASE_SERVICE_ROLE_KEY.trim().replace(/^["'](.+)["']$/, '$1');

    if (!SUPABASE_URL || (!SUPABASE_ANON_KEY && !SUPABASE_SERVICE_ROLE_KEY)) {
      console.warn("Supabase configuration missing in environment");
      return null;
    }

    // Normalize URL
    if (SUPABASE_URL) {
      if (!SUPABASE_URL.startsWith('http')) {
        SUPABASE_URL = `https://${SUPABASE_URL}`;
      }
      // Remove trailing slashes and ensure it's just the origin
      try {
        const urlObj = new URL(SUPABASE_URL);
        SUPABASE_URL = urlObj.origin;
      } catch (e) {
        SUPABASE_URL = SUPABASE_URL.replace(/\/+$/, '');
      }
    }
    
    // Prefer Service Role Key for server-side operations to bypass RLS
    const keyToUse = SUPABASE_SERVICE_ROLE_KEY || SUPABASE_ANON_KEY;
    console.log(`Initializing Supabase on server with URL: ${SUPABASE_URL} and ${SUPABASE_SERVICE_ROLE_KEY ? 'SERVICE_ROLE_KEY' : 'ANON_KEY'}`);
    supabaseClient = createClient(SUPABASE_URL!, keyToUse!);

    // Ensure private bucket exists for premium masters/stems
    try {
      supabaseClient.storage.listBuckets().then(({ data: buckets, error: listError }: any) => {
        if (listError) {
          console.warn('[STORAGE SETUP] Error listing buckets:', listError.message);
          return;
        }
        const hasPrivate = buckets?.some((b: any) => b.name === 'beats-private');
        if (!hasPrivate) {
          console.log('[STORAGE SETUP] Creating private bucket "beats-private"...');
          supabaseClient.storage.createBucket('beats-private', {
            public: false
          }).then(({ error: createError }: any) => {
            if (createError) console.error('[STORAGE SETUP] Error creating "beats-private":', createError.message);
            else console.log('[STORAGE SETUP] "beats-private" bucket established successfully.');
          });
        } else {
          console.log('[STORAGE SETUP] "beats-private" bucket already exists.');
        }
      }).catch((e: any) => console.error('[STORAGE SETUP] Bucket check failed:', e));
    } catch (e) {
      console.error('[STORAGE SETUP] Failed to initialize private bucket check:', e);
    }
  }
  return supabaseClient;
}

// Private files for persistent logs and backups
const SYSTEM_LOGS_FILE = path.join(process.cwd(), "system_logs.json");
const DELETED_BACKUPS_FILE = path.join(process.cwd(), "deleted_backups.json");

function getSystemLogs() {
  try {
    if (fs.existsSync(SYSTEM_LOGS_FILE)) {
      const content = fs.readFileSync(SYSTEM_LOGS_FILE, "utf-8");
      return JSON.parse(content);
    }
  } catch (err) {
    console.error("Error reading system logs:", err);
  }
  return [];
}

function writeSystemLogs(logs: any[]) {
  try {
    fs.writeFileSync(SYSTEM_LOGS_FILE, JSON.stringify(logs.slice(0, 2000), null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing system logs:", err);
  }
}

function logSystemEvent(type: string, message: string, severity: string = "error", details: any = null) {
  const logs = getSystemLogs();
  const newLog = {
    id: "log_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
    type,
    message,
    severity,
    route: details?.route || null,
    userId: details?.userId || null,
    stack: details?.stack || null,
    timestamp: new Date().toISOString(),
    details
  };
  logs.unshift(newLog);
  writeSystemLogs(logs);
  console.log(`[SYSTEM LOG - ${severity.toUpperCase()}] [${type}] ${message}`);
}

// --- VIRTUAL CONVERSATIONS FALLBACK SYSTEM ---
interface VirtualMessage {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  is_read: boolean;
}

interface VirtualConversation {
  id: string;
  buyer_id: string;
  seller_id: string;
  created_at: string;
  updated_at: string;
  messages: VirtualMessage[];
}

const FALLBACK_CHATS_FILE = path.join(process.cwd(), "fallback_chats.json");

function getFallbackChats(): VirtualConversation[] {
  try {
    if (fs.existsSync(FALLBACK_CHATS_FILE)) {
      const content = fs.readFileSync(FALLBACK_CHATS_FILE, "utf-8");
      return JSON.parse(content);
    }
  } catch (err) {
    console.error("Error reading fallback chats:", err);
  }
  return [];
}

function writeFallbackChats(chats: VirtualConversation[]) {
  try {
    fs.writeFileSync(FALLBACK_CHATS_FILE, JSON.stringify(chats, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing fallback chats:", err);
  }
}

function getDeletedBackups() {
  try {
    if (fs.existsSync(DELETED_BACKUPS_FILE)) {
      const content = fs.readFileSync(DELETED_BACKUPS_FILE, "utf-8");
      return JSON.parse(content);
    }
  } catch (err) {
    console.error("Error reading backups:", err);
  }
  return [];
}

function writeDeletedBackups(backups: any[]) {
  try {
    fs.writeFileSync(DELETED_BACKUPS_FILE, JSON.stringify(backups, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing backups:", err);
  }
}

function addDeletedBackup(type: string, originalId: string, data: any) {
  const backups = getDeletedBackups();
  const newBackup = {
    backup_id: "bak_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
    type,
    original_id: originalId,
    data,
    deleted_at: new Date().toISOString()
  };
  backups.unshift(newBackup);
  writeDeletedBackups(backups);
  console.log(`[SYSTEM BACKUP] Archived ${type} ID ${originalId} safely to backups.`);
}

// --- SECURITY HARDENING MIDDLEWARES (Rate Limiting, Upload Validation, Auth Verification) ---

interface RateLimitRecord {
  count: number;
  resetTime: number;
}
const rateLimitRegistry = new Map<string, RateLimitRecord>();

function apiRateLimiter(maxRequests: number, windowMs: number) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const originalUrl = req.originalUrl || req.path || "";
    const method = req.method ? req.method.toUpperCase() : "GET";

    // 1. Never rate-limit GET requests
    if (method === "GET") {
      return next();
    }

    // 2. ONLY rate-limit API endpoints (must start with /api)
    if (!originalUrl.startsWith("/api")) {
      return next();
    }

    // 3. Exclude static assets and frontend rendering files completely
    const lowPath = originalUrl.toLowerCase();
    const isAsset = 
      lowPath.includes('.') || 
      lowPath.includes('/src/') || 
      lowPath.includes('/assets/') || 
      lowPath.includes('/@vite/') || 
      lowPath.includes('/node_modules/') ||
      lowPath.endsWith('.js') ||
      lowPath.endsWith('.css') ||
      lowPath.endsWith('.png') ||
      lowPath.endsWith('.jpg') ||
      lowPath.endsWith('.jpeg') ||
      lowPath.endsWith('.webp') ||
      lowPath.endsWith('.svg') ||
      lowPath.endsWith('.json');

    if (isAsset) {
      return next();
    }

    const clientIp = req.ip || req.headers["x-forwarded-for"] || req.socket.remoteAddress || "anonymous";
    const key = `${clientIp as string}:${originalUrl}`;
    const now = Date.now();

    let record = rateLimitRegistry.get(key);
    if (!record || now > record.resetTime) {
      record = {
        count: 0,
        resetTime: now + windowMs
      };
    }

    record.count++;
    rateLimitRegistry.set(key, record);

    if (record.count > maxRequests) {
      return res.status(429).json({
        success: false,
        error: "Too many requests"
      });
    }

    next();
  };
}

function resolveStorageBucket(fileType: string | undefined, fileName: string | undefined): string {
  const ext = fileName ? fileName.substring(fileName.lastIndexOf('.')).toLowerCase() : '';
  const fileTypeLc = fileType ? fileType.toLowerCase() : '';
  const nameLc = fileName ? fileName.toLowerCase() : '';

  if (
    ext === '.zip' ||
    ext === '.rar' ||
    fileTypeLc === 'master' ||
    fileTypeLc === 'stems' ||
    fileTypeLc === 'kit' ||
    fileTypeLc === 'bundle' ||
    nameLc.includes('master') ||
    nameLc.includes('stems') ||
    nameLc.includes('kit') ||
    nameLc.includes('bundle')
  ) {
    return 'beats-private';
  }
  return 'beats';
}

function validateUpload(fileName: string, bucket: string, sizeInBytes: number): { isValid: boolean; error?: string } {
  if (!fileName) return { isValid: false, error: "Nome do ficheiro indefinido." };
  const ext = path.extname(fileName).toLowerCase();
  
  // Whitelist of allowed extensions
  const allowedExtensions = [".mp3", ".wav", ".zip", ".rar", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".pdf", ".mp4"];
  if (!allowedExtensions.includes(ext)) {
    return { isValid: false, error: `Extensão de ficheiro '${ext}' não é permitida por motivos de segurança.` };
  }

  // Dangerous extension block (redundancy)
  const dangerousExtensions = [".exe", ".sh", ".bat", ".cmd", ".js", ".ts", ".html", ".htm", ".php", ".py", ".pl", ".jsp", ".asp", ".aspx", ".cgi", ".jar", ".vbs", ".lnk", ".sys", ".dll"];
  if (dangerousExtensions.includes(ext)) {
    return { isValid: false, error: "Ficheiros executáveis ou scripts potencialmente perigosos são estritamente proibidos." };
  }

  // Size limit validation
  const imageBuckets = ["covers", "avatars", "images"];
  const maxImageSize = 15 * 1024 * 1024; // 15MB
  const maxAudioSize = 250 * 1024 * 1024; // 250MB

  if (imageBuckets.includes(bucket)) {
    const allowedImageExts = [".png", ".jpg", ".jpeg", ".webp", ".gif"];
    if (!allowedImageExts.includes(ext)) {
      return { isValid: false, error: "Apenas imagens (.png, .jpg, .jpeg, .webp, .gif) são permitidas neste bucket." };
    }
    if (sizeInBytes > maxImageSize) {
      return { isValid: false, error: `O tamanho da imagem excede o limite máximo permitido de 15MB.` };
    }
  } else {
    if (sizeInBytes > maxAudioSize) {
      return { isValid: false, error: `O tamanho do ficheiro excede o limite máximo permitido de 250MB.` };
    }
  }

  return { isValid: true };
}

async function authenticateUser(req: any, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith("Bearer ") ? authHeader.split(" ")[1] : null;
  const customToken = req.headers["x-access-token"] || req.body.accessToken || req.query.accessToken;
  const tokenToUse = token || customToken;

  if (!tokenToUse) {
    return res.status(401).json({ error: "Sessão expirada ou não autenticada. Por favor, faça login." });
  }

  const supabase = getSupabase();
  if (!supabase) {
    return res.status(503).json({ error: "Serviço de banco de dados indisponível." });
  }

  try {
    const { data: { user }, error } = await supabase.auth.getUser(tokenToUse);
    if (error || !user) {
      console.warn("[AUTH MIDDLEWARE] Token validation failed:", error?.message);
      return res.status(401).json({ error: "Sessão inválida ou expirada. Por favor, autentique-se novamente." });
    }

    req.user = user;

    const { data: profile } = await supabase
      .from("profiles")
      .select("id, role, display_name")
      .eq("id", user.id)
      .maybeSingle();

    req.profile = profile || { id: user.id, role: "buyer" };
    next();
  } catch (err: any) {
    console.error("[AUTH MIDDLEWARE ERROR]", err);
    res.status(500).json({ error: "Erro interno ao validar autenticação." });
  }
}

async function requireAdmin(req: any, res: express.Response, next: express.NextFunction) {
  authenticateUser(req, res, () => {
    if (!req.user) return; // Response is already sent inside authenticateUser if failed

    const role = req.profile?.role;
    const emailLower = req.user?.email?.toLowerCase()?.trim() || '';
    
    // Explicit Admin designation (same list as AuthContext.tsx)
    const isAdminOverride = 
      emailLower === 'dieluxpista@gmail.com' ||
      emailLower === 'miguelfranciscoalfredo24@gmail.com' ||
      emailLower === 'domingosdejesusk@gmail.com' ||
      emailLower === 'buzzinangola@gmail.com';

    if (role === "admin" || isAdminOverride) {
      next();
    } else {
      console.warn(`[ADMIN SECURITY BLOCK] Unauthorized administration attempt by user ${req.user.id} (${emailLower})`);
      res.status(403).json({ error: "Acesso administrativo estritamente proibido. Esta tentativa foi guardada para auditoria de segurança." });
    }
  });
}

// --- DYNAMIC PROFESSIONAL SEO INTERCEPTOR & JSON-LD GENERATOR ---
async function getSEOData(req: express.Request) {
  const siteUrl = getExpandedSiteUrl(req);
  const canonicalUrl = `${siteUrl}${req.path}`;

  let title = "BATUKADA | A Maior Plataforma Angolana de Beats e Kits";
  let description = "Submete, compra e vende Beats, Soundkits, Kizomba, Afro-Trap, Semba, Kuduro e mais na BATUKADA. O maior marketplace de música angolana.";
  let image = "https://i.ibb.co/hF1MD85X/20260523-155411.png"; // Official Logo
  let type = "website";
  let jsonLd: any = null;

  const supabase = getSupabase();
  
  // Try to extract IDs from the clean path routes or query strings
  let beatId = req.query.beat as string;
  let producerName = req.query.producer as string;
  let playlistId = req.query.playlist as string;

  const pathParts = req.path.split('/').filter(Boolean);
  if (pathParts[0] === 'beat' && pathParts[1]) {
    beatId = pathParts[1];
  } else if (pathParts[0] === 'producer' && pathParts[1]) {
    producerName = decodeURIComponent(pathParts[1]);
  } else if (pathParts[0] && pathParts[0].startsWith('@')) {
    producerName = decodeURIComponent(pathParts[0].substring(1));
  } else if (pathParts[0] === 'playlist' && pathParts[1]) {
    playlistId = pathParts[1];
  }

  try {
    if (pathParts[0] === 'all-beats') {
      title = "Explorar Beats e Sound Kits Angolanos | BATUKADA";
      description = "Explora o maior catálogo de instrumentais, loops, stems e drum kits originais em Angola. Adquire beats de alta qualidade de Afrobeat, Amapiano, Kizomba, Kuduro, Semba, Drill e Hip-Hop.";
      jsonLd = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "Explorar Beats e Sound Kits Angolanos",
        "description": description,
        "url": canonicalUrl,
        "publisher": {
          "@type": "Organization",
          "name": "BATUKADA",
          "logo": "https://i.ibb.co/hF1MD85X/20260523-155411.png"
        }
      };
    } else if (pathParts[0] === 'producers' || pathParts[0] === 'producers-ranking') {
      title = "Ranking & Lista de Produtores Musicais Angolanos | BATUKADA";
      description = "Descobre as mentes criativas por trás dos maiores hits de Angola. Ouve o portfólio dos melhores beatmakers de Kizomba, Semba, Afrobeat, Amapiano e Kuduro.";
      jsonLd = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "Ranking & Lista de Produtores Musicais Angolanos",
        "description": description,
        "url": canonicalUrl,
        "publisher": {
          "@type": "Organization",
          "name": "BATUKADA",
          "logo": "https://i.ibb.co/hF1MD85X/20260523-155411.png"
        }
      };
    } else if (pathParts[0] === 'licensing') {
      title = "Preços e Licenciamento de Instrumentais | BATUKADA";
      description = "Sabe como funcionam as licenças Básica, Premium e Exclusiva na Batukada. Adquire direitos de uso seguros e transparentes com preços a partir de Luanda para o mundo.";
      jsonLd = {
        "@context": "https://schema.org",
        "@type": "WebPage",
        "name": "Termos de Licenciamento de Beats",
        "description": description,
        "url": canonicalUrl,
        "publisher": {
          "@type": "Organization",
          "name": "BATUKADA",
          "logo": "https://i.ibb.co/hF1MD85X/20260523-155411.png"
        }
      };
    } else if (pathParts[0] === 'termos') {
      title = "Termos de Serviço e Regulamentos Gerais | BATUKADA";
      description = "Consulta os regulamentos oficiais de utilização da plataforma BATUKADA. Segurança, propriedade intelectual e garantias comerciais para artistas e produtores.";
      jsonLd = {
        "@context": "https://schema.org",
        "@type": "WebPage",
        "name": "Termos de Serviço",
        "description": description,
        "url": canonicalUrl,
        "publisher": {
          "@type": "Organization",
          "name": "BATUKADA",
          "logo": "https://i.ibb.co/hF1MD85X/20260523-155411.png"
        }
      };
    } else if (beatId && supabase) {
      const numericId = parseInt(beatId, 10);
      const queryId = isNaN(numericId) ? beatId : numericId;
      
      const { data: beat } = await supabase
        .from('beats')
        .select('*')
        .eq('id', queryId)
        .maybeSingle();

      if (beat) {
        let pName = beat.producer_name || beat.producer || "Produtor Autorizado";
        title = `"${beat.title}" | ${beat.genre || 'Instrumental'} Type Beat por ${pName} | BATUKADA`;
        description = `Download e Licenciamento Profissional para o beat "${beat.title}" (${beat.bpm ? beat.bpm + ' BPM' : 'Vários Tempos'}) produzido por ${pName} no portal Batukada. Adquire instrumentais 100% originais em Angola.`;
        
        if (beat.cover_url) {
          // Resolve storage public url
          image = `${supabase.storage.from("beats").getPublicUrl(beat.cover_url).data.publicUrl}`;
        }
        type = "music.song";

        jsonLd = {
          "@context": "https://schema.org",
          "@type": "MusicRecording",
          "name": beat.title,
          "genre": beat.genre || "Beats",
          "byArtist": {
            "@type": "MusicGroup",
            "name": pName
          },
          "inAlbum": {
            "@type": "MusicAlbum",
            "name": "Marketplace BATUKADA"
          },
          "offers": {
            "@type": "Offer",
            "price": beat.price_basic || 0,
            "priceCurrency": "AOA",
            "url": `${siteUrl}/beat/${beat.id}`,
            "availability": "https://schema.org/InStock"
          }
        };
      }
    } else if (producerName && supabase) {
      // Find seller profile matching artistic_name or username
      let profile: any = null;
      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(producerName);
      
      if (isUUID) {
        const { data } = await supabase.from('profiles').select('*').eq('id', producerName).maybeSingle();
        profile = data;
      } else {
        const { data } = await supabase.from('profiles').select('*').or(`username.ilike.${producerName},artistic_name.ilike.${producerName}`).maybeSingle();
        profile = data;
      }

      if (profile) {
        const dName = profile.artistic_name || profile.display_name || profile.username || "Produtor";
        title = `${dName} | Produtor Musical Oficial | BATUKADA`;
        description = `Ouve e adquire licenças de beats exclusivos produzidos por ${dName} na BATUKADA. Apoia a produção musical e o talento angolano.`;
        
        if (profile.avatar_url) {
          image = profile.avatar_url;
        }
        type = "profile";

        jsonLd = {
          "@context": "https://schema.org",
          "@type": "Person",
          "name": dName,
          "description": profile.bio || `Produtor musical com portfólio de beats e instrumentais de alta fidelidade na Batukada.`,
          "image": image,
          "jobTitle": "Music Producer",
          "homeLocation": {
            "@type": "Place",
            "name": profile.city || "Luanda, Angola"
          }
        };
      }
    } else if (playlistId && supabase) {
      const numericId = parseInt(playlistId, 10);
      const queryId = isNaN(numericId) ? playlistId : numericId;
      const { data: playlist } = await supabase.from('playlists').select('*').eq('id', queryId).maybeSingle();

      if (playlist) {
        title = `${playlist.title} | Playlist Digital | BATUKADA`;
        description = playlist.description || `Explora a seleção de ritmos e instrumentais da Playlist "${playlist.title}" na BATUKADA. A maior plataforma de beats em Angola.`;
        
        if (playlist.cover_image) {
          image = playlist.cover_image;
        } else {
          image = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=450";
        }
        type = "music.playlist";

        jsonLd = {
          "@context": "https://schema.org",
          "@type": "MusicAlbum",
          "name": playlist.title,
          "description": description,
          "image": image,
          "byArtist": {
            "@type": "Organization",
            "name": "BATUKADA"
          }
        };
      }
    }
  } catch (error) {
    console.error("SEO data query runtime issue:", error);
  }

  // General default schema markup description for indexer
  if (!jsonLd) {
    jsonLd = {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "BATUKADA",
      "url": siteUrl,
      "logo": "https://i.ibb.co/hF1MD85X/20260523-155411.png",
      "description": "A maior e mais rápida plataforma digital angolana para submeter, partilhar, comprar e vender Beats e Soundkits independentes de alta qualidade."
    };
  }

  return { title, description, image, type, canonicalUrl, jsonLd, siteUrl };
}

function injectSEOTags(html: string, seo: any): string {
  // Replace static page title
  let modified = html.replace(/<title>[^<]*<\/title>/i, `<title>${seo.title}</title>`);

  const metaHtml = `
    <!-- PRIMARY METADATA -->
    <meta name="description" content="${seo.description}" />
    <meta name="keywords" content="venda de beats, batukada, instrumental angolano, afrobeat, kizomba, semba, kuduro, rap angola, drill, loop kits, drum kits, beats gratis, comprar beats, produtor musical, angola" />
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
    <meta name="theme-color" content="#08080a" />
    <link rel="canonical" href="${seo.canonicalUrl}" />

    <!-- OPEN GRAPH PREVIEWS -->
    <meta property="og:type" content="${seo.type}" />
    <meta property="og:title" content="${seo.title}" />
    <meta property="og:description" content="${seo.description}" />
    <meta property="og:image" content="${seo.image}" />
    <meta property="og:url" content="${seo.canonicalUrl}" />
    <meta property="og:site_name" content="BATUKADA" />
    <meta property="og:locale" content="pt_AO" />

    <!-- TWITTER CARDS -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="${seo.title}" />
    <meta name="twitter:description" content="${seo.description}" />
    <meta name="twitter:image" content="${seo.image}" />
    <meta name="twitter:site" content="@batukada_ao" />

    <!-- FUTURE WEB ANALYTICS INTEGRATIONS PLACEHOLDERS -->
    <!--
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-XXXXXXXXXX');
    </script>
    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', 'XXXXXXXXXXXXXXXXXX');
      fbq('track', 'PageView');
    </script>
    -->

    <!-- STRUCTURED DATA (JSON-LD SCHEMAS) -->
    <script type="application/ld+json">
      ${JSON.stringify(seo.jsonLd)}
    </script>
  `;

  if (modified.includes('</head>')) {
    modified = modified.replace('</head>', `${metaHtml}\n</head>`);
  } else {
    modified = modified + metaHtml;
  }

  return modified;
}

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  
  // Enable CORS
  app.use(cors());
  app.use(express.json({ limit: '50mb' }));
  
  // Security and Performance Tracking Middleware Interceptor
  app.use((req, res, next) => {
    const startTime = Date.now();
    const originalUrl = req.originalUrl || req.url;

    // Skip static assets
    if (originalUrl.includes('.') && !originalUrl.startsWith("/api")) {
      return next();
    }

    // Detect suspect patterns (SQL injections, path transversals, brute-forcing auth / wp probes)
    const suspectPatterns = [
      /(\%27)|(\')|(\-\-)|(\%23)|(#)/i, // basic SQLi signatures
      /(union\s+select)/i,
      /(\.\.\/)/, // Directory traversal
      /(etc\/passwd)/,
      /(wp-admin|wp-login)/
    ];
    
    const isSuspect = suspectPatterns.some(pat => pat.test(originalUrl));
    if (isSuspect) {
      logSystemEvent(
        "security_spam",
        `Suspect request detected: [${req.method}] ${originalUrl} from ${req.ip || "unknown"}`,
        "warning",
        { route: originalUrl, method: req.method, ip: req.ip }
      );
    }

    res.on("finish", () => {
      const duration = Date.now() - startTime;
      
      // Log slow APIs
      if (duration > 1500 && originalUrl.startsWith("/api")) {
        logSystemEvent(
          "performance_slow",
          `Slow API detected: [${req.method}] ${originalUrl} took ${duration}ms`,
          "warning",
          { route: originalUrl, durationMs: duration, method: req.method }
        );
      }

      // Log status errors
      if (res.statusCode >= 400) {
        let logType = "api_error";
        let severity = "error";
        if (res.statusCode === 429) {
          logType = "security_spam";
          severity = "warning";
        } else if (res.statusCode === 401 || res.statusCode === 403) {
          logType = "security_abuse";
          severity = "warning";
        }

        logSystemEvent(
          logType,
          `API returned ${res.statusCode} on [${req.method}] ${originalUrl}`,
          severity,
          { route: originalUrl, statusCode: res.statusCode, method: req.method }
        );
      }
    });

    next();
  });

  // Health check - define BEFORE other middlewares for maximum responsiveness
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "ok", 
      timestamp: new Date().toISOString(), 
      env: process.env.NODE_ENV,
      uptime: process.uptime()
    });
  });

  // Supabase dynamic proxy endpoint to bypass any client-side CORS / sandbox iframe network failures
  app.all('/api/supabase-proxy/*', async (req, res) => {
    let SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
    if (SUPABASE_URL) SUPABASE_URL = SUPABASE_URL.trim().replace(/^["'](.+)["']$/, '$1');
    if (!SUPABASE_URL) {
      return res.status(500).json({ error: "Supabase URL not configured on server" });
    }
    
    if (!SUPABASE_URL.startsWith('http')) {
      SUPABASE_URL = `https://${SUPABASE_URL}`;
    }
    try {
      const urlObj = new URL(SUPABASE_URL);
      SUPABASE_URL = urlObj.origin;
    } catch (e) {
      SUPABASE_URL = SUPABASE_URL.replace(/\/+$/, '');
    }

    const relPath = req.params[0] || '';
    const query = req.url.split('?')[1] || '';
    const targetUrl = `${SUPABASE_URL}/${relPath}${query ? '?' + query : ''}`;

    const headers: Record<string, string> = {};
    const keysToSkip = new Set([
      'host',
      'origin',
      'referer',
      'connection',
      'keep-alive',
      'proxy-connection',
      'content-length',
      'transfer-encoding',
      'upgrade',
      'cookie',
    ]);
    for (const [key, val] of Object.entries(req.headers)) {
      const lowerKey = key.toLowerCase();
      if (typeof val === 'string' && !keysToSkip.has(lowerKey)) {
        headers[key] = val;
      }
    }

    try {
      const fetchOpts: RequestInit = {
        method: req.method,
        headers,
      };

      if (req.method !== 'GET' && req.method !== 'HEAD') {
        if (req.body) {
          if (Buffer.isBuffer(req.body)) {
            fetchOpts.body = req.body;
          } else if (typeof req.body === 'object') {
            fetchOpts.body = JSON.stringify(req.body);
          } else {
            fetchOpts.body = String(req.body);
          }
        }
      }

      console.log(`[SUPABASE PROXY] Failsafe routing [${req.method}] ${req.url} -> ${targetUrl}`);
      const proxyResponse = await fetch(targetUrl, fetchOpts);
      
      res.status(proxyResponse.status);

      proxyResponse.headers.forEach((value, name) => {
        if (name.toLowerCase() !== 'transfer-encoding' && name.toLowerCase() !== 'content-encoding' && name.toLowerCase() !== 'connection') {
          res.setHeader(name, value);
        }
      });

      const arrayBuffer = await proxyResponse.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      res.send(buffer);
    } catch (err: any) {
      console.error(`[SUPABASE PROXY ERROR] Direct fallback failure to ${targetUrl}:`, err);
      res.status(500).json({ error: "Failed to proxy to Supabase", details: err.message });
    }
  });

  // --- AUTOMATIC REAL-TIME SITEMAP GENERATION ---
  app.get('/sitemap.xml', async (req, res) => {
    res.header('Content-Type', 'application/xml');
    const siteUrl = getExpandedSiteUrl(req);

    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <!-- Core Public Views -->
  <url>
    <loc>${siteUrl}/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${siteUrl}/all-beats</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${siteUrl}/producers</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${siteUrl}/licensing</loc>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>${siteUrl}/termos</loc>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
`;

    const supabase = getSupabase();
    if (supabase) {
      try {
        // Dynamic Beats URLs in Sitemap
        const { data: beats } = await supabase.from('beats').select('id, created_at').limit(150);
        if (beats) {
          beats.forEach((beat: any) => {
            xml += `  <url>
    <loc>${siteUrl}/beat/${beat.id}</loc>
    <lastmod>${new Date(beat.created_at || Date.now()).toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>\n`;
          });
        }

        // Dynamic Producer Profiles URLs in Sitemap (role = 'seller')
        const { data: producers } = await supabase.from('profiles').select('id, username, artistic_name, updated_at').eq('role', 'seller').limit(100);
        if (producers) {
          producers.forEach((p: any) => {
            const pName = p.artistic_name || p.username || p.id;
            xml += `  <url>
    <loc>${siteUrl}/producer/${encodeURIComponent(pName)}</loc>
    <lastmod>${new Date(p.updated_at || Date.now()).toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>\n`;
          });
        }

        // Dynamic Playlists URLs in Sitemap (is_public = true)
        const { data: playlists } = await supabase.from('playlists').select('id, created_at').eq('is_public', true).limit(100);
        if (playlists) {
          playlists.forEach((pl: any) => {
            xml += `  <url>
    <loc>${siteUrl}/playlist/${pl.id}</loc>
    <lastmod>${new Date(pl.created_at || Date.now()).toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.6</priority>
  </url>\n`;
          });
        }
      } catch (err) {
        console.error("Sitemap dynamic fetch issue:", err);
      }
    }

    xml += `</urlset>`;
    res.send(xml);
  });

  // --- AUTOMATIC OPTIMIZED ROBOTS.TXT ---
  app.get('/robots.txt', (req, res) => {
    res.type('text/plain');
    const host = req.headers.host || 'batukada.ao';
    const protocol = req.secure || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
    res.send(`User-agent: *
Allow: /
Allow: /all-beats
Allow: /producers
Allow: /licensing
Allow: /termos
Allow: /beat/
Allow: /producer/
Allow: /playlist/
Disallow: /admin-payouts
Disallow: /admin-finance
Disallow: /dashboard
Disallow: /messages
Disallow: /notifications
Disallow: /api/

Sitemap: ${protocol}://${host}/sitemap.xml`);
  });

  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  // ==============================================================================
  // REAL PAYPAL API PAYMENTS ENGINE (PRODUCTION-READY)
  // ==============================================================================

  function toValidUuid(id: any): string {
    if (!id) return "00000000-0000-0000-0000-000000000000";
    const strId = String(id).trim();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (uuidRegex.test(strId)) {
      return strId;
    }
    if (/^\d+$/.test(strId)) {
      const padded = strId.padStart(12, "0");
      return `00000000-0000-0000-0000-${padded}`;
    }
    let hex = "";
    for (let i = 0; i < strId.length; i++) {
      const code = strId.charCodeAt(i);
      hex += (code % 16).toString(16);
    }
    const cleanHex = hex.toLowerCase().replace(/[^0-9a-f]/g, "0").padStart(32, "0").substring(0, 32);
    return `${cleanHex.substring(0, 8)}-${cleanHex.substring(8, 12)}-${cleanHex.substring(12, 16)}-${cleanHex.substring(16, 20)}-${cleanHex.substring(20, 32)}`;
  }

  function normalizeBeatId(id: any): any {
    if (id === null || id === undefined) return id;
    const strId = String(id).trim();

    // Support both direct integers and padded pseudo UUID-like strings (e.g., 00000000-0000-0000-0000-000000000006)
    if (strId.includes("-")) {
      const parts = strId.split("-");
      const lastPart = parts[parts.length - 1]; // e.g. "000000000006"
      const cleaned = lastPart.replace(/^0+/, ""); // strip leading zeros: "6"
      const finalVal = cleaned === "" ? "0" : cleaned;
      if (/^\d+$/.test(finalVal)) {
        const parsed = parseInt(finalVal, 10);
        if (!isNaN(parsed)) {
          console.log(`[BEAT ID NORMALIZATION] Converted "${strId}" -> ${parsed}`);
          return parsed;
        }
      }
    }

    if (/^\d+$/.test(strId)) {
      const parsed = parseInt(strId, 10);
      if (!isNaN(parsed)) {
        return parsed;
      }
    }

    return strId;
  }

  async function getPayPalAccessToken() {
    const rawMode = process.env.PAYPAL_MODE || "sandbox";
    const mode = rawMode.trim().toLowerCase();
    
    let clientId = "";
    let clientSecret = "";

    if (mode === "live") {
      clientId = process.env.PAYPAL_LIVE_CLIENT_ID || process.env.PAYPAL_CLIENT_ID || "";
      clientSecret = process.env.PAYPAL_LIVE_SECRET || process.env.PAYPAL_CLIENT_SECRET || process.env.PAYPAL_SECRET || "";
      console.log("[PAYPAL CONFIG] Active Environment: PayPal Live Mode 🟢");
    } else {
      clientId = process.env.PAYPAL_SANDBOX_CLIENT_ID || process.env.PAYPAL_CLIENT_ID || "";
      clientSecret = process.env.PAYPAL_SANDBOX_SECRET || process.env.PAYPAL_CLIENT_SECRET || process.env.PAYPAL_SECRET || "";
      console.log("[PAYPAL CONFIG] Active Environment: PayPal Sandbox Mode 🧪");
    }

    if (!clientId || !clientSecret) {
      console.warn(`[PAYPAL CONFIG WARNING] Client ID or Secret missing in env structures for mode: ${mode}`);
      throw new Error(`Credenciais do PayPal não configuradas no servidor para o modo: ${mode}`);
    }

    const baseUrl = mode === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
    const auth = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");

    const response = await fetch(`${baseUrl}/v1/oauth2/token`, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${auth}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: "grant_type=client_credentials"
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`PayPal auth token exchange failed (${mode}): ${errText}`);
    }

    const data = await response.json();
    return {
      accessToken: data.access_token,
      baseUrl
    };
  }

  function appendPayPalLocalBackup(txData: any) {
    try {
      const filePath = path.join(process.cwd(), "paypal_transactions_ledger.json");
      let records = [];
      if (fs.existsSync(filePath)) {
        try {
          records = JSON.parse(fs.readFileSync(filePath, "utf-8"));
        } catch (e) {
          records = [];
        }
      }
      records.push({
        ...txData,
        backed_up_at: new Date().toISOString()
      });
      fs.writeFileSync(filePath, JSON.stringify(records, null, 2), "utf-8");
      console.log("[PAYPAL LOCAL LEDGER] Successfully backed up transaction to local ledger file.");
    } catch (err: any) {
      console.error("[PAYPAL LOCAL LEDGER] CRITICAL ERROR! Local transaction write failed:", err.message);
    }
  }

  async function savePayPalTransaction(supabase: any, txData: {
    order_id: string;
    capture_id: string;
    payer_email: string;
    amount: number;
    currency: string;
    status: string;
    buyer_id: string;
    beat_id: string;
  }) {
    console.log("[PAYPAL TRANSACTIONS] Log entry attempt:", txData);
    try {
      // Idempotency: skip write if capture_id already logged in Postgres
      if (txData.capture_id && txData.capture_id !== "webhook_capture") {
        const { data: existingTx } = await supabase
          .from("paypal_transactions")
          .select("id")
          .eq("capture_id", txData.capture_id)
          .maybeSingle();

        if (existingTx) {
          console.log(`[PAYPAL TRANSACTIONS] Database duplicate safety triggered: transaction for capture_id ${txData.capture_id} has already been logged.`);
          return;
        }
      }

      const dbPayload = {
        order_id: toValidUuid(txData.order_id),
        capture_id: txData.capture_id,
        payer_email: txData.payer_email,
        amount: txData.amount,
        currency: txData.currency,
        status: txData.status,
        buyer_id: toValidUuid(txData.buyer_id),
        beat_id: toValidUuid(txData.beat_id),
        created_at: new Date().toISOString()
      };

      const { error } = await supabase.from("paypal_transactions").insert(dbPayload);
      if (error) {
        console.warn("[PAYPAL TRANSACTIONS] Table write omitted. Table might not be present in Postgres yet. Saving to ledger backup.", error.message);
        appendPayPalLocalBackup(txData);
      } else {
        console.log("[PAYPAL TRANSACTIONS] SQL record saved successfully in public.paypal_transactions");
      }
    } catch (err: any) {
      console.error("[PAYPAL TRANSACTIONS] Write failed with exception. Saving locally:", err.message);
      appendPayPalLocalBackup(txData);
    }
  }

  async function reverseOrderRoyalties(orderId: string, supabase: any) {
    console.log(`[ROYALTY REVERSAL ENGINE] Beginning royalty reversal checks for order: ${orderId}`);
    try {
      const validOrderId = toValidUuid(orderId);

      // 1. Prevent double reversal: Check royalty_reversals table
      const { data: existingRev, error: revSearchErr } = await supabase
        .from("royalty_reversals")
        .select("id")
        .eq("order_id", validOrderId)
        .maybeSingle();

      if (existingRev) {
        console.log(`[ROYALTY REVERSAL] Order ${orderId} has already been reversed. Skipping.`);
        return;
      }

      // 2. Fetch all completed wallet transactions associated with this order_id
      const { data: txs, error: txsErr } = await supabase
        .from("wallet_transactions")
        .select("*")
        .eq("order_id", validOrderId)
        .eq("status", "completed");

      if (txsErr) {
        console.error(`[ROYALTY REVERSAL] Error fetching transactions for order ${orderId}:`, txsErr.message);
      }

      const transactionsToReverse = txs || [];
      if (transactionsToReverse.length === 0) {
        console.log(`[ROYALTY REVERSAL] No completed transactions found directly for order ${orderId}. Reversal engine completed with zero operations.`);
      }

      let totalReversedAmount = 0;

      // 3. Process reversal for each transaction found
      for (const tx of transactionsToReverse) {
        const prodId = toValidUuid(tx.producer_id);
        const amountToDeduct = Number(tx.producer_amount || 0);
        totalReversedAmount += amountToDeduct;

        console.log(`[ROYALTY REVERSAL] Reversing ${amountToDeduct} Kz from producer ${prodId} for transaction ${tx.id}`);

        // Fetch current balances from profiles
        const { data: profile, error: profErr } = await supabase
          .from("profiles")
          .select("wallet_available_balance, wallet_balance, wallet_total_earned, wallet_pending_debt")
          .eq("id", prodId)
          .maybeSingle();

        if (profErr || !profile) {
          console.warn(`[ROYALTY REVERSAL] Failsafe: Profile ${prodId} not found, bypassing profile balance updates.`);
          continue;
        }

        const curAvail = Number(profile.wallet_available_balance || 0);
        const curBalance = Number(profile.wallet_balance || 0);
        const curEarned = Number(profile.wallet_total_earned || 0);
        const curDebt = Number(profile.wallet_pending_debt || 0);

        // Deduct available balance without going negative
        const deductFromAvail = Math.min(amountToDeduct, curAvail);
        const remainingDebt = amountToDeduct - deductFromAvail;

        const nextAvail = Math.max(0, curAvail - deductFromAvail);
        const nextBalance = Math.max(0, curBalance - deductFromAvail);
        const nextEarned = Math.max(0, curEarned - amountToDeduct);
        const nextDebt = curDebt + remainingDebt;

        console.log(`[ROYALTY REVERSAL PROFILE UPDATE] Producer ${prodId}: Avail: ${curAvail} -> ${nextAvail}, Balance: ${curBalance} -> ${nextBalance}, Earned: ${curEarned} -> ${nextEarned}, Debt: ${curDebt} -> ${nextDebt}`);

        const { error: profUpdErr } = await supabase
          .from("profiles")
          .update({
            wallet_available_balance: nextAvail,
            wallet_balance: nextBalance,
            wallet_total_earned: nextEarned,
            wallet_pending_debt: nextDebt
          })
          .eq("id", prodId);

        if (profUpdErr) {
          console.error(`[ROYALTY REVERSAL] Profile update failed for user ${prodId}:`, profUpdErr.message);
        }

        // Fetch and update wallets table
        try {
          const { data: wallet, error: walErr } = await supabase
            .from("wallets")
            .select("available_balance, total_earned, pending_debt")
            .eq("producer_id", prodId)
            .maybeSingle();

          if (!walErr && wallet) {
            const curWalAvail = Number(wallet.available_balance || 0);
            const curWalEarned = Number(wallet.total_earned || 0);
            const curWalDebt = Number(wallet.pending_debt || 0);

            const deductFromWalAvail = Math.min(amountToDeduct, curWalAvail);
            const walRemainingDebt = amountToDeduct - deductFromWalAvail;

            const nextWalAvail = Math.max(0, curWalAvail - deductFromWalAvail);
            const nextWalEarned = Math.max(0, curWalEarned - amountToDeduct);
            const nextWalDebt = curWalDebt + walRemainingDebt;

            console.log(`[ROYALTY REVERSAL WALLET UPDATE] Producer ${prodId}: Avail: ${curWalAvail} -> ${nextWalAvail}, Earned: ${curWalEarned} -> ${nextWalEarned}, Debt: ${curWalDebt} -> ${nextWalDebt}`);

            await supabase
              .from("wallets")
              .update({
                available_balance: nextWalAvail,
                total_earned: nextWalEarned,
                pending_debt: nextWalDebt
              })
              .eq("producer_id", prodId);
          }
        } catch (walSyncErr: any) {
          console.warn(`[ROYALTY REVERSAL] Wallet sync details skipped:`, walSyncErr.message);
        }

        // Write a negative transaction ledger entry to show the reversal
        try {
          await supabase.from("wallet_transactions").insert({
            producer_id: prodId,
            amount: -tx.amount,
            producer_amount: -amountToDeduct,
            platform_amount: -tx.platform_amount,
            transaction_type: "reversal",
            order_id: validOrderId,
            status: "completed",
            collab_beat_title: `Estorno: ${tx.collab_beat_title || 'Reversal'}`
          });
        } catch (insErr: any) {
          console.warn("[ROYALTY REVERSAL LEDGER ERROR] Skipping ledger insertion:", insErr.message);
        }

        // Send reversal notification to producer
        try {
          await supabase.from("notifications").insert([
            {
              user_id: prodId,
              type: "system",
              title: "Estorno de Royalties ⚠️",
              message: `O pagamento referente ao beat "${tx.collab_beat_title || 'Instrumental'}" foi reembolsado ou cancelado. Os royalties de ${amountToDeduct.toLocaleString("pt-AO")} Kz foram estornados da sua conta. ${remainingDebt > 0 ? `Uma dívida pendente de ${remainingDebt.toLocaleString("pt-AO")} Kz foi registrada.` : ""}`,
              read: false,
              created_at: new Date().toISOString()
            }
          ]);
        } catch (notifErr: any) {
          console.warn("[ROYALTY REVERSAL NOTIFICATION ERROR] Skipped sending notification:", notifErr.message);
        }
      }

      // 4. Mark reversal complete in royalty_reversals table
      const { error: revInsErr } = await supabase
        .from("royalty_reversals")
        .insert({
          order_id: validOrderId,
          reversal_amount: totalReversedAmount
        });

      if (revInsErr) {
        console.error(`[ROYALTY REVERSAL BOOKKEEPING ERROR] Failed to record in royalty_reversals:`, revInsErr.message);
      } else {
        console.log(`[ROYALTY REVERSAL SUCCESS] Royalty reversal completed perfectly for order: ${orderId}`);
      }

    } catch (err: any) {
      console.error(`[ROYALTY REVERSAL CRITICAL EXCEPTION]`, err);
    }
  }

  async function activatePaidOrder(orderId: string, supabase: any) {
    console.log(`[ORDER ACTIVATION] Triggering checkout automation process for order: ${orderId}`);
    
    // Atomic update: transition state from 'pending' to 'paid' atomically
    const { data: updatedRows, error: updateOrderError } = await supabase
      .from("orders")
      .update({ status: "paid" })
      .eq("id", toValidUuid(orderId))
      .eq("status", "pending")
      .select();

    if (updateOrderError) {
      console.error(`[ORDER ACTIVATION] DB State write error for order: ${orderId}`, updateOrderError);
      throw new Error(`Falha ao actualizar estado do pedido na base de dados.`);
    }

    if (!updatedRows || updatedRows.length === 0) {
      console.log(`[SECURITY] Duplicate activation prevented for order: ${orderId}`);
      // Fetch the order to return it, but abort any further activation processing/payout distribution
      const { data: existingOrder } = await supabase
        .from("orders")
        .select("*")
        .eq("id", toValidUuid(orderId))
        .single();
      return existingOrder || { id: orderId, status: "paid" };
    }

    const order = updatedRows[0];
    console.log(`[ORDER ACTIVATION] DB Order status set to "paid" atomically for ${orderId}`);

    // 4. Distribute Producer Earnings
    try {
      let orderItems = [];
      const { data: items, error: itemsError } = await supabase
        .from("order_items")
        .select("*")
        .eq("order_id", toValidUuid(orderId));

      if (items && items.length > 0) {
        orderItems = items;
      } else if (order.beat_id) {
        // Fallback for direct orders without standard item tables
        orderItems = [{
          beat_id: toValidUuid(order.beat_id),
          producer_id: order.producer_id || null,
          price: Number(order.amount || order.total_amount || 0)
        }];
      }

      console.log(`[ORDER ACTIVATION] Processing ${orderItems.length} tracks/kits for payout.`);

      const allPayouts: any[] = [];

      for (const item of orderItems) {
        const itemPrice = Number(item.price || 0);
        const netValue = itemPrice * 0.9;
        const normBId = item.beat_id ? normalizeBeatId(item.beat_id) : null;
        
        let beatTitle = "Beat / Produto";
        let dbProducerId = item.producer_id;

        // Fetch beat info if we have beat_id
        if (normBId) {
          try {
            const { data: beatData } = await supabase
              .from("beats")
              .select("title, producer_id")
              .eq("id", normBId)
              .single();
            if (beatData) {
              beatTitle = beatData.title || beatTitle;
              dbProducerId = beatData.producer_id || dbProducerId;
            }
          } catch (e: any) {
            console.error("[ORDER ACTIVATION] Failed querying title / producer for beat:", e.message);
          }
        }

        // Fetch collaborations
        let collabs: any[] = [];
        if (normBId) {
          try {
            const { data: dbCollabs, error: dbCollabsErr } = await supabase
              .from("beat_collaborators")
              .select("*")
              .eq("beat_id", normBId);
            if (!dbCollabsErr && dbCollabs && dbCollabs.length > 0) {
              collabs = dbCollabs;
            } else {
              // Try local file as fallback
              const fileContent = readCollaborators();
              collabs = fileContent.filter((c: any) => Number(c.beat_id) === Number(normBId));
            }
          } catch (errCollab) {
            console.warn("[ORDER PAYMENT COLLAB] Ignored fetch error:", errCollab);
          }
        }

        if (collabs.length > 0) {
          console.log(`[COLLABS] Beat "${beatTitle}" has ${collabs.length} collaborators configured:`);
          for (const collab of collabs) {
            const pct = Number(collab.split_percentage || 0);
            const splitAmount = netValue * (pct / 100);
            const splitOriginal = itemPrice * (pct / 100);
            const splitPlatform = splitOriginal * 0.1;
            console.log(`  - Producer: ${collab.producer_id}, Split: ${pct}%, Net earned: ${splitAmount}`);
            allPayouts.push({
              producer_id: toValidUuid(collab.producer_id),
              netRevenue: splitAmount,
              originalPrice: splitOriginal,
              platformFee: splitPlatform,
              beatTitle: beatTitle,
              isCollab: true,
              collabPercentage: pct
            });
          }
        } else if (dbProducerId) {
          console.log(`[COLLABS] Beat "${beatTitle}" has standard 100% split to main producer ${dbProducerId}.`);
          allPayouts.push({
            producer_id: toValidUuid(dbProducerId),
            netRevenue: netValue,
            originalPrice: itemPrice,
            platformFee: itemPrice * 0.1,
            beatTitle: beatTitle,
            isCollab: false
          });
        }
      }

      // Group cumulative netRevenue for wallet balances to prevent parallel update races
      const groupedRevenue: Record<string, number> = {};
      for (const p of allPayouts) {
        groupedRevenue[p.producer_id] = (groupedRevenue[p.producer_id] || 0) + p.netRevenue;
      }

      // Loop through each participating producer and update profiles/wallets
      for (const [pId, rawNetRevenue] of Object.entries(groupedRevenue)) {
        let netRevenue = Number(rawNetRevenue);
        console.log(`[ORDER ACTIVATION] Dispatching payout to producer ${pId}: ${netRevenue} Kz`);
        
        // 1. Check and deduct from pending debt first
        let currentDebt = 0;
        try {
          const { data: profile } = await supabase
            .from("profiles")
            .select("wallet_pending_debt")
            .eq("id", toValidUuid(pId))
            .maybeSingle();
          if (profile) {
            currentDebt = Number(profile.wallet_pending_debt || 0);
          }
        } catch (e: any) {
          console.warn("[DEBT CHECK ERROR] Failed to fetch debt for checkout:", e.message);
        }

        let deductFromDebt = 0;
        if (currentDebt > 0) {
          deductFromDebt = Math.min(netRevenue, currentDebt);
          const nextDebt = currentDebt - deductFromDebt;
          netRevenue = netRevenue - deductFromDebt;
          
          console.log(`[DEBT CLEARANCE] Producer ${pId} has debt: ${currentDebt} Kz. Cleared: ${deductFromDebt} Kz. Remaining debt: ${nextDebt} Kz. Net payout credited: ${netRevenue} Kz.`);
          
          try {
            await supabase
              .from("profiles")
              .update({ wallet_pending_debt: nextDebt })
              .eq("id", toValidUuid(pId));
              
            await supabase
              .from("wallets")
              .update({ pending_debt: nextDebt })
              .eq("producer_id", toValidUuid(pId));
          } catch (debtErr: any) {
            console.warn("[DEBT CLEARANCE ERROR]", debtErr.message);
          }
        }

        if (netRevenue <= 0) {
          console.log(`[ORDER ACTIVATION] Payout for producer ${pId} fully devoured by pending debt closure. Skipping balance updates.`);
          continue;
        }

        // Log and perform the atomic wallet update via direct database function RPC
        console.log('[Wallet ATOMIC UPDATE]', pId, netRevenue);

        const { error: rpcErr } = await supabase.rpc("increment_producer_wallet", {
          p_producer_id: toValidUuid(pId),
          p_amount: netRevenue
        });

        if (rpcErr) {
          console.error(`[Wallet ATOMIC UPDATE ERROR] custom increment_producer_wallet function failed for producer ${pId}:`, rpcErr.message);

          // Full proof dynamic fallback to stay functional if the database schema is not fully upgraded with the RPC.
          // Fallback uses a single transaction-like select lock block
          console.log(`[Wallet FALLBACK UPDATE] Executing safe fallback direct updates for producer ${pId}: ${netRevenue}`);
          const { data: profile } = await supabase
            .from("profiles")
            .select("wallet_pending_balance, wallet_available_balance, wallet_total_earned, wallet_balance")
            .eq("id", toValidUuid(pId))
            .single();

          const curPending = Number(profile?.wallet_pending_balance || 0);
          const curAvailable = Number(profile?.wallet_available_balance || 0);
          const curEarned = Number(profile?.wallet_total_earned || 0);
          const curBalance = Number(profile?.wallet_balance || 0);

          await supabase
            .from("profiles")
            .update({
              wallet_pending_balance: curPending + netRevenue,
              wallet_available_balance: curAvailable + netRevenue,
              wallet_total_earned: curEarned + netRevenue,
              wallet_balance: curBalance + netRevenue
            })
            .eq("id", toValidUuid(pId));

          // Synced wallet records updates
          try {
            const { data: wallet } = await supabase
              .from("wallets")
              .select("*")
              .eq("producer_id", toValidUuid(pId))
              .single();

            if (wallet) {
              await supabase
                .from("wallets")
                .update({
                  pending_balance: Number(wallet.pending_balance || 0) + netRevenue,
                  available_balance: Number(wallet.available_balance || 0) + netRevenue,
                  total_earned: Number(wallet.total_earned || 0) + netRevenue
                })
                .eq("producer_id", toValidUuid(pId));
            } else {
              await supabase.from("wallets").insert({
                producer_id: toValidUuid(pId),
                available_balance: netRevenue,
                pending_balance: netRevenue,
                total_earned: netRevenue,
                total_withdrawn: 0
              });
            }
          } catch (walErr: any) {
            console.warn("[ORDER ACTIVATION] Sync wallet tables bypassed in fallback:", walErr.message);
          }
        }
      }

      // Register notifications and individual transactions
      for (const p of allPayouts) {
        const titleStr = p.isCollab 
          ? `Ganhos de Colaboração! 🤝` 
          : `Nova Venda Realizada! 💰`;
          
        const messageStr = p.isCollab
          ? `Excelente! Recebeste um split de ${p.collabPercentage}% no beat "${p.beatTitle}" no valor líquido de ${p.netRevenue.toLocaleString("pt-AO")} Kz.`
          : `Parabéns! Realizaste uma nova venda do beat "${p.beatTitle}" no valor líquido de ${p.netRevenue.toLocaleString("pt-AO")} Kz.`;

        await supabase.from("notifications").insert([
          {
            user_id: p.producer_id,
            type: "purchase",
            title: titleStr,
            message: messageStr,
            read: false,
            created_at: new Date().toISOString()
          }
        ]);

        try {
          // Dual insert: try writing collab_percentage, collab_beat_title and order_id
          const { error: insErr } = await supabase.from("wallet_transactions").insert({
            producer_id: p.producer_id,
            amount: p.originalPrice,
            producer_amount: p.netRevenue,
            platform_amount: p.platformFee,
            transaction_type: p.isCollab ? `collab_sale:${p.collabPercentage}` : "sale",
            collab_percentage: p.isCollab ? p.collabPercentage : null,
            collab_beat_title: p.beatTitle,
            status: "completed",
            order_id: toValidUuid(orderId)
          });

          if (insErr) {
            // Fallback for older database schema
            await supabase.from("wallet_transactions").insert({
              producer_id: p.producer_id,
              amount: p.originalPrice,
              producer_amount: p.netRevenue,
              platform_amount: p.platformFee,
              transaction_type: p.isCollab ? `collab_sale:${p.collabPercentage}` : "sale",
              status: "completed",
              order_id: toValidUuid(orderId)
            });
          }
        } catch (walErr: any) {
          console.warn("[ORDER ACTIVATION] Sync wallet transaction bypassed:", walErr.message);
        }
      }
    } catch (payoutErr: any) {
      console.error("[ORDER ACTIVATION] payoutErr", payoutErr);
    }

    // 5. Unlock Active Downloads (purchased_beats records)
    try {
      if (order.beat_id) {
        const { data: activeList } = await supabase
          .from("purchased_beats")
          .select("*")
          .eq("order_id", toValidUuid(order.id))
          .eq("beat_id", toValidUuid(order.beat_id));

        const active = activeList && activeList.length > 0 ? activeList[0] : null;

        let licId = 1;
        if (order.license_type === "premium") licId = 2;
        if (order.license_type === "exclusive") licId = 3;

        if (!active) {
          await supabase.from("purchased_beats").insert({
            customer_id: toValidUuid(order.customer_id || order.buyer_id),
            beat_id: toValidUuid(order.beat_id),
            order_id: toValidUuid(order.id),
            license_id: licId
          });
        } else {
          await supabase.from("purchased_beats")
            .update({ license_id: licId })
            .eq("id", toValidUuid(active.id));
        }
      } else {
        // Multi-Cart items
        const { data: listItems } = await supabase
          .from("order_items")
          .select("*")
          .eq("order_id", toValidUuid(order.id));

        if (listItems && listItems.length > 0) {
          for (const item of listItems) {
            const { data: currList } = await supabase
              .from("purchased_beats")
              .select("*")
              .eq("order_id", toValidUuid(order.id))
              .eq("beat_id", toValidUuid(item.beat_id));

            const curr = currList && currList.length > 0 ? currList[0] : null;
            const itemLicId = Number(item.license_id) || 1;

            if (!curr) {
              await supabase.from("purchased_beats").insert({
                customer_id: toValidUuid(order.customer_id || order.buyer_id),
                beat_id: toValidUuid(item.beat_id),
                order_id: toValidUuid(order.id),
                license_id: itemLicId
              });
            } else {
              await supabase.from("purchased_beats")
                .update({ license_id: itemLicId })
                .eq("id", toValidUuid(curr.id));
            }
          }
        }
      }
      console.log("[ORDER ACTIVATION] Licensing maps set up successfully.");
    } catch (unlockErr: any) {
      console.error("[ORDER ACTIVATION] Unlock licenses failure:", unlockErr.message);
    }

    // 6. Notify Client/Buyer of status
    try {
      const bId = order.customer_id || order.buyer_id;
      if (bId) {
        const valBuyerId = toValidUuid(bId);
        const { data: presentNotifs } = await supabase
          .from("notifications")
          .select("id")
          .eq("user_id", valBuyerId)
          .eq("order_id", toValidUuid(order.id))
          .eq("type", "purchase_confirmed");

        if (!presentNotifs || presentNotifs.length === 0) {
          await supabase.from("notifications").insert([
            {
              user_id: valBuyerId,
              order_id: toValidUuid(order.id),
              type: "purchase_confirmed",
              title: "Pagamento Confirmado",
              message: "Seu pagamento por PayPal foi confirmado com sucesso!\nA sua licença já está disponível em 'Licenças Ativas'.",
              read: false,
              created_at: new Date().toISOString()
            }
          ]);
          console.log("[ORDER ACTIVATION] Delivered client purchase confirmation notification.");
        }
      }
    } catch (notifErr: any) {
      console.error("[ORDER ACTIVATION] Direct client notification skipped:", notifErr.message);
    }

    console.log(`[ORDER ACTIVATION] Order ${orderId} successfully completed and automated!`);
    return order;
  }

  // --- Secure Order Creation Endpoint ---
  app.post("/api/orders/create", authenticateUser, async (req: any, res) => {
    const { beatId, licenseType, items } = req.body;
    
    // Log that we ignore client price if they sent one
    if (req.body.price !== undefined || req.body.amount !== undefined) {
      console.log('[SECURITY] CLIENT PRICE IGNORED');
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "Serviço de base de dados indisponível." });
    }

    try {
      let finalAmount = 0;
      let orderToInsert: any = {};
      let itemsToInsert: any[] = [];
      let mappedBeatsForPromo: any[] = [];

      // Determine if multi-item cart versus single item
      const isMulti = Array.isArray(items) && items.length > 0;

      if (isMulti) {
        // Multi-cart checkout path
        const beatIds = items.map((it: any) => toValidUuid(it.id || it.beatId));
        const { data: beatsData, error: beatsErr } = await supabase
          .from("beats")
          .select("id, title, producer_id, price_basic, price_premium, price_exclusive")
          .in("id", beatIds);

        if (beatsErr || !beatsData || beatsData.length !== items.length) {
          console.error("[SECURITY CHECKOUT] Some beats not found for cart items:", items, beatsErr);
          return res.status(404).json({ error: "Um ou mais beats selecionados não foram encontrados na base de dados." });
        }

        // Map items to the format expected by the promotions engine
        mappedBeatsForPromo = items.map((it: any) => {
          const beat = beatsData.find((b: any) => toValidUuid(b.id) === toValidUuid(it.id || it.beatId));
          if (!beat) {
            throw new Error(`Beat non-existent: ${it.id || it.beatId}`);
          }

          if (toValidUuid(req.user.id) === toValidUuid(beat.producer_id)) {
            throw new Error(`Você não pode comprar o seu próprio beat "${beat.title}".`);
          }

          return {
            id: beat.id,
            title: beat.title,
            producer_id: beat.producer_id,
            price: {
              basic: Number(beat.price_basic !== null && beat.price_basic !== undefined ? beat.price_basic : 25000),
              premium: Number(beat.price_premium !== null && beat.price_premium !== undefined ? beat.price_premium : 75000),
              exclusive: Number(beat.price_exclusive !== null && beat.price_exclusive !== undefined ? beat.price_exclusive : 250000)
            },
            selectedLicense: String(it.selectedLicense || it.license_type || it.license || 'basic').toLowerCase().trim()
          };
        });

        // Pull active promotions from database
        const allPromotions = await getPromotionsFromDB();
        const activePromos = allPromotions.filter(p => p.status === 'active');

        // Evaluate promotions securely server-side
        const evaluation = evaluateCartPromotions(mappedBeatsForPromo, activePromos);
        finalAmount = evaluation.total;

        // Build the base order properties
        orderToInsert = {
          beat_id: null,
          beat_title: `${mappedBeatsForPromo.length} Instrumentais`,
          customer_id: toValidUuid(req.user.id),
          amount: finalAmount,
          status: 'pending',
          license_type: 'multi'
        };

        // Prepare order items
        itemsToInsert = evaluation.cartItems.map((item: any) => {
          const selectedLicense = String(item.selectedLicense || 'basic');
          const finalItemPrice = item.isFree ? 0 : (item.price[selectedLicense] !== undefined ? item.price[selectedLicense] : 0);
          
          let licenseId = 1; // basic
          if (selectedLicense === 'premium' || selectedLicense === 'wav' || selectedLicense === 'trackout') {
            licenseId = 2;
          } else if (selectedLicense === 'exclusive' || selectedLicense === 'unlimited') {
            licenseId = 3;
          }

          return {
            beat_id: toValidUuid(item.id),
            license_id: licenseId,
            producer_id: toValidUuid(item.producer_id),
            price: finalItemPrice
          };
        });

      } else {
        // Single-item checkout fallback path
        if (!beatId || !licenseType) {
          return res.status(400).json({ error: "Parâmetros 'beatId' e 'licenseType' são obrigatórios." });
        }

        const normalizedBId = toValidUuid(beatId);
        const { data: beat, error: beatErr } = await supabase
          .from("beats")
          .select("id, title, producer_id, price_basic, price_premium, price_exclusive")
          .eq("id", normalizedBId)
          .single();

        if (beatErr || !beat) {
          console.error("[SECURITY CHECKOUT] Beat not found:", beatId, beatErr);
          return res.status(404).json({ error: "O instrumental/beat selecionado não foi encontrado." });
        }

        if (toValidUuid(req.user.id) === toValidUuid(beat.producer_id)) {
          return res.status(400).json({ error: "Você não pode comprar o seu próprio beat." });
        }

        let serverPrice = 0;
        const lic = String(licenseType).toLowerCase().trim();
        if (lic === "basic" || lic === "mp3") {
          serverPrice = beat.price_basic !== null && beat.price_basic !== undefined ? beat.price_basic : 25000;
        } else if (lic === "premium" || lic === "wav" || lic === "trackout") {
          serverPrice = beat.price_premium !== null && beat.price_premium !== undefined ? beat.price_premium : 75000;
        } else if (lic === "exclusive" || lic === "unlimited") {
          serverPrice = beat.price_exclusive !== null && beat.price_exclusive !== undefined ? beat.price_exclusive : 250000;
        } else {
          return res.status(400).json({ error: "Tipo de licença inválido." });
        }

        finalAmount = serverPrice;

        orderToInsert = {
          beat_id: beat.id,
          beat_title: beat.title,
          customer_id: toValidUuid(req.user.id),
          amount: finalAmount,
          status: 'pending',
          license_type: licenseType
        };

        let licenseId = 1;
        if (lic === 'premium' || lic === 'wav' || lic === 'trackout') {
          licenseId = 2;
        } else if (lic === 'exclusive' || lic === 'unlimited') {
          licenseId = 3;
        }

        itemsToInsert = [{
          beat_id: beat.id,
          license_id: licenseId,
          producer_id: toValidUuid(beat.producer_id),
          price: finalAmount
        }];
      }

      console.log('[SECURITY CHECKOUT] Verified order grand total amount on server:', finalAmount);

      // Create main entry in order database
      const { data: order, error: orderErr } = await supabase
        .from("orders")
        .insert(orderToInsert)
        .select()
        .single();

      if (orderErr || !order) {
        console.error("[SECURITY CHECKOUT] Failed to insert parent order:", orderErr);
        return res.status(500).json({ error: "Erro ao criar pedido na base de dados." });
      }

      // Add order items
      const finalItemsPayload = itemsToInsert.map(item => ({
        ...item,
        order_id: order.id
      }));

      const { data: insertedItems, error: itemsErr } = await supabase
        .from("order_items")
        .insert(finalItemsPayload)
        .select();

      if (itemsErr) {
        console.error("[SECURITY CHECKOUT] Failed to insert order items mapping:", itemsErr);
        // Clean up
        await supabase.from("orders").delete().eq("id", order.id);
        return res.status(500).json({ error: "Erro ao vincular itens à sua transação." });
      }

      // If a promotion was applied, log its usage to promotion_usage table
      if (isMulti) {
        const allPromotions = await getPromotionsFromDB();
        const activePromos = allPromotions.filter(p => p.status === 'active');
        const evaluation = evaluateCartPromotions(mappedBeatsForPromo, activePromos);

        if (evaluation.applicablePromotion && evaluation.discountApplied > 0) {
          try {
            await savePromotionUsageInDB({
              promotion_id: evaluation.applicablePromotion.id,
              order_id: order.id,
              customer_id: req.user.id,
              discount_applied: evaluation.discountApplied
            });
            console.log(`[PROMO LOGGED] Successfully stored usage of promotion: ${evaluation.applicablePromotion.name} with discount: ${evaluation.discountApplied}`);
          } catch (usageErr: any) {
            console.error("[PROMO LOGGED ERROR] Failed to save promotion usage:", usageErr.message);
          }
        }
      }

      return res.json({ success: true, orderId: order.id, order });

    } catch (err: any) {
      console.error("[SECURITY CHECKOUT ERROR]", err);
      return res.status(500).json({ error: err.message || "Erro interno no servidor antes de criar a ordem." });
    }
  });

  // --- Smart Link & Short URL System Endpoints & Routing ---

  // Helper: Parse device type and browser
  function parseUserAgentHeader(uaHeader: string) {
    const ua = uaHeader || "";
    let device_type = "desktop";
    if (/mobile|android|iphone|ipad|phone/i.test(ua)) {
      device_type = "mobile";
    } else if (/tablet|ipad|playbook|silk/i.test(ua)) {
      device_type = "tablet";
    }

    let browser = "Browser";
    if (/chrome|crios/i.test(ua)) browser = "Chrome";
    else if (/firefox|fxios/i.test(ua)) browser = "Firefox";
    else if (/safari/i.test(ua)) browser = "Safari";
    else if (/msie|trident/i.test(ua)) browser = "Internet Explorer";
    else if (/edg/i.test(ua)) browser = "Edge";
    else if (/opr/i.test(ua)) browser = "Opera";

    return { device_type, browser };
  }

  // Helper: Parse referrer
  function parseReferrerHeader(refererHeader: string, refParam: string) {
    const ref = (refererHeader || refParam || "Direct").trim().toLowerCase();
    
    if (ref.includes("youtube") || ref.includes("youtu.be")) return "YouTube";
    if (ref.includes("instagram") || ref.includes("ig.me")) return "Instagram";
    if (ref.includes("tiktok")) return "TikTok";
    if (ref.includes("whatsapp") || ref.includes("wa.me")) return "WhatsApp";
    if (ref.includes("facebook") || ref.includes("fb.me")) return "Facebook";
    if (ref.includes("twitter") || ref.includes("t.co")) return "Twitter";
    if (ref === "direct" || ref === "") return "Direct";
    
    try {
      const url = new URL(ref);
      return url.hostname;
    } catch (e) {
      return refererHeader ? refererHeader.substring(0, 50) : "Direct";
    }
  }

  // Helper to handle Smart Link Redirects
  function registerSmartRedirect(type: 'beat' | 'kit' | 'profile' | 'promotion') {
    return async (req: express.Request, res: express.Response, next: express.NextFunction) => {
      try {
        const { code } = req.params;
        const link = await lookupShortLinkByCodeAndType(code, type);
        
        if (!link) {
          return res.redirect("/");
        }

        // Gather tracking variables
        const ua = req.headers["user-agent"] || "";
        const { device_type, browser } = parseUserAgentHeader(ua);
        
        const referer = req.headers["referer"] || req.headers["referrer"] || "";
        const refQuery = (req.query.ref as string) || "";
        const referrer = parseReferrerHeader(referer as string, refQuery);

        const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "127.0.0.1") as string;
        const ip_hash = crypto.createHash("sha256").update(ip).digest("hex");

        const country = (
          req.headers["cf-ipcountry"] || 
          req.headers["x-client-geo-country"] || 
          req.headers["x-appengine-country"] || 
          "Angola"
        ) as string;

        const city = (
          req.headers["x-client-geo-city"] || 
          req.headers["x-appengine-city"] || 
          "Luanda"
        ) as string;

        // Perform click tracking out-of-band in process.nextTick (extremely lightweight/non-blocking redirect speed)
        process.nextTick(() => {
          logClick(link.id, {
            ip_hash,
            country,
            city,
            device_type,
            browser,
            referrer,
            user_agent: ua
          }).catch(err => {
            console.error("[ASYNC SHORTER REDIRECT TRACKING EXCEPTION]", err);
          });
        });

        // Fast instant redirect returned to browser immediately
        return res.redirect(link.target_url);

      } catch (err) {
        console.error(`[SHORT LINK REDIRECT EXCEPTION] Prefixed redirect failed:`, err);
        return res.redirect("/");
      }
    };
  }

  // Redirect Routes
  app.get("/b/:code", registerSmartRedirect("beat"));
  app.get("/p/:code", registerSmartRedirect("profile"));
  app.get("/k/:code", registerSmartRedirect("kit"));

  // Safe and clean prefixed fallback or promotion routing structure
  app.get("/s/:code", async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    try {
      const { code } = req.params;
      const link = await lookupShortLinkByCode(code);
      
      if (!link) {
        return res.redirect("/");
      }

      const ua = req.headers["user-agent"] || "";
      const { device_type, browser } = parseUserAgentHeader(ua);
      
      const referer = req.headers["referer"] || req.headers["referrer"] || "";
      const refQuery = (req.query.ref as string) || "";
      const referrer = parseReferrerHeader(referer as string, refQuery);

      const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "127.0.0.1") as string;
      const ip_hash = crypto.createHash("sha256").update(ip).digest("hex");

      const country = (req.headers["cf-ipcountry"] || req.headers["x-client-geo-country"] || "Angola") as string;
      const city = (req.headers["x-client-geo-city"] || "Luanda") as string;

      // Perform click tracking asynchronously in nextTick
      process.nextTick(() => {
        logClick(link.id, {
          ip_hash,
          country,
          city,
          device_type,
          browser,
          referrer,
          user_agent: ua
        }).catch(err => {
          console.error("[ASYNC UNIVERSAL REDIRECT TRACKING EXCEPTION]", err);
        });
      });

      return res.redirect(link.target_url);
    } catch (err) {
      console.error("[UNIVERSAL REDIRECT MODULE EXCEPTION]", err);
      return res.redirect("/");
    }
  });

  // API Endpoints
  app.get("/api/short-links/analytics/:producerId", authenticateUser, async (req: any, res) => {
    try {
      const { producerId } = req.params;
      const days = parseInt(req.query.days as string) || 0;

      if (req.user.id !== producerId) {
        return res.status(403).json({ success: false, error: "Não autorizado a visualizar dados deste produtor." });
      }

      const analytics = await getShortLinkAnalytics(producerId, days);
      return res.json({ success: true, analytics });
    } catch (err: any) {
      console.error("[SHORT LINKS API ERROR] Failed to fetch analytics:", err);
      return res.status(500).json({ success: false, error: err.message || "Erro obtendo estatísticas de links." });
    }
  });

  app.post("/api/short-links/create", authenticateUser, async (req: any, res) => {
    try {
      const { type, targetId, targetUrl, baseSlug } = req.body;
      if (!type || !targetId || !targetUrl || !baseSlug) {
        return res.status(400).json({ success: false, error: "Parâmetros obrigatórios ausentes." });
      }

      const link = await createShortLink(type, targetId, targetUrl, req.user.id, baseSlug);
      const siteUrl = getExpandedSiteUrl(req);
      const prefix = type === 'profile' ? 'p' : type === 'beat' ? 'b' : type === 'kit' ? 'k' : 's';
      
      return res.json({ 
        success: true, 
        link: {
          ...link,
          short_url: `${siteUrl}/${prefix}/${link.code}`
        }
      });
    } catch (err: any) {
      console.error("[SHORT LINKS API ERROR] Failed to create short link:", err);
      return res.status(500).json({ success: false, error: err.message || "Erro gerando link encurtado." });
    }
  });

  app.post("/api/short-links/sync", authenticateUser, async (req: any, res) => {
    try {
      const syncResult = await syncSmartLinks();
      return res.json(syncResult);
    } catch (err: any) {
      console.error("[SHORT LINKS API ERROR] Sync failed:", err);
      return res.status(500).json({ success: false, error: err.message || "Falha ao sincronizar links." });
    }
  });


  // --- Promotions System Endpoints ---
  app.get("/api/promotions", async (req, res) => {
    try {
      const producerId = req.query.producer_id as string;
      const promotions = await getPromotionsFromDB(producerId);
      return res.json({ success: true, promotions });
    } catch (err: any) {
      console.error("GET promotions error:", err);
      return res.status(500).json({ success: false, error: "Erro ao obter campanhas promocionais." });
    }
  });

  app.post("/api/promotions", authenticateUser, async (req: any, res) => {
    try {
      const { name, promo_type, buy_qty, get_qty, discount_value, start_date, end_date, targets } = req.body;
      if (!name || !promo_type) {
        return res.status(400).json({ success: false, error: "Nome e tipo de promoção são campos obrigatórios." });
      }
      const inserted = await createPromotionInDB({
        producer_id: req.user.id,
        name,
        code: req.body.code || null,
        promo_type,
        buy_qty: Number(buy_qty) || 0,
        get_qty: Number(get_qty) || 0,
        discount_value: Number(discount_value) || 0,
        start_date: start_date || null,
        end_date: end_date || null,
        status: 'active'
      }, targets || []);
      return res.json({ success: true, promotion: inserted });
    } catch (err: any) {
      console.error("POST promotions error:", err);
      return res.status(500).json({ success: false, error: "Erro ao criar nova campanha promocional." });
    }
  });

  app.patch("/api/promotions/:id/status", authenticateUser, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      if (status !== 'active' && status !== 'inactive') {
        return res.status(400).json({ success: false, error: "Estado inválido." });
      }
      const updated = await updatePromotionStatusInDB(id, status);
      if (updated) {
        return res.json({ success: true });
      }
      return res.status(404).json({ success: false, error: "Campanha promocional não encontrada." });
    } catch (err: any) {
      console.error("PATCH status error:", err);
      return res.status(500).json({ success: false, error: "Falha ao alternar estado da campanha." });
    }
  });

  app.delete("/api/promotions/:id", authenticateUser, async (req: any, res) => {
    try {
      const { id } = req.params;
      const deleted = await deletePromotionFromDB(id);
      if (deleted) {
        return res.json({ success: true });
      }
      return res.status(404).json({ success: false, error: "Campanha promocional não encontrada na base de dados." });
    } catch (err: any) {
      console.error("DELETE promotion error:", err);
      return res.status(500).json({ success: false, error: "Falha ao eliminar campanha promocional." });
    }
  });

  app.get("/api/promotions/analytics/:producerId", authenticateUser, async (req: any, res) => {
    try {
      const { producerId } = req.params;
      if (req.user.id !== producerId) {
        return res.status(403).json({ success: false, error: "Não autorizado a visualizar estas métricas de marketing." });
      }
      const stats = await getPromotionAnalytics(producerId);
      return res.json({ success: true, stats });
    } catch (err: any) {
      console.error("GET analytics error:", err);
      return res.status(500).json({ success: false, error: "Falha ao processar analíticos de campanhas." });
    }
  });

  app.post("/api/promotions/evaluate", async (req, res) => {
    try {
      const { cart } = req.body;
      if (!Array.isArray(cart)) {
        return res.status(400).json({ success: false, error: "Carrinho de compras nulo ou malformado." });
      }
      const allPromotions = await getPromotionsFromDB();
      const activePromos = allPromotions.filter(p => p.status === 'active');
      const result = evaluateCartPromotions(cart, activePromos);
      return res.json({ success: true, result });
    } catch (err: any) {
      console.error("POST evaluate error:", err);
      return res.status(500).json({ success: false, error: "Erro crítico avaliando promoções do carrinho no servidor." });
    }
  });

  app.post("/api/promotions/use", authenticateUser, async (req: any, res) => {
    try {
      const { promotionId, orderId, discountApplied } = req.body;
      if (!promotionId || !orderId) {
        return res.status(400).json({ success: false, error: "Parâmetros 'promotionId' e 'orderId' são obrigatórios." });
      }
      const usage = await savePromotionUsageInDB({
        promotion_id: promotionId,
        order_id: orderId,
        customer_id: req.user.id || null,
        discount_applied: Number(discountApplied) || 0
      });
      return res.json({ success: true, usage });
    } catch (err: any) {
      console.error("POST use error:", err);
      return res.status(500).json({ success: false, error: "Erro ao registar uso de promoção." });
    }
  });

  // --- PayPal Create Order Endpoint ---
  app.post(["/api/paypal/create-order", "/api/pp-gateway/create-order", "/api/billing/setup-session"], async (req, res) => {
    // 2. LOG REQUEST BODY (BEFORE ANY VALIDATION)
    console.log('======================');
    console.log('PAYPAL BODY:', req.body);
    console.log('======================');

    console.log('STEP 1: Checking environment variable state');
    // Verify env configurations safely according to the mode
    const reqMode = (process.env.PAYPAL_MODE || "sandbox").trim().toLowerCase();
    const hasSandboxCreds = !!(process.env.PAYPAL_SANDBOX_CLIENT_ID && process.env.PAYPAL_SANDBOX_SECRET);
    const hasLiveCreds = !!(process.env.PAYPAL_LIVE_CLIENT_ID && process.env.PAYPAL_LIVE_SECRET);
    const hasLegacyCreds = !!(process.env.PAYPAL_CLIENT_ID && (process.env.PAYPAL_CLIENT_SECRET || process.env.PAYPAL_SECRET));

    console.log('PAYPAL_MODE STATE:', reqMode);
    console.log('SANDBOX CONFIG EXISTS:', hasSandboxCreds);
    console.log('LIVE CONFIG EXISTS:', hasLiveCreds);
    console.log('LEGACY FALLBACK CONFIG EXISTS:', hasLegacyCreds);

    const { orderId, amount, currency, beatId, buyerId } = req.body;

    console.log('STEP 2: Validating required fields');
    // 3. VERIFY REQUIRED FIELDS / CHECK EMPTY VALUES
    if (!orderId) {
      console.error("[PAYPAL ERROR] Missing orderId in request body");
      return res.status(400).json({ 
        success: false, 
        error: "O parâmetro 'orderId' é obrigatório no corpo do pedido.",
        debug: "orderId is empty or undefined",
        details: { body: req.body } 
      });
    }

    if (!buyerId) {
      console.warn("[PAYPAL WARNING] Missing buyerId in initial request payload, fallback to database resolution.");
    }
    if (!beatId) {
      console.warn("[PAYPAL WARNING] Missing beatId in initial request payload, fallback to database resolution.");
    }

    const supabase = getSupabase();
    if (!supabase) {
      console.error("[PAYPAL ERROR] Database system connector failed");
      return res.status(503).json({ 
        success: false, 
        error: "Ligação à BD falhou ou o conector do Supabase não foi inicializado.",
        debug: "Supabase connection is uninitialized"
      });
    }

    try {
      console.log('STEP 3: Looking up order in database');
      // 4. VERIFY ORDER EXISTS IN DATABASE / LOG ORDER LOOKUP
      const { data: order, error: orderError } = await supabase
        .from("orders")
        .select("*")
        .eq("id", toValidUuid(orderId))
        .single();

      if (orderError || !order) {
        console.error("[PAYPAL ERROR] Order search yielded zero items for ID:", orderId, orderError);
        return res.status(404).json({ 
          success: false, 
          error: `O pedido de pagamento com o ID '${orderId}' não existe ou foi removido da base de dados.`,
          debug: `Order lookup failed: ${orderError?.message || 'Empty result'}`
        });
      }

      console.log('ORDER FOUND:', order);

      // Validations: prevent duplicate payments
      if (order.status === "paid" || order.status === "completed") {
        console.error("[PAYPAL ERROR] Double charge block on already processed order:", orderId);
        return res.status(400).json({ 
          success: false, 
          error: "Este pedido já foi marcado como pago e processado anteriormente.",
          debug: `Order already marked status as ${order.status}`
        });
      }

      console.log('STEP 4: Verifying amount validity');
      // A robust parser to extract numeric values from strings that might contain Portuguese formatting (e.g., 15.000,00 or 15 000,00)
      function parsePrice(val: any): number {
        if (val === null || val === undefined) return 0;
        if (typeof val === "number") return val;
        
        let str = String(val).trim();
        str = str.replace(/\s/g, ""); // remove spaces
        
        if (str.includes(",") && str.includes(".")) {
          str = str.replace(/\./g, "").replace(/,/g, ".");
        } else if (str.includes(",")) {
          str = str.replace(/,/g, ".");
        }
        
        const parsed = parseFloat(str);
        return isNaN(parsed) ? 0 : parsed;
      }

      // 5. VERIFY AMOUNT FORMAT / VALIDITY
      const orderAmountValue = parsePrice(order.amount || order.total_amount || amount || 0);
      if (orderAmountValue <= 0) {
        console.error("[PAYPAL ERROR] Invalid product or cart price value:", orderAmountValue);
        return res.status(400).json({ 
          success: false, 
          error: "O valor total do pedido não pode ser nulo ou menor/igual a zero.",
          debug: `Parsed order amount: ${orderAmountValue}`
        });
      }

      console.log('STEP 5: Verifying beat availability');
      // Validate related beat is in database
      const finalBeatId = order.beat_id || beatId;
      if (finalBeatId) {
        const normalizedBId = normalizeBeatId(finalBeatId);
        const { data: beat, error: beatCheckErr } = await supabase
          .from("beats")
          .select("id, title")
          .eq("id", normalizedBId)
          .single();

        if (beatCheckErr || !beat) {
          console.error("[PAYPAL ERROR] Missing child product beat relation:", finalBeatId, "normalized:", normalizedBId);
          return res.status(400).json({ 
            success: false, 
            error: "O produto instrumental associado a este pedido já não está disponível para aquisição no catálogo do servidor.",
            debug: `Beat relation lookup with ID ${finalBeatId} (normalized to ${normalizedBId}) failed`,
            details: beatCheckErr
          });
        }
      }

      console.log('STEP 6: Carrying out currency conversions');
      // 6. AOA CONVERSION TO USD (PayPal constraint) / 13. VERIFY CURRENCY SUPPORT
      let exchangeRate = 850;
      const envRate = process.env.PAYPAL_EXCHANGE_RATE;
      if (envRate) {
        const parsedRate = parseFloat(String(envRate).replace(/[^0-9.]/g, ""));
        if (!isNaN(parsedRate) && parsedRate > 0) {
          exchangeRate = parsedRate;
        }
      }

      let valUSDNum = orderAmountValue / exchangeRate;
      if (isNaN(valUSDNum) || valUSDNum < 0.01) {
        valUSDNum = 0.01; // absolute minimum required by PayPal
      }
      const amountInUSD = valUSDNum.toFixed(2);

      console.log('USD VALUE:', amountInUSD);
      console.log(`[PAYPAL CREATE] Converting ${orderAmountValue} Kz to ${amountInUSD} USD (Rate: ${exchangeRate})`);

      console.log('STEP 7: Negotiating access tokens with PayPal');
      // 8 & 12. VALIDATE PAYPAL CREDENTIALS / ENDPOINTS
      let accessToken, baseUrl;
      try {
        const authData = await getPayPalAccessToken();
        accessToken = authData.accessToken;
        baseUrl = authData.baseUrl;
        console.log('TOKEN SUCCESS');
      } catch (authErr: any) {
        console.error('TOKEN ERROR:', authErr);
        console.error("[PAYPAL ERROR] Authentication token handshaking sequence failed:", authErr.message || authErr);
        return res.status(401).json({ 
          success: false, 
          error: "Credenciais do PayPal inválidas ou incompletas no servidor.",
          debug: `Token flow error: ${authErr.message || authErr}`,
          details: { client_configured: !!process.env.PAYPAL_CLIENT_ID }
        });
      }

      // Configure redirects
      const siteUrl = getExpandedSiteUrl(req);

      const cleanLicense = String(order.license_type || "Basica")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "") // remove accents
        .replace(/[^a-zA-Z0-9 ]/g, ""); // keep only alphanumeric and space

      const cleanOrderId = String(order.id).trim().replace(/[^a-zA-Z0-9_.+-]/g, "");
      const cleanDescription = `Licenca de Audio - Batukada - ID ${cleanOrderId.slice(0, 8)} - Licenca ${cleanLicense.toUpperCase()}`;

      const paypalPayload = {
        intent: "CAPTURE",
        purchase_units: [
          {
            reference_id: cleanOrderId,
            amount: {
              currency_code: "USD",
              value: amountInUSD // String formatted value (e.g. "20.00")
            },
            description: cleanDescription.substring(0, 127) // Dynamic caps truncate safely to 127 chars
          }
        ],
        application_context: {
          brand_name: "BATUKADA",
          landing_page: "NO_PREFERENCE",
          user_action: "PAY_NOW",
          shipping_preference: "NO_SHIPPING", // Avoid prompting for checkout address
          return_url: `${siteUrl}/api/billing/return-callback?orderId=${encodeURIComponent(order.id)}`,
          cancel_url: `${siteUrl}/api/billing/cancel-callback?orderId=${encodeURIComponent(order.id)}`
        }
      };

      console.log('STEP 8: Posting payload to PayPal sandbox/live REST API');
      console.log('PAYPAL OUTBOUND PAYLOAD:', JSON.stringify(paypalPayload, null, 2));

      // 3. Request order creation on PayPal REST API
      const pResponse = await fetch(`${baseUrl}/v2/checkout/orders`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(paypalPayload)
      });

      // 10. LOG PAYPAL ERRORS ON API REJECTION
      if (!pResponse.ok) {
        const errorText = await pResponse.text();
        let parsedError;
        try {
          parsedError = JSON.parse(errorText);
        } catch (_) {}
        
        console.error('PAYPAL ERROR:', parsedError || errorText);
        return res.status(502).json({ 
          success: false, 
          error: "Ocorreu um erro ao comunicar com os servidores do PayPal.",
          debug: `Outbound PayPal POST threw ${pResponse.status}`,
          details: parsedError || errorText
        });
      }

      console.log('STEP 9: Processing PayPal server response');
      // 9. LOG PAYPAL RESPONSE
      const paypalOrder = await pResponse.json();
      console.log('PAYPAL CREATE RESPONSE:', paypalOrder);

      const approvalUrl = paypalOrder.links?.find((l: any) => l.rel === "approve")?.href;

      if (!approvalUrl) {
        console.error("[PAYPAL ERROR] The links object didn't yield an approval link redirector:", paypalOrder);
        return res.status(502).json({ 
          success: false, 
          error: "Não conseguimos gerar as hiperligações de aprovação/redirecionamento da conta PayPal.",
          debug: "Approval URL was not present in PayPal's HATEOAS links response.",
          details: paypalOrder
        });
      }

      console.log(`[PAYPAL CREATE] Checkout session instantiated successfully: ${paypalOrder.id}. Redirection target is: ${approvalUrl}`);
      res.json({
        success: true,
        paypalOrderId: paypalOrder.id,
        approvalUrl
      });
    } catch (err: any) {
      console.error('FULL PAYPAL ERROR:', err);
      if (err?.response?.data) {
        console.error('PAYPAL RESPONSE DATA:', err.response.data);
      }
      if (err?.response?.status) {
        console.error('PAYPAL RESPONSE STATUS:', err.response.status);
      }
      console.error("[PAYPAL CREATE EXCEPTION]", err.message || err);
      res.status(500).json({ 
        success: false, 
        error: "Falha de processamento no checkout do servidor de facturação: " + (err.message || err),
        debug: err.message || err,
        details: err?.response?.data || null
      });
    }
  });

  // --- Sandbox-Safe PayPal Order Check Endpoint ---
  app.get("/api/paypal/check-order/:paypalOrderId", async (req, res) => {
    const { paypalOrderId } = req.params;
    const queryOrderId = req.query.orderId as string;

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ success: false, error: "BD não conectada." });
    }

    try {
      const { accessToken, baseUrl } = await getPayPalAccessToken();

      // View order details on PayPal
      const checkResponse = await fetch(`${baseUrl}/v2/checkout/orders/${paypalOrderId}`, {
        headers: {
          "Authorization": `Bearer ${accessToken}`
        }
      });

      if (!checkResponse.ok) {
        const checkErr = await checkResponse.text();
        console.error(`[PAYPAL CHECK ERROR] Failed fetching details for ${paypalOrderId}:`, checkErr);
        return res.status(404).json({ success: false, error: "Não foi possível verificar a transação no PayPal." });
      }

      const orderDetails = await checkResponse.json();
      console.log(`[PAYPAL CHECK-ORDER] Current PayPal status for ${paypalOrderId}: ${orderDetails.status}`);

      const dbOrderId = orderDetails.purchase_units?.[0]?.reference_id || queryOrderId;
      if (!dbOrderId) {
        console.warn("[PAYPAL CHECK-ORDER] No matching local DB order reference found in reference_id or query.");
      }

      let currentStatus = orderDetails.status; // e.g. "APPROVED", "COMPLETED", "CREATED", "SAVED"

      if (currentStatus === "APPROVED") {
        console.log(`[PAYPAL CHECK-ORDER] Order ${paypalOrderId} is APPROVED. Triggering capture automation...`);
        // Capture the approved order automatically
        const captureResponse = await fetch(`${baseUrl}/v2/checkout/orders/${paypalOrderId}/capture`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${accessToken}`,
            "Content-Type": "application/json"
          }
        });

        if (captureResponse.ok) {
          const captureDetails = await captureResponse.json();
          const captureItem = captureDetails.purchase_units?.[0]?.payments?.captures?.[0];
          const captureStatus = captureItem?.status;
          console.log(`[PAYPAL CHECK-ORDER] Capture status is: ${captureStatus}`);

          if (captureStatus === "COMPLETED" && dbOrderId) {
            currentStatus = "COMPLETED";
            // Check order presence and current status in database
            const uuidId = toValidUuid(dbOrderId);
            const { data: currentDbOrder } = await supabase
              .from("orders")
              .select("status")
              .eq("id", uuidId)
              .single();

            if (currentDbOrder && currentDbOrder.status !== "paid" && currentDbOrder.status !== "completed") {
              const usdAmount = Number(captureItem?.amount?.value || 0);

              // Local Order Reconciliation Validation
              const { data: localOrder } = await supabase
                .from("orders")
                .select("amount")
                .eq("id", toValidUuid(dbOrderId))
                .maybeSingle();

              const expectedAmount = Number(localOrder?.amount || 0);
              const tolerance = 0.05;
              if (usdAmount < (expectedAmount - tolerance)) {
                console.error(`[PAYPAL POLLING RECONCILIATION FAILURE] Captured: ${usdAmount}, Expected: ${expectedAmount}`);
                return res.status(400).json({ success: false, error: "Reconciliação de valor falhou: o montante capturado é inferior ao esperado." });
              }

              const activatedOrder = await activatePaidOrder(dbOrderId, supabase);
              const payerEmail = captureDetails.payer?.email_address || "cliente@paypal.com";

              await savePayPalTransaction(supabase, {
                order_id: dbOrderId,
                capture_id: captureItem?.id || "polling_capture",
                payer_email: payerEmail,
                amount: usdAmount,
                currency: "USD",
                status: "approved",
                buyer_id: activatedOrder.customer_id || activatedOrder.buyer_id,
                beat_id: activatedOrder.beat_id || "cart"
              });
            }
          }
        } else {
          const capErrText = await captureResponse.text();
          console.error(`[PAYPAL CHECK-ORDER] Auto-capture failed for APPROVED order ${paypalOrderId}:`, capErrText);
        }
      } else if (currentStatus === "COMPLETED" && dbOrderId) {
        // If it's already completed on PayPal but DB status lagged behind, activate it!
        const uuidId = toValidUuid(dbOrderId);
        const { data: currentDbOrder } = await supabase
          .from("orders")
          .select("status")
          .eq("id", uuidId)
          .single();

        if (currentDbOrder && currentDbOrder.status !== "paid" && currentDbOrder.status !== "completed") {
          console.log(`[PAYPAL CHECK-ORDER] Completing db order validation for COMPLETED PayPal order ${paypalOrderId}`);
          const usbValue = Number(orderDetails.purchase_units?.[0]?.amount?.value || 0);

          // Local Order Reconciliation Validation
          const { data: localOrder } = await supabase
            .from("orders")
            .select("amount")
            .eq("id", toValidUuid(dbOrderId))
            .maybeSingle();

          const expectedAmount = Number(localOrder?.amount || 0);
          const tolerance = 0.05;
          if (usbValue < (expectedAmount - tolerance)) {
            console.error(`[PAYPAL CHECK POLLING RECONCILIATION FAILURE] Value: ${usbValue}, Expected: ${expectedAmount}`);
            return res.status(400).json({ success: false, error: "Reconciliação de valor falhou: o montante é inferior ao esperado." });
          }

          const activatedOrder = await activatePaidOrder(dbOrderId, supabase);
          const payerEmail = orderDetails.payer?.email_address || "cliente@paypal.com";

          await savePayPalTransaction(supabase, {
            order_id: dbOrderId,
            capture_id: orderDetails.purchase_units?.[0]?.payments?.captures?.[0]?.id || "polling_complete",
            payer_email: payerEmail,
            amount: usbValue,
            currency: "USD",
            status: "approved",
            buyer_id: activatedOrder.customer_id || activatedOrder.buyer_id,
            beat_id: activatedOrder.beat_id || "cart"
          });
        }
      }

      res.json({
        success: true,
        status: currentStatus,
        orderId: dbOrderId
      });

    } catch (e: any) {
      console.error("[PAYPAL CHECK ERROR EXCEPTION]", e);
      res.status(500).json({ success: false, error: e.message || "Falha verificando checkout." });
    }
  });

  // --- PayPal Capture Order Endpoint (Standalone REST POST) ---
  app.post(["/api/paypal/capture-order", "/api/pp-gateway/capture-order", "/api/billing/capture-session"], async (req, res) => {
    const { paypalOrderId, orderId } = req.body;
    if (!paypalOrderId || !orderId) {
      return res.status(400).json({ error: "paypalOrderId e orderId são obrigatórios." });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "BD não conectada." });
    }

    try {
      const { accessToken, baseUrl } = await getPayPalAccessToken();

      // Trigger PayPal Capturing
      const response = await fetch(`${baseUrl}/v2/checkout/orders/${paypalOrderId}/capture`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("[PAYPAL CAPTURE ERROR] POST API Failed:", errorText);
        return res.status(502).json({ error: "O pagamento do PayPal não pôde ser capturado na API." });
      }

      const captureDetails = await response.json();
      const captureStatus = captureDetails.purchase_units?.[0]?.payments?.captures?.[0]?.status;

      if (captureStatus !== "COMPLETED") {
        return res.status(400).json({ 
          error: `O estado de captura do PayPal é ${captureStatus}. Pagamento pendente.`,
          details: captureDetails
        });
      }

      const captureItem = captureDetails.purchase_units[0].payments.captures[0];
      const payerEmail = captureDetails.payer?.email_address || "cliente@paypal.com";
      const usdAmount = Number(captureItem.amount.value);

      // Local Order Reconciliation Validation
      const { data: localOrder, error: fetchOrderError } = await supabase
        .from("orders")
        .select("amount")
        .eq("id", toValidUuid(orderId))
        .maybeSingle();

      if (fetchOrderError || !localOrder) {
        console.error("[PAYPAL CAPTURE ERROR] Local order fetch error:", fetchOrderError);
        return res.status(404).json({ error: "Ordem local não encontrada para reconciliação." });
      }

      const expectedAmount = Number(localOrder.amount || 0);
      const tolerance = 0.05;
      if (usdAmount < (expectedAmount - tolerance)) {
        console.error(`[PAYPAL RECONCILIATION FAILURE] Captured: ${usdAmount}, Expected: ${expectedAmount}`);
        return res.status(400).json({ error: "Reconciliação de valor falhou: o montante capturado é inferior ao esperado." });
      }

      // Automated State Transition
      const activatedOrder = await activatePaidOrder(orderId, supabase);

      // Save record payload
      await savePayPalTransaction(supabase, {
        order_id: orderId,
        capture_id: captureItem.id,
        payer_email: payerEmail,
        amount: usdAmount,
        currency: "USD",
        status: "approved",
        buyer_id: activatedOrder.customer_id || activatedOrder.buyer_id,
        beat_id: activatedOrder.beat_id || "cart"
      });

      res.json({ success: true, status: "paid", orderId });
    } catch (err: any) {
      console.error("[PAYPAL CAPTURE EXCEPTION]", err.message);
      res.status(500).json({ error: "Erro interno ao capturar transação: " + err.message });
    }
  });

  // --- PayPal Redirect Return Success Callback ---
  app.get(["/api/paypal/return-callback", "/api/pp-gateway/return-callback", "/api/billing/return-callback"], async (req, res) => {
    const { token, orderId } = req.query; // token is the PayPal Order ID
    if (!token || !orderId) {
      console.error("[PAYPAL REDIRECT ERROR] Missing args:", { token, orderId });
      return res.redirect("/?paypal_error=true");
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.redirect(`/?paypal_error=true&orderId=${orderId}`);
    }

    try {
      console.log(`[PAYPAL RETURN] Executing capture for PayPal Order ${token}, linking orderId: ${orderId}`);
      
      const { accessToken, baseUrl } = await getPayPalAccessToken();

      // Execute actual POST Capture
      const response = await fetch(`${baseUrl}/v2/checkout/orders/${token}/capture`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json"
        }
      });

      if (!response.ok) {
        const errBody = await response.text();
        console.error("[PAYPAL RETURN CAPTURE FAIL] API Error:", errBody);
        
        // Check if already captured earlier by webhook/polling
        const verifyResp = await fetch(`${baseUrl}/v2/checkout/orders/${token}`, {
          headers: { "Authorization": `Bearer ${accessToken}` }
        });
        
        if (verifyResp.ok) {
          const checkOrder = await verifyResp.json();
          const pStatus = checkOrder.status;
          console.log(`[PAYPAL RETURN VERIFY] Paypal order status: ${pStatus}`);
          
          if (pStatus === "COMPLETED" || pStatus === "APPROVED") {
            console.log("[PAYPAL RETURN VERIFY] Already processed successfully earlier. Proceeding to landing page.");
            await activatePaidOrder(String(orderId), supabase);
            return res.redirect(`/?paypal_success=true&orderId=${orderId}`);
          }
        }
        
        return res.redirect(`/?paypal_error=true&orderId=${orderId}`);
      }

      const details = await response.json();
      const captures = details.purchase_units?.[0]?.payments?.captures;
      const captureItem = captures && captures.length > 0 ? captures[0] : null;

      if (!captureItem || (captureItem.status !== "COMPLETED" && captureItem.status !== "PENDING")) {
        console.error("[PAYPAL RETURN] Captured but status incorrect:", details);
        return res.redirect(`/?paypal_error=true&orderId=${orderId}`);
      }

      const payerEmail = details.payer?.email_address || "paypal@batukada.ao";
      const usdPaid = Number(captureItem.amount?.value || 0);

      // 1. Process Order automation triggers
      const activated = await activatePaidOrder(String(orderId), supabase);

      // 2. Save PayPal transaction log
      await savePayPalTransaction(supabase, {
        order_id: String(orderId),
        capture_id: captureItem.id,
        payer_email: payerEmail,
        amount: usdPaid,
        currency: captureItem.amount?.currency_code || "USD",
        status: "approved",
        buyer_id: activated.customer_id || activated.buyer_id,
        beat_id: activated.beat_id || "cart"
      });

      console.log(`[PAYPAL CALLBACK SUCCESS] Fully activated order ${orderId}! Redirecting user...`);
      res.redirect(`/?paypal_success=true&orderId=${orderId}`);
    } catch (err: any) {
      console.error("[PAYPAL RETURN CALLBACK EXCEPTION]", err.message);
      res.redirect(`/?paypal_error=true&orderId=${orderId}`);
    }
  });

  // --- PayPal Redirect Cancel Link ---
  app.get(["/api/paypal/cancel-callback", "/api/pp-gateway/cancel-callback", "/api/billing/cancel-callback"], (req, res) => {
    const { orderId } = req.query;
    console.log(`[PAYPAL CANCEL] User cancelled payment for order ${orderId}`);
    res.redirect(`/?paypal_cancel=true&orderId=${orderId || ""}`);
  });

  // --- Webhook Idempotency & Signature Helpers ---
  function isWebhookEventProcessed(eventId: string): boolean {
    try {
      const ledgerPath = path.join(process.cwd(), "paypal_webhooks_processed.json");
      if (!fs.existsSync(ledgerPath)) return false;
      const processedEvents = JSON.parse(fs.readFileSync(ledgerPath, "utf-8"));
      return Array.isArray(processedEvents) && processedEvents.includes(eventId);
    } catch (e) {
      return false;
    }
  }

  function markWebhookEventProcessed(eventId: string) {
    try {
      const ledgerPath = path.join(process.cwd(), "paypal_webhooks_processed.json");
      let processedEvents: string[] = [];
      if (fs.existsSync(ledgerPath)) {
        try {
          processedEvents = JSON.parse(fs.readFileSync(ledgerPath, "utf-8"));
        } catch (e) {
          processedEvents = [];
        }
      }
      if (!processedEvents.includes(eventId)) {
        processedEvents.push(eventId);
        if (processedEvents.length > 2000) {
          processedEvents.shift();
        }
        fs.writeFileSync(ledgerPath, JSON.stringify(processedEvents, null, 2), "utf-8");
      }
    } catch (e: any) {
      console.error("[PAYPAL IDEMPOTENCY LEDGER WORK] Failed writing webhook bookkeeping:", e.message);
    }
  }

  async function verifyPayPalWebhookSignature(req: express.Request, body: any, mode: string, accessToken: string, baseUrl: string): Promise<boolean> {
    const authAlgo = req.headers["paypal-auth-algo"] as string || req.headers["PAYPAL-AUTH-ALGO"] as string;
    const certUrl = req.headers["paypal-cert-url"] as string || req.headers["PAYPAL-CERT-URL"] as string;
    const transmissionId = req.headers["paypal-transmission-id"] as string || req.headers["PAYPAL-TRANSMISSION-ID"] as string;
    const transmissionSig = req.headers["paypal-transmission-sig"] as string || req.headers["PAYPAL-TRANSMISSION-SIG"] as string;
    const transmissionTime = req.headers["paypal-transmission-time"] as string || req.headers["PAYPAL-TRANSMISSION-TIME"] as string;

    const webhookId = mode === "live"
      ? (process.env.PAYPAL_LIVE_WEBHOOK_ID || process.env.PAYPAL_WEBHOOK_ID || "").trim()
      : (process.env.PAYPAL_SANDBOX_WEBHOOK_ID || process.env.PAYPAL_WEBHOOK_ID || "").trim();

    if (!webhookId) {
      console.warn("[PAYPAL WEBHOOK SIGNATURE] Webhook ID not configured (PAYPAL_SANDBOX_WEBHOOK_ID / PAYPAL_LIVE_WEBHOOK_ID). Verification omitted on Sandbox/Dev.");
      return true; // allow Dev testing when ID not set, but log it explicitly
    }

    if (!authAlgo || !certUrl || !transmissionId || !transmissionSig || !transmissionTime) {
      console.error("[PAYPAL WEBHOOK SIGNATURE FAIL] Missing verifying signature headers. Spoof protection active, rejecting.");
      return false;
    }

    try {
      const verifyBody = {
        auth_algo: authAlgo,
        cert_url: certUrl,
        transmission_id: transmissionId,
        transmission_sig: transmissionSig,
        transmission_time: transmissionTime,
        webhook_id: webhookId,
        webhook_event: body
      };

      const verifyResponse = await fetch(`${baseUrl}/v1/notifications/verify-webhook-signature`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(verifyBody)
      });

      if (!verifyResponse.ok) {
        const errText = await verifyResponse.text();
        console.error("[PAYPAL WEBHOOK KEY EXCH] Error response status from PayPal webhook verification:", verifyResponse.status, errText);
        return false;
      }

      const verifyResult = await verifyResponse.json();
      console.log("[PAYPAL WEBHOOK EVAL RESULT] Obtained verification status:", verifyResult.verification_status);
      return verifyResult.verification_status === "SUCCESS";
    } catch (e: any) {
      console.error("[PAYPAL WEBHOOK VERIFICATION CORE ERROR]", e.message);
      return false;
    }
  }

  // --- PayPal Webhook Handler ---
  app.post(["/api/paypal/webhook", "/api/pp-gateway/webhook", "/api/billing/webhook"], async (req, res) => {
    const body = req.body;
    
    if (!body || !body.event_type) {
      return res.status(400).send("No event body.");
    }

    const eventId = body.id || "EV-placeholder";
    console.log(`[PAYPAL WEBHOOK] Event received: ${body.event_type} [Event ID: ${eventId}]`);

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).send("Database not configured.");
    }

    // Supported Webhook triggers
    const allowedEvents = [
      "PAYMENT.CAPTURE.COMPLETED", 
      "PAYMENT.CAPTURE.DENIED", 
      "PAYMENT.CAPTURE.REFUNDED", 
      "PAYMENT.CAPTURE.REVERSED",
      "CUSTOMER.DISPUTE.CREATED",
      "CUSTOMER.DISPUTE.RESOLVED",
      "CHECKOUT.ORDER.APPROVED"
    ];
    if (!allowedEvents.includes(body.event_type)) {
      console.log(`[PAYPAL WEBHOOK] Unhandled event type details: ${body.event_type}. Responding with 200.`);
      return res.status(200).send("Ignored event");
    }

    // Idempotency check: process each event exactly once
    if (isWebhookEventProcessed(eventId)) {
      console.log(`[PAYPAL Webhook Idempotency] Event ${eventId} was already processed earlier. Preventing duplication.`);
      return res.status(200).send("Event already processed");
    }

    // Verify official signature
    let accessToken: string;
    let baseUrl: string;
    let mode = "sandbox";
    try {
      const authData = await getPayPalAccessToken();
      accessToken = authData.accessToken;
      baseUrl = authData.baseUrl;
      mode = (process.env.PAYPAL_MODE || "sandbox").trim().toLowerCase();
    } catch (err: any) {
      console.error("[PAYPAL Webhook Auth] Credentials handshake failed:", err.message);
      return res.status(500).send("Server configured incorrectly for auth.");
    }

    const isVerified = await verifyPayPalWebhookSignature(req, body, mode, accessToken, baseUrl);
    if (!isVerified) {
      console.error(`[PAYPAL WEBHOOK SPOOF REJECTION] Signature verification failed for event ${eventId}. Webhook authenticity rejected.`);
      return res.status(401).send("Webhook signature verification failed.");
    }

    // Bookkeep the event as accepted and processed
    markWebhookEventProcessed(eventId);

    // Defer heavy business processing to run asynchronously
    // This complies with instructions: 'responder rápido, processar async quando necessário, evitar bloquear servidor'
    res.status(200).send("Webhook Accepted and Scheduled");

    // Start background processing
    (async () => {
      try {
        console.log(`[PAYPAL WEBHOOK ASYNC ENGINE] Started processing ${body.event_type} for event ${eventId}`);
        
        let dbOrderId = body.resource?.purchase_units?.[0]?.reference_id || body.resource?.reference_id;
        const paypalOrderId = body.resource?.supplementary_data?.related_ids?.order_id 
          || (body.event_type === "CHECKOUT.ORDER.APPROVED" ? body.resource?.id : null);

        if (!dbOrderId && paypalOrderId) {
          try {
            const detailResponse = await fetch(`${baseUrl}/v2/checkout/orders/${paypalOrderId}`, {
              headers: { "Authorization": `Bearer ${accessToken}` }
            });
            if (detailResponse.ok) {
              const detail = await detailResponse.json();
              dbOrderId = detail.purchase_units?.[0]?.reference_id;
              console.log(`[PAYPAL Webhook Resolve] Dynamic lookup successfully solved DB Order ID ${dbOrderId} for PayPal Order ${paypalOrderId}`);
            }
          } catch (e: any) {
            console.error("[PAYPAL Webhook Resolve Error] Dynamic look up failed:", e.message);
          }
        }

        // Failsafe lookup for disputes/reversals where order ID is not directly in root resource
        if (!dbOrderId) {
          // Check if dispute or reversal reference exists
          const txnId = body.resource?.id // for capture reversals
            || body.resource?.disputed_transactions?.[0]?.seller_transaction_id // for disputes
            || body.resource?.disputed_transactions?.[0]?.buyer_transaction_id;
            
          if (txnId) {
            console.log(`[PAYPAL RESOLVE ID] Webhook lacks reference_id, searching paypal_transactions table for key: ${txnId}`);
            try {
              const { data: matchedTx } = await supabase
                .from("paypal_transactions")
                .select("order_id")
                .eq("capture_id", txnId)
                .maybeSingle();
              if (matchedTx?.order_id) {
                dbOrderId = matchedTx.order_id;
                console.log(`[PAYPAL RESOLVE ID SUCCESS] Found referenced DB Order ID ${dbOrderId} for transaction ${txnId}`);
              }
            } catch (e: any) {
              console.warn("[PAYPAL Webhook Resolve ID Error]", e.message);
            }
          }
        }

        if (!dbOrderId) {
          console.warn("[PAYPAL Webhook Warning] Could not resolve database Order ID UUID. Omitted handling background updates.");
          return;
        }

        console.log(`[PAYPAL WEBHOOK WORKER] Matched local order: ${dbOrderId}`);

        // Handle each specific business event
        if (body.event_type === "PAYMENT.CAPTURE.COMPLETED") {
          const captureId = body.resource?.id || "webhook_capture";
          const payerEmail = body.resource?.payer?.email_address || "webhook@paypal.com";
          const amountUSD = Number(body.resource?.amount?.value || body.resource?.purchase_units?.[0]?.amount?.value || 0);

          console.log(`[PAYPAL WEBHOOK COMPLETED] Processing payout authorization for order ${dbOrderId}, sum: ${amountUSD} USD`);
          
          const orderRecord = await activatePaidOrder(dbOrderId, supabase);

          await savePayPalTransaction(supabase, {
            order_id: dbOrderId,
            capture_id: captureId,
            payer_email: payerEmail,
            amount: amountUSD,
            currency: body.resource?.amount?.currency_code || "USD",
            status: "approved",
            buyer_id: orderRecord.customer_id || orderRecord.buyer_id,
            beat_id: orderRecord.beat_id || "cart"
          });
          
          console.log(`[PAYPAL WEBHOOK COMPLETED SUCCESS] Completed order activation & ledger entry for order ${dbOrderId}`);

        } else if (body.event_type === "CHECKOUT.ORDER.APPROVED") {
          console.log(`[PAYPAL WEBHOOK APPROVED] Order ${dbOrderId} dynamically approved by client checkout. Executing auto-capture cascade...`);
          
          // Request capture of approved order to securely lock funds on server
          const captureResponse = await fetch(`${baseUrl}/v2/checkout/orders/${paypalOrderId}/capture`, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${accessToken}`,
              "Content-Type": "application/json"
            }
          });

          if (captureResponse.ok) {
            const captureDetails = await captureResponse.json();
            const captureItem = captureDetails.purchase_units?.[0]?.payments?.captures?.[0];
            const captureId = captureItem?.id || "webhook_auto_capture";
            const payerEmail = captureDetails.payer?.email_address || "approved-hook@paypal.com";
            const amountUSD = Number(captureItem?.amount?.value || 0);

            console.log(`[PAYPAL WEBHOOK AUTO-CAPTURE SUCCESS] Successfully captured approved order ${dbOrderId}. Activating features...`);
            const orderRecord = await activatePaidOrder(dbOrderId, supabase);

            await savePayPalTransaction(supabase, {
              order_id: dbOrderId,
              capture_id: captureId,
              payer_email: payerEmail,
              amount: amountUSD,
              currency: captureItem?.amount?.currency_code || "USD",
              status: "approved",
              buyer_id: orderRecord.customer_id || orderRecord.buyer_id,
              beat_id: orderRecord.beat_id || "cart"
            });
          } else {
            const errBody = await captureResponse.text();
            console.log(`[PAYPAL WEBHOOK APPROVED CALLBACK] Capture was already processed or handled elsewhere:`, errBody);
          }

        } else if (body.event_type === "PAYMENT.CAPTURE.DENIED") {
          console.warn(`[PAYPAL WEBHOOK DENIED] Order ${dbOrderId} was DENIED by PayPal.`);
          await supabase
            .from("orders")
            .update({ status: "failed" })
            .eq("id", toValidUuid(dbOrderId));

        } else if (body.event_type === "PAYMENT.CAPTURE.REFUNDED") {
          console.log(`[PAYPAL WEBHOOK REFUND] Order ${dbOrderId} has been REFUNDED on PayPal. Invoking royalty reversals.`);
          await supabase
            .from("orders")
            .update({ status: "refunded" })
            .eq("id", toValidUuid(dbOrderId));

          await reverseOrderRoyalties(dbOrderId, supabase);

        } else if (body.event_type === "PAYMENT.CAPTURE.REVERSED") {
          console.log(`[PAYPAL WEBHOOK REVERSED] Order ${dbOrderId} has been REVERSED on PayPal. Invoking royalty reversals.`);
          await supabase
            .from("orders")
            .update({ status: "reversed" })
            .eq("id", toValidUuid(dbOrderId));

          await reverseOrderRoyalties(dbOrderId, supabase);

        } else if (body.event_type === "CUSTOMER.DISPUTE.CREATED") {
          console.log(`[PAYPAL WEBHOOK DISPUTE] Dispute opened for Order ${dbOrderId}. Setting order status to disputed to lock access.`);
          await supabase
            .from("orders")
            .update({ status: "disputed" })
            .eq("id", toValidUuid(dbOrderId));

        } else if (body.event_type === "CUSTOMER.DISPUTE.RESOLVED") {
          const outcome = body.resource?.dispute_outcome?.outcome_code;
          console.log(`[PAYPAL WEBHOOK DISPUTE RESOLVED] Dispute resolved for Order ${dbOrderId}. Outcome code: ${outcome}`);
          
          // If won by buyer, reverse previously distributed royalties
          const buyerWon = outcome === "RESOLVED_BUYER_FAVOUR" || outcome === "RESOLVED_BUYER_FAVOR" || body.resource?.dispute_life_cycle_stage === "CHARGEBACK";
          if (buyerWon) {
            await supabase
              .from("orders")
              .update({ status: "reversed" })
              .eq("id", toValidUuid(dbOrderId));

            await reverseOrderRoyalties(dbOrderId, supabase);
          } else {
            console.log(`[PAYPAL WEBHOOK DISPUTE RESOLVED] Dispute resolved in favor of merchant/seller. Restoring completed status.`);
            await supabase
              .from("orders")
              .update({ status: "completed" })
              .eq("id", toValidUuid(dbOrderId));
          }
        }

      } catch (e: any) {
        console.error(`[PAYPAL WEBHOOK ASYNC EXCEPTION] Critical error parsing event ${eventId}:`, e.message);
      }
    })();
  });

  // Auth Proxy
  app.post("/api/auth/login", apiRateLimiter(10, 60 * 1000), async (req, res) => {
    const { email, password } = req.body;
    console.log(`Auth Proxy: Login attempt for ${email}`);
    const supabase = getSupabase();
    if (!supabase) {
      console.error("Auth Proxy: Supabase not configured");
      return res.status(503).json({ error: "Supabase not configured" });
    }

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      console.error(`Auth Proxy: Login failed for ${email}:`, error.message);
      return res.status(error.status || 500).json(error);
    }
    console.log(`Auth Proxy: Login successful for ${email}`);
    res.json(data);
  });

  // Initialize/migrate producer data so active producers can view real test data immediately
  app.post("/api/producer/init", async (req, res) => {
    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: "userId is required" });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "Supabase not configured" });
    }

    try {
      console.log(`[PRODUCER INIT] Checking data alignment for user: ${userId}`);

      // Check if user already owns any beats
      const { data: userBeats, error: checkError } = await supabase
        .from("beats")
        .select("id")
        .eq("producer_id", userId)
        .limit(1);

      if (checkError) {
        console.error("[PRODUCER INIT] checkError:", checkError);
      }

      const defaultProducerId = "6e4c1b73-32b3-4252-85bc-d74f0a6f6adb";

      if ((!userBeats || userBeats.length === 0) && userId !== defaultProducerId) {
        console.log(`[PRODUCER INIT] User ${userId} has 0 beats. Reassiging/migrating default seed beats to them...`);

        // Update beats from the old default user to the new user
        const { data: updatedBeats, error: updateBeatsErr } = await supabase
          .from("beats")
          .update({ producer_id: userId })
          .eq("producer_id", defaultProducerId)
          .select();

        if (updateBeatsErr) {
          console.error("[PRODUCER INIT] Error updating beats:", updateBeatsErr);
        } else {
          console.log(`[PRODUCER INIT] Successfully reassigned beats to ${userId}:`, updatedBeats);
        }

        // Update order_items to belong to the new user
        const { error: updateItemsErr } = await supabase
          .from("order_items")
          .update({ producer_id: userId })
          .eq("producer_id", defaultProducerId);

        if (updateItemsErr) {
          console.error("[PRODUCER INIT] Error updating order_items:", updateItemsErr);
        }

        // Create banking info if it doesn't exist
        const { data: bankingInfo } = await supabase
          .from("producer_banking_info")
          .select("*")
          .eq("producer_id", userId)
          .maybeSingle();

        if (!bankingInfo) {
          await supabase.from("producer_banking_info").insert({
            producer_id: userId,
            bank_name: "Banco de Poupança e Crédito (BPC)",
            account_number: "AO06000100001234567890123",
            full_name: "Produtor Autorizado",
            country: "Angola",
            status: "verified"
          });
        }

        // Also update the profile of this user to roles = 'seller'
        await supabase
          .from("profiles")
          .update({ 
            role: "seller",
            is_verified: true,
            verification_status: "verified"
          })
          .eq("id", userId);
          
        console.log(`[PRODUCER INIT] Completed background alignment for user: ${userId}`);
      }

      res.json({ success: true });
    } catch (e: any) {
      console.error("[PRODUCER INIT] Exception:", e);
      res.status(500).json({ error: e.message });
    }
  });

  // Admin withdrawal request actions endpoint (bypasses RLS utilizing Service Role Key)
  app.post("/api/admin/withdrawal/action", requireAdmin, async (req, res) => {
    const { withdrawalId, action } = req.body;
    if (!withdrawalId || !action || (action !== "approve" && action !== "reject")) {
      return res.status(400).json({ error: "withdrawalId and action ('approve' | 'reject') are required." });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "Supabase not configured" });
    }

    try {
      console.log(`[API ADMIN WITHDRAWAL] Processing ${action} on ID: ${withdrawalId}`);

      // Call the database function to process the withdrawal request atomically
      const { data: rpcResult, error: rpcErr } = await supabase.rpc("process_withdrawal_request", {
        p_withdrawal_id: withdrawalId,
        p_action: action
      });

      if (rpcErr) {
        console.error("[API ADMIN WITHDRAWAL] RPC execution error:", rpcErr);
        return res.status(500).json({ error: "Erro na base de dados ao processar o saque: " + rpcErr.message });
      }

      // Check return format of custom process_withdrawal_request function
      const resultObj = typeof rpcResult === "string" ? JSON.parse(rpcResult) : rpcResult;

      if (!resultObj || !resultObj.success) {
        const errorMsg = resultObj?.error || "Erro desconhecido ao processar saque.";
        console.error("[API ADMIN WITHDRAWAL] Processing failed:", errorMsg);
        return res.status(400).json({ error: errorMsg });
      }

      // 4. Send notification with the correct DB columns (read: false instead of is_read: false)
      try {
        const withdrawAmount = Number(resultObj.amount || 0);
        const producerId = resultObj.producer_id;
        const notificationTitle = action === "approve" ? "Saque aprovado" : "Saque rejeitado";
        const notificationMessage = action === "approve"
          ? `O seu levantamento de ${withdrawAmount.toLocaleString('pt-AO')} Kz foi aprovado com sucesso.`
          : `O seu levantamento de ${withdrawAmount.toLocaleString('pt-AO')} Kz foi rejeitado pela administração.`;

        await supabase
          .from("notifications")
          .insert({
            user_id: producerId,
            title: notificationTitle,
            message: notificationMessage,
            type: action === "approve" ? "withdrawal_approved" : "withdrawal_rejected",
            read: false,
            created_at: new Date().toISOString()
          });
        console.log("[API ADMIN WITHDRAWAL] Notification inserted successfully.");
      } catch (notifErr: any) {
        console.error("[API ADMIN WITHDRAWAL] Notification inserting exception:", notifErr);
      }

      return res.json({ success: true, data: { id: withdrawalId, status: resultObj.status } });
    } catch (err: any) {
      console.error("[API ADMIN WITHDRAWAL] Critical exception:", err);
      return res.status(500).json({ error: "Erro crítico no servidor: " + err.message });
    }
  });

  // Admin profile update endpoint (bypasses RLS utilizing Service Role Key)
  app.post("/api/admin/profiles/update", requireAdmin, async (req, res) => {
    const { profileId, updates } = req.body;
    if (!profileId || !updates || typeof updates !== "object") {
      return res.status(400).json({ error: "profileId and updates are required." });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "Supabase not configured" });
    }

    try {
      console.log(`[API ADMIN PROFILE UPDATE] Direct SQL updates for profile ${profileId}:`, updates);

      // Define an explicit whitelist of allowed keys for user profile updates from the admin dashboard
      const allowedKeys = [
        "display_name",
        "username",
        "role",
        "is_verified",
        "verification_status",
        "bio",
        "avatar_url",
        "website",
        "commission_rate",
        "paypal_email",
        "banking_info",
        "payout_method",
        "phone",
        "country"
      ];

      const blockedWalletFields = ["wallet_balance", "wallet_available_balance", "wallet_pending_balance", "wallet_total_earned"];
      let hasBlockedField = false;

      const filteredUpdates: Record<string, any> = {};
      for (const [key, val] of Object.entries(updates)) {
        if (blockedWalletFields.includes(key)) {
          hasBlockedField = true;
          continue;
        }
        if (allowedKeys.includes(key)) {
          filteredUpdates[key] = val;
        }
      }

      if (hasBlockedField) {
        console.warn('[SECURITY] BLOCKED WALLET FIELD UPDATE');
      }

      if (Object.keys(filteredUpdates).length === 0) {
        return res.status(400).json({ error: "Todos os campos fornecidos são inválidos ou proibidos de serem atualizados." });
      }

      const { data, error } = await supabase
        .from("profiles")
        .update(filteredUpdates)
        .eq("id", profileId)
        .select();

      if (error) {
        console.error("[API ADMIN PROFILE UPDATE] Supabase error:", error);
        return res.status(500).json({ error: error.message });
      }

      console.log("[API ADMIN PROFILE UPDATE] Update success:", data);
      return res.json({ success: true, data });
    } catch (e: any) {
      console.error("[API ADMIN PROFILE UPDATE] Exception:", e);
      return res.status(500).json({ error: e.message });
    }
  });

  // Admin orders endpoint (bypasses RLS utilizing Service Role Key)
  app.get("/api/admin/orders", requireAdmin, async (req, res) => {
    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "Supabase not configured on server" });
    }
    try {
      console.log(`[API ADMIN ORDERS] Fetching all orders, order_items, and beats bypassing RLS...`);
      
      const { data: orders, error: ordersErr } = await supabase.from('orders').select('*');
      if (ordersErr) {
        console.error("[API ADMIN ORDERS] Error fetching orders:", ordersErr);
        throw ordersErr;
      }

      const { data: orderItems, error: itemsErr } = await supabase.from('order_items').select('id, order_id, beat_id, license_id, price, producer_id, created_at');
      if (itemsErr) {
        console.error("[API ADMIN ORDERS] Error fetching order_items:", itemsErr);
        throw itemsErr;
      }

      const { data: beats, error: beatsErr } = await supabase.from('beats').select('id, title');
      if (beatsErr) {
        console.error("[API ADMIN ORDERS] Error fetching beats:", beatsErr);
        throw beatsErr;
      }

      console.log(`[API ADMIN ORDERS] Successfully retrieved ${orders?.length || 0} orders, ${orderItems?.length || 0} items, and ${beats?.length || 0} beats.`);
      return res.json({
        success: true,
        orders: orders || [],
        orderItems: orderItems || [],
        beats: beats || []
      });
    } catch (err: any) {
      console.error("[API ADMIN ORDERS] Exception:", err);
      return res.status(500).json({ error: "Erro crítico ao carregar dados administrativos: " + err.message });
    }
  });

  // Secure GET endpoint for producer banking info
  app.get("/api/producer/banking-info/:userId", authenticateUser, async (req, res) => {
    const { userId } = req.params;
    if (!userId) {
      return res.status(400).json({ error: "userId is required" });
    }
    // Strict ownership validation
    if ((req as any).user.id !== userId && (req as any).profile?.role !== "admin") {
      return res.status(403).json({ error: "Não autorizado" });
    }
    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "Supabase not configured" });
    }
    try {
      console.log(`[API BANKING INFO] Fetching for user: ${userId}`);
      const { data, error } = await supabase
        .from("producer_banking_info")
        .select("*")
        .eq("producer_id", userId)
        .maybeSingle();
      if (error) {
        console.error("Error fetching banking info:", error);
        return res.status(500).json({ error: error.message });
      }
      return res.json(data);
    } catch (err: any) {
      console.error("Critical error fetching banking info:", err);
      return res.status(500).json({ error: err.message });
    }
  });

  // Secure POST endpoint for producer banking info (Upsert)
  app.post("/api/producer/banking-info", authenticateUser, async (req, res) => {
    const { userId, ...bankingData } = req.body;
    if (!userId) {
      return res.status(400).json({ error: "userId is required" });
    }
    // Strict ownership validation
    if ((req as any).user.id !== userId && (req as any).profile?.role !== "admin") {
      return res.status(403).json({ error: "Não autorizado" });
    }
    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "Supabase not configured" });
    }
    try {
      console.log(`[API BANKING INFO] Upserting for user ${userId}:`, bankingData);
      
      const payload = {
        producer_id: userId,
        bank_name: bankingData.bank_name || bankingData.bankName || "",
        account_number: bankingData.account_number || bankingData.accountNumber || "",
        full_name: bankingData.full_name || bankingData.fullName || bankingData.account_holder || "",
        swift_bic: bankingData.swift_bic || bankingData.swiftBic || "",
        phone: bankingData.phone || "",
        country: bankingData.country || "Angola",
        status: 'verified', // Auto-verify on save to allow immediate testing of withdrawals
        updated_at: new Date().toISOString()
      };

      // Check if row already exists
      const { data: existing, error: checkError } = await supabase
        .from("producer_banking_info")
        .select("id")
        .eq("producer_id", userId)
        .maybeSingle();
        
      if (checkError) {
        console.error("Check banking error:", checkError);
      }

      let result;
      if (existing) {
        result = await supabase
          .from("producer_banking_info")
          .update(payload)
          .eq("producer_id", userId)
          .select();
      } else {
        result = await supabase
          .from("producer_banking_info")
          .insert(payload)
          .select();
      }

      if (result.error) {
        console.error("Database error saving banking info:", result.error);
        return res.status(400).json({ error: result.error.message, details: result.error.details, hint: result.error.hint });
      }

      const refreshed = result.data && result.data.length > 0 ? result.data[0] : null;
      console.log("BANKING SAVED SUCCESSFULLY:", refreshed);
      return res.json({ success: true, data: refreshed });
    } catch (err: any) {
      console.error("Critical error saving banking info:", err);
      return res.status(500).json({ error: err.message });
    }
  });

  // Delete beat (server-side proxy bypassing RLS key limitations if using service role, validating owner/permissions)
  app.delete("/api/beats/:id", async (req, res) => {
    const { id } = req.params;
    const { userId } = req.body;
    
    console.log(`[API DELETE] Soft-deleting first. Delete beat ID: ${id} by user: ${userId}`);
    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase not configured" });

    try {
      // 1. Fetch current beat details to back up
      const { data: beat, error: fetchError } = await supabase
        .from("beats")
        .select("*")
        .eq("id", id)
        .maybeSingle();

      if (fetchError) {
        console.error(`[API DELETE] Error fetching beat ${id}:`, fetchError);
      }

      if (!beat) {
        console.log(`[API DELETE] Beat ${id} not found in database, might already be deleted or is a mock beat.`);
        return res.json({ success: true, message: "Beat not found in database, assumed deleted" });
      }

      // Security check: If a userId is passed, make sure it matches the producer_id of the beat
      if (userId && beat.producer_id && beat.producer_id !== userId) {
        console.warn(`[API DELETE] Unauthorized delete attempt of beat ${id}. Producer is ${beat.producer_id}, requester is ${userId}`);
        return res.status(403).json({ error: "Não tens autorização para eliminar este beat." });
      }

      // 2. Perform Soft Delete Backup archiving on server BEFORE deleting DB reference
      try {
        addDeletedBackup("beat", id, beat);
        logSystemEvent("recovery", `Beat soft-deletado: '${beat.title}' com sucesso. Backup arquivado.`, "info", { route: `/api/beats/${id}`, userId });
      } catch (bkErr: any) {
        console.error("[API DELETE] Backup write error:", bkErr);
      }

      // 3. Delete only the database record so it's removed from catalogo
      const { error: deleteError } = await supabase
        .from("beats")
        .delete()
        .eq("id", id);

      console.log(`[API DELETE] db delete completed. error:`, deleteError);

      if (deleteError) {
        throw deleteError;
      }

      // NOTE: We DO NOT remove files from Supabase Storage here!
      // This is part of the soft-delete & auto backup safety. The files are kept intact
      // so if the admin clicks "Restore Beat", we insert the row back and it matches immediately!
      
      const data = { success: true };
      return res.json({ success: true, data });
    } catch (err: any) {
      console.error(`[API DELETE] Exception:`, err);
      logSystemEvent("api_error", `Falha ao apagar beat ${id}: ${err.message}`, "error", { route: `/api/beats/${id}`, stack: err.stack });
      return res.status(500).json({ error: err.message || String(err) });
    }
  });

  // Save or update beat (High-Reliability proxy to bypass client-side database/CORS/network/RLS issues)
  app.post("/api/beats/save", async (req, res) => {
    const { mode, activeBeatId, payload } = req.body;
    console.log(`[API BEATS/SAVE] Request received with mode: ${mode}, id: ${activeBeatId}`);
    
    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase client not configured" });

    try {
      let result;
      if (mode === 'edit') {
        result = await supabase
          .from('beats')
          .update(payload)
          .eq('id', activeBeatId)
          .select();
      } else {
        result = await supabase
          .from('beats')
          .insert(payload)
          .select();
      }

      if (result.error) {
        console.error('[API BEATS/SAVE] Primary save error:', result.error);

        // Minimal retry payload if there is a schema column mismatch
        if (result.error.code === '42703' || result.error.code === 'PGRST204' || (result.error as any).status === 400 || result.error.message.includes('column')) {
          console.warn('[API BEATS/SAVE] Probable schema mismatch. Retrying with minimal legacy payload.');
          const minimalPayload = {
            producer_id: payload.producer_id,
            title: payload.title,
            bpm: payload.bpm,
            genre: payload.genre,
            tags: payload.tags,
            price_basic: payload.price_basic,
            price_premium: payload.price_premium,
            price_exclusive: payload.price_exclusive,
            cover_url: payload.cover_url,
            master_url: payload.master_url,
            demo_url: payload.demo_url,
            stems_url: payload.stems_url,
            artist_name: payload.artist_name,
            status: payload.status,
            category: payload.category
          };

          const retryResult = mode === 'edit'
            ? await supabase.from('beats').update(minimalPayload).eq('id', activeBeatId).select()
            : await supabase.from('beats').insert(minimalPayload).select();

          if (retryResult.error) {
            console.error('[API BEATS/SAVE] Retry save error:', retryResult.error);
            return res.status(400).json({ error: retryResult.error.message, code: retryResult.error.code });
          }

          // Asynchronously generate short link if saving is successful
          if (retryResult.data && retryResult.data.length > 0) {
            const beatVal = retryResult.data[0];
            (async () => {
              try {
                const isKit = beatVal.type === 'kit' || beatVal.category?.toLowerCase().includes('kit') || beatVal.category?.toLowerCase().includes('pack');
                const targetType = isKit ? 'kit' : 'beat';
                const targetUrl = isKit ? `/marketplace?tab=kits&beat=${beatVal.id}` : `/beat/${beatVal.id}`;
                await createShortLink(targetType, beatVal.id, targetUrl, beatVal.producer_id, beatVal.title);
              } catch (e) {
                console.error('[AUTO SHORT LINK] Error generating:', e);
              }
            })();
          }

          return res.json({ success: true, data: retryResult.data });
        }
        
        return res.status(400).json({ error: result.error.message, code: result.error.code });
      }

      console.log('[API BEATS/SAVE] Save successful');

      // Asynchronously generate short link if saving is successful
      if (result.data && result.data.length > 0) {
        const beatVal = result.data[0];
        (async () => {
          try {
            const isKit = beatVal.type === 'kit' || beatVal.category?.toLowerCase().includes('kit') || beatVal.category?.toLowerCase().includes('pack');
            const targetType = isKit ? 'kit' : 'beat';
            const targetUrl = isKit ? `/marketplace?tab=kits&beat=${beatVal.id}` : `/beat/${beatVal.id}`;
            await createShortLink(targetType, beatVal.id, targetUrl, beatVal.producer_id, beatVal.title);
          } catch (e) {
            console.error('[AUTO SHORT LINK] Error generating:', e);
          }
        })();
      }

      return res.json({ success: true, data: result.data });
    } catch (err: any) {
      console.error("[API BEATS/SAVE] Critical exception:", err);
      return res.status(500).json({ error: err.message || String(err) });
    }
  });

  // Helper to determine the correct MIME type based on file name/extension
  const getContentType = (fileName: string, fileType?: string): string => {
    if (fileType && fileType.trim() !== '') return fileType;
    const ext = fileName.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'mp3': return 'audio/mpeg';
      case 'wav': return 'audio/wav';
      case 'png': return 'image/png';
      case 'jpg':
      case 'jpeg': return 'image/jpeg';
      case 'zip': return 'application/zip';
      default: return 'application/octet-stream';
    }
  };

  // High-Reliability Notification API Proxy to avoid browser fetch issues and bypass client-side RLS/network blockages
  app.post("/api/notifications/read", async (req, res) => {
    const { id, ids } = req.body;
    console.log(`[API NOTIFICATIONS/READ] Requested for single id: ${id} or multiple ids:`, ids);
    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase client not configured" });

    try {
      const idsToMark = ids && Array.isArray(ids) && ids.length > 0 ? ids : (id ? [id] : []);
      if (idsToMark.length === 0) {
        return res.status(400).json({ error: "Missing 'id' or 'ids' array in body" });
      }

      const { data, error } = await supabase
        .from("notifications")
        .update({ read: true })
        .in("id", idsToMark)
        .select();

      if (error) {
        console.error("[API NOTIFICATIONS/READ] Database error:", error.message);
        return res.status(500).json({ error: error.message });
      }

      return res.json({ success: true, updated: idsToMark.length, data });
    } catch (err: any) {
      console.error("[API NOTIFICATIONS/READ] Critical exception:", err);
      return res.status(500).json({ error: err.message || String(err) });
    }
  });

  app.post("/api/notifications/read-all", async (req, res) => {
    const { userId } = req.body;
    console.log(`[API NOTIFICATIONS/READ-ALL] Requested for user: ${userId}`);
    if (!userId) return res.status(400).json({ error: "Missing 'userId' in body" });

    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase client not configured" });

    try {
      const { data, error } = await supabase
        .from("notifications")
        .update({ read: true })
        .eq("user_id", userId)
        .eq("read", false)
        .select();

      if (error) {
        console.error("[API NOTIFICATIONS/READ-ALL] Database error:", error.message);
        return res.status(500).json({ error: error.message });
      }

      return res.json({ success: true, updated: data?.length || 0 });
    } catch (err: any) {
      console.error("[API NOTIFICATIONS/READ-ALL] Critical exception:", err);
      return res.status(500).json({ error: err.message || String(err) });
    }
  });

  app.post("/api/notifications/delete", async (req, res) => {
    const { id, ids } = req.body;
    console.log(`[API NOTIFICATIONS/DELETE] Requested for single id: ${id} or multiple ids:`, ids);
    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase client not configured" });

    try {
      const idsToDelete = ids && Array.isArray(ids) && ids.length > 0 ? ids : (id ? [id] : []);
      if (idsToDelete.length === 0) {
        return res.status(400).json({ error: "Missing 'id' or 'ids' array in body" });
      }

      const { data, error } = await supabase
        .from("notifications")
        .delete()
        .in("id", idsToDelete)
        .select();

      if (error) {
        console.error("[API NOTIFICATIONS/DELETE] Database error:", error.message);
        return res.status(500).json({ error: error.message });
      }

      return res.json({ success: true, deleted: idsToDelete.length, data });
    } catch (err: any) {
      console.error("[API NOTIFICATIONS/DELETE] Critical exception:", err);
      return res.status(500).json({ error: err.message || String(err) });
    }
  });

  app.post("/api/notifications/delete-all", async (req, res) => {
    const { userId } = req.body;
    console.log(`[API NOTIFICATIONS/DELETE-ALL] Requested for user: ${userId}`);
    if (!userId) return res.status(400).json({ error: "Missing 'userId' in body" });

    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase client not configured" });

    try {
      const { data, error } = await supabase
        .from("notifications")
        .delete()
        .eq("user_id", userId)
        .select();

      if (error) {
        console.error("[API NOTIFICATIONS/DELETE-ALL] Database error:", error.message);
        return res.status(500).json({ error: error.message });
      }

      return res.json({ success: true, deleted: data?.length || 0 });
    } catch (err: any) {
      console.error("[API NOTIFICATIONS/DELETE-ALL] Critical exception:", err);
      return res.status(500).json({ error: err.message || String(err) });
    }
  });

  // Secure signed URL generator for premium assets (masters & stems)
  app.post("/api/beats/signed-url", authenticateUser, async (req: any, res) => {
    const { beatId, fileType } = req.body;
    const user = req.user;

    if (!beatId || !fileType) {
      return res.status(400).json({ error: "beatId and fileType ('master' | 'stems') are required." });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(503).json({ error: "Supabase not configured." });
    }

    try {
      console.log(`[SIGNED URL REQUEST] User ${user.slug || user.id} requesting ${fileType} for beat ${beatId}`);

      // Step 1: Query the beat (supporting UUID/string or integer IDs)
      let beatQuery = supabase.from('beats').select('producer_id, master_url, stems_url, demo_url, cover_url, is_free_download');
      if (typeof beatId === 'string' && beatId.includes('-')) {
        beatQuery = beatQuery.eq('id', beatId);
      } else {
        beatQuery = beatQuery.eq('id', isNaN(Number(beatId)) ? beatId : Number(beatId));
      }
      
      const { data: beat, error: beatErr } = await beatQuery.maybeSingle();

      if (beatErr || !beat) {
        return res.status(404).json({ error: "Instrumental ou Kit não encontrado." });
      }

      // Step 2: Validate permissions (must be original producer, admin, free item, or must have purchased with PAID order)
      let isAuthorized = false;

      if (beat.producer_id === user.id) {
        isAuthorized = true;
      } else if (beat.is_free_download) {
        console.log(`[SIGNED URL] Authorizing free download for ${beatId}`);
        isAuthorized = true;
      } else {
        // Check if user is admin
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", user.id)
          .maybeSingle();

        if (profile?.role === "admin") {
          isAuthorized = true;
        }
      }

      if (!isAuthorized) {
        // Query the purchase to see if they bought it
        let purchaseQuery = supabase.from('purchased_beats').select('*, orders(*)').eq('customer_id', user.id);
        if (typeof beatId === 'string' && beatId.includes('-')) {
          purchaseQuery = purchaseQuery.eq('beat_id', beatId);
        } else {
          purchaseQuery = purchaseQuery.eq('beat_id', isNaN(Number(beatId)) ? beatId : Number(beatId));
        }

        const { data: purchase, error: purchaseErr } = await purchaseQuery.maybeSingle();

        if (purchaseErr || !purchase) {
          console.warn(`[SIGNED URL REFUSED] Access denied to user ${user.id} for beat ${beatId} - no purchase found.`);
          return res.status(403).json({ error: "Você não possui licença de compra para este artigo." });
        }

        const orderStatus = String(purchase.orders?.status || '').toLowerCase();
        const canAccess = ['completed', 'paid', 'approved', 'confirmed'].includes(orderStatus);
        if (!canAccess) {
          console.warn(`[SIGNED URL REFUSED] Access denied to user ${user.id} for beat ${beatId} - order status is ${orderStatus}`);
          return res.status(403).json({ error: "O pagamento deste artigo ainda está pendente de confirmação." });
        }
      }

      // Step 3: Extract the path of the file they are requesting
      const rawPath = fileType === 'stems' ? beat.stems_url : beat.master_url;
      if (!rawPath) {
        return res.status(404).json({ error: "O ficheiro solicitado não está configurado para este beat." });
      }

      // Normalize path
      let sanitizedPath = rawPath;
      if (sanitizedPath.startsWith('http')) {
        const publicUrlPrefix = '/storage/v1/object/public/';
        if (sanitizedPath.includes(publicUrlPrefix)) {
          const splitParts = sanitizedPath.split(publicUrlPrefix)[1];
          const slashIdx = splitParts.indexOf('/');
          if (slashIdx !== -1) {
            sanitizedPath = splitParts.substring(slashIdx + 1);
          } else {
            sanitizedPath = splitParts;
          }
        }
      }

      if (sanitizedPath.startsWith('beats/')) {
        sanitizedPath = sanitizedPath.substring(6);
      }
      if (sanitizedPath.startsWith('beats-private/')) {
        sanitizedPath = sanitizedPath.substring(14);
      }
      sanitizedPath = sanitizedPath.replace(/^\/+/, '');

      console.log(`[SIGNED URL GENERATOR] Creating signed url for path: ${sanitizedPath}, fileType: ${fileType}`);

      // Try generating signed URL from beats-private first
      let { data, error } = await supabase.storage
        .from('beats-private')
        .createSignedUrl(sanitizedPath, 300);

      // Fallback to beats public bucket if not in private storage (migration safety)
      if (error || !data?.signedUrl) {
        console.log(`[SIGNED URL RETRY] Not found in beats-private, trying beats bucket for ${sanitizedPath}...`);
        const fallbackRes = await supabase.storage
          .from('beats')
          .createSignedUrl(sanitizedPath, 300);
        data = fallbackRes.data;
        error = fallbackRes.error;
      }

      if (error || !data?.signedUrl) {
        console.error('[SIGNED URL CRITICAL ERROR] Failed to create signed URL:', error);
        return res.status(500).json({ error: "Não foi possível gerar um link seguro temporário para download." });
      }

      return res.json({ success: true, signedUrl: data.signedUrl });
    } catch (err: any) {
      console.error('[SIGNED URL API EXCEPTION]', err);
      return res.status(500).json({ error: "Erro interno no servidor de descargas." });
    }
  });

  function validateStorageOwnership(userId: string, targetPath: string): boolean {
    if (!targetPath) return false;
    // Prevent path traversal
    if (targetPath.includes('..') || targetPath.includes('\\')) {
      return false;
    }
    const cleanPath = targetPath.startsWith('/') ? targetPath.substring(1) : targetPath;
    return cleanPath.startsWith(`${userId}/`);
  }

  // Storage Upload Proxy
  app.post("/api/storage/upload", authenticateUser, async (req: any, res) => {
    const { base64Data, bucket: rawBucket, path, contentType, fileType } = req.body;
    console.log("Received upload request for bucket:", rawBucket, "path:", path, "fileType:", fileType);
    
    if (!base64Data) {
        return res.status(400).json({ error: "Missing base64Data" });
    }

    const userId = req.user.id;

    // Validate path ownership
    if (!validateStorageOwnership(userId, path)) {
      console.warn(`[UPLOAD SECURITY] Ownership validation failed for user ${userId} and path ${path}`);
      return res.status(403).json({
        error: "Storage path ownership violation"
      });
    }

    // Force reconstruct finalPath using authenticated userId
    const pathParts = path.split('/');
    const finalPath = `${userId}/${pathParts.slice(1).join('/')}`;

    // Backend-enforced bucket routing using central resolver
    const bucket = resolveStorageBucket(fileType, finalPath || path);
    console.log(`[STORAGE AUDIT] resolveStorageBucket decided bucket: ${bucket} for file: ${finalPath}`);

    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase not configured" });

    try {
        const parts = base64Data.split(',');
        if (parts.length < 2) {
            return res.status(400).json({ error: "Invalid base64Data format" });
        }
        
        const buffer = Buffer.from(parts[1], 'base64');
        console.log(`Uploading to bucket ${bucket} at path ${finalPath} with size ${buffer.length} bytes`);
        
        // Anti-spam & Security Hardening: Validate extension & size limit bounds
        const validation = validateUpload(finalPath, bucket, buffer.length);
        if (!validation.isValid) {
            console.warn("[UPLOAD VALIDATION REFUSED]", validation.error);
            return res.status(400).json({ error: validation.error });
        }
        
        const finalContentType = getContentType(finalPath, contentType);
        const { error } = await supabase.storage.from(bucket).upload(finalPath, buffer, {
            contentType: finalContentType,
            upsert: true
        });
        
        if (error) {
            console.error("Supabase upload error:", error);
            return res.status(500).json(error);
        }

        let fileUrl = '';
        if (bucket === 'beats-private') {
            fileUrl = `beats-private/${finalPath}`;
            console.log("Proxy upload success. Private reference:", fileUrl);
        } else {
            const { data: publicUrlData } = supabase.storage.from(bucket).getPublicUrl(finalPath);
            fileUrl = publicUrlData?.publicUrl || "";
            console.log("Proxy upload success. Public URL:", fileUrl);
        }
        res.json({ success: true, fileUrl });
    } catch(err) {
        console.error("Upload proxy error:", err);
        res.status(500).json({ error: String(err) });
    }
  });

  // Serve chunked uploads statically
  const uploadStaticPath = path.join("/tmp", "uploads");
  try {
    if (!fs.existsSync(uploadStaticPath)) {
      fs.mkdirSync(uploadStaticPath, { recursive: true });
    }
  } catch (e) {
    console.warn("Failed to create static uploads path:", e);
  }
  app.use('/api/uploads', express.static(uploadStaticPath));

  // Chunked Upload Endpoint for files exceeding 50MB
  app.post("/api/storage/upload-chunk", authenticateUser, async (req: any, res) => {
    let { fileId, chunkIndex, totalChunks, fileName, chunkData, bucket: rawBucket, path: storagePath, fileType } = req.body;
    
    // Backend-enforced bucket routing for chunked uploads using central resolver
    const bucket = resolveStorageBucket(fileType, fileName || storagePath);
    console.log(`[STORAGE AUDIT] resolveStorageBucket decided bucket: ${bucket} for chunk upload of ${fileName}`);

    console.log(`[SERVER UPLOAD CHUNK] Request received. fileId: ${fileId}, chunkIndex: ${chunkIndex}, totalChunks: ${totalChunks}, fileName: ${fileName}, chunkData length: ${chunkData ? chunkData.length : 0}, bucket: ${bucket}, path: ${storagePath}`);

    if (!fileId || chunkIndex === undefined || !totalChunks || !fileName || !chunkData) {
      console.warn('[SERVER UPLOAD CHUNK] Missing parameters in body:', { fileId, chunkIndex, totalChunks, fileName, hasData: !!chunkData });
      return res.status(400).json({ error: "Missing required chunk parameters" });
    }

    const userId = req.user.id;

    if (bucket && storagePath) {
      if (!validateStorageOwnership(userId, storagePath)) {
        console.warn(`[UPLOAD CHUNK SECURITY] Ownership validation failed for user ${userId} and path ${storagePath}`);
        return res.status(403).json({
          error: "Storage path ownership violation"
        });
      }
      
      const pathParts = storagePath.split('/');
      storagePath = `${userId}/${pathParts.slice(1).join('/')}`;
    }

    // Security Hardening: Proactive file extension check
    const proactiveVal = validateUpload(fileName, bucket || "beats", 0);
    if (!proactiveVal.isValid) {
      console.warn("[CHUNK UPLOAD BLOCKED - UNSUPPORTED EXTENSION]", proactiveVal.error);
      return res.status(400).json({ error: proactiveVal.error });
    }

    try {
      const uploadDir = path.join("/tmp", "uploads", fileId);
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }

      const chunkPath = path.join(uploadDir, `chunk_${chunkIndex}`);
      
      // Clean base64 encoding prefix if present
      let cleanBase64 = chunkData;
      if (chunkData.includes(',')) {
        cleanBase64 = chunkData.split(',')[1];
      }
      
      const buffer = Buffer.from(cleanBase64, 'base64');
      fs.writeFileSync(chunkPath, buffer);

      console.log(`[CHUNK UPLOAD] Saved chunk ${chunkIndex + 1}/${totalChunks} for fileId ${fileId} in ${chunkPath}`);

      // Check if we have received all chunks
      let allChunksReceived = true;
      for (let i = 0; i < totalChunks; i++) {
        if (!fs.existsSync(path.join(uploadDir, `chunk_${i}`))) {
          allChunksReceived = false;
          break;
        }
      }

      if (allChunksReceived) {
        console.log(`[CHUNK UPLOAD] All ${totalChunks} chunks received for ${fileName}. Combining...`);
        const finalFileName = fileName.replace(/\s+/g, "_");
        const finalFilePath = path.join(uploadDir, finalFileName);
        
        fs.writeFileSync(finalFilePath, ''); // Truncate / ensure created

        for (let i = 0; i < totalChunks; i++) {
          const chunkFile = path.join(uploadDir, `chunk_${i}`);
          const chunkBuffer = fs.readFileSync(chunkFile);
          fs.appendFileSync(finalFilePath, chunkBuffer);
          
          try {
            fs.unlinkSync(chunkFile); // Clean up chunk
          } catch(e) {
            console.warn(`[CHUNK UPLOAD] Warning: Failed to delete temporary chunk file ${chunkFile}:`, e);
          }
        }
        
        // Security checks: Check full combined size of assembled file
        const fileStats = fs.statSync(finalFilePath);
        const finalVal = validateUpload(fileName, bucket || "beats", fileStats.size);
        if (!finalVal.isValid) {
          console.warn("[CHUNK UPLOAD COMBINE BLOCKED - FILE EXCEEDS SIZE LIMITS]", finalVal.error);
          try {
            fs.unlinkSync(finalFilePath);
          } catch {}
          return res.status(400).json({ error: finalVal.error });
        }

        let fileUrl = `/api/uploads/${fileId}/${finalFileName}`;
        
        // Push the merged file from ephemeral container disk up to permanent Supabase Storage !
        if (bucket && storagePath) {
          try {
            const combinedBuffer = fs.readFileSync(finalFilePath);
            console.log(`[CHUNK UPLOAD] Moving combined file to Supabase: bucket=${bucket}, path=${storagePath}`);
            const supabase = getSupabase();
            if (supabase) {
              const finalContentType = getContentType(finalFileName);
              const { error: uploadError } = await supabase.storage.from(bucket).upload(storagePath, combinedBuffer, {
                contentType: finalContentType,
                upsert: true
              });
              
              if (uploadError) {
                console.error("[CHUNK UPLOAD] Failed to upload combined file to Supabase:", uploadError);
              } else {
                if (bucket === 'beats-private') {
                  fileUrl = `beats-private/${storagePath}`;
                  console.log(`[CHUNK UPLOAD] Uploaded successfully to Supabase. Private reference: ${fileUrl}`);
                } else {
                  const { data: publicUrlData } = supabase.storage.from(bucket).getPublicUrl(storagePath);
                  if (publicUrlData?.publicUrl) {
                    fileUrl = publicUrlData.publicUrl;
                    console.log(`[CHUNK UPLOAD] Uploaded successfully to Supabase. Public URL: ${fileUrl}`);
                  }
                }
              }
            }
          } catch (supErr) {
            console.error("[CHUNK UPLOAD] Error uploading chunks combined file to Supabase storage:", supErr);
          }
        }
        
        console.log(`[CHUNK UPLOAD] Combined file successfully. Accessible at: ${fileUrl}`);
        return res.json({ success: true, fileUrl, combined: true });
      }

      return res.json({ success: true, combined: false });
    } catch (err: any) {
      console.error("[CHUNK UPLOAD] Error:", err);
      res.status(500).json({ error: err.message || String(err) });
    }
  });

  // Socket.IO mapping: userId -> socketId
  const userSockets = new Map<string, string>();

  io.on("connection", (socket) => {
    const userId = socket.handshake.query.userId as string;
    if (userId) {
      userSockets.set(userId, socket.id);
      console.log(`User connected: ${userId} (${socket.id})`);
    }

    socket.on("private_message", async ({ toUserId, content, conversationId, senderId }) => {
      const checkId = String(conversationId);
      
      if (checkId.startsWith("virtual_")) {
        const fallbackChats = getFallbackChats();
        const chatIndex = fallbackChats.findIndex((c) => String(c.id) === checkId);
        
        const timestamp = new Date().toISOString();
        const virtualMsg: VirtualMessage = {
          id: `vm_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          conversation_id: checkId,
          sender_id: senderId,
          content,
          created_at: timestamp,
          is_read: false
        };

        if (chatIndex !== -1) {
          fallbackChats[chatIndex].messages.push(virtualMsg);
          fallbackChats[chatIndex].updated_at = timestamp;
          writeFallbackChats(fallbackChats);
        } else {
          const newVirtualConv: VirtualConversation = {
            id: checkId,
            buyer_id: senderId,
            seller_id: toUserId,
            created_at: timestamp,
            updated_at: timestamp,
            messages: [virtualMsg]
          };
          fallbackChats.push(newVirtualConv);
          writeFallbackChats(fallbackChats);
        }

        // Emit to recipient if online
        const recipientSocketId = userSockets.get(toUserId);
        if (recipientSocketId) {
          io.to(recipientSocketId).emit("new_message", virtualMsg);
        }
        
        // Confirm to sender
        socket.emit("message_sent", virtualMsg);
        return;
      }

      const supabase = getSupabase();
      if (!supabase) {
        console.error("Supabase not configured");
        return;
      }
      
      // 1. Persist to DB
      const { data: message, error } = await supabase
        .from("messages")
        .insert([{ conversation_id: conversationId, sender_id: senderId, content }])
        .select()
        .single();

      if (error) {
        console.error("Error saving message:", error);
        return;
      }

      // 2. Emit to recipient if online
      const recipientSocketId = userSockets.get(toUserId);
      if (recipientSocketId) {
        io.to(recipientSocketId).emit("new_message", message);
      }
      
      // 3. Confirm to sender
      socket.emit("message_sent", message);
      
      // 4. Update conversation updated_at in DB
      await supabase
        .from("conversations")
        .update({ updated_at: new Date().toISOString() })
        .eq("id", conversationId);
    });

    socket.on("typing", ({ toUserId, conversationId, isTyping }) => {
      const recipientSocketId = userSockets.get(toUserId);
      if (recipientSocketId) {
        io.to(recipientSocketId).emit("user_typing", { conversationId, isTyping });
      }
    });

    socket.on("disconnect", () => {
      if (userId) {
        userSockets.delete(userId);
        console.log(`User disconnected: ${userId}`);
      }
    });
  });

  // List conversations
  app.get("/api/conversations", async (req, res) => {
    const userId = req.query.userId;
    if (!userId) return res.status(400).json({ error: "Missing userId" });

    const supabase = getSupabase();
    if (!supabase) return res.json([]);

    let data: any[] = [];
    try {
      const { data: dbData, error } = await supabase
        .from("conversations")
        .select(`
          *,
          messages (
            id,
            sender_id,
            content,
            created_at,
            is_read
          )
        `)
        .or(`buyer_id.eq.${userId},seller_id.eq.${userId}`)
        .order('updated_at', { ascending: false });

      if (!error && dbData) {
        data = dbData;
      }
    } catch (e) {
      console.error("DB load conversations error:", e);
    }

    try {
      const fallbackChats = getFallbackChats();
      const userFallbacks = fallbackChats.filter(
        (c) => String(c.buyer_id) === String(userId) || String(c.seller_id) === String(userId)
      );
      data = [...data, ...userFallbacks];
    } catch (fErr) {
      console.error("Error merging fallback chats:", fErr);
    }

    // Sort combined conversations by updated_at descending
    data.sort((a, b) => {
      const tA = new Date(a.updated_at || a.created_at).getTime();
      const tB = new Date(b.updated_at || b.created_at).getTime();
      return tB - tA;
    });

    // Fetch buyer and seller profiles to show usernames and avatars
    if (data && data.length > 0) {
      try {
        const participantIds = new Set<string>();
        data.forEach((conv: any) => {
          if (conv.buyer_id) participantIds.add(conv.buyer_id);
          if (conv.seller_id) participantIds.add(conv.seller_id);
        });

        if (participantIds.size > 0) {
          const { data: profiles, error: pError } = await supabase
            .from("profiles")
            .select("id, username, artistic_name, display_name, avatar_url, role, is_verified")
            .in("id", Array.from(participantIds));

          if (pError) {
            console.error("[CONVERSATIONS_SQL_ERROR] Failed to query profiles structure:", pError);
          }

          if (!pError && profiles) {
            const participants = Array.from(participantIds);
            console.log("participants:", participants);

            profiles.forEach((p: any) => {
              const profile = p;
              console.log("profile:", profile);
            });

            const profileMap = new Map(profiles.map((p: any) => {
              const enriched = {
                ...p,
                full_name: p.display_name || p.artistic_name || p.username || ""
              };
              return [String(p.id).toLowerCase(), enriched];
            }));

            data.forEach((conv: any) => {
              conv.buyer_profile = conv.buyer_id ? (profileMap.get(String(conv.buyer_id).toLowerCase()) || null) : null;
              conv.seller_profile = conv.seller_id ? (profileMap.get(String(conv.seller_id).toLowerCase()) || null) : null;
              
              const conversation = conv;
              console.log("conversation:", conversation);
            });
          }
        }
      } catch (err) {
        console.error("Error fetching profiles for conversations:", err);
      }
    }

    res.json(data || []);
  });

  // Get messages for a conversation
  app.get("/api/conversations/:id/messages", async (req, res) => {
    const { id } = req.params;
    
    if (String(id).startsWith("virtual_")) {
      const fallbackChats = getFallbackChats();
      const chat = fallbackChats.find((c) => String(c.id) === String(id));
      if (chat) {
        return res.json(chat.messages || []);
      }
      return res.json([]);
    }

    const supabase = getSupabase();
    if (!supabase) return res.json([]);

    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", id)
      .order("created_at", { ascending: true });

    if (error) return res.status(500).json(error);
    res.json(data || []);
  });

  // Synchronize users from auth or profiles table to public.users to prevent foreign key errors with conversations
  async function ensurePublicUserExists(supabaseClientInstance: any, userId: string) {
    try {
      const { data: existingUser } = await supabaseClientInstance
        .from('users')
        .select('id')
        .eq('id', userId)
        .maybeSingle();

      if (existingUser) {
        return;
      }

      // Fetch metadata from profiles first
      let username: string | null = null;
      let email: string | null = null;
      let avatarUrl: string | null = null;

      try {
        const { data: profileVal } = await supabaseClientInstance
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .maybeSingle();
        if (profileVal) {
          username = profileVal.username || profileVal.display_name || profileVal.artistic_name || null;
          email = profileVal.email || null;
          avatarUrl = profileVal.avatar_url || null;
        }
      } catch (profErr) {
        console.warn(`[USER SYNC] Profiles query failed for ${userId}:`, profErr);
      }

      // Fetch from auth as fallback
      if (!email) {
        try {
          const { data: authVal } = await supabaseClientInstance.auth.admin.getUserById(userId);
          if (authVal && authVal.user) {
            email = authVal.user.email || null;
            if (!username && authVal.user.user_metadata) {
              username = authVal.user.user_metadata.username || authVal.user.user_metadata.full_name || null;
            }
          }
        } catch (authErr) {
          console.warn(`[USER SYNC] Auth.admin lookup failed for ${userId}:`, authErr);
        }
      }

      const cleanEmail = email || `user_${userId.substring(0, 8)}@example.com`;
      const cleanUsername = username || `user_${userId.substring(0, 8)}`;

      console.log(`[USER SYNC] Auto-synced missing user ${userId} to public.users table. Email: ${cleanEmail}`);
      await supabaseClientInstance
        .from('users')
        .insert([{
          id: userId,
          email: cleanEmail,
          username: cleanUsername,
          avatar_url: avatarUrl,
          role: 'customer'
        }]);
    } catch (e) {
      console.error(`[USER SYNC] Master error ensuring public user exists for ${userId}:`, e);
    }
  }

  // Create or get conversation
  app.post("/api/conversations", apiRateLimiter(15, 60 * 1000), async (req, res) => {
    const { buyerId, sellerId } = req.body;
    if (!buyerId || !sellerId) {
      return res.status(400).json({ error: "buyerId and sellerId are required" });
    }

    const supabase = getSupabase();

    // Helper function to append buyer_profile and seller_profile
    async function enrichWithProfiles(conv: any) {
      if (!conv) return conv;
      if (!supabase) return conv;
      try {
        const { data: profiles, error: pError } = await supabase
          .from("profiles")
          .select("id, username, artistic_name, display_name, avatar_url, role, is_verified")
          .in("id", [buyerId, sellerId]);

        if (pError) {
          console.error("[ENRICH_CONVERSATIONS_SQL_ERROR] Failed to query profiles:", pError);
        }

        if (!pError && profiles) {
          const profileMap = new Map(profiles.map((p: any) => {
            const enriched = {
              ...p,
              full_name: p.display_name || p.artistic_name || p.username || ""
            };
            return [p.id, enriched];
          }));
          conv.buyer_profile = profileMap.get(conv.buyer_id) || null;
          conv.seller_profile = profileMap.get(conv.seller_id) || null;
        }
      } catch (err) {
        console.error("Error enriching conversation with profiles:", err);
      }
      return conv;
    }

    // First check in fallback chats to avoid writing to DB if virtual chat exists
    const fallbackChats = getFallbackChats();
    const existingFallback = fallbackChats.find(
      (conv) =>
        (String(conv.buyer_id) === String(buyerId) && String(conv.seller_id) === String(sellerId)) ||
        (String(conv.buyer_id) === String(sellerId) && String(conv.seller_id) === String(buyerId))
    );
    if (existingFallback) {
      const enrichedFallback = await enrichWithProfiles({ ...existingFallback });
      return res.json(enrichedFallback);
    }

    if (!supabase) return res.status(503).json({ error: "Supabase not configured" });

    // Ensure both transaction participants exist in public.users to prevent foreign key errors
    await ensurePublicUserExists(supabase, buyerId);
    await ensurePublicUserExists(supabase, sellerId);
    
    // Check if exists using a simple, highly-compatible query and filtering in JS
    let existing = null;
    try {
      const { data: existingConvs, error: queryError } = await supabase
        .from("conversations")
        .select("*")
        .or(`buyer_id.eq.${buyerId},seller_id.eq.${buyerId},buyer_id.eq.${sellerId},seller_id.eq.${sellerId}`);

      if (!queryError && existingConvs) {
        existing = existingConvs.find(
          (conv: any) =>
            (String(conv.buyer_id) === String(buyerId) && String(conv.seller_id) === String(sellerId)) ||
            (String(conv.buyer_id) === String(sellerId) && String(conv.seller_id) === String(buyerId))
        );
      }
    } catch (e) {
      console.error("Error querying conversations from DB:", e);
    }

    if (existing) {
      const enrichedExisting = await enrichWithProfiles({ ...existing });
      return res.json(enrichedExisting);
    }

    // Try to create new conversation in real DB
    try {
      const { data, error } = await supabase
        .from("conversations")
        .insert([{ buyer_id: buyerId, seller_id: sellerId }])
        .select()
        .single();

      if (!error && data) {
        const enrichedData = await enrichWithProfiles({ ...data });
        return res.json(enrichedData);
      }

      // If database insert fails due to foreign key constraints or any error, fall back to creating a dynamic local virtual chat
      console.warn("Error creating conversation in DB, falling back to virtual conversation:", error);
      logSystemEvent(
        "api_warning",
        `Created fallback virtual chat for buyer=${buyerId}, seller=${sellerId} because: ${error ? (error.message || JSON.stringify(error)) : "Unknown DB error"}`,
        "warning"
      );
    } catch (insertExc) {
      console.error("Exception during DB conversation insert, falling back to virtual conversation:", insertExc);
    }

    // Virtual creation fallback
    const newVirtualId = `virtual_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newVirtualConv: VirtualConversation = {
      id: newVirtualId,
      buyer_id: buyerId,
      seller_id: sellerId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      messages: []
    };
    
    fallbackChats.push(newVirtualConv);
    writeFallbackChats(fallbackChats);
    
    const enrichedVirtual = await enrichWithProfiles({ ...newVirtualConv });
    res.json(enrichedVirtual);
  });

  // Mark messages as read
  app.post("/api/conversations/:id/read", async (req, res) => {
    const { id } = req.params;
    const { userId } = req.body;
    
    if (!userId || typeof userId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(userId)) {
      console.warn(`[MARK_READ_WARNING] Mark messages as read received invalid or empty userId: ${userId}`);
      return res.status(400).json({ error: "Invalid or missing userId (must be a valid UUID)" });
    }
    
    if (String(id).startsWith("virtual_")) {
      const fallbackChats = getFallbackChats();
      const chatIndex = fallbackChats.findIndex((c) => String(c.id) === String(id));
      if (chatIndex !== -1) {
        fallbackChats[chatIndex].messages.forEach((m) => {
          if (String(m.sender_id) !== String(userId)) {
            m.is_read = true;
          }
        });
        writeFallbackChats(fallbackChats);
      }
      return res.json({ success: true });
    }

    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase not configured" });

    const { error } = await supabase
      .from("messages")
      .update({ is_read: true })
      .eq("conversation_id", id)
      .neq("sender_id", userId);

    if (error) {
      console.error("[MARK_READ_ERROR] Failed to update messages in database. Details:", error);
      return res.status(500).json({ error: error.message || error });
    }
    res.json({ success: true });
  });

  // Delete conversation
  app.delete("/api/conversations/:id", async (req, res) => {
    const { id } = req.params;
    console.log(`[CONVERSATIONS] Request to delete conversation received for ID: ${id}`);

    if (String(id).startsWith("virtual_")) {
      try {
        const fallbackChats = getFallbackChats();
        const updated = fallbackChats.filter((c) => String(c.id) !== String(id));
        writeFallbackChats(updated);
        console.log(`[CONVERSATIONS] Virtual conversation ${id} deleted successfully.`);
        return res.json({ success: true });
      } catch (err) {
        console.error(`[CONVERSATIONS] Failed to delete virtual conversation ${id}:`, err);
        return res.status(500).json({ error: "Failed to delete virtual conversation" });
      }
    }

    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase not configured" });

    try {
      // Direct supabase delete on conversations table (cascades automatically to messages on DB level)
      const { error: deleteErr } = await supabase
        .from("conversations")
        .delete()
        .eq("id", id);

      if (deleteErr) {
        console.error(`[CONVERSATIONS] Failed to delete conversation ${id} from database. Error:`, deleteErr);
        return res.status(500).json({ error: deleteErr.message || deleteErr });
      }

      console.log(`[CONVERSATIONS] Database conversation ${id} successfully deleted.`);
      res.json({ success: true });
    } catch (e: any) {
      console.error(`[CONVERSATIONS] Server error during deletion of conversation ${id}:`, e);
      res.status(500).json({ error: e.message || "Unknown server error" });
    }
  });

  // User search
  app.get("/api/users", async (req, res) => {
    const { search } = req.query;
    const supabase = getSupabase();
    if (!supabase) return res.json([]);

    // In a real app, you'd search the auth.users or a public profiles table
    // Since we don't have a public profiles table in schema.sql yet, let's assume it exists
    const { data, error } = await supabase
      .from("profiles")
      .select("id, username, display_name, artistic_name, avatar_url")
      .ilike("username", `%${search}%`)
      .limit(10);

    if (error) return res.status(500).json(error);
    const mappedData = data ? data.map((p: any) => ({
      ...p,
      full_name: p.display_name || p.artistic_name || p.username || ""
    })) : [];
    res.json(mappedData);
  });

  // ==========================================
  // REAL-TIME SOCIAL ACTIVITY FEED SYSTEM
  // ==========================================

  const ACTIVITY_FEED_FILE = path.join("/tmp", "activity_feed.json");

  // Ensure activity_feed JSON store exists
  function initActivityFeedFile() {
    try {
      if (!fs.existsSync(ACTIVITY_FEED_FILE)) {
        fs.writeFileSync(ACTIVITY_FEED_FILE, JSON.stringify([], null, 2));
      }
    } catch (e) {
      console.error("[ACTIVITY ENGINE] Failed to initialize activity file:", e);
    }
  }
  initActivityFeedFile();

  function getLocalActivities() {
    try {
      if (fs.existsSync(ACTIVITY_FEED_FILE)) {
        const data = fs.readFileSync(ACTIVITY_FEED_FILE, "utf-8");
        return JSON.parse(data);
      }
    } catch (e) {
      console.error("[ACTIVITY ENGINE] Fail reading local file:", e);
    }
    return [];
  }

  function saveLocalActivity(act: any) {
    try {
      const list = getLocalActivities();
      list.unshift(act); // Latest first
      const trimmed = list.slice(0, 250); // Hard limit 250 items for memory/perf
      fs.writeFileSync(ACTIVITY_FEED_FILE, JSON.stringify(trimmed, null, 2));
    } catch (e) {
      console.error("[ACTIVITY ENGINE] Fail writing local file:", e);
    }
  }

  // Helper to commit activity to BOTH Supabase (if table exists) and Local JSON
  async function commitActivity(payload: any) {
    // 1. Map to exact DB schema columns safely
    const dbPayload = {
      user_id: payload.user_id || payload.userId || null,
      username: payload.actor_username || payload.actorUsername || payload.username || "membro",
      avatar_url: payload.actor_avatar || payload.actorAvatar || payload.avatar_url || null,
      type: payload.type,
      target_id: payload.target_id ? String(payload.target_id) : null,
      target_title: payload.target_title || null,
      metadata: {
        actor_name: payload.actor_name || payload.actorName || "Membro",
        target_cover: payload.target_cover || payload.targetCover || null,
        ...(payload.metadata || {})
      },
      created_at: payload.created_at || new Date().toISOString()
    };

    // 2. Map to legacy formats to support existing frontend keys instantly
    const clientObj = {
      id: payload.id || Math.random().toString(36).substring(2) + Date.now().toString(36),
      user_id: dbPayload.user_id,
      username: dbPayload.username,
      avatar_url: dbPayload.avatar_url,
      type: dbPayload.type,
      target_id: dbPayload.target_id,
      target_title: dbPayload.target_title,
      metadata: dbPayload.metadata,
      created_at: dbPayload.created_at,

      // Compatibility bindings
      actor_name: dbPayload.metadata.actor_name,
      actor_username: dbPayload.username,
      actor_avatar: dbPayload.avatar_url,
      target_cover: dbPayload.metadata.target_cover
    };

    // Save to local JSON fallback
    saveLocalActivity(clientObj);

    // Broadcast via Socket.IO instantly
    io.emit("new_social_activity", clientObj);
    console.log(`[ACTIVITY ENGINE] Broadcasted activity [${clientObj.type}] by @${clientObj.username}`);

    // Try committing to Supabase if config is alive
    const sb = getSupabase();
    if (sb) {
      try {
        const { error } = await sb.from("activity_feed").insert([dbPayload]);
        if (error) {
          if (
            error.code === "42P01" || 
            error.code === "PGRST205" || 
            error.message?.includes("relation") || 
            error.message?.includes("schema cache") || 
            error.message?.includes("Could not find the table")
          ) {
            console.log("[ACTIVITY ENGINE] Table 'activity_feed' not created in database yet. Using local JSON store safely.");
          } else {
            console.error("[ACTIVITY ENGINE] Supabase insert error:", error.message);
          }
        } else {
          console.log("[ACTIVITY ENGINE] Activity successfully synced to Supabase database.");
        }
      } catch (err: any) {
        console.warn("[ACTIVITY ENGINE] Supabase insertion bypass:", err.message || err);
      }
    }
    return clientObj;
  }

  // GET global feed
  app.get("/api/activity/feed", async (req, res) => {
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 50);
    const sb = getSupabase();
    if (sb) {
      try {
        const { data, error } = await sb
          .from("activity_feed")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(limit);
        
        if (!error && data && data.length > 0) {
          // Normalize payload to provide both schemas to standard frontend listeners
          const normalized = data.map((item: any) => ({
            ...item,
            actor_name: item.metadata?.actor_name || item.username || "Membro",
            actor_username: item.username,
            actor_avatar: item.avatar_url,
            target_cover: item.metadata?.target_cover || null
          }));
          return res.json(normalized);
        }
      } catch (err) {
        console.warn("[API FEED] Fallback to local files due to db error or missing table:", err);
      }
    }
    
    // Return from local JSON
    const local = getLocalActivities();
    return res.json(local.slice(0, limit));
  });

  // GET personalized feed based on followed profiles (Alias to feed)
  app.get("/api/feed/following/:userId", async (req, res) => {
    res.redirect(`/api/activity/following/${req.params.userId}`);
  });

  // GET personalized feed based on followed profiles
  app.get("/api/activity/following/:userId", async (req, res) => {
    const userId = req.params.userId;
    const limit = Math.min(parseInt(req.query.limit as string) || 30, 100);
    const sb = getSupabase();
    
    let followingIds: string[] = [];
    if (sb) {
      try {
        const { data: follows } = await sb
          .from("followers")
          .select("following_id")
          .eq("follower_id", userId);
          
        if (follows && follows.length > 0) {
          followingIds = follows.map((f: any) => f.following_id);
        }
      } catch (err) {
        console.warn("[API PERSONAL FEED] Could not load following IDs:", err);
      }
    }

    const feedItems: any[] = [];
    const dedupKeys = new Set<string>();
    const profileIdsToFetch = new Set<string>();

    if (sb) {
      try {
        let rawActivities: any[] = [];
        let rawBeats: any[] = [];

        // 1. Fetch followed users activities & beats if exists
        if (followingIds.length > 0) {
          try {
            const actRes = await sb.from("activity_feed")
              .select("*")
              .in("user_id", followingIds)
              .order("created_at", { ascending: false })
              .limit(40);
            if (!actRes.error && actRes.data) {
              actRes.data.forEach((item: any) => {
                rawActivities.push({ ...item, is_followed: true });
              });
            }

            const beatsRes = await sb.from("beats")
              .select("*")
              .in("producer_id", followingIds)
              .eq("status", "published")
              .order("created_at", { ascending: false })
              .limit(40);
            if (!beatsRes.error && beatsRes.data) {
              beatsRes.data.forEach((beat: any) => {
                rawBeats.push({ ...beat, is_followed: true });
              });
            }
          } catch (err) {
            console.warn("[API PERSONAL FEED] Error fetching selective following data:", err);
          }
        }

        // 2. Fetch global activities & beats to enrich/backfill if personal is small or empty (highly interactive!)
        const minTargetCount = 20;
        const totalFollowedFound = rawActivities.length + rawBeats.length;
        
        if (followingIds.length === 0 || totalFollowedFound < minTargetCount) {
          const globalLimit = minTargetCount - totalFollowedFound + 15;
          try {
            // Fetch global recent activities
            const gActRes = await sb.from("activity_feed")
              .select("*")
              .order("created_at", { ascending: false })
              .limit(globalLimit);
            
            if (!gActRes.error && gActRes.data) {
              gActRes.data.forEach((item: any) => {
                // Ensure we don't duplicate if it was already fetched in the personal feed
                if (followingIds.includes(item.user_id)) {
                  rawActivities.push({ ...item, is_followed: true });
                } else {
                  rawActivities.push({ ...item, is_followed: false, is_suggestion: true });
                }
              });
            }

            // Fetch global recent beats
            const gBeatsRes = await sb.from("beats")
              .select("*")
              .eq("status", "published")
              .order("created_at", { ascending: false })
              .limit(globalLimit);
            
            if (!gBeatsRes.error && gBeatsRes.data) {
              gBeatsRes.data.forEach((beat: any) => {
                if (followingIds.includes(beat.producer_id)) {
                  rawBeats.push({ ...beat, is_followed: true });
                } else {
                  rawBeats.push({ ...beat, is_followed: false, is_suggestion: true });
                }
              });
            }
          } catch (gErr) {
            console.warn("[API PERSONAL FEED] Error during global backfill query:", gErr);
          }
        }

        // Collect all target profiles to query details (avatars, verified state)
        rawActivities.forEach((act: any) => {
          if (act.user_id) profileIdsToFetch.add(act.user_id);
          if (act.target_id) profileIdsToFetch.add(act.target_id);
        });
        rawBeats.forEach((beat: any) => {
          if (beat.producer_id) profileIdsToFetch.add(beat.producer_id);
        });

        // Query profiles details in one efficient batch!
        const profilesMap = new Map<string, any>();
        if (profileIdsToFetch.size > 0) {
          try {
            const { data: profilesRes } = await sb.from("profiles")
              .select("id, username, display_name, avatar_url, artistic_name, is_verified")
              .in("id", Array.from(profileIdsToFetch));
            
            if (profilesRes) {
              profilesRes.forEach((p: any) => {
                profilesMap.set(p.id, p);
              });
            }
          } catch (profErr) {
            console.warn("[API PERSONAL FEED] Profiles batch querying failed:", profErr);
          }
        }

        // 3. Process parsed activities with profiles metadata
        rawActivities.forEach((item: any) => {
          const profileData = profilesMap.get(item.user_id);
          const is_verified = profileData?.is_verified === true;
          const actor_name = item.metadata?.actor_name || profileData?.artistic_name || profileData?.display_name || item.username || "Membro";
          const actor_username = profileData?.username || item.username;
          const actor_avatar = profileData?.avatar_url || item.avatar_url;
          const target_cover = item.metadata?.target_cover || null;

          // Deduplicate based on type and target_id
          const dupKey = `${item.type}_${item.target_id || item.id}`;
          if (dedupKeys.has(dupKey)) return;

          const feedItem = {
            id: String(item.id),
            user_id: item.user_id,
            username: actor_username || item.username,
            avatar_url: actor_avatar,
            is_verified: is_verified,
            type: item.type,
            target_id: item.target_id ? String(item.target_id) : null,
            target_title: item.target_title,
            metadata: item.metadata || {},
            created_at: item.created_at,
            actor_name,
            actor_username,
            actor_avatar,
            target_cover,
            is_followed: !!item.is_followed,
            is_suggestion: !!item.is_suggestion
          };

          feedItems.push(feedItem);
          dedupKeys.add(dupKey);
        });

        // 4. Process beats as activities with profiles details
        rawBeats.forEach((beat: any) => {
          const cat = (beat.category || "").toLowerCase();
          const isKit = cat.includes("kit") || cat.includes("pack");
          const feedType = isKit ? "kit_upload" : "beat_upload";

          const dupKey = `${feedType}_${beat.id}`;
          if (dedupKeys.has(dupKey)) return;

          const producer = profilesMap.get(beat.producer_id);
          const is_verified = producer?.is_verified === true;
          const actor_username = producer?.username || producer?.display_name || `producer_${beat.producer_id}`;
          const actor_name = producer?.artistic_name || producer?.display_name || "Produtor";
          const actor_avatar = producer?.avatar_url || null;

          const feedItem = {
            id: `generated_${feedType}_${beat.id}`,
            user_id: beat.producer_id,
            username: actor_username,
            avatar_url: actor_avatar,
            is_verified: is_verified,
            type: feedType,
            target_id: String(beat.id),
            target_title: beat.title,
            metadata: {
              actor_name,
              target_cover: beat.cover_url,
              genre: beat.genre || "Trap",
              bpm: beat.bpm || 120,
              key: beat.key || "C",
              scale: beat.scale || "Maior",
              type: beat.type || "beat"
            },
            created_at: beat.created_at,
            actor_name,
            actor_username,
            actor_avatar,
            target_cover: beat.cover_url,
            is_followed: !!beat.is_followed,
            is_suggestion: !!beat.is_suggestion
          };

          feedItems.push(feedItem);
          dedupKeys.add(dupKey);
        });

        // 5. Sort chronologically (newest first)
        feedItems.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

        if (feedItems.length > 0) {
          return res.json(feedItems.slice(0, limit));
        }

      } catch (err) {
        console.warn("[API PERSONAL FEED] Database personal/global feed failed, using local fallback...", err);
      }
    }

    // Fallback: local list
    const localList = getLocalActivities();
    // Normalize fallback items to include followed tags
    const processedLocal = localList.map((act: any) => {
      const isFollowed = followingIds.includes(act.user_id) || followingIds.includes(act.target_id);
      return {
        ...act,
        is_followed: isFollowed,
        is_suggestion: !isFollowed
      };
    });

    if (followingIds.length > 0) {
      // Prioritize followed ones, then append suggestions
      const followed = processedLocal.filter((act: any) => act.is_followed);
      const suggestions = processedLocal.filter((act: any) => !act.is_followed);
      const mergedLocal = [...followed, ...suggestions];
      return res.json(mergedLocal.slice(0, limit));
    }

    return res.json(processedLocal.slice(0, limit));
  });

  // GET feed only for a specific user/producer profile
  app.get("/api/activity/profile/:username", async (req, res) => {
    const username = req.params.username.toLowerCase();
    const limit = Math.min(parseInt(req.query.limit as string) || 15, 30);
    const sb = getSupabase();

    if (sb) {
      try {
        const { data, error } = await sb
          .from("activity_feed")
          .select("*")
          .or(`username.ilike.${username},target_title.ilike.${username}`)
          .order("created_at", { ascending: false })
          .limit(limit);

        if (!error && data && data.length > 0) {
          const normalized = data.map((item: any) => ({
            ...item,
            actor_name: item.metadata?.actor_name || item.username || "Membro",
            actor_username: item.username,
            actor_avatar: item.avatar_url,
            target_cover: item.metadata?.target_cover || null
          }));
          return res.json(normalized);
        }
      } catch (err) {
        console.warn("[API PROFILE FEED] DB lookup fallback to JSON logs:", err);
      }
    }

    // Local filter fallback
    const local = getLocalActivities();
    const filtered = local.filter(
      (act: any) =>
        (act.username && act.username.toLowerCase() === username) ||
        (act.actor_username && act.actor_username.toLowerCase() === username) ||
        (act.target_title && act.target_title.toLowerCase().includes(username))
    );
    return res.json(filtered.slice(0, limit));
  });

  // POST endpoint to manually create generic social events with strict typing protection
  app.post("/api/activity/create", async (req, res) => {
    const body = req.body;
    if (!body.type || !body.actor_username) {
      return res.status(400).json({ error: "Missing type or actor_username parameter" });
    }
    try {
      const result = await commitActivity(body);
      return res.json({ success: true, data: result });
    } catch (err: any) {
      console.error("[API SOCIAL CREATE] Failed to commit activity event:", err);
      return res.status(500).json({ error: err.message || String(err) });
    }
  });

  // --- COLLABORATIONS ENDPOINTS (COLLAB SPLITS) ---

  // Private file for redundant collaborators storage
  const COLLABORATORS_FILE = path.join(process.cwd(), "beat_collaborators.json");

  function readCollaborators() {
    try {
      if (fs.existsSync(COLLABORATORS_FILE)) {
        return JSON.parse(fs.readFileSync(COLLABORATORS_FILE, "utf-8"));
      }
    } catch (err) {
      console.error("Error reading collaborators:", err);
    }
    return [];
  }

  function writeCollaborators(data: any[]) {
    try {
      fs.writeFileSync(COLLABORATORS_FILE, JSON.stringify(data, null, 2), "utf-8");
    } catch (err) {
      console.error("Error writing collaborators:", err);
    }
  }

  // 1. Get collaborators of a beat
  app.get("/api/collabs/beat/:beatId", async (req, res) => {
    const beatId = Number(req.params.beatId);
    if (isNaN(beatId)) {
      return res.status(400).json({ error: "beatId inválido" });
    }
    const supabase = getSupabase();
    if (!supabase) return res.status(500).json({ error: "Base de dados não inicializada" });

    try {
      // Try to query Supabase
      const { data, error } = await supabase
        .from("beat_collaborators")
        .select("*, profiles:producer_id(id, artistic_name, email, username)")
        .eq("beat_id", beatId);

      if (!error && data && data.length > 0) {
        return res.json({ success: true, data });
      }
    } catch (e) {
      console.warn("[COLLABS] Supabase table beat_collaborators select omitted or failed, falling back to local file.", e);
    }

    // Fallback: file reading
    const collabs = readCollaborators();
    const filtered = collabs.filter((c: any) => Number(c.beat_id) === Number(beatId));
    
    // Hydrate fields of profiles from profiles table
    try {
      const results = [];
      for (const item of filtered) {
        const { data: prof } = await supabase
          .from("profiles")
          .select("id, artistic_name, email, username")
          .eq("id", toValidUuid(item.producer_id))
          .single();
        results.push({
          ...item,
          profiles: prof || { id: item.producer_id, artistic_name: "Produtor", email: "", username: "produtor" }
        });
      }
      return res.json({ success: true, data: results });
    } catch (err: any) {
      return res.json({ success: true, data: filtered.map(f => ({ ...f, profiles: { id: f.producer_id, artistic_name: "Produtor", email: "", username: "produtor" } })) });
    }
  });

  // 2. Set collaborators of a beat
  app.post("/api/collabs/beat/:beatId", authenticateUser, async (req: any, res) => {
    const beatId = Number(req.params.beatId);
    const { collaborators } = req.body; // Array list of { producer_id, split_percentage }
    if (isNaN(beatId)) {
      return res.status(400).json({ error: "beatId inválido" });
    }
    if (!Array.isArray(collaborators)) {
      return res.status(400).json({ error: "colaboradores deve ser um array" });
    }

    // Validation: make sure splits sum up to exactly 100%
    const validCollabs = collaborators.filter(c => c.producer_id && Number(c.split_percentage) > 0);
    const totalSplit = validCollabs.reduce((sum, c) => sum + Number(c.split_percentage || 0), 0);
    if (validCollabs.length > 0 && Math.abs(totalSplit - 100) > 0.01) {
      return res.status(400).json({ error: "As percentagens dos colaboradores devem totalizar 100%." });
    }

    const supabase = getSupabase();
    if (!supabase) return res.status(500).json({ error: "Base de dados não inicializada" });

    // Verify ownership of the beat
    try {
      const { data: beat, error: beatErr } = await supabase
        .from("beats")
        .select("producer_id")
        .eq("id", beatId)
        .single();

      if (beatErr || !beat) {
        console.warn(`[COLLABS] Beat verify error or not found for ID ${beatId}:`, beatErr?.message);
        return res.status(404).json({ error: "Beat não encontrado." });
      }

      const ownerId = toValidUuid(beat.producer_id);
      const requesterId = toValidUuid(req.user.id);

      if (ownerId !== requesterId) {
        console.log(`[SECURITY] Unauthorized split modification attempt: User ${requesterId} tried to edit splits for beat ${beatId} owned by ${ownerId}`);
        return res.status(403).json({ error: "Não autorizado a modificar este beat." });
      }
    } catch (e: any) {
      console.error("[SECURITY] Exception during beat collaboration owner check:", e.message);
      return res.status(500).json({ error: "Erro interno ao validar permissões." });
    }

    // Format new entries with UUID ids
    const newEntries = validCollabs.map(c => ({
      id: crypto.randomUUID(),
      beat_id: beatId,
      producer_id: toValidUuid(c.producer_id),
      split_percentage: Number(c.split_percentage),
      created_at: new Date().toISOString()
    }));

    // 1. Try Supabase
    let supabaseSuccess = false;
    try {
      const { error: delError } = await supabase
        .from("beat_collaborators")
        .delete()
        .eq("beat_id", beatId);

      if (!delError) {
        if (newEntries.length > 0) {
          const { error: insError } = await supabase
            .from("beat_collaborators")
            .insert(newEntries);
          if (!insError) {
            supabaseSuccess = true;
          } else {
            console.warn("[COLLABS] Ins error on Supabase:", insError.message);
          }
        } else {
          supabaseSuccess = true;
        }
      } else {
        console.warn("[COLLABS] Del error on Supabase:", delError.message);
      }
    } catch (e: any) {
      console.warn("[COLLABS] Supabase write failed, falling back to JSON:", e.message);
    }

    // 2. Always update local JSON to keep them perfectly in sync and fully redundant
    const allCollabs = readCollaborators();
    const otherCollabs = allCollabs.filter((c: any) => Number(c.beat_id) !== Number(beatId));
    const updatedCollabs = [...otherCollabs, ...newEntries];
    writeCollaborators(updatedCollabs);

    return res.json({ success: true, supabaseSynced: supabaseSuccess, data: newEntries });
  });

  // 3. Get all collaborations of a producer (beats they are collaborator on)
  app.get("/api/collabs/producer/:producerId", async (req, res) => {
    const producerId = toValidUuid(req.params.producerId);
    const supabase = getSupabase();
    if (!supabase) return res.status(500).json({ error: "Base de dados não inicializada" });

    try {
      // Try to query Supabase
      const { data, error } = await supabase
        .from("beat_collaborators")
        .select("*, beats(*)")
        .eq("producer_id", producerId);

      if (!error && data && data.length > 0) {
        return res.json({ success: true, data });
      }
    } catch (e) {
      console.warn("[COLLABS] Supabase select failed:", e);
    }

    // Fallback: read from file
    const collabs = readCollaborators();
    const filtered = collabs.filter((c: any) => toValidUuid(c.producer_id) === producerId);

    // Hydrate beats detailed profiles
    const results = [];
    for (const item of filtered) {
      const { data: beat } = await supabase
        .from("beats")
        .select("*")
        .eq("id", Number(item.beat_id))
        .single();
      if (beat) {
        results.push({
          ...item,
          beats: beat
        });
      }
    }
    return res.json({ success: true, data: results });
  });

  // 4. Get list of producers for collaborator selector dropdown
  app.get("/api/collabs/producers", async (req, res) => {
    const supabase = getSupabase();
    if (!supabase) return res.status(500).json({ error: "Base de dados não inicializada" });
    
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, artistic_name, username, email, avatar_url, display_name")
        .in("role", ["producer", "seller", "admin"]);
      if (!error && data) {
        return res.json({ success: true, data });
      }
      return res.status(500).json({ error: error?.message || "Erro desconhecido ao carregar produtores" });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || "Erro desconhecido ao carregar produtores" });
    }
  });

  // --- REAL SOCIAL FOLLOWS & PLAY METRICS ENDPOINTS ---

  // Simple in-memory storage fallback and anti-spam protection maps
  const rateLimitPlays = new Map<string, number>();
  const fallbackPlayEvents: any[] = [];
  const fallbackBeatPlaysCount = new Map<string, number>();

  // Robust file-based persistent play caching for local durability
  try {
    const cachePath = path.join(process.cwd(), "plays_count_cache.json");
    if (fs.existsSync(cachePath)) {
      const data = JSON.parse(fs.readFileSync(cachePath, "utf-8"));
      Object.entries(data).forEach(([key, val]) => {
        fallbackBeatPlaysCount.set(key, Number(val));
      });
      console.log(`[PLAY SERVICE BACKEND] Loaded ${fallbackBeatPlaysCount.size} persistent play counts from disk.`);
    } else {
      console.log("[PLAY SERVICE BACKEND] No persistent plays count disk cache found. Initializing empty.");
    }
  } catch (err: any) {
    console.warn("[PLAY SERVICE BACKEND] Exception loading disk plays cache (ignored):", err.message);
  }

  const savePlayCountsCache = () => {
    try {
      const cachePath = path.join(process.cwd(), "plays_count_cache.json");
      const obj: Record<string, number> = {};
      fallbackBeatPlaysCount.forEach((val, key) => {
        obj[key] = val;
      });
      fs.writeFileSync(cachePath, JSON.stringify(obj, null, 2), "utf-8");
      console.log(`[PLAY SERVICE BACKEND] Persisted ${fallbackBeatPlaysCount.size} play counts to disk.`);
    } catch (err: any) {
      console.warn("[PLAY SERVICE BACKEND] Exception saving disk plays cache (ignored):", err.message);
    }
  };

  // API endpoint for frontend to load play counts map
  app.get("/api/plays/counts", (req, res) => {
    const counts: Record<string, number> = {};
    fallbackBeatPlaysCount.forEach((val, key) => {
      counts[key] = val;
    });
    return res.json(counts);
  });

  // 1. Follow a seller/producer
  app.post("/api/social/follow", apiRateLimiter(20, 60 * 1000), async (req, res) => {
    const { followerId, followingId, followerName, followerUsername, followerAvatar } = req.body;
    if (!followerId || !followingId) {
      return res.status(400).json({ error: "Parâmetros followerId e followingId são obrigatórios." });
    }

    if (followerId === followingId) {
      return res.status(400).json({ error: "Não podes seguir a ti próprio!" });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(500).json({ error: "Banco de dados não configurado." });
    }

    // Trigger Social Activity Event creation automatically
    try {
      let targetProducerName = "Produtor";
      const { data: pData } = await supabase.from("profiles").select("artistic_name, display_name, username").eq("id", followingId).maybeSingle();
      if (pData) {
        targetProducerName = pData.artistic_name || pData.display_name || pData.username || "Produtor";
      }

      await commitActivity({
        user_id: followerId,
        type: "follow",
        actor_name: followerName || "Utilizador",
        actor_username: followerUsername || (followerName ? followerName.toLowerCase().replace(/\s+/g, "") : "utilizador"),
        actor_avatar: followerAvatar || null,
        target_id: followingId,
        target_title: targetProducerName,
        metadata: {
          followerId,
          followingId
        }
      });
    } catch (actErr) {
      console.warn("Bypassed activity follow trigger on exception:", actErr);
    }

    try {
      // Insert into followers relation
      const { error } = await supabase
        .from("followers")
        .insert([{ follower_id: followerId, following_id: followingId }]);

      if (error) {
        if (error.code === "23505" || error.message?.includes("duplicate key")) {
          // Already following relation exists, ignore and count as success
          console.log(`[FOLLOW DE-DUP] Follow relation already exists for follower ${followerId} -> following ${followingId}`);
        } else {
          return res.status(500).json({ error: error.message });
        }
      }

      // Automatically trigger real notification so they get notified instantly
      try {
        let finalAvatarUrl = followerAvatar || null;
        let finalUsername = followerUsername || "";
        let finalName = followerName || "";

        try {
          const { data: followerProfile } = await supabase
            .from("profiles")
            .select("avatar_url, username, artistic_name, display_name")
            .eq("id", followerId)
            .maybeSingle();

          if (followerProfile) {
            if (followerProfile.avatar_url) finalAvatarUrl = followerProfile.avatar_url;
            if (followerProfile.username) finalUsername = followerProfile.username;
            const nameUsed = followerProfile.artistic_name || followerProfile.display_name || followerProfile.username;
            if (nameUsed) finalName = nameUsed;
          }
        } catch (dbErr) {
          console.warn("Could not query follower profile details:", dbErr);
        }

        await supabase.from("notifications").insert([{
          user_id: followingId,
          type: "follower",
          title: "Novo Seguidor Real",
          message: `@${finalName || 'Alguém'} começou a seguir-te!`,
          read: false,
          metadata: {
            follower_id: followerId,
            follower_username: finalUsername || (finalName ? finalName.toLowerCase().replace(/\s+/g, "") : ""),
            sender_avatar: finalAvatarUrl,
            avatar_url: finalAvatarUrl
          }
        }]);
      } catch (notifErr) {
        console.error("NOTIFICATION UPDATE ERROR", notifErr);
      }

      return res.json({ success: true });
    } catch (err: any) {
      console.error("Exception in follow endpoint:", err);
      return res.status(500).json({ error: err.message || "Erro interno do servidor ao seguir" });
    }
  });

  // --- REAL COMMENTS SYSTEM ENDPOINTS ---

  const COMMENTS_FILE = path.join("/tmp", "comments.json");

  // Helper to read local comments
  function getLocalComments(): any[] {
    try {
      if (!fs.existsSync(COMMENTS_FILE)) {
        fs.writeFileSync(COMMENTS_FILE, JSON.stringify([], null, 2));
        return [];
      }
      const raw = fs.readFileSync(COMMENTS_FILE, "utf-8");
      return JSON.parse(raw) || [];
    } catch (e) {
      console.error("[COMMENTS ENGINE] Error reading local comments:", e);
      return [];
    }
  }

  // Helper to save local comments
  function saveLocalComments(comments: any[]) {
    try {
      fs.writeFileSync(COMMENTS_FILE, JSON.stringify(comments, null, 2));
    } catch (e) {
      console.error("[COMMENTS ENGINE] Error saving local comments:", e);
    }
  }

  // GET Comments for a specific beat
  app.get("/api/comments/:beatId", async (req, res) => {
    const { beatId } = req.params;
    if (!beatId) return res.status(400).json({ error: "Missing beatId parameter" });

    const supabase = getSupabase();
    let commentsList: any[] = [];
    let isSupabaseSuccess = false;

    if (supabase) {
      try {
        const { data, error } = await supabase
          .from("comments")
          .select("*")
          .eq("beat_id", String(beatId))
          .order("created_at", { ascending: false });

        if (!error && data) {
          commentsList = data;
          isSupabaseSuccess = true;
        } else if (error) {
          const isTableMissing = error.code === "42P01" || error.code === "PGRST205" || error.message?.includes("relation") || error.message?.includes("Could not find the table");
          if (!isTableMissing) {
            console.error("[COMMENTS ENGINE] Supabase select error:", error.message);
          }
        }
      } catch (err: any) {
        console.warn("[COMMENTS ENGINE] Exception querying comments table:", err.message || err);
      }
    }

    // If Supabase failed or table is missing, use local JSON fallback
    if (!isSupabaseSuccess) {
      const allLocal = getLocalComments();
      commentsList = allLocal
        .filter((c: any) => String(c.beat_id) === String(beatId))
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }

    // Fetch profile details for all referenced users in comments list
    if (commentsList.length > 0) {
      const userIds = Array.from(new Set(commentsList.map(c => c.user_id).filter(id => id)));
      let profilesMap = new Map<string, any>();

      if (supabase && userIds.length > 0) {
        try {
          const { data: profiles, error: profError } = await supabase
            .from("profiles")
            .select("id, username, artistic_name, display_name, avatar_url, is_verified")
            .in("id", userIds);

          if (!profError && profiles) {
            profiles.forEach((p: any) => {
              profilesMap.set(p.id, p);
            });
          }
        } catch (e) {
          console.warn("[COMMENTS ENGINE] Error fetching comment user profiles:", e);
        }
      }

      // Attach profile metadata to comments
      commentsList = commentsList.map((comment: any) => {
        const profile = profilesMap.get(comment.user_id);
        return {
          ...comment,
          likes: comment.likes || [],
          reactions: comment.reactions || {},
          is_pinned: comment.is_pinned || false,
          author_name: profile?.artistic_name || profile?.display_name || "Membro",
          author_username: profile?.username || "membro",
          author_avatar: profile?.avatar_url || null,
          is_verified: profile?.is_verified === true
        };
      });
    }

    return res.json({ success: true, comments: commentsList });
  });

  // POST Create comment or reply
  app.post("/api/comments", apiRateLimiter(15, 60 * 1000), async (req, res) => {
    const { beat_id, user_id, content, parent_id } = req.body;
    if (!beat_id || !user_id || !content) {
      return res.status(400).json({ error: "Missing required parameters: beat_id, user_id, content" });
    }

    const supabase = getSupabase();
    let authorProfile: any = null;

    // Fetch user profile info first so we have name/avatar for notifications/activities
    if (supabase) {
      try {
        const { data: profile } = await supabase
          .from("profiles")
          .select("id, username, artistic_name, display_name, avatar_url, is_verified")
          .eq("id", user_id)
          .maybeSingle();
        if (profile) {
          authorProfile = profile;
        }
      } catch (err) {
        console.warn("[COMMENTS ENGINE] Error fetching author profile:", err);
      }
    }

    const commentId = crypto.randomUUID();
    const newCommentObj = {
      id: commentId,
      beat_id: String(beat_id),
      user_id: user_id,
      parent_id: parent_id || null,
      content: content,
      timestamp_seconds: req.body.timestamp_seconds !== undefined && req.body.timestamp_seconds !== null ? Number(req.body.timestamp_seconds) : null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    let isSupabaseSuccess = false;

    if (supabase) {
      try {
        const { error } = await supabase
          .from("comments")
          .insert([newCommentObj]);

        if (!error) {
          isSupabaseSuccess = true;
          console.log("[COMMENTS ENGINE] Comment saved successfully to Supabase.");
        } else {
          const isTableMissing = error.code === "42P01" || error.code === "PGRST205" || error.message?.includes("relation") || error.message?.includes("Could not find the table");
          if (!isTableMissing) {
            console.error("[COMMENTS ENGINE] Supabase insert comments error:", error.message);
          }
        }
      } catch (err: any) {
        console.warn("[COMMENTS ENGINE] Exception inserting comment:", err.message || err);
      }
    }

    // Always keep local JSON updated/as backup/primary fallback
    const allLocal = getLocalComments();
    allLocal.push(newCommentObj);
    saveLocalComments(allLocal);

    // Send down comment details decorated with profile details right away
    const clientComment = {
      ...newCommentObj,
      author_name: authorProfile?.artistic_name || authorProfile?.display_name || "Membro",
      author_username: authorProfile?.username || "membro",
      author_avatar: authorProfile?.avatar_url || null,
      is_verified: authorProfile?.is_verified === true
    };

    // Broadcast comment creation via socket for instant live updates
    io.emit("new_comment", clientComment);

    // Fetch target beat dynamic profile to generate activities/notifications
    let beatTitle = "Beat";
    let beatProducerId: string | null = null;

    if (supabase) {
      try {
        const { data: beat } = await supabase
          .from("beats")
          .select("title, producer_id")
          .eq("id", isNaN(Number(beat_id)) ? beat_id : Number(beat_id))
          .maybeSingle();

        if (beat) {
          beatTitle = beat.title;
          beatProducerId = beat.producer_id;
        }
      } catch (err) {
        console.warn("[COMMENTS ENGINE] Error fetching beat details for comment trigger:", err);
      }
    }

    // 1. Trigger user notifications (Supabase writes/falls back silently)
    if (supabase) {
      try {
        const notifierName = authorProfile?.artistic_name || authorProfile?.display_name || `@${authorProfile?.username || 'Alguém'}`;
        
        if (parent_id) {
          // This is a thread reply - notify the owner of the comment being replied to
          const allComments = isSupabaseSuccess ? [] : allLocal;
          let parentUserId: string | null = null;

          if (isSupabaseSuccess) {
            const { data: parentComment } = await supabase
              .from("comments")
              .select("user_id")
              .eq("id", parent_id)
              .maybeSingle();
            if (parentComment) parentUserId = parentComment.user_id;
          } else {
            const parentComment = allComments.find(c => c.id === parent_id);
            if (parentComment) parentUserId = parentComment.user_id;
          }

          if (parentUserId && parentUserId !== user_id) {
            await supabase.from("notifications").insert([{
              user_id: parentUserId,
              type: "comment",
              title: "Nova resposta",
              message: `${notifierName} respondeu ao teu comentário em '${beatTitle}'!`,
              read: false,
              metadata: { beat_id: String(beat_id), comment_id: commentId }
            }]);
          }
        } else {
          // Parent comment - notify the beat producer/owner
          if (beatProducerId && beatProducerId !== user_id) {
            const tSecs = req.body.timestamp_seconds !== undefined && req.body.timestamp_seconds !== null ? Number(req.body.timestamp_seconds) : null;
            let noteMsg = `${notifierName} comentou no teu beat '${beatTitle}'!`;
            if (tSecs !== null) {
              const m = Math.floor(tSecs / 60);
              const s = Math.floor(tSecs % 60);
              noteMsg = `${notifierName} comentou aos ${m}:${s < 10 ? "0" : ""}${s} do teu beat '${beatTitle}'!`;
            }
            await supabase.from("notifications").insert([{
              user_id: beatProducerId,
              type: "comment",
              title: "Novo comentário no teu beat",
              message: noteMsg,
              read: false,
              metadata: { beat_id: String(beat_id), comment_id: commentId }
            }]);
          }
        }

        // 1b. Trigger mentions notifications e.g. @username
        const mentionsList = content.match(/@([a-zA-Z0-9_\-]+)/g);
        if (mentionsList) {
          const notifierName = authorProfile?.artistic_name || authorProfile?.display_name || `@${authorProfile?.username || 'Alguém'}`;
          for (const m of mentionsList) {
            const targetUsername = m.substring(1).trim();
            if (targetUsername) {
              try {
                const { data: targetProfile } = await supabase
                  .from("profiles")
                  .select("id")
                  .eq("username", targetUsername)
                  .maybeSingle();

                if (targetProfile && targetProfile.id !== user_id) {
                  await supabase.from("notifications").insert([{
                    user_id: targetProfile.id,
                    type: "comment",
                    title: "Comentário com menção! 💬",
                    message: `${notifierName} mencionou-te num comentário em '${beatTitle}': "${content}"`,
                    read: false,
                    metadata: { beat_id: String(beat_id), comment_id: commentId }
                  }]);
                  console.log(`[MENTIONS] Dispatched notification for username ${targetUsername}`);
                }
              } catch (mentionErr) {
                console.warn("[MENTIONS] Error parsing/notifying mention:", mentionErr);
              }
            }
          }
        }
      } catch (notifErr) {
        console.error("NOTIFICATION UPDATE ERROR", notifErr);
      }
    }

    // 2. Commit social feed activity for standard parent comments
    if (!parent_id) {
      try {
        const tSecs = req.body.timestamp_seconds !== undefined && req.body.timestamp_seconds !== null ? Number(req.body.timestamp_seconds) : null;
        await commitActivity({
          user_id: user_id,
          type: "comment",
          actor_name: authorProfile?.artistic_name || authorProfile?.display_name || "Membro",
          actor_username: authorProfile?.username || "membro",
          actor_avatar: authorProfile?.avatar_url || null,
          target_id: String(beat_id),
          target_title: beatTitle,
          metadata: {
            comment: content,
            timestamp_seconds: tSecs
          }
        });
      } catch (actErr) {
        console.warn("[COMMENTS ENGINE] Activity creation exception:", actErr);
      }
    }

    return res.json({ success: true, comment: clientComment });
  });

  // LIKE a comment
  app.post("/api/comments/:commentId/like", async (req, res) => {
    const { commentId } = req.params;
    const { user_id } = req.body;
    if (!commentId || !user_id) {
      return res.status(400).json({ error: "Missing required parameters: commentId, user_id" });
    }

    const allLocal = getLocalComments();
    const comment = allLocal.find(c => c.id === commentId);
    let likes = [];

    if (comment) {
      if (!comment.likes) comment.likes = [];
      const index = comment.likes.indexOf(user_id);
      if (index > -1) {
        comment.likes.splice(index, 1);
      } else {
        comment.likes.push(user_id);
      }
      likes = comment.likes;
      saveLocalComments(allLocal);
    }

    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data } = await supabase
          .from("comments")
          .select("likes")
          .eq("id", commentId)
          .maybeSingle();
        
        let dbLikes = data?.likes || [];
        const index = dbLikes.indexOf(user_id);
        if (index > -1) {
          dbLikes.splice(index, 1);
        } else {
          dbLikes.push(user_id);
        }
        await supabase
          .from("comments")
          .update({ likes: dbLikes })
          .eq("id", commentId);
        likes = dbLikes;
      } catch (err) {
        console.warn("[COMMENTS ENGINE] Supabase likes write skipped/failed:", err);
      }
    }

    io.emit("comment_updated", { id: commentId, likes });
    return res.json({ success: true, likes });
  });

  // REACT to a comment
  app.post("/api/comments/:commentId/react", async (req, res) => {
    const { commentId } = req.params;
    const { user_id, emoji } = req.body;
    if (!commentId || !user_id || !emoji) {
      return res.status(400).json({ error: "Missing required parameters: commentId, user_id, emoji" });
    }

    const allLocal = getLocalComments();
    const comment = allLocal.find(c => c.id === commentId);
    let reactions = {};

    if (comment) {
      if (!comment.reactions) comment.reactions = {};
      if (!comment.reactions[emoji]) comment.reactions[emoji] = [];
      const index = comment.reactions[emoji].indexOf(user_id);
      if (index > -1) {
        comment.reactions[emoji].splice(index, 1);
      } else {
        comment.reactions[emoji].push(user_id);
      }
      reactions = comment.reactions;
      saveLocalComments(allLocal);
    }

    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data } = await supabase
          .from("comments")
          .select("reactions")
          .eq("id", commentId)
          .maybeSingle();
        
        let dbReactions = data?.reactions || {};
        if (!dbReactions[emoji]) dbReactions[emoji] = [];
        const index = dbReactions[emoji].indexOf(user_id);
        if (index > -1) {
          dbReactions[emoji].splice(index, 1);
        } else {
          dbReactions[emoji].push(user_id);
        }
        await supabase
          .from("comments")
          .update({ reactions: dbReactions })
          .eq("id", commentId);
        reactions = dbReactions;
      } catch (err) {
        console.warn("[COMMENTS ENGINE] Supabase reactions write skipped/failed:", err);
      }
    }

    io.emit("comment_updated", { id: commentId, reactions });
    return res.json({ success: true, reactions });
  });

  // PIN / UNPIN a comment
  app.post("/api/comments/:commentId/pin", async (req, res) => {
    const { commentId } = req.params;
    const { producer_id } = req.body;
    if (!commentId || !producer_id) {
      return res.status(400).json({ error: "Missing required parameters: commentId, producer_id" });
    }

    const allLocal = getLocalComments();
    const comment = allLocal.find(c => c.id === commentId);
    let is_pinned = false;

    if (comment) {
      const prevPinned = comment.is_pinned || false;
      comment.is_pinned = !prevPinned;
      is_pinned = comment.is_pinned;
      
      if (is_pinned) {
        allLocal.forEach(c => {
          if (c.beat_id === comment.beat_id && c.id !== commentId) {
            c.is_pinned = false;
          }
        });
      }
      saveLocalComments(allLocal);
    }

    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data } = await supabase
          .from("comments")
          .select("is_pinned, beat_id")
          .eq("id", commentId)
          .maybeSingle();
        
        const toggled = !data?.is_pinned;
        if (toggled && data?.beat_id) {
          await supabase
            .from("comments")
            .update({ is_pinned: false })
            .eq("beat_id", data.beat_id);
        }
        await supabase
          .from("comments")
          .update({ is_pinned: toggled })
          .eq("id", commentId);
        is_pinned = toggled;
      } catch (err) {
        console.warn("[COMMENTS ENGINE] Supabase pin write skipped/failed:", err);
      }
    }

    io.emit("comment_updated", { id: commentId, is_pinned });
    return res.json({ success: true, is_pinned });
  });

  // DELETE a comment
  app.delete("/api/comments/:commentId", async (req, res) => {
    const { commentId } = req.params;
    const { userId } = req.query; // Auth context user ID to enforce rules

    if (!commentId || !userId) {
      return res.status(400).json({ error: "Missing required parameters: commentId, userId" });
    }

    const supabase = getSupabase();
    let isSupabaseSuccess = false;
    let commentToDelete: any = null;

    // Find the comment first so we can check permissions (comment author OR beat owner)
    const allLocal = getLocalComments();
    commentToDelete = allLocal.find(c => c.id === commentId);

    if (supabase) {
      try {
        const { data } = await supabase
          .from("comments")
          .select("*")
          .eq("id", commentId)
          .maybeSingle();
        if (data) commentToDelete = data;
      } catch (err) {
        console.warn("[COMMENTS ENGINE] Error fetching comment for delete verification:", err);
      }
    }

    if (!commentToDelete) {
      return res.status(404).json({ error: "Comment not found" });
    }

    // Authorization Check:
    // Is user the comment author?
    let isAuthorized = String(commentToDelete.user_id) === String(userId);

    // Is user the beat owner?
    if (!isAuthorized && supabase) {
      try {
        const { data: beat } = await supabase
          .from("beats")
          .select("producer_id")
          .eq("id", isNaN(Number(commentToDelete.beat_id)) ? commentToDelete.beat_id : Number(commentToDelete.beat_id))
          .maybeSingle();

        if (beat && String(beat.producer_id) === String(userId)) {
          isAuthorized = true;
        }
      } catch (err) {
        console.warn("[COMMENTS ENGINE] Error fetching beat owner for deletion check:", err);
      }
    }

    if (!isAuthorized) {
      return res.status(403).json({ error: "No permission to delete this comment" });
    }

    // Delete matches from Supabase
    if (supabase) {
      try {
        const { error } = await supabase
          .from("comments")
          .delete()
          .eq("id", commentId);

        if (!error) {
          isSupabaseSuccess = true;
          console.log("[COMMENTS ENGINE] Comment deleted from Supabase.");
        }
      } catch (err: any) {
        console.warn("[COMMENTS ENGINE] Exception deleting from Supabase:", err.message || err);
      }
    }

    // Sync deletion to local JSON
    const updatedLocal = allLocal.filter(c => c.id !== commentId && c.parent_id !== commentId);
    saveLocalComments(updatedLocal);

    // Broadcast deletion
    io.emit("deleted_comment", { commentId });

    return res.json({ success: true, deletedId: commentId });
  });

  // 2. Unfollow a seller/producer
  app.post("/api/social/unfollow", async (req, res) => {
    const { followerId, followingId } = req.body;
    if (!followerId || !followingId) {
      return res.status(400).json({ error: "Parâmetros followerId e followingId são obrigatórios." });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(500).json({ error: "Banco de dados não configurado." });
    }

    try {
      // Delete from follower relation
      const { error } = await supabase
        .from("followers")
        .delete()
        .eq("follower_id", followerId)
        .eq("following_id", followingId);

      if (error) {
        return res.status(500).json({ error: error.message });
      }

      return res.json({ success: true });
    } catch (err: any) {
      console.error("Exception in unfollow endpoint:", err);
      return res.status(500).json({ error: err.message || "Erro interno do servidor ao deixar de seguir" });
    }
  });

  // 3. Is following check query
  app.get("/api/social/is-following", async (req, res) => {
    const { followerId, followingId } = req.query;
    if (!followerId || !followingId) {
      return res.status(400).json({ error: "Missing followerId or followingId" });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.status(500).json({ error: "Banco de dados não configurado." });
    }

    try {
      const { data, error } = await supabase
        .from("followers")
        .select("id")
        .eq("follower_id", followerId)
        .eq("following_id", followingId)
        .maybeSingle();

      if (error) {
        return res.status(500).json({ error: error.message });
      }

      return res.json({ isFollowing: !!data });
    } catch (err: any) {
      console.error("Exception checking follow status:", err);
      return res.status(500).json({ error: err.message || "Erro interno do servidor" });
    }
  });

  // Anti-spam tracker mapping to restrict double-counting to 1 play per 30 minutes
  const playsAntiSpamCache = new Map<string, number>();

  // 4a. Unified, Secure Real Plays Registration Endpoint
  app.post("/api/plays/register", async (req, res) => {
    const { beat_id, played_seconds, session_id, userId } = req.body;

    console.log(`[API PLAYS] Received register play request for beat_id: ${beat_id}, user_id: ${userId}, played_seconds: ${played_seconds}`);

    if (!beat_id) {
      return res.status(400).json({ error: "beat_id é obrigatório." });
    }

    const playedSeconds = parseInt(played_seconds, 10) || 0;
    const ipAddress = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';

    // Simple sha256 hash or replacement for anonymous IP tracing
    let ipHash = "generic_guest";
    try {
      ipHash = crypto.createHash("sha256").update(String(ipAddress)).digest("hex").substring(0, 16);
    } catch (hashErr) {
      ipHash = String(ipAddress).replace(/[^a-zA-Z0-9]/g, "");
    }

    const resolvedSessionId = session_id || "guest_session_" + ipHash;
    const cleanUserId = userId && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(userId) ? userId : null;

    // Handle both integer ids and padded UUIDs gracefully
    let queryBeatDbId: any = beat_id;
    let playEventBeatId: string = beat_id;

    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(beat_id));
    const isInt = /^\d+$/.test(String(beat_id));

    if (isUUID) {
      if (String(beat_id).startsWith("00000000-0000-0000-0000-")) {
        queryBeatDbId = parseInt(String(beat_id).split("-")[4], 10);
      } else {
        queryBeatDbId = beat_id;
      }
      playEventBeatId = String(beat_id);
    } else if (isInt) {
      queryBeatDbId = parseInt(String(beat_id), 10);
      const padded = String(queryBeatDbId).padStart(12, "0");
      playEventBeatId = `00000000-0000-0000-0000-${padded}`;
    } else {
      console.log(`[API PLAYS] Virtual or mock beat tracked: ${beat_id}`);
      return res.json({ success: true, localOnly: true, message: "Play tracked for virtual/mock beat." });
    }

    const supabase = getSupabase();
    if (!supabase) {
      console.log("[API PLAYS] Supabase client is missing. Tracking locally/mock only.");
      return res.json({ success: true, localOnly: true });
    }

    try {
      // Fetch metadata and current play counts of the beat IMMEDIATELY
      let beatInfo = null;
      let hasPlaysCountColumn = true;
      try {
        const { data, error } = await supabase
          .from("beats")
          .select("producer_id, title, plays_count")
          .eq("id", queryBeatDbId)
          .maybeSingle();
        if (error) {
          if (error.message?.includes("plays_count") || error.message?.includes("schema cache") || error.code === "PGRST205") {
            hasPlaysCountColumn = false;
            const { data: fallbackData } = await supabase
              .from("beats")
              .select("producer_id, title")
              .eq("id", queryBeatDbId)
              .maybeSingle();
            beatInfo = fallbackData;
          } else {
            console.warn("[API PLAYS] Error looking up beat info:", error.message);
          }
        } else {
          beatInfo = data;
        }
      } catch (err: any) {
        console.warn("[API PLAYS] Exception during beat lookup:", err.message);
      }

      const producerId = beatInfo?.producer_id || null;
      const beatTitle = beatInfo?.title || "Beat";
      const currentPlaysCount = beatInfo?.plays_count || 0;

      console.log(`[API PLAYS] Current database play count for "${beatTitle}" is: ${currentPlaysCount}`);

      // Build the lock key for security throttle
      const userAntiSpamKey = cleanUserId ? `user:${cleanUserId}` : `session:${resolvedSessionId}:${ipHash}`;
      const antiSpamCacheKey = `${beat_id}:${userAntiSpamKey}`;

      const now = Date.now();
      const lastPlayedTime = playsAntiSpamCache.get(antiSpamCacheKey);

      // Anti-spam validation: 1 play per beat every 1 minute to enable reactive testing
      const ONE_MINUTE_MS = 60 * 1000;
      if (lastPlayedTime && (now - lastPlayedTime < ONE_MINUTE_MS)) {
        console.log(`[API PLAYS] [PLAY ANTI-SPAM MEMORY PREVENTED] Throttled play for beat ${beat_id} and ${userAntiSpamKey}. Returning current count.`);
        return res.json({
          success: true,
          message: "Play event rate-limited. Só é permitido 1 play por beat por minuto.",
          ignored: true,
          plays_count: currentPlaysCount
        });
      }

      // Double-check real database play_events in the last 1 minute for ultimate verification
      const oneMinuteAgo = new Date(Date.now() - ONE_MINUTE_MS).toISOString();
      let dbCheckQuery = supabase
        .from("play_events")
        .select("id")
        .eq("beat_id", queryBeatDbId)
        .gt("created_at", oneMinuteAgo);

      if (cleanUserId) {
        dbCheckQuery = dbCheckQuery.eq("user_id", cleanUserId);
      } else {
        dbCheckQuery = dbCheckQuery.or(`session_id.eq.${resolvedSessionId},ip_hash.eq.${ipHash}`);
      }

      let hasRecentPlay = false;
      let hasPlayEventsTable = true;
      try {
        const { data: dbMatches, error: dbCheckErr } = await dbCheckQuery.limit(1);
        if (dbCheckErr) {
          if (dbCheckErr.message?.includes("play_events") || dbCheckErr.message?.includes("relation") || dbCheckErr.message?.includes("schema cache") || dbCheckErr.code === "PGRST205" || dbCheckErr.code === "42P01") {
            hasPlayEventsTable = false;
          } else {
            console.warn("[API PLAYS] Error checking play_events table:", dbCheckErr.message);
          }
        } else if (dbMatches && dbMatches.length > 0) {
          hasRecentPlay = true;
        }
      } catch (checkErr: any) {
        console.warn("[API PLAYS] Exception checking play_events in DB:", checkErr.message);
        hasPlayEventsTable = false;
      }

      if (!hasPlayEventsTable) {
        const oneMinuteAgoMs = Date.now() - ONE_MINUTE_MS;
        const matchingMemRecent = fallbackPlayEvents.some((evt: any) => {
          if (evt.beat_id !== playEventBeatId) return false;
          if (new Date(evt.created_at).getTime() < oneMinuteAgoMs) return false;
          if (cleanUserId && evt.user_id === cleanUserId) return true;
          if (!cleanUserId) {
            return evt.session_id === resolvedSessionId || evt.ip_hash === ipHash;
          }
          return false;
        });
        if (matchingMemRecent) {
          playsAntiSpamCache.set(antiSpamCacheKey, now);
          console.log(`[API PLAYS] [PLAY ANTI-SPAM MEMORY RECENT] Found matching recent plays in memory. Returning current count.`);
          return res.json({
            success: true,
            message: "Play já registado recentemente em cache.",
            ignored: true,
            plays_count: currentPlaysCount
          });
        }
      } else if (hasRecentPlay) {
        playsAntiSpamCache.set(antiSpamCacheKey, now);
        console.log(`[API PLAYS] [PLAY ANTI-SPAM DB RECENT] Found matching recent plays in table. Returning current count.`);
        return res.json({
          success: true,
          message: "Play já registado recentemente no banco de dados.",
          ignored: true,
          plays_count: currentPlaysCount
        });
      }

      // Record local timestamp
      playsAntiSpamCache.set(antiSpamCacheKey, now);

      // 1. Log play event in our plays tracking table using padded plays identifier
      let loggedToPlayEvents = false;
      if (hasPlayEventsTable) {
        const { error: insertErr } = await supabase
          .from("play_events")
          .insert([{
            beat_id: queryBeatDbId,
            producer_id: producerId,
            user_id: cleanUserId,
            session_id: resolvedSessionId,
            ip_hash: ipHash,
            played_seconds: playedSeconds
          }]);

        if (insertErr) {
          if (insertErr.code === "42P01" || insertErr.message?.includes("relation") || insertErr.message?.includes("schema cache") || insertErr.message?.includes("play_events")) {
            console.info("Table play_events is missing. Logging in memory instead.");
            hasPlayEventsTable = false;
          } else {
            console.info("Info creating insertion on play_events (silenced):", insertErr.message);
          }
        } else {
          loggedToPlayEvents = true;
        }
      }

      if (!loggedToPlayEvents) {
        // Log in fallbackPlayEvents
        fallbackPlayEvents.push({
          id: Math.random().toString(36).substring(2),
          beat_id: playEventBeatId,
          producer_id: producerId,
          user_id: cleanUserId,
          session_id: resolvedSessionId,
          ip_hash: ipHash,
          played_seconds: playedSeconds,
          created_at: new Date().toISOString()
        });
      }

      // Also log into legacy table for backwards-compatibility
      try {
        await supabase
          .from("beat_plays")
          .insert([{
            beat_id: queryBeatDbId,
            user_id: cleanUserId,
            ip_address: String(ipAddress)
          }]);
      } catch (legacyErr) {
        // ignore compat insertion if table is absent
      }

      // 2. Increment column beats.plays_count atomically!
      const keyId = String(queryBeatDbId);
      const currentFallbackCount = fallbackBeatPlaysCount.get(keyId) || 0;
      const dbBasePlays = currentPlaysCount || 0;
      const newPlayCount = Math.max(dbBasePlays, currentFallbackCount) + 1;

      // Always update our local persistent server-side disk cache!
      fallbackBeatPlaysCount.set(keyId, newPlayCount);
      savePlayCountsCache();

      let updatedInDb = false;

      if (hasPlaysCountColumn) {
        // Try the RPC first since it is a secure atomic procedure
        let rpcErr = null;
        try {
          const { error } = await supabase.rpc('increment_beat_plays', {
            beat_id_input: queryBeatDbId
          });
          rpcErr = error;
        } catch (err: any) {
          rpcErr = err;
        }

        if (!rpcErr) {
          updatedInDb = true;
        } else {
          // Safe fallback to direct record sync if RPC is absent
          console.info("[PLAY SERVICE BACKEND] Updating plays_count via direct record sync.");
          const { error: updateErr } = await supabase
            .from("beats")
            .update({ plays_count: newPlayCount })
            .eq("id", queryBeatDbId);

          if (updateErr) {
            if (updateErr.message?.includes("plays_count") || updateErr.message?.includes("schema cache") || updateErr.code === "PGRST205") {
              console.info("Column plays_count is missing. Tracking in memory instead.");
              hasPlaysCountColumn = false;
            } else {
              console.info("Info updating plays_count on beat (silenced):", updateErr.message);
            }
          } else {
            updatedInDb = true;
          }
        }
      }

      // 3. Trigger Real-time Analytics Push via sockets
      try {
        io.emit("beat_play_incremented", { beat_id, plays_count: newPlayCount, producer_id: producerId });
      } catch (ioErr) {
        console.warn("Realtime plays socket broadcast skipped:", ioErr);
      }

      // Trigger social achievement milestones (Section 8)
      if (
        newPlayCount === 1000 ||
        newPlayCount === 5000 ||
        (currentPlaysCount < 1000 && newPlayCount >= 1000) ||
        (currentPlaysCount < 5000 && newPlayCount >= 5000)
      ) {
        try {
          const formattedScale = newPlayCount >= 5000 ? "5.000" : "1.000";
          await commitActivity({
            type: "trending_spike",
            username: "batukada",
            target_title: beatTitle,
            target_id: producerId,
            parent_id: beat_id,
            message: `🔥 "${beatTitle}" ultrapassou ${formattedScale} plays! Parabéns! 🥁`,
            metadata: {
              beat_id: beat_id,
              plays_count: newPlayCount
            }
          });
        } catch (feedErr) {
          console.warn("Activity milestone creation skipped silently:", feedErr);
        }
      }

      return res.json({ success: true, message: "Play registado com sucesso", plays_count: newPlayCount });
    } catch (err: any) {
      console.error("Exception in unified plays register:", err);
      return res.status(500).json({ error: err.message || String(err) });
    }
  });

  // 4b. Legacy Beat Play compatibility endpoint (maps directly to the unified registration logic)
  app.post("/api/beats/:id/play", async (req, res) => {
    const beatId = req.params.id;
    const { userId, session_id } = req.body;
    
    // Format request parameters and forward to the unified schema
    req.body.beat_id = beatId;
    req.body.played_seconds = req.body.played_seconds || 15;
    req.body.session_id = session_id || req.body.sessionId;
    
    // Redirect internal code flow internally
    const url = `/api/plays/register`;
    const siteUrl = getExpandedSiteUrl(req);
    const response = await fetch(`${siteUrl}${url}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req.body)
    });
    
    if (response.ok) {
      const respData = await response.json();
      return res.json(respData);
    }
    
    return res.json({ success: true, message: "Fallback legacy tracked local-only" });
  });

  // 5. Get Aggregate Statistics for Producer profile dynamically from actual SQL relations
  app.get("/api/social/stats/:id", async (req, res) => {
    const producerId = req.params.id;
    const supabase = getSupabase();
    if (!supabase) {
      return res.json({ followers: 0, totalPlays: 0, likes_count: 0 });
    }

    try {
      // Select beats by producer
      const { data: beats } = await supabase.from("beats").select("id").eq("producer_id", producerId);
      const beatIds = (beats || []).map(b => b.id);

      let followersCount = 0;
      let playsCount = 0;
      let likesCount = 0;

      // Real Follows query
      try {
        const { count: followersRes, error: fErr } = await supabase
          .from("followers")
          .select("id", { count: "exact", head: true })
          .eq("following_id", producerId);
        if (!fErr && followersRes !== null) {
          followersCount = followersRes;
        }
      } catch (e) {
        console.error("Error querying followers counts:", e);
      }

      let uniqueListeners = 0;
      let retentionRate = 65; // realistic default baseline
      let replayRate = 1.0;    // realistic default baseline

      // Real Plays count via play_events match, with fallback compatibility
      if (beatIds.length > 0) {
        let playsCountFromEvents = 0;
        try {
          const { count: peCount, error: peErr } = await supabase
            .from("play_events")
            .select("id", { count: "exact", head: true })
            .in("beat_id", beatIds);
          if (!peErr && peCount !== null) {
            playsCountFromEvents = peCount;
          }
        } catch (peE) {
          // ignore error, fall back gracefully
        }

        // Add matching fallback play events count
        try {
          const memCount = fallbackPlayEvents.filter((ev: any) => beatIds.includes(ev.beat_id)).length;
          playsCountFromEvents += memCount;
        } catch (e) {}

        let playsCountFromOld = 0;
        try {
          const { count: bCount, error: bErr } = await supabase
            .from("beat_plays")
            .select("id", { count: "exact", head: true })
            .in("beat_id", beatIds);
          if (!bErr && bCount !== null) {
            playsCountFromOld = bCount;
          }
        } catch (bE) {}

        // Combine compat counts
        playsCount = Math.max(playsCountFromEvents, playsCountFromOld) || (playsCountFromEvents + playsCountFromOld) || 0;

        // Calculate advanced analytics metrics from the play_events records
        try {
          let allEvents: any[] = [];
          
          try {
            const { data, error: eventsErr } = await supabase
              .from("play_events")
              .select("user_id, session_id, ip_hash, played_seconds")
              .in("beat_id", beatIds);
            
            if (!eventsErr && data) {
              allEvents = data;
            }
          } catch (e) {
            // failed to load from db table
          }

          // Merge local memory fallback events for statistics precision
          try {
            const memEvents = fallbackPlayEvents.filter((ev: any) => beatIds.includes(ev.beat_id));
            allEvents = [...allEvents, ...memEvents];
          } catch (e) {}
          
          if (allEvents && allEvents.length > 0) {
            const listenersSet = new Set<string>();
            let processedForRetention = 0;
            let highRetentionCount = 0;

            allEvents.forEach((ev: any) => {
              const listenerKey = ev.user_id || `${ev.session_id}:${ev.ip_hash}`;
              listenersSet.add(listenerKey);

              if (ev.played_seconds !== undefined) {
                processedForRetention++;
                if (ev.played_seconds >= 30) {
                  highRetentionCount++;
                }
              }
            });

            uniqueListeners = listenersSet.size;
            if (processedForRetention > 0) {
              retentionRate = Math.round((highRetentionCount / processedForRetention) * 100);
            }
            replayRate = Number((allEvents.length / Math.max(1, uniqueListeners)).toFixed(2));
          } else {
            // realistic mockup mapping
            uniqueListeners = Math.max(1, Math.round(playsCount * 0.78));
            replayRate = Number((playsCount / uniqueListeners).toFixed(1)) || 1.1;
          }
        } catch (err) {
          console.warn("Could not calculate detailed play metrics:", err);
          uniqueListeners = Math.max(1, Math.round(playsCount * 0.78));
        }

        // Real Likes received
        const { count: likesRes } = await supabase
          .from("favorites")
          .select("id", { count: "exact", head: true })
          .in("beat_id", beatIds);
        likesCount = likesRes || 0;
      }

      return res.json({
        followers: followersCount,
        totalPlays: playsCount,
        likes_count: likesCount,
        totalBeats: beatIds.length,
        uniqueListeners: uniqueListeners,
        retentionRate: retentionRate,
        replayRate: replayRate
      });
    } catch (err) {
      console.error("Error calculating statistical summary on server:", err);
      return res.json({ followers: 0, totalPlays: 0, likes_count: 0 });
    }
  });

  // Track Real-time Analytics Event (Anti-spam rate limiting is done client-side and server-side)
  app.post("/api/analytics/event", async (req, res) => {
    const { id, producer_id, beat_id, event_type, user_id, amount } = req.body;
    if (!producer_id || !event_type) {
      return res.status(400).json({ error: "producer_id e event_type são obrigatórios." });
    }

    const supabase = getSupabase();
    if (!supabase) {
      return res.json({ success: true, localOnly: true });
    }

    try {
      // Clean target variables
      const isPropUUID = (v: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
      const cleanProdId = isPropUUID(producer_id) ? producer_id : null;
      let cleanBeatId = beat_id;
      if (beat_id && typeof beat_id === 'string' && !isPropUUID(beat_id)) {
        // If integer beat ID, leave as parameter if schema allows, or clean
        cleanBeatId = null; 
      }
      const cleanUserId = user_id && isPropUUID(user_id) ? user_id : null;

      if (!cleanProdId) {
        return res.json({ success: true, localOnly: true, message: "Non-standard producer ID, logged visually on client." });
      }

      const { error } = await supabase
        .from("analytics_events")
        .insert([{
          id: id || Math.random().toString(36).substring(2, 15),
          producer_id: cleanProdId,
          beat_id: cleanBeatId,
          event_type: event_type,
          user_id: cleanUserId,
          amount: amount ? Number(amount) : null
        }]);

      if (error) {
        // Suppress and handle gracefully if table is missing or columns mismatch
        if (error.code === "42P01" || error.code === "PGRST205" || error.message?.includes("relation") || error.message?.includes("schema cache") || error.message?.includes("does not exist")) {
          // Normal behavior on dynamic sandboxes: fallback to local logs
        } else {
          console.warn("[SERVER ANALYTICS] Notice:", error.message);
        }
      }

      return res.json({ success: true });
    } catch (err: any) {
      console.error("Exception logging analytics event on server:", err);
      return res.json({ success: true, localError: true });
    }
  });

  // ==========================================
  // STABILITY, LOGS, RECOVERY & HEALTH ROUTES
  // ==========================================

  // Endpoint to record client-side logs (frontend errors, player failures, track plays crashes)
  app.post("/api/system/logs/add", (req, res) => {
    const { type, message, severity, route, userId, stack, details } = req.body;
    logSystemEvent(type || "frontend_error", message || "No message supplied", severity || "error", {
      route,
      userId,
      stack,
      ...details
    });
    res.json({ success: true });
  });

  // Get all logs (requires Admin)
  app.get("/api/system/logs", requireAdmin, (req, res) => {
    const logs = getSystemLogs();
    res.json({ success: true, logs });
  });

  // Clear system logs (requires Admin)
  app.post("/api/system/logs/clear", requireAdmin, (req, res) => {
    writeSystemLogs([]);
    logSystemEvent("security_logs", "System logs cleared by admin", "info");
    res.json({ success: true });
  });

  // Backup playlists on server before delete
  app.post("/api/system/backup/playlist", async (req, res) => {
    const { playlist, beats } = req.body;
    if (!playlist) return res.status(400).json({ error: "Missing playlist payload" });
    addDeletedBackup("playlist", playlist.id, { playlist, beats });
    res.json({ success: true });
  });

  // Backup profile on server before suspend / delete
  app.post("/api/system/backup/profile", async (req, res) => {
    const { profile } = req.body;
    if (!profile) return res.status(400).json({ error: "Missing profile payload" });
    addDeletedBackup("profile", profile.id, profile);
    res.json({ success: true });
  });

  // Delete profile endpoint with soft-delete first and backup!
  app.post("/api/system/profile/delete", requireAdmin, async (req, res) => {
    const { profileId } = req.body;
    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase not connected" });
    try {
      const { data: profile } = await supabase.from("profiles").select("*").eq("id", profileId).maybeSingle();
      if (!profile) return res.status(404).json({ error: "Perfil não encontrado" });

      addDeletedBackup("profile", profileId, profile);

      const { error: updateError } = await supabase
        .from("profiles")
        .update({ role: "suspended" })
        .eq("id", profileId);

      if (updateError) throw updateError;

      logSystemEvent("security_abuse", `Perfil ID: ${profileId} soft-deletado com sucesso.`, "warning");
      res.json({ success: true });
    } catch (err: any) {
      logSystemEvent("api_error", `Falha ao apagar perfil: ${err.message}`, "error");
      res.status(500).json({ error: err.message });
    }
  });

  // List all recovery items (requires Admin)
  app.get("/api/system/recovery/list", requireAdmin, (req, res) => {
    const backups = getDeletedBackups();
    res.json({ success: true, backups });
  });

  // Recovery trigger (requires Admin)
  app.post("/api/system/recovery/restore", requireAdmin, async (req, res) => {
    const { backupId } = req.body;
    const backups = getDeletedBackups();
    const backupItem = backups.find((b: any) => b.backup_id === backupId);

    if (!backupItem) {
      return res.status(404).json({ error: "Backup reference index not found." });
    }

    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase not connected" });

    try {
      if (backupItem.type === "beat") {
        const beatObj = { ...backupItem.data };
        
        // Remove DB insertion blocks or auto-generated fields if required
        const { error } = await supabase.from("beats").insert([beatObj]);
        if (error) {
          throw error;
        }
        
        logSystemEvent("recovery", `Beat '${beatObj.title || beatObj.id}' restaurado de backups com sucesso.`, "info");
      } else if (backupItem.type === "playlist") {
        const { playlist, beats } = backupItem.data;
        
        // Restore playlist details
        const { error: plError } = await supabase.from("playlists").insert([playlist]);
        if (plError) throw plError;

        // Restore playlist beat mappings if they existed
        if (beats && beats.length > 0) {
          await supabase.from("playlist_beats").insert(beats);
        }

        logSystemEvent("recovery", `Playlist '${playlist.title}' restaurada dos backups de segurança.`, "info");
      } else if (backupItem.type === "profile") {
        const profileObj = { ...backupItem.data };
        
        const { error } = await supabase.from("profiles").upsert([profileObj]);
        if (error) throw error;

        logSystemEvent("recovery", `Perfil de utilizador de '${profileObj.display_name || profileObj.id}' restaurado.`, "info");
      }

      // Remove the item from backup cache so it's marked as restored
      const updatedBackups = backups.filter((b: any) => b.backup_id !== backupId);
      writeDeletedBackups(updatedBackups);

      res.json({ success: true, message: `O item foi restaurado com sucesso para a base dados ativa.` });
    } catch (err: any) {
      logSystemEvent("api_error", `Falha ao restaurar backup ${backupId}: ${err.message}`, "error", { stack: err.stack });
      res.status(500).json({ error: err.message || String(err) });
    }
  });

  // Storage Validator checks (Orphaned files, Broken Images/Covers/Audios, DB listings matching)
  app.get("/api/system/storage/validate", requireAdmin, async (req, res) => {
    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "No connection configuration to database." });

    try {
      // 1. Fetch all Beats from DB
      const { data: dbBeats, error: bError } = await supabase
        .from("beats")
        .select("id, title, cover_url, master_url, demo_url, stems_url");

      if (bError) throw bError;

      // 2. Fetch all files inside storage "covers" and "beats" folders
      const { data: storageBeatsFiles } = await supabase.storage.from("beats").list("", { limit: 1000 });

      // Build listing lists
      const fileNamesInStorage = (storageBeatsFiles || []).map((f: any) => f.name);
      
      const orphanedFiles: string[] = [];
      const beatsWithoutAudio: any[] = [];
      const beatsWithoutCover: any[] = [];
      const brokenLinks: any[] = [];

      // Look through beats to identify issues
      for (const beat of (dbBeats || [])) {
        const isMasterValid = beat.master_url && fileNamesInStorage.includes(beat.master_url);
        const isDemoValid = beat.demo_url && fileNamesInStorage.includes(beat.demo_url);
        
        if (!beat.master_url && !beat.demo_url) {
          beatsWithoutAudio.push({ id: beat.id, title: beat.title, reason: "Ausência total de arquivos de áudio no registo." });
        } else if (beat.master_url && !isMasterValid && !beat.master_url.startsWith("http")) {
          brokenLinks.push({ id: beat.id, title: beat.title, field: "master_url", value: beat.master_url, reason: "Arquivo Master listado mas em falta no Storage." });
        } else if (beat.demo_url && !isDemoValid && !beat.demo_url.startsWith("http")) {
          brokenLinks.push({ id: beat.id, title: beat.title, field: "demo_url", value: beat.demo_url, reason: "Arquivo Demo listado mas em falta no Storage." });
        }

        if (!beat.cover_url) {
          beatsWithoutCover.push({ id: beat.id, title: beat.title, reason: "Capa não configurada." });
        } else {
          const isCoverValid = fileNamesInStorage.includes(beat.cover_url);
          if (!isCoverValid && !beat.cover_url.startsWith("http")) {
            brokenLinks.push({ id: beat.id, title: beat.title, field: "cover_url", value: beat.cover_url, reason: "Capa inexistente no Storage." });
          }
        }
      }

      // Check for orphaned assets inside Storage
      const referencedUrls = new Set<string>();
      for (const beat of (dbBeats || [])) {
        if (beat.cover_url) referencedUrls.add(beat.cover_url);
        if (beat.master_url) referencedUrls.add(beat.master_url);
        if (beat.demo_url) referencedUrls.add(beat.demo_url);
        if (beat.stems_url) referencedUrls.add(beat.stems_url);
      }

      for (const stFile of fileNamesInStorage) {
        if (stFile !== ".emptyFolderPlaceholder" && !referencedUrls.has(stFile)) {
          const ext = path.extname(stFile).toLowerCase();
          if ([".mp3", ".wav", ".zip", ".rar"].includes(ext)) {
            orphanedFiles.push(stFile);
          }
        }
      }

      res.json({
        success: true,
        summary: {
          totalBeatsChecked: dbBeats?.length || 0,
          totalStorageFilesChecked: fileNamesInStorage.length,
          orphanedFilesCount: orphanedFiles.length,
          beatsWithoutAudioCount: beatsWithoutAudio.length,
          beatsWithoutCoverCount: beatsWithoutCover.length,
          brokenLinksCount: brokenLinks.length
        },
        orphanedFiles,
        beatsWithoutAudio,
        beatsWithoutCover,
        brokenLinks
      });
    } catch (err: any) {
      logSystemEvent("api_error", `Falha na verificação de Storage: ${err.message}`, "error");
      res.status(500).json({ error: err.message || String(err) });
    }
  });

  // --- STORAGE AUDIT & ROBUST MAINTENANCE SERVICES ---

  // Helper: Recursive Storage Files Listing
  async function listBucketFilesRecursively(supabaseClient: any, bucket: string, folder: string = ""): Promise<{ path: string; name: string }[]> {
    const allFiles: { path: string; name: string }[] = [];
    try {
      const { data, error } = await supabaseClient.storage.from(bucket).list(folder, {
        limit: 150,
        sortBy: { column: 'name', order: 'asc' }
      });
      
      if (error) {
        console.error(`[STORAGE AUDIT] Error listing bucket "${bucket}" folder "${folder}":`, error);
        return allFiles;
      }
      
      if (data && data.length > 0) {
        for (const item of data) {
          if (item.name === '.emptyFolderPlaceholder') continue;
          const relativePath = folder ? `${folder}/${item.name}` : item.name;
          const isFolder = !item.id || item.metadata === null || Object.keys(item.metadata || {}).length === 0;
          
          if (isFolder) {
            const subFiles = await listBucketFilesRecursively(supabaseClient, bucket, relativePath);
            allFiles.push(...subFiles);
          } else {
            allFiles.push({
              path: relativePath,
              name: item.name
            });
          }
        }
      }
    } catch (err) {
      console.error(`[STORAGE AUDIT] Exception in listing bucket "${bucket}" folder "${folder}":`, err);
    }
    return allFiles;
  }

  // Helper: Audit database references and verify Storage coherence
  async function auditOrphanFiles(supabaseClient: any) {
    console.log("[STORAGE AUDIT] Running deep Storage validation audit...");
    
    // 1. Fetch file lists recursively from Supabase Storage
    const beatsPublicFiles = await listBucketFilesRecursively(supabaseClient, "beats", "");
    const beatsPrivateFiles = await listBucketFilesRecursively(supabaseClient, "beats-private", "");
    
    const allStorageFiles = [
      ...beatsPublicFiles.map(f => ({ bucket: "beats", ...f })),
      ...beatsPrivateFiles.map(f => ({ bucket: "beats-private", ...f }))
    ];

    // 2. Fetch all Beat / Drum-kit records from the main beats table
    const { data: dbBeats, error: dbError } = await supabaseClient
      .from("beats")
      .select("id, title, cover_url, master_url, demo_url, stems_url, category, artist_name");
    
    if (dbError) {
      console.error("[STORAGE AUDIT] Failed to retrieve db files from beats:", dbError);
      throw dbError;
    }

    const beatsList = dbBeats || [];
    
    // 3. Assemble referenced files list for precise correlation matching
    const referencedPaths = new Set<string>();
    const dbReferences: { id: string; title: string; field: string; value: string; category?: string }[] = [];

    for (const beat of beatsList) {
      const fieldsToCheck = ["cover_url", "master_url", "demo_url", "stems_url"] as const;
      for (const field of fieldsToCheck) {
        const val = beat[field];
        if (val) {
          referencedPaths.add(decodeURIComponent(val));
          dbReferences.push({
            id: beat.id,
            title: beat.title,
            field,
            value: val,
            category: beat.category
          });
        }
      }
    }

    // 4. Identify Orphan Storage Files (Exist in storage but have no DB registration referencing them)
    const orphans: { bucket: string; path: string }[] = [];

    for (const file of allStorageFiles) {
      let isReferenced = false;
      const decodedPath = decodeURIComponent(file.path);
      
      for (const ref of referencedPaths) {
        if (ref.includes(decodedPath)) {
          isReferenced = true;
          break;
        }
      }

      if (!isReferenced) {
        console.warn(`[STORAGE AUDIT] [ORPHAN FILE DETECTED] Orphan file found in Supabase: bucket=${file.bucket}, path=${file.path}`);
        orphans.push({
          bucket: file.bucket,
          path: file.path
        });
      }
    }

    // 5. Identify Broken Database References (DB points to files that are missing in Storage)
    const missingStorageFiles: { beatId: string; title: string; field: string; value: string; reason: string; category?: string }[] = [];

    for (const ref of dbReferences) {
      const valDecoded = decodeURIComponent(ref.value);
      
      const isPublic = valDecoded.includes("/beats/") || (!valDecoded.startsWith("http") && ref.field === "cover_url" && !valDecoded.includes("beats-private"));
      const isPrivate = valDecoded.includes("beats-private/") || (!valDecoded.startsWith("http") && (ref.field === "master_url" || ref.field === "stems_url"));

      if (isPublic) {
        const exists = beatsPublicFiles.some(f => valDecoded.includes(decodeURIComponent(f.path)));
        if (!exists && !ref.value.startsWith("http")) {
          missingStorageFiles.push({
            beatId: ref.id,
            title: ref.title,
            field: ref.field,
            value: ref.value,
            category: ref.category,
            reason: `Arquivo em falta no bucket público 'beats'`
          });
        }
      } else if (isPrivate) {
        const exists = beatsPrivateFiles.some(f => valDecoded.includes(decodeURIComponent(f.path)));
        if (!exists) {
          missingStorageFiles.push({
            beatId: ref.id,
            title: ref.title,
            field: ref.field,
            value: ref.value,
            category: ref.category,
            reason: `Arquivo em falta no bucket privado 'beats-private'`
          });
        }
      }
    }

    return {
      orphans,
      missingStorageFiles,
      totalStorageFiles: allStorageFiles.length,
      totalDbRecords: beatsList.length
    };
  }

  // Helper: Clean up abandoned chunks from /tmp/uploads/* older than 24 hours
  async function cleanupAbandonedChunks() {
    const uploadDir = path.join("/tmp", "uploads");
    console.log(`[STORAGE AUDIT] [CHUNK CLEANUP] Scanning chunks folder ${uploadDir}...`);
    if (!fs.existsSync(uploadDir)) {
      console.log(`[STORAGE AUDIT] [CHUNK CLEANUP] Directory ${uploadDir} does not exist. Skipping.`);
      return { deletedDirs: 0, deletedFiles: 0 };
    }
    
    let deletedDirs = 0;
    let deletedFiles = 0;
    
    try {
      const topItems = fs.readdirSync(uploadDir);
      const now = Date.now();
      const cutoffAgeMs = 24 * 60 * 60 * 1000; // 24 Hours

      for (const item of topItems) {
        if (item === '.' || item === '..') continue;
        const fullPath = path.join(uploadDir, item);
        try {
          const stats = fs.statSync(fullPath);
          const ageMs = now - stats.mtime.getTime();
          
          if (ageMs > cutoffAgeMs) {
            console.log(`[STORAGE AUDIT] [CHUNK CLEANUP] Removing abandoned temporary upload file/folder: ${fullPath} (Age: ${(ageMs / 3600000).toFixed(1)}h)`);
            if (stats.isDirectory()) {
              fs.rmSync(fullPath, { recursive: true, force: true });
              deletedDirs++;
            } else {
              fs.unlinkSync(fullPath);
              deletedFiles++;
            }
          }
        } catch (err) {
          console.error(`[STORAGE AUDIT] [CHUNK CLEANUP] Error processing item ${fullPath}:`, err);
        }
      }
    } catch (err) {
      console.error(`[STORAGE AUDIT] [CHUNK CLEANUP] Critical error during automatic chunks cleanup:`, err);
    }
    
    return { deletedDirs, deletedFiles };
  }

  // Helper: Automated orphan and chunk cleanup executor
  async function cleanupOrphanFiles(supabaseClient: any) {
    console.log("[STORAGE AUDIT] Initiating automated orphan cleanup...");
    
    const audit = await auditOrphanFiles(supabaseClient);
    const removalResults: { bucket: string; path: string; success: boolean; error?: string }[] = [];

    // Remove each detected orphan from Storage
    for (const orphan of audit.orphans) {
      try {
        console.log(`[STORAGE AUDIT] [CLEANUP] Removing orphan asset from Storage: bucket=${orphan.bucket}, path=${orphan.path}`);
        const { error } = await supabaseClient.storage.from(orphan.bucket).remove([orphan.path]);
        if (error) {
          console.error(`[STORAGE AUDIT] Failed to remove orphan ${orphan.bucket}/${orphan.path}:`, error);
          removalResults.push({ bucket: orphan.bucket, path: orphan.path, success: false, error: error.message });
        } else {
          console.log(`[STORAGE AUDIT] [ORPHAN FILE DELETED] Successfully deleted orphan file: ${orphan.bucket}/${orphan.path}`);
          removalResults.push({ bucket: orphan.bucket, path: orphan.path, success: true });
        }
      } catch (err: any) {
        console.error(`[STORAGE AUDIT] Exception removing orphan ${orphan.bucket}/${orphan.path}:`, err);
        removalResults.push({ bucket: orphan.bucket, path: orphan.path, success: false, error: err.message || String(err) });
      }
    }

    // Clean up temporary chunks on container disk older than 24 hours
    const chunkCleanupStats = await cleanupAbandonedChunks();

    return {
      orphanDeletions: removalResults,
      chunkCleanupStats,
      auditResult: audit
    };
  }

  // GET /api/admin/storage-audit endpoint
  app.get("/api/admin/storage-audit", requireAdmin, async (req, res) => {
    const supabase = getSupabase();
    if (!supabase) return res.status(503).json({ error: "Supabase client not initialized" });

    try {
      const doCleanup = req.query.cleanup === "true" || req.query.action === "cleanup";
      console.log(`[STORAGE AUDIT] GET /api/admin/storage-audit requested. Trigger cleanup: ${doCleanup}`);

      if (doCleanup) {
        const cleanupResult = await cleanupOrphanFiles(supabase);
        return res.json({
          success: true,
          message: "Auditoria e limpeza automáticas de armazenamento executadas com sucesso.",
          timestamp: new Date().toISOString(),
          orphansCleaned: cleanupResult.orphanDeletions.filter(o => o.success).length,
          orphansFailed: cleanupResult.orphanDeletions.filter(o => !o.success).length,
          chunksCleaned: cleanupResult.chunkCleanupStats,
          audit: {
            totalStorageFiles: cleanupResult.auditResult.totalStorageFiles,
            totalDbRecords: cleanupResult.auditResult.totalDbRecords,
            orphanFiles: cleanupResult.auditResult.orphans,
            brokenDbReferences: cleanupResult.auditResult.missingStorageFiles
          }
        });
      } else {
        const auditResult = await auditOrphanFiles(supabase);
        return res.json({
          success: true,
          message: "Auditoria de armazenamento finalizada com sucesso.",
          timestamp: new Date().toISOString(),
          audit: {
            totalStorageFiles: auditResult.totalStorageFiles,
            totalDbRecords: auditResult.totalDbRecords,
            orphanFiles: auditResult.orphans,
            filesWithoutDbRecord: auditResult.orphans,
            brokenDbReferences: auditResult.missingStorageFiles
          }
        });
      }
    } catch (err: any) {
      console.error("[STORAGE AUDIT] Error executing audit administrative endpoint:", err);
      res.status(500).json({ error: err.message || String(err) });
    }
  });

  // Daily interval to handle automated storage hygiene
  setInterval(async () => {
    try {
      console.log("[STORAGE AUDIT] Running scheduled recurrent storage audit and cleanup routine...");
      const supabase = getSupabase();
      if (supabase) {
        await cleanupOrphanFiles(supabase);
      }
    } catch (e) {
      console.error("[STORAGE AUDIT] Exception in scheduled storage hygiene interval:", e);
    }
  }, 24 * 60 * 60 * 1000); // Daily (24 Hours)

  // Hourly interval to clean up chunk uploads folder
  setInterval(async () => {
    try {
      await cleanupAbandonedChunks();
    } catch (e) {
      console.error("[STORAGE AUDIT] Hourly chunk cleanup exception:", e);
    }
  }, 60 * 60 * 1000); // Hourly (1 Hour)

  // Proactive startup maintenance trigger (runs 10 seconds post-boot)
  setTimeout(async () => {
    try {
      console.log("[STORAGE AUDIT] Running startup temporary upload chunks check...");
      await cleanupAbandonedChunks();
    } catch (e) {
      console.error("[STORAGE AUDIT] Post-boot chunk cleanup check failed:", e);
    }
  }, 10000);

  // Health check - GET /api/system/health
  app.get("/api/system/health", async (req, res) => {
    const supabase = getSupabase();
    let dbStatus = "offline";
    let storageStatus = "offline";
    let paypalStatus = "unconfigured";

    if (supabase) {
      try {
        const { error } = await supabase.from("beats").select("id").limit(1);
        if (!error) {
          dbStatus = "online";
        } else {
          dbStatus = `degraded: ${error.message}`;
        }
      } catch (err: any) {
        dbStatus = `offline: ${err.message || err}`;
      }
    }

    if (supabase) {
      try {
        const { error } = await supabase.storage.listBuckets();
        if (!error) {
          storageStatus = "online";
        } else {
          storageStatus = `degraded: ${error.message}`;
        }
      } catch (err: any) {
        storageStatus = `offline: ${err.message || err}`;
      }
    }

    const mode = (process.env.PAYPAL_MODE || "sandbox").trim().toLowerCase();
    const hasPaypalClientId = !!(
      process.env.VITE_PAYPAL_CLIENT_ID || 
      process.env.PAYPAL_CLIENT_ID || 
      (mode === "live" ? process.env.PAYPAL_LIVE_CLIENT_ID : process.env.PAYPAL_SANDBOX_CLIENT_ID)
    );
    const hasPaypalSecret = !!(
      process.env.PAYPAL_SECRET || 
      process.env.PAYPAL_CLIENT_SECRET || 
      (mode === "live" ? process.env.PAYPAL_LIVE_SECRET : process.env.PAYPAL_SANDBOX_SECRET)
    );
    if (hasPaypalClientId && hasPaypalSecret) {
      paypalStatus = `configured (${mode})`;
    }

    res.json({
      status: (dbStatus === "online" && storageStatus === "online") ? "healthy" : "warning",
      db: dbStatus,
      storage: storageStatus,
      paypal: paypalStatus,
      server_uptime: process.uptime(),
      timestamp: new Date().toISOString()
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);

    // Dynamic SEO integration inside Dev mode
    app.get('*', async (req, res, next) => {
      if (req.url.includes('.') || req.url.startsWith('/api') || req.url.startsWith('/socket.io')) {
        return next();
      }
      try {
        const templatePath = path.join(process.cwd(), 'index.html');
        if (fs.existsSync(templatePath)) {
          let template = fs.readFileSync(templatePath, 'utf-8');
          template = await vite.transformIndexHtml(req.url, template);
          const seo = await getSEOData(req);
          const html = injectSEOTags(template, seo);
          res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
        } else {
          next();
        }
      } catch (err) {
        console.error("Dev SEO transformer crashed:", err);
        next();
      }
    });
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    // Disable standard index.html fallback from express.static
    app.use(express.static(distPath, { index: false }));
    
    app.get('*', async (req, res, next) => {
      if (req.url.includes('.')) {
        return next();
      }
      try {
        const indexPath = path.join(distPath, 'index.html');
        if (fs.existsSync(indexPath)) {
          const rawHtml = fs.readFileSync(indexPath, 'utf-8');
          const seo = await getSEOData(req);
          const html = injectSEOTags(rawHtml, seo);
          res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
        } else {
          res.sendFile(indexPath);
        }
      } catch (err) {
        console.error("Prod SEO Interception crashed:", err);
        res.sendFile(path.join(distPath, 'index.html'));
      }
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server successfully started and listening on 0.0.0.0:${PORT}`);
    console.log(`- Health check: http://localhost:${PORT}/api/health`);
  });
}

startServer().catch(err => {
  console.error("CRITICAL: Failed to start server:", err);
  process.exit(1);
});
