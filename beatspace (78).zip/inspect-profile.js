import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
  try {
    const urlObj = new URL(url);
    url = urlObj.origin;
  } catch (e) {
    url = url.replace(/\/+$/, '');
  }
}

async function run() {
  if (!url || !key) {
    console.log("No URL or Key found!");
    return;
  }
  
  const supabase = createClient(url, key);
  console.log("Supabase Client initialized with", url);

  const targetEmail = 'prodjaymbeats@gmail.com';
  console.log(`\n--- SEARCHING FOR EMAIL "${targetEmail}" IN PROFILES TABLE ---`);
  
  const { data: profile, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('email', targetEmail)
    .maybeSingle();
    
  if (error) {
    console.error("Error fetching profile:", error);
    return;
  }
  
  if (profile) {
    console.log("Profile found!");
    console.log(JSON.stringify(profile, null, 2));
  } else {
    console.log(`No user profile found for email: ${targetEmail}`);
    
    // Let's print all emails in profiles to see
    console.log("\n--- ALL PROFILE EMAILS IN THE DB ---");
    const { data: allProfiles } = await supabase.from('profiles').select('id, email, username, artistic_name, display_name');
    console.log(allProfiles);
  }
}

run().catch(console.error);
