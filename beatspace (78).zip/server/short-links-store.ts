import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

// Define structural TS interfaces aligned with database schema
export interface ShortLink {
  id: string;
  code: string;
  type: 'beat' | 'kit' | 'profile' | 'promotion';
  target_id: string | null;
  target_url: string;
  producer_id: string;
  clicks_count: number;
  created_at?: string;
  updated_at?: string;
}

export interface ShortLinkClick {
  id: string;
  short_link_id: string;
  ip_hash: string | null;
  country: string | null;
  city: string | null;
  device_type: string | null;
  browser: string | null;
  referrer: string | null;
  user_agent: string | null;
  created_at?: string;
}

export interface ShortLinkDailySummary {
  id?: string;
  short_link_id: string;
  date: string; // YYYY-MM-DD
  clicks_count: number;
  referrers_breakdown: Record<string, number>;
  countries_breakdown: Record<string, number>;
  devices_breakdown: Record<string, number>;
  created_at?: string;
  updated_at?: string;
}

function getSupabaseAdmin() {
  let SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  let SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  
  if (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY) {
    SUPABASE_URL = SUPABASE_URL.trim().replace(/^["'](.+)["']$/, '$1');
    SUPABASE_SERVICE_ROLE_KEY = SUPABASE_SERVICE_ROLE_KEY.trim().replace(/^["'](.+)["']$/, '$1');
    
    if (!SUPABASE_URL.startsWith('http')) {
      SUPABASE_URL = `https://${SUPABASE_URL}`;
    }
    return createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false }
    });
  }
  return null;
}

// Local filesystem fallback database files (to handle development environments without explicit tables in Supabase)
const DB_DIR = path.join(process.cwd(), 'database');
const LOCAL_LINKS_FILE = path.join(DB_DIR, 'short_links_db.json');
const LOCAL_CLICKS_FILE = path.join(DB_DIR, 'short_link_clicks_db.json');
const LOCAL_SUMMARIES_FILE = path.join(DB_DIR, 'short_link_daily_summaries_db.json');

function ensureDir() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
}

function readLocalLinks(): ShortLink[] {
  try {
    ensureDir();
    if (fs.existsSync(LOCAL_LINKS_FILE)) {
      const data = fs.readFileSync(LOCAL_LINKS_FILE, 'utf8');
      return JSON.parse(data || '[]');
    }
  } catch (e) {
    console.error('[SHORT LINKS Fallback] Error reading local short_links_db.json:', e);
  }
  return [];
}

function writeLocalLinks(links: ShortLink[]) {
  try {
    ensureDir();
    fs.writeFileSync(LOCAL_LINKS_FILE, JSON.stringify(links, null, 2), 'utf8');
  } catch (e) {
    console.error('[SHORT LINKS Fallback] Error writing local short_links_db.json:', e);
  }
}

function readLocalClicks(): ShortLinkClick[] {
  try {
    ensureDir();
    if (fs.existsSync(LOCAL_CLICKS_FILE)) {
      const data = fs.readFileSync(LOCAL_CLICKS_FILE, 'utf8');
      return JSON.parse(data || '[]');
    }
  } catch (e) {
    console.error('[SHORT LINKS Fallback] Error reading local short_link_clicks_db.json:', e);
  }
  return [];
}

function writeLocalClicks(clicks: ShortLinkClick[]) {
  try {
    ensureDir();
    fs.writeFileSync(LOCAL_CLICKS_FILE, JSON.stringify(clicks, null, 2), 'utf8');
  } catch (e) {
    console.error('[SHORT LINKS Fallback] Error writing local short_link_clicks_db.json:', e);
  }
}

function readLocalSummaries(): ShortLinkDailySummary[] {
  try {
    ensureDir();
    if (fs.existsSync(LOCAL_SUMMARIES_FILE)) {
      const data = fs.readFileSync(LOCAL_SUMMARIES_FILE, 'utf8');
      return JSON.parse(data || '[]');
    }
  } catch (e) {
    console.error('[SHORT LINKS Fallback] Error reading local short_link_daily_summaries_db.json:', e);
  }
  return [];
}

function writeLocalSummaries(summaries: ShortLinkDailySummary[]) {
  try {
    ensureDir();
    fs.writeFileSync(LOCAL_SUMMARIES_FILE, JSON.stringify(summaries, null, 2), 'utf8');
  } catch (e) {
    console.error('[SHORT LINKS Fallback] Error writing local short_link_daily_summaries_db.json:', e);
  }
}


export function slugify(text: string): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .normalize('NFD') // remove accents
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s_-]/g, '') // keep keep legal characters
    .trim()
    .replace(/[\s_]+/g, '-') // convert spaces and underscores to single dash
    .replace(/-+/g, '-'); // remove consecutive dashes
}

export function generateRandomSuffix(): string {
  return Math.random().toString(36).substring(2, 6);
}

// Core Operations

/**
 * Creates or retrieves a short link. If a duplicate slug target matches another record, it appends a suffix.
 */
export async function createShortLink(
  type: 'beat' | 'kit' | 'profile' | 'promotion',
  targetId: string,
  targetUrl: string,
  producerId: string,
  baseSlug: string
): Promise<ShortLink> {
  const admin = getSupabaseAdmin();
  const cleanSlug = slugify(baseSlug) || 'link';

  // We loop to avoid code collisions
  let finalCode = cleanSlug;
  let codeAttempts = 0;
  let isUnique = false;

  while (!isUnique && codeAttempts < 10) {
    if (codeAttempts > 0) {
      finalCode = `${cleanSlug}-${generateRandomSuffix()}`;
    }

    const collision = await lookupShortLinkByCodeAndType(finalCode, type);
    if (!collision) {
      isUnique = true;
    } else if (collision.target_id === targetId && collision.type === type) {
      // It exists for this exact same resource, reuse it
      return collision;
    } else {
      codeAttempts++;
    }
  }

  const payload: ShortLink = {
    id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
    code: finalCode,
    type,
    target_id: targetId,
    target_url: targetUrl,
    producer_id: producerId,
    clicks_count: 0,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  if (admin) {
    try {
      const { data, error } = await admin
        .from('short_links')
        .insert(payload)
        .select()
        .single();

      if (!error && data) {
        return data as ShortLink;
      }

      console.warn('[SHORT LINKS] Supabase insert failed (falling back to JSON store):', error?.message);
    } catch (dbErr: any) {
      console.warn('[SHORT LINKS] Supabase exception, falling back to JSON:', dbErr.message);
    }
  }

  // Fallback to local files
  const localLinks = readLocalLinks();
  localLinks.push(payload);
  writeLocalLinks(localLinks);
  return payload;
}

/**
 * Looking up short links by code and type. E.g. b/azura matches type='beat', code='azura'
 */
export async function lookupShortLinkByCodeAndType(code: string, type: 'beat' | 'kit' | 'profile' | 'promotion'): Promise<ShortLink | null> {
  const admin = getSupabaseAdmin();
  const cleanCode = code.toLowerCase().trim();

  if (admin) {
    try {
      const { data, error } = await admin
        .from('short_links')
        .select('*')
        .eq('code', cleanCode)
        .eq('type', type)
        .maybeSingle();

      if (!error && data) {
        return data as ShortLink;
      }
    } catch (dbErr) {
      // Ignored, proceed to fallback
    }
  }

  const localLinks = readLocalLinks();
  const found = localLinks.find(l => l.code === cleanCode && l.type === type);
  return found || null;
}

/**
 * Generic lookup of short link by code alone (as a general search, or path resolver)
 */
export async function lookupShortLinkByCode(code: string): Promise<ShortLink | null> {
  const admin = getSupabaseAdmin();
  const cleanCode = code.toLowerCase().trim();

  if (admin) {
    try {
      const { data, error } = await admin
        .from('short_links')
        .select('*')
        .eq('code', cleanCode)
        .maybeSingle();

      if (!error && data) {
        return data as ShortLink;
      }
    } catch (dbErr) {
      // Ignored
    }
  }

  const localLinks = readLocalLinks();
  const found = localLinks.find(l => l.code === cleanCode);
  return found || null;
}

/**
 * Helper to clean and standardize referrers
 */
export function cleanReferrerValue(ref: string): string {
  const cleanRef = (ref || 'Direto').trim().toLowerCase();
  if (cleanRef.includes('youtube') || cleanRef.includes('youtu.be') || cleanRef.includes('yt')) return 'YouTube';
  if (cleanRef.includes('instagram') || cleanRef.includes('ig.me') || cleanRef.includes('ig')) return 'Instagram';
  if (cleanRef.includes('tiktok') || cleanRef.includes('tk')) return 'TikTok';
  if (cleanRef.includes('whatsapp') || cleanRef.includes('wa.me') || cleanRef.includes('wa')) return 'WhatsApp';
  if (cleanRef.includes('facebook') || cleanRef.includes('fb.me') || cleanRef.includes('fb')) return 'Facebook';
  if (cleanRef.includes('twitter') || cleanRef.includes('t.co')) return 'Twitter';
  if (cleanRef === 'direct' || cleanRef === 'direto' || cleanRef === '') return 'Direto';
  
  try {
    const url = new URL(ref);
    return url.hostname;
  } catch (e) {
    return ref ? ref.substring(0, 50) : 'Direto';
  }
}

/**
 * Keeps the short_link_clicks thin and ultra performant by pruning detailed logs older than 90 days.
 * Runs asynchronously in the background.
 */
export async function pruneOldClicks() {
  const admin = getSupabaseAdmin();
  const maxRetentionDays = 90;
  const cutoffDate = new Date(Date.now() - maxRetentionDays * 24 * 60 * 60 * 1000).toISOString();

  if (admin) {
    try {
      await admin
        .from('short_link_clicks')
        .delete()
        .lt('created_at', cutoffDate);
    } catch (e) {
      // Ignored
    }
  }

  try {
    const localClicks = readLocalClicks();
    const beforeLength = localClicks.length;
    const cutoffTime = new Date(cutoffDate).getTime();
    const filtered = localClicks.filter(c => {
      const cDate = new Date(c.created_at || '');
      return cDate.getTime() >= cutoffTime;
    });
    if (filtered.length < beforeLength) {
      writeLocalClicks(filtered);
    }
  } catch (err) {
    // Ignored
  }
}

/**
 * Incrementally updates the daily aggregated metrics permanently.
 */
export async function updateDailySummary(
  shortLinkId: string,
  details: {
    referrer: string | null;
    country: string | null;
    device_type: string | null;
  }
) {
  const admin = getSupabaseAdmin();
  const todayStr = new Date().toISOString().substring(0, 10); // YYYY-MM-DD
  
  const ref = cleanReferrerValue(details.referrer || 'Direto');
  const country = details.country || 'Angola';
  const device = (details.device_type || 'desktop').toLowerCase();

  // 1. Supabase Aggregated Summaries Storage
  if (admin) {
    try {
      const { data: existing, error } = await admin
        .from('short_link_daily_summaries')
        .select('*')
        .eq('short_link_id', shortLinkId)
        .eq('date', todayStr)
        .maybeSingle();

      if (!error) {
        if (existing) {
          const refs = existing.referrers_breakdown || {};
          const countries = existing.countries_breakdown || {};
          const devices = existing.devices_breakdown || {};

          refs[ref] = (refs[ref] || 0) + 1;
          countries[country] = (countries[country] || 0) + 1;
          devices[device] = (devices[device] || 0) + 1;

          await admin
            .from('short_link_daily_summaries')
            .update({
              clicks_count: (existing.clicks_count || 0) + 1,
              referrers_breakdown: refs,
              countries_breakdown: countries,
              devices_breakdown: devices,
              updated_at: new Date().toISOString()
            })
            .eq('id', existing.id);
        } else {
          await admin
            .from('short_link_daily_summaries')
            .insert({
              short_link_id: shortLinkId,
              date: todayStr,
              clicks_count: 1,
              referrers_breakdown: { [ref]: 1 },
              countries_breakdown: { [country]: 1 },
              devices_breakdown: { [device]: 1 }
            });
        }
      }
    } catch (e) {
      console.error('[ANALYTICS] Supabase daily summarization failed:', e);
    }
  }

  // 2. Local Fallback Aggregated Summaries Storage
  try {
    const summaries = readLocalSummaries();
    const index = summaries.findIndex(s => s.short_link_id === shortLinkId && s.date === todayStr);

    if (index !== -1) {
      summaries[index].clicks_count += 1;
      
      const refs = summaries[index].referrers_breakdown || {};
      refs[ref] = (refs[ref] || 0) + 1;
      summaries[index].referrers_breakdown = refs;

      const countries = summaries[index].countries_breakdown || {};
      countries[country] = (countries[country] || 0) + 1;
      summaries[index].countries_breakdown = countries;

      const devices = summaries[index].devices_breakdown || {};
      devices[device] = (devices[device] || 0) + 1;
      summaries[index].devices_breakdown = devices;
    } else {
      summaries.push({
        id: Math.random().toString(36).substring(2, 11),
        short_link_id: shortLinkId,
        date: todayStr,
        clicks_count: 1,
        referrers_breakdown: { [ref]: 1 },
        countries_breakdown: { [country]: 1 },
        devices_breakdown: { [device]: 1 },
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
    }
    writeLocalSummaries(summaries);
  } catch (err) {
    // Ignored
  }
}

/**
 * Log a click securely with environment request details
 */
export async function logClick(
  shortLinkId: string,
  reqDetails: {
    ip_hash: string | null;
    country: string | null;
    city: string | null;
    device_type: string | null;
    browser: string | null;
    referrer: string | null;
    user_agent: string | null;
  }
) {
  const admin = getSupabaseAdmin();
  const clickPayload: ShortLinkClick = {
    id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
    short_link_id: shortLinkId,
    ip_hash: reqDetails.ip_hash,
    country: reqDetails.country || 'Angola',
    city: reqDetails.city || 'Luanda',
    device_type: reqDetails.device_type || 'desktop',
    browser: reqDetails.browser || 'Browser',
    referrer: reqDetails.referrer || 'Direct',
    user_agent: reqDetails.user_agent,
    created_at: new Date().toISOString()
  };

  // Run asynchronously without blocking redirect rendering
  (async () => {
    let supabaseSucceeded = false;
    
    // 1. Permanently update pre-aggregated summaries immediately (fast, memory-scale or indexed)
    try {
      await updateDailySummary(shortLinkId, {
        referrer: reqDetails.referrer,
        country: reqDetails.country,
        device_type: reqDetails.device_type
      });
    } catch (ex) {
      // Non-blocking
    }

    if (admin) {
      try {
        // 2. Log click details (will be retained for 90 days)
        const { error: clickErr } = await admin
          .from('short_link_clicks')
          .insert(clickPayload);

        if (!clickErr) {
          try {
            await admin.rpc('increment_short_link_clicks', { link_id: shortLinkId });
          } catch (e) {
            // Fallback native update
          }
          const { data: linkData } = await admin.from('short_links').select('clicks_count').eq('id', shortLinkId).maybeSingle();
          if (linkData) {
            await admin.from('short_links').update({ clicks_count: (linkData.clicks_count || 0) + 1 }).eq('id', shortLinkId);
          }
          supabaseSucceeded = true;
        }
      } catch (err) {
        // Fallback below
      }
    }

    if (!supabaseSucceeded) {
      const localLinks = readLocalLinks();
      const linkIndex = localLinks.findIndex(l => l.id === shortLinkId);
      if (linkIndex !== -1) {
        localLinks[linkIndex].clicks_count = (localLinks[linkIndex].clicks_count || 0) + 1;
        localLinks[linkIndex].updated_at = new Date().toISOString();
        writeLocalLinks(localLinks);
      }

      const localClicks = readLocalClicks();
      localClicks.push(clickPayload);
      writeLocalClicks(localClicks);
    }

    // 3. Periodic background pruning of old historical clicks (approx 3% chance on click to keep it low-impact)
    if (Math.random() < 0.03) {
      try {
        await pruneOldClicks();
      } catch (e) {
        // Ignored
      }
    }
  })();
}

/**
 * Returns all short links created by a producer
 */
export async function getProducerShortLinks(producerId: string): Promise<ShortLink[]> {
  const admin = getSupabaseAdmin();
  const cleanProdId = producerId.trim().toLowerCase();

  if (admin) {
    try {
      const { data, error } = await admin
        .from('short_links')
        .select('*')
        .eq('producer_id', cleanProdId);

      if (!error && data) {
        return data as ShortLink[];
      }
    } catch (e) {
      // Ignored
    }
  }

  const localLinks = readLocalLinks();
  return localLinks.filter(l => l.producer_id.trim().toLowerCase() === cleanProdId);
}

/**
 * Returns aggregated analytics for the producer's dashboard
 */
export async function getShortLinkAnalytics(producerId: string, daysRange: number = 0) {
  const links = await getProducerShortLinks(producerId);
  const linkIds = links.map(l => l.id);

  let summaries: ShortLinkDailySummary[] = [];
  const admin = getSupabaseAdmin();
  let fetchedFromSupabase = false;

  if (admin && linkIds.length > 0) {
    try {
      // Direct, fast indexed summary scan
      const { data, error } = await admin
        .from('short_link_daily_summaries')
        .select('*')
        .in('short_link_id', linkIds);

      if (!error && data) {
        summaries = data as ShortLinkDailySummary[];
        fetchedFromSupabase = true;
      }
    } catch (e) {
      // Fallback below
    }
  }

  if (!fetchedFromSupabase) {
    summaries = readLocalSummaries().filter(s => linkIds.includes(s.short_link_id));
  }

  // Graceful retrospective migration check: if summaries is empty but we have historical clicks, backfill them permanently
  if (summaries.length === 0 && linkIds.length > 0) {
    let clicks: ShortLinkClick[] = [];
    let clicksFetched = false;
    if (admin) {
      try {
        const { data, error } = await admin
          .from('short_link_clicks')
          .select('*')
          .in('short_link_id', linkIds);
        if (!error && data) {
          clicks = data as ShortLinkClick[];
          clicksFetched = true;
        }
      } catch (err) {}
    }
    if (!clicksFetched) {
      clicks = readLocalClicks().filter(c => linkIds.includes(c.short_link_id));
    }

    if (clicks.length > 0) {
      const tempSummariesMap: Record<string, ShortLinkDailySummary> = {};
      clicks.forEach(c => {
        const dateStr = (c.created_at || new Date().toISOString()).substring(0, 10);
        const key = `${c.short_link_id}_${dateStr}`;
        const ref = cleanReferrerValue(c.referrer || 'Direto');
        const country = c.country || 'Angola';
        const device = (c.device_type || 'desktop').toLowerCase();

        if (!tempSummariesMap[key]) {
          tempSummariesMap[key] = {
            short_link_id: c.short_link_id,
            date: dateStr,
            clicks_count: 0,
            referrers_breakdown: {},
            countries_breakdown: {},
            devices_breakdown: {}
          };
        }
        tempSummariesMap[key].clicks_count++;
        tempSummariesMap[key].referrers_breakdown[ref] = (tempSummariesMap[key].referrers_breakdown[ref] || 0) + 1;
        tempSummariesMap[key].countries_breakdown[country] = (tempSummariesMap[key].countries_breakdown[country] || 0) + 1;
        tempSummariesMap[key].devices_breakdown[device] = (tempSummariesMap[key].devices_breakdown[device] || 0) + 1;
      });

      summaries = Object.values(tempSummariesMap);
      
      // Permanently backfill summaries asynchronously
      (async () => {
        if (admin) {
          try {
            await admin.from('short_link_daily_summaries').insert(summaries);
          } catch (e) {}
        } else {
          const allLocal = readLocalSummaries();
          writeLocalSummaries([...allLocal, ...summaries]);
        }
      })();
    }
  }

  // Filter summaries by selected range
  const now = new Date();
  let filteredSummaries = summaries;

  if (daysRange > 0) {
    const cutoffDate = new Date(now.getTime() - daysRange * 24 * 60 * 60 * 1000);
    if (daysRange === 1) {
      cutoffDate.setHours(0, 0, 0, 0);
    }
    const cutoffStr = cutoffDate.toISOString().substring(0, 10);
    filteredSummaries = summaries.filter(s => s.date >= cutoffStr);
  }

  // Build Aggregations
  let totalClicksLength = 0;
  const devicesMap: Record<string, number> = { mobile: 0, desktop: 0, tablet: 0 };
  const referrersMap: Record<string, number> = {};
  const countriesMap: Record<string, number> = {};

  filteredSummaries.forEach(s => {
    totalClicksLength += s.clicks_count;

    const refs = s.referrers_breakdown || {};
    Object.keys(refs).forEach(rk => {
      referrersMap[rk] = (referrersMap[rk] || 0) + refs[rk];
    });

    const countries = s.countries_breakdown || {};
    Object.keys(countries).forEach(ck => {
      countriesMap[ck] = (countriesMap[ck] || 0) + countries[ck];
    });

    const devs = s.devices_breakdown || {};
    Object.keys(devs).forEach(dk => {
      const standardDev = dk.toLowerCase();
      devicesMap[standardDev] = (devicesMap[standardDev] || 0) + devs[dk];
    });
  });

  // Calculate Growth percentages
  let growthFactor = 0;
  if (daysRange > 0) {
    const currCutoff = new Date(now.getTime() - daysRange * 24 * 60 * 60 * 1000);
    const prevCutoff = new Date(now.getTime() - daysRange * 2 * 24 * 60 * 60 * 1000);
    
    if (daysRange === 1) {
      currCutoff.setHours(0,0,0,0);
      prevCutoff.setDate(prevCutoff.getDate() - 1);
      prevCutoff.setHours(0,0,0,0);
    }
    const currStr = currCutoff.toISOString().substring(0,10);
    const prevStr = prevCutoff.toISOString().substring(0,10);

    const currentPeriodClicks = summaries
      .filter(s => s.date >= currStr)
      .reduce((sum, s) => sum + s.clicks_count, 0);

    const previousPeriodClicks = summaries
      .filter(s => s.date >= prevStr && s.date < currStr)
      .reduce((sum, s) => sum + s.clicks_count, 0);

    if (previousPeriodClicks > 0) {
      growthFactor = parseFloat((((currentPeriodClicks - previousPeriodClicks) / previousPeriodClicks) * 100).toFixed(1));
    } else {
      growthFactor = currentPeriodClicks > 0 ? 100 : 0;
    }
  }

  // Calculate Link lists
  const linksPerformance = links.map(l => {
    const linkClicks = filteredSummaries
      .filter(s => s.short_link_id === l.id)
      .reduce((sum, s) => sum + s.clicks_count, 0);
    return {
      id: l.id,
      code: l.code,
      type: l.type,
      target_url: l.target_url,
      clicks: linkClicks
    };
  }).sort((a, b) => b.clicks - a.clicks);

  const mostSharedBeats = linksPerformance.filter(l => l.type === 'beat');
  const mostClickedKits = linksPerformance.filter(l => l.type === 'kit');

  const deviceDistribution = Object.keys(devicesMap)
    .filter(name => devicesMap[name] > 0 || ['mobile', 'desktop', 'tablet'].includes(name))
    .map(name => ({
      name: name.toUpperCase(),
      value: devicesMap[name] || 0
    }));

  const referrerDistribution = Object.keys(referrersMap).map(name => ({
    name,
    value: referrersMap[name]
  })).sort((a, b) => b.value - a.value);

  const countryDistribution = Object.keys(countriesMap).map(name => ({
    name,
    value: countriesMap[name]
  })).sort((a, b) => b.value - a.value);

  return {
    totalClicks: totalClicksLength,
    growthPercentage: growthFactor,
    linksPerformance: linksPerformance.slice(0, 10),
    mostSharedBeats: mostSharedBeats.slice(0, 10),
    mostClickedKits: mostClickedKits.slice(0, 10),
    deviceDistribution,
    referrerDistribution,
    countryDistribution
  };
}

/**
 * Automates synchronization/generation of missing short links for all beats, kits and profiles.
 * Safe to be executed transparently.
 */
export async function syncSmartLinks() {
  const admin = getSupabaseAdmin();
  if (!admin) {
    console.warn('[SHORT LINKS SYNC] Supabase admin not configured. Sync skipped.');
    return { success: false, reason: 'Supabase URL/Service Role not configured' };
  }

  const report = {
    profilesSynced: 0,
    beatsSynced: 0,
    kitsSynced: 0,
    errors: [] as string[]
  };

  try {
    // 1. Fetch profiles
    const { data: profiles, error: profErr } = await admin.from('profiles').select('id, username, display_name');
    if (profErr) {
      throw profErr;
    }

    for (const profile of (profiles || [])) {
      if (!profile.username) continue;
      // We check if we already have this user's profile short url saved
      const exists = await lookupShortLinkByCodeAndType(profile.username, 'profile');
      if (!exists) {
        try {
          await createShortLink(
            'profile',
            profile.id,
            `/producer/${profile.id}`,
            profile.id,
            profile.username
          );
          report.profilesSynced++;
        } catch (e: any) {
          report.errors.push(`Profile ${profile.username} failed: ${e.message}`);
        }
      }
    }

    // 2. Fetch beats and kits
    const { data: beats, error: beatErr } = await admin.from('beats').select('id, title, producer_id, type, category');
    if (beatErr) {
      throw beatErr;
    }

    for (const beat of (beats || [])) {
      if (!beat.title) continue;
      const isKit = beat.type === 'kit' || beat.category?.toLowerCase().includes('kit') || beat.category?.toLowerCase().includes('pack');
      const targetType = isKit ? 'kit' : 'beat';
      const codeType = isKit ? 'k' : 'b';

      const baseSlug = slugify(beat.title);
      const exists = await lookupShortLinkByCodeAndType(baseSlug, targetType);

      if (!exists) {
        try {
          const targetUrl = targetType === 'kit' ? `/marketplace?tab=kits&beat=${beat.id}` : `/beat/${beat.id}`;
          await createShortLink(
            targetType,
            beat.id,
            targetUrl,
            beat.producer_id,
            baseSlug
          );

          if (isKit) report.kitsSynced++;
          else report.beatsSynced++;
        } catch (e: any) {
          report.errors.push(`Beat ${beat.title} failed: ${e.message}`);
        }
      }
    }

    console.log('[SHORT LINKS SYNC COMPLETE] Synced elements:', {
      profiles: report.profilesSynced,
      beats: report.beatsSynced,
      kits: report.kitsSynced
    });

    return { success: true, report };

  } catch (err: any) {
    console.error('[SHORT LINKS SYNC FAILED] Exception executing sync:', err.message);
    return { success: false, error: err.message };
  }
}
