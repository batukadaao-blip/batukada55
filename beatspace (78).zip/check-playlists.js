import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url && key) {
  const supabase = createClient(url, key);
  
  const tables = ['playlists', 'playlist_beats'];
  for (const table of tables) {
    const { data, error } = await supabase.from(table).select('*').limit(1);
    if (!error) {
      console.log(`Table '${table}' exists! Schema/columns:`, data.length > 0 ? Object.keys(data[0]) : 'empty table');
    } else {
      console.log(`Table '${table}' check error:`, error.message);
    }
  }
} else {
  console.log('Missing credentials');
}
