import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let supabaseUrl = process.env.VITE_SUPABASE_URL || '';
if (supabaseUrl.endsWith('/rest/v1/')) {
  supabaseUrl = supabaseUrl.replace('/rest/v1/', '');
} else if (supabaseUrl.endsWith('/rest/v1')) {
  supabaseUrl = supabaseUrl.replace('/rest/v1', '');
}

const supabase = createClient(supabaseUrl, process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '');

async function checkConversations() {
  const userId = '6e4c1b73-32b3-4252-85bc-d74f0a6f6adb';
  const { data, error } = await supabase
    .from('conversations')
    .select('*')
    .or(`buyer_id.eq.${userId},seller_id.eq.${userId}`);
  if (error) {
    console.error('Error fetching conversations:', error);
  } else {
    console.log('Conversations for JORGENOBEAT count in DB:', data?.length);
    for (const c of (data || [])) {
      console.log('--- Conversation:', c.id);
      console.log('Buyer ID:', c.buyer_id);
      console.log('Seller ID:', c.seller_id);
      
      // Fetch profiles directly
      const { data: bProfile } = await supabase.from('profiles').select('*').eq('id', c.buyer_id).maybeSingle();
      const { data: sProfile } = await supabase.from('profiles').select('*').eq('id', c.seller_id).maybeSingle();
      console.log('Buyer Profile:', bProfile);
      console.log('Seller Profile:', sProfile);
    }
  }
}

checkConversations();
