import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
}

async function run() {
  if (!url || !serviceRoleKey) {
    console.log("No URL or Service Role Key found!");
    return;
  }
  
  const adminClient = createClient(url, serviceRoleKey);
  
  console.log("Querying 'followers' table...");
  const { data: followers, error } = await adminClient
    .from('followers')
    .select('*');
    
  if (error) {
    console.error("Error fetching followers:", error);
    return;
  }
  
  console.log("Followers matching entries count:", followers.length);
  console.log("Entries:", JSON.stringify(followers, null, 2));
}

run().catch(console.error);
