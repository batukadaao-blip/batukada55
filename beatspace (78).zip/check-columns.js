import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL || '', process.env.SUPABASE_SERVICE_ROLE_KEY || '');

async function checkColumns() {
  const url = `${process.env.VITE_SUPABASE_URL || ''}/rest/v1/`;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';
  console.log('fetching from:', url);
  const response = await fetch(url, {
    headers: {
      'apikey': key,
      'Authorization': `Bearer ${key}`
    }
  });
  const json = await response.json();
  console.log('Schema tables:', Object.keys(json?.definitions || {}));
  console.log('beats columns:', Object.keys(json?.definitions?.beats?.properties || {}));
}

checkColumns();
