import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
}

async function run() {
  if (!url || !serviceRoleKey) {
    console.log("No URL or Service Role Key found!");
    return;
  }
  
  const adminClient = createClient(url, serviceRoleKey);
  
  console.log("Querying information_schema for public tables...");
  const { data, error } = await adminClient.rpc('get_tables_list_fallback');
  if (error) {
    // If rpc doesn't exist, we can use standard query on a common table or raw select
    console.log("RPC get_tables_list_fallback failed, trying raw query...");
    const { data: tables, error: rawErr } = await adminClient
      .from('profiles')
      .select('id')
      .limit(1);
    console.log("Profiles test query status:", { ok: !rawErr, error: rawErr });
  } else {
    console.log("Tables list:", data);
  }
  
  // Let's do a direct select using postgres if possible, but we don't have direct access. 
  // Let's try to query an schema-defining view or check if there was an sql executor.
}

run().catch(console.error);
