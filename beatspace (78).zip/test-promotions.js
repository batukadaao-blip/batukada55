import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
}

async function run() {
  if (!url || !serviceRoleKey) {
    console.log("No URL or Service Role Key found!");
    return;
  }
  const supabase = createClient(url, serviceRoleKey);
  console.log("Checking if promotions table exists...");
  const { data, error } = await supabase.from('promotions').select('*').limit(1);
  if (error) {
    console.log("Error querying promotions:", error.message, error.code);
  } else {
    console.log("Promotions table exists! Rows found:", data.length);
  }
}

run().catch(console.error);
