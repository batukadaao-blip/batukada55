import dotenv from 'dotenv';
dotenv.config();

console.log('ENV keys list:', Object.keys(process.env));
console.log('VITE_SUPABASE_URL:', process.env.VITE_SUPABASE_URL);
console.log('SUPABASE_URL:', process.env.SUPABASE_URL);
