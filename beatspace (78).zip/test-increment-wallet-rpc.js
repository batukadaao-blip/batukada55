import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url && key) {
  const supabase = createClient(url, key);
  console.log('Testing process_withdrawal_request RPC call...');
  try {
    const { data, error } = await supabase.rpc('process_withdrawal_request', {
      p_withdrawal_id: '3d185eed-7391-4064-bddc-7385c2111642',
      p_action: 'reject'
    });
    if (error) {
      console.log('RPC Call finished with database error:', error.code, error.message);
    } else {
      console.log('RPC Call SUCCEEDED! Result:', data);
    }
  } catch (e) {
    console.log('RPC Call threw JS exception:', e.message);
  }
} else {
  console.log('Missing credentials in environment.');
}
