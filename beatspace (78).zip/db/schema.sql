-- SQL Script to create Marketplace and Messaging Tables in PostgreSQL (Supabase)

-- 0. Profiles Table (for identity)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE,
  display_name TEXT,
  artistic_name TEXT,
  full_name TEXT,
  avatar_url TEXT,
  city TEXT,
  phone TEXT,
  bio TEXT,
  role TEXT DEFAULT 'buyer',
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 1. Beats Table
CREATE TABLE IF NOT EXISTS public.beats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    producer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    type TEXT DEFAULT 'beat',
    category TEXT,
    bpm INTEGER,
    genre TEXT,
    tags TEXT[],
    price_basic DECIMAL(12, 2) DEFAULT 0,
    price_premium DECIMAL(12, 2) DEFAULT 0,
    price_exclusive DECIMAL(12, 2) DEFAULT 0,
    cover_url TEXT,
    master_url TEXT,
    demo_url TEXT,
    stems_url TEXT,
    status TEXT DEFAULT 'published',
    artist_name TEXT,
    producer_name TEXT,
    is_free_download BOOLEAN DEFAULT FALSE,
    free_download_requires_follow BOOLEAN DEFAULT FALSE,
    free_download_requires_comment BOOLEAN DEFAULT FALSE,
    free_download_requires_email BOOLEAN DEFAULT FALSE,
    free_download_count INTEGER DEFAULT 0,
    plays_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Conversations Table
CREATE TABLE IF NOT EXISTS public.conversations (
  id SERIAL PRIMARY KEY,
  buyer_id UUID NOT NULL REFERENCES auth.users(id),
  seller_id UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Messages Table
CREATE TABLE IF NOT EXISTS public.messages (
  id SERIAL PRIMARY KEY,
  conversation_id INTEGER REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES auth.users(id),
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3.1. Notifications Table
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  read BOOLEAN DEFAULT FALSE,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.beats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- 5. Profiles Policies
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- 6. Beats Policies
DROP POLICY IF EXISTS "Beats are viewable by everyone" ON public.beats;
CREATE POLICY "Anyone can view published beats" ON public.beats FOR SELECT USING (status = 'published' OR status IS NULL OR auth.uid() = producer_id);
CREATE POLICY "Producers can insert their own beats" ON public.beats FOR INSERT WITH CHECK (auth.uid() = producer_id);
CREATE POLICY "Producers can update their own beats" ON public.beats FOR UPDATE USING (auth.uid() = producer_id);
CREATE POLICY "Producers can delete their own beats" ON public.beats FOR DELETE USING (auth.uid() = producer_id);

-- 7. Conversations Policies
CREATE POLICY "Users can view their own conversations" ON public.conversations FOR SELECT USING (auth.uid() = buyer_id OR auth.uid() = seller_id);
CREATE POLICY "Users can insert conversations they are part of" ON public.conversations FOR INSERT WITH CHECK (auth.uid() = buyer_id OR auth.uid() = seller_id);

-- 8. Messages Policies
CREATE POLICY "Users can view messages in their conversations" ON public.messages FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.conversations 
    WHERE conversations.id = messages.conversation_id 
    AND (conversations.buyer_id = auth.uid() OR conversations.seller_id = auth.uid())
  )
);
CREATE POLICY "Users can insert messages in their conversations" ON public.messages FOR INSERT WITH CHECK (
  auth.uid() = sender_id AND
  EXISTS (
    SELECT 1 FROM public.conversations 
    WHERE conversations.id = messages.conversation_id 
    AND (conversations.buyer_id = auth.uid() OR conversations.seller_id = auth.uid())
  )
);

-- 8.1. Notifications Policies
CREATE POLICY "Users can view their own notifications" ON public.notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update their own notifications" ON public.notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can update own notifications" ON public.notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own notifications" ON public.notifications FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "System can insert notifications" ON public.notifications FOR INSERT WITH CHECK (true); -- Allow system/service to insert for any user

-- 9. Trigger to create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  base_username TEXT;
  final_username TEXT;
  suffix_counter INT := 1;
BEGIN
  -- Get base username from metadata or email prefix
  base_username := COALESCE(
    NEW.raw_user_meta_data->>'username', 
    NEW.raw_user_meta_data->>'artistic_name', 
    SPLIT_PART(NEW.email, '@', 1)
  );
  
  -- Clean base username to be a valid, lowercased alphanumeric string
  base_username := LOWER(REGEXP_REPLACE(base_username, '[^a-zA-Z0-9_]', '', 'g'));
  IF base_username = '' THEN
    base_username := 'user';
  END IF;
  
  final_username := base_username;
  
  -- Resolve username conflicts by appending numerical suffix
  WHILE EXISTS (SELECT 1 FROM public.profiles WHERE username = final_username) LOOP
    final_username := base_username || suffix_counter::text;
    suffix_counter := suffix_counter + 1;
  END LOOP;

  INSERT INTO public.profiles (id, username, display_name, artistic_name, avatar_url, role)
  VALUES (
    NEW.id,
    final_username,
    COALESCE(NEW.raw_user_meta_data->>'artistic_name', NEW.raw_user_meta_data->>'username', SPLIT_PART(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'artistic_name', SPLIT_PART(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'avatar_url',
    COALESCE(NEW.raw_user_meta_data->>'account_type', 'buyer')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger cleanup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Ensure all current users have a profile
INSERT INTO public.profiles (id)
SELECT id FROM auth.users
ON CONFLICT (id) DO NOTHING;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Ensure relationship exists for PostgREST
DO $$ 
BEGIN
    -- 1. Fix 'id' to be UUID if it's currently integer (common issue in migrations)
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='id' AND data_type='integer' AND table_schema='public') THEN
        -- We rename the old one to avoid data loss just in case, but usually for new apps we can just drop/recreate
        ALTER TABLE public.beats RENAME COLUMN id TO id_old;
        ALTER TABLE public.beats ADD COLUMN id UUID PRIMARY KEY DEFAULT gen_random_uuid();
        -- If there's no data yet, this is clean.
    END IF;

    -- 2. Ensure producer_id is UUID and references profiles correctly
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='producer_id' AND data_type='integer' AND table_schema='public') THEN
        ALTER TABLE public.beats ALTER COLUMN producer_id TYPE UUID USING NULL;
    END IF;

    -- 3. Add status column if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='status' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN status TEXT DEFAULT 'published';
    END IF;

    -- 4. Add type column if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='type' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN type TEXT DEFAULT 'beat';
    END IF;

    -- 5. Add category column if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='category' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN category TEXT;
    END IF;

    -- 6. Add artist_name column if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='artist_name' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN artist_name TEXT;
    END IF;

    -- 6.1. Add producer_name column if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='producer_name' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN producer_name TEXT;
    END IF;

    -- Add free download columns if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='is_free_download' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN is_free_download BOOLEAN DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='free_download_requires_follow' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN free_download_requires_follow BOOLEAN DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='free_download_requires_comment' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN free_download_requires_comment BOOLEAN DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='free_download_requires_email' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN free_download_requires_email BOOLEAN DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='free_download_count' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN free_download_count INTEGER DEFAULT 0;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='beats' AND column_name='plays_count' AND table_schema='public') THEN
        ALTER TABLE public.beats ADD COLUMN plays_count INTEGER DEFAULT 0;
    END IF;

    -- 6.2. Add role column to profiles if missing
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='profiles' AND column_name='role' AND table_schema='public') THEN
        ALTER TABLE public.profiles ADD COLUMN role TEXT DEFAULT 'buyer';
    END IF;

    -- Update existing users who have published beats to automatically be 'seller'
    UPDATE public.profiles SET role = 'seller' WHERE id IN (SELECT DISTINCT producer_id FROM public.beats);

    -- 7. Ensure Foreign Keys are correct
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'beats_producer_id_fkey') THEN
        ALTER TABLE public.beats
        ADD CONSTRAINT beats_producer_id_fkey
        FOREIGN KEY (producer_id)
        REFERENCES public.profiles(id)
        ON DELETE CASCADE;
    END IF;
END $$;

-- 8. Explicitly grant permissions to Authenticated users
GRANT ALL ON public.beats TO authenticated;
GRANT ALL ON public.beats TO service_role;

-- 9. Refresh RLS Policies
DROP POLICY IF EXISTS "Producers can insert their own beats" ON public.beats;
CREATE POLICY "Producers can insert their own beats" ON public.beats FOR INSERT TO authenticated WITH CHECK (auth.uid() = producer_id);

DROP POLICY IF EXISTS "Anyone can view published beats" ON public.beats;
CREATE POLICY "Anyone can view published beats" ON public.beats FOR SELECT USING (status = 'published' OR status IS NULL OR auth.uid() = producer_id);

DROP POLICY IF EXISTS "Producers can delete their own beats" ON public.beats;
CREATE POLICY "Producers can delete their own beats" ON public.beats FOR DELETE TO authenticated USING (auth.uid() = producer_id);

DROP POLICY IF EXISTS "Producers can update their own beats" ON public.beats;
CREATE POLICY "Producers can update their own beats" ON public.beats FOR UPDATE TO authenticated USING (auth.uid() = producer_id);
-- Note: 'beats' and 'avatars' buckets must exist and be public.

-- 10. Followers Table Setup
CREATE TABLE IF NOT EXISTS public.followers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index to avoid duplicates
CREATE UNIQUE INDEX IF NOT EXISTS unique_follow_relationship
ON public.followers (follower_id, following_id);

-- Enable RLS
ALTER TABLE public.followers ENABLE ROW LEVEL SECURITY;

-- Select policy
DROP POLICY IF EXISTS "Followers are viewable by everyone" ON public.followers;
CREATE POLICY "Followers are viewable by everyone"
ON public.followers
FOR SELECT
USING (true);

-- Insert policy
DROP POLICY IF EXISTS "Authenticated users can follow" ON public.followers;
CREATE POLICY "Authenticated users can follow"
ON public.followers
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = follower_id);

-- Delete policy
DROP POLICY IF EXISTS "Users can unfollow" ON public.followers;
CREATE POLICY "Users can unfollow"
ON public.followers
FOR DELETE
TO authenticated
USING (auth.uid() = follower_id);

-- Grant privileges
GRANT ALL ON public.followers TO authenticated;
GRANT ALL ON public.followers TO service_role;


-- ALLOW PUBLIC READ ON BUCKETS
-- CREATE POLICY "Public Read" ON storage.objects FOR SELECT USING (bucket_id IN ('beats', 'avatars'));

-- ALLOW AUTHENTICATED UPLOAD
-- CREATE POLICY "Auth Upload" ON storage.objects FOR INSERT WITH CHECK (
--     bucket_id IN ('beats', 'avatars') AND 
--     auth.role() = 'authenticated'
-- );

-- 11. Play Events Table Setup for Real Tracking
CREATE TABLE IF NOT EXISTS public.play_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  beat_id UUID NOT NULL REFERENCES public.beats(id) ON DELETE CASCADE,
  producer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  session_id TEXT NOT NULL,
  ip_hash TEXT NOT NULL,
  played_seconds INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.play_events ENABLE ROW LEVEL SECURITY;

-- Select policy
DROP POLICY IF EXISTS "Play events are viewable by everyone" ON public.play_events;
CREATE POLICY "Play events are viewable by everyone" ON public.play_events
FOR SELECT USING (true);

-- Insert policy
DROP POLICY IF EXISTS "Anyone can insert play event" ON public.play_events;
CREATE POLICY "Anyone can insert play event" ON public.play_events
FOR INSERT WITH CHECK (true);

-- Grant privileges
GRANT ALL ON public.play_events TO authenticated;
GRANT ALL ON public.play_events TO anon;
GRANT ALL ON public.play_events TO service_role;


-- 12. Create Real RPC for instant play increments
CREATE OR REPLACE FUNCTION public.increment_beat_plays(
  beat_id_input UUID
)
RETURNS void
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.beats
  SET plays_count = COALESCE(plays_count, 0) + 1
  WHERE id::text = beat_id_input::text;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION public.increment_beat_plays(
  beat_id_input INTEGER
)
RETURNS void
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.beats
  SET plays_count = COALESCE(plays_count, 0) + 1
  WHERE id::text = beat_id_input::text;
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION public.increment_beat_plays(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.increment_beat_plays(UUID) TO anon;
GRANT EXECUTE ON FUNCTION public.increment_beat_plays(UUID) TO service_role;

GRANT EXECUTE ON FUNCTION public.increment_beat_plays(INTEGER) TO authenticated;
GRANT EXECUTE ON FUNCTION public.increment_beat_plays(INTEGER) TO anon;
GRANT EXECUTE ON FUNCTION public.increment_beat_plays(INTEGER) TO service_role;


-- 13. Beat Collaborators Table Setup for Splits
CREATE TABLE IF NOT EXISTS public.beat_collaborators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  beat_id INTEGER REFERENCES public.beats(id) ON DELETE CASCADE,
  producer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  split_percentage NUMERIC NOT NULL CHECK (split_percentage >= 0 AND split_percentage <= 100),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Enable RLS
ALTER TABLE public.beat_collaborators ENABLE ROW LEVEL SECURITY;

-- Policies
DROP POLICY IF EXISTS "Public beat_collaborators are viewable by everyone" ON public.beat_collaborators;
CREATE POLICY "Public beat_collaborators are viewable by everyone" 
ON public.beat_collaborators FOR SELECT USING (true);

DROP POLICY IF EXISTS "Producers can insert their own collab splits" ON public.beat_collaborators;
CREATE POLICY "Producers can insert their own collab splits" 
ON public.beat_collaborators FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.beats 
    WHERE id = beat_collaborators.beat_id 
    AND producer_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "Producers can update their own collab splits" ON public.beat_collaborators;
CREATE POLICY "Producers can update their own collab splits" 
ON public.beat_collaborators FOR UPDATE USING (
  EXISTS (
    SELECT 1 FROM public.beats 
    WHERE id = beat_collaborators.beat_id 
    AND producer_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "Producers can delete their own collab splits" ON public.beat_collaborators;
CREATE POLICY "Producers can delete their own collab splits" 
ON public.beat_collaborators FOR DELETE USING (
  EXISTS (
    SELECT 1 FROM public.beats 
    WHERE id = beat_collaborators.beat_id 
    AND producer_id = auth.uid()
  )
);

-- Grant privileges
GRANT ALL ON public.beat_collaborators TO authenticated;
GRANT ALL ON public.beat_collaborators TO anon;
GRANT ALL ON public.beat_collaborators TO service_role;



