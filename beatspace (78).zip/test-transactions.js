import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
  try {
    const urlObj = new URL(url);
    url = urlObj.origin;
  } catch (e) {
    url = url.replace(/\/+$/, '');
  }
}

if (url && key) {
  const supabase = createClient(url, key);
  const { data, error } = await supabase.from('transactions').select('*').limit(1);
  console.log('Transactions query keys (if any):', data && data.length > 0 ? Object.keys(data[0]) : '(empty table)');
  // We can insert a draft transaction or query columns by looking at what information is returned by trying to insert empty row
  const { error: insErr } = await supabase.from('transactions').insert({});
  console.log('Insert empty transaction error (reveals columns/types):', insErr);
}
