import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const url = process.env.VITE_SUPABASE_URL || '';
const serviceRole = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!url || !serviceRole) {
  console.error("Missing SUPABASE env vars");
  process.exit(1);
}

const supabase = createClient(url, serviceRole, {
  auth: { persistSession: false }
});

async function main() {
  console.log("Checking tables...");
  
  // Try to query short_links
  const { data: sl, error: slErr } = await supabase.from('short_links').select('*').limit(1);
  if (slErr) {
    console.log("short_links query failed:", slErr.message);
  } else {
    console.log("short_links query succeeded. Data:", sl);
  }

  // Try to query short_link_clicks
  const { data: slc, error: slcErr } = await supabase.from('short_link_clicks').select('*').limit(1);
  if (slcErr) {
    console.log("short_link_clicks query failed:", slcErr.message);
  } else {
    console.log("short_link_clicks query succeeded. Data:", slc);
  }
}

main().catch(console.error);
