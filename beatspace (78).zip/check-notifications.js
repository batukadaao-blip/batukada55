import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl) {
  console.error("VITE_SUPABASE_URL is missing!");
} else {
  const supabase = createClient(supabaseUrl, serviceKey);

  async function check() {
    console.log("Checking beat_plays table...");
    const { data, error } = await supabase.from('beat_plays').select('*').limit(1);
    if (error) {
      console.log('Error querying beat_plays table:', error.code, error.message);
    } else {
      console.log('beat_plays table exists! Sample data:', data);
      if (data && data.length > 0) {
        console.log('beat_plays columns:', Object.keys(data[0]));
        console.log('beat_id type:', typeof data[0].beat_id);
      } else {
        // Try to insert a mock play or get definition
        console.log('beat_plays is empty, let\'s query metadata');
      }
    }
  }

  check();
}
