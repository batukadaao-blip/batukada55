import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

let url = process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

if (url) {
  if (!url.startsWith('http')) {
    url = `https://${url}`;
  }
  try {
    const urlObj = new URL(url);
    url = urlObj.origin;
  } catch (e) {
    url = url.replace(/\/+$/, '');
  }
}

if (url && key) {
  const supabase = createClient(url, key);
  console.log('Testing RPC process_beat_sale with valid UUID...');
  const { data, error } = await supabase.rpc('process_beat_sale', {
    p_beat_id: '00000000-0000-0000-0000-000000000006', // valid format UUID
    p_producer_id: '6e4c1b73-32b3-4252-85bc-d74f0a6f6adb',
    p_total_price: 20000
  });
  console.log('process_beat_sale RESULT:', data);
  console.log('process_beat_sale ERROR:', error);
}
