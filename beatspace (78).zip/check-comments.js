import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl) {
  console.error("VITE_SUPABASE_URL is missing!");
} else {
  const supabase = createClient(supabaseUrl, serviceKey);

  async function check() {
    console.log("Checking comments table...");
    const { data, error } = await supabase.from('comments').select('*').limit(1);
    if (error) {
      console.log('Error querying comments table:', error.code, error.message);
    } else {
      console.log('comments table exists! Sample data:', data);
    }
  }

  check();
}
