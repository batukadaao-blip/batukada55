import React, { StrictMode, ReactNode, ErrorInfo } from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

import {AuthProvider} from './context/AuthContext.tsx';
import {ToastProvider} from './context/ToastContext.tsx';
import {LanguageProvider} from './context/LanguageContext.tsx';

// Temporary detailed GlobalErrorBoundary to capture and debug runtime crashes immediately
class GlobalErrorBoundary extends React.Component<
  { children: ReactNode },
  { hasError: boolean; error: Error | null; errorInfo: ErrorInfo | null }
> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("GLOBAL CRITICAL ERROR CAPTURED BY MAIN BOUNDARY:", error, errorInfo);
    this.setState({ errorInfo });
    // Also track system logs to help debug
    try {
      fetch('/api/system/logs/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'frontend_boundary_critical',
          message: error.message || 'Critical rendering crash',
          stack: error.stack || '',
          componentStack: errorInfo.componentStack || ''
        })
      }).catch(() => {});
    } catch (_) {}
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#000000] text-slate-100 flex flex-col items-center justify-center p-6 font-sans select-text">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-[#5865F2]/10 via-transparent to-transparent -z-10" />
          <div className="w-full max-w-2xl bg-[#0c0c12]/80 border border-white/[0.06] rounded-[2rem] p-8 md:p-10 shadow-2xl backdrop-blur-3xl space-y-6">
            <div className="flex items-center gap-4 border-b border-white/[0.04] pb-6">
              <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 shrink-0">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <div>
                <span className="text-red-400 font-bold text-[10px] uppercase tracking-wider">Erro de Renderização Frontend</span>
                <h1 className="text-2xl font-black text-white uppercase italic tracking-tight">Recuperação de Emergência Batukada</h1>
              </div>
            </div>

            <p className="text-gray-400 text-sm leading-relaxed">
              Detetámos uma falha silenciosa num componente do React. Para garantir a estabilidade do Batukada, o sistema isolou o erro. Pode tentar reiniciar a aplicação abaixo:
            </p>

            <div className="bg-[#050508] border border-white/[0.03] rounded-xl p-5 space-y-3 font-mono text-xs overflow-auto max-h-[250px] leading-relaxed">
              <div className="text-red-400 font-bold">
                [{this.state.error?.name || 'Error'}]: {this.state.error?.message || 'Erro Desconhecido'}
              </div>
              {this.state.error?.stack && (
                <pre className="text-gray-500 whitespace-pre-wrap select-text text-[10px]">
                  {this.state.error.stack}
                </pre>
              )}
              {this.state.errorInfo?.componentStack && (
                <div className="pt-2 border-t border-white/[0.04]">
                  <span className="text-[#5865F2] font-semibold">Caminho da Falha (Component Stack):</span>
                  <pre className="text-gray-500 whitespace-pre-wrap text-[10px] mt-1">
                    {this.state.errorInfo.componentStack}
                  </pre>
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-white/[0.04]">
              <button
                onClick={() => {
                  try {
                    localStorage.clear();
                    sessionStorage.clear();
                  } catch (_) {}
                  window.location.reload();
                }}
                className="w-full sm:w-auto px-6 py-3 rounded-lg bg-red-650 hover:bg-red-700 text-white font-bold uppercase tracking-wider text-xs transition-colors cursor-pointer"
              >
                Limpar Cache e Reiniciar
              </button>
              <button
                onClick={() => window.location.reload()}
                className="w-full sm:w-auto px-6 py-3 rounded-lg bg-white/5 hover:bg-white/10 text-white border border-white/5 font-bold uppercase tracking-wider text-xs transition-colors cursor-pointer"
              >
                Tentar Novamente
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}


// Cleanly handle standard browser/client-side fetch abort signal rejections and errors
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    if (event.error && !event.message?.includes('ResizeObserver')) {
      const { message, stack } = event.error;
      const route = window.location.pathname;
      fetch('/api/system/logs/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'frontend_uncaught',
          message: message || event.message || 'Uncaught exception',
          severity: 'error',
          route,
          stack
        })
      }).catch(() => {});
    }
  });

  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    let message = '';
    let name = '';
    
    if (typeof reason === 'string') {
      message = reason;
    } else if (reason && typeof reason === 'object') {
      message = reason.message || '';
      name = reason.name || '';
    }

    const lowerMsg = message.toLowerCase();
    const lowerName = name.toLowerCase();

    if (
      lowerName === 'aborterror' || 
      lowerMsg.includes('abort') || 
      lowerMsg.includes('fetch') || 
      lowerMsg.includes('load failed') ||
      lowerMsg.includes('failed to fetch') ||
      lowerMsg.includes('net::err') ||
      lowerMsg.includes('connection')
    ) {
      event.preventDefault();
      console.log('Gracefully handled client-side fetch rejection:', message || name);
    }
  });

  window.addEventListener('error', (event) => {
    const message = event.message || '';
    const errorMsg = event.error?.message || '';
    const errorName = event.error?.name || '';
    
    const combined = `${message} ${errorMsg} ${errorName}`.toLowerCase();
    
    if (
      combined.includes('fetch') ||
      combined.includes('load failed') ||
      combined.includes('failed to fetch') ||
      combined.includes('error in connection') ||
      combined.includes('net::err') ||
      combined.includes('abort')
    ) {
      event.preventDefault();
      console.log('Gracefully handled window error event:', combined);
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <ToastProvider>
        <GlobalErrorBoundary>
          <LanguageProvider>
            <App />
          </LanguageProvider>
        </GlobalErrorBoundary>
      </ToastProvider>
    </AuthProvider>
  </StrictMode>,
);
