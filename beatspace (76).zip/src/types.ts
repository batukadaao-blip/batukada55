export interface Beat {
  id: string;
  title: string;
  producer: string;
  producer_name?: string;
  producer_id?: string;
  producer_username?: string;
  genre: string;
  price: {
    basic: number;
    premium: number;
    exclusive: number;
  };
  image: string;
  audioUrl: string;
  bpm: number;
  type?: 'beat' | 'kit';
  category?: string;
  created_at?: string;
  score?: number;
  key?: string;
  scale?: string;
  is_free_download?: boolean;
  free_download_requires_follow?: boolean;
  free_download_requires_comment?: boolean;
  free_download_requires_email?: boolean;
  free_download_count?: number;
  demo_url?: string;
  master_url?: string;
  audio_url?: string;
  producer_avatar?: string;
  featured?: boolean;
  featured_priority?: number;
  featured_start?: string;
  featured_end?: string;
  campaign?: string;
  plays_count?: number;
}

export type NotificationType = 'purchase' | 'upload' | 'flash_sale' | 'featured' | 'follower' | 'like' | 'comment' | 'verified' | 'account' | 'payment' | 'security' | 'purchase_confirmed';

export interface Notification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: string;
  message: string;
  read: boolean;
  created_at: string;
  metadata?: any;
}

export interface Producer {
  id: string;
  name: string;
  username?: string;
  tagline?: string;
  bio: string;
  avatar: string;
  banner?: string;
  followers: number;
  following?: number;
  totalBeats: number;
  totalPlays?: string;
  isVerified?: boolean;
  location?: string;
  joinDate?: string;
  genres?: string[];
  role?: string;
  socials?: {
    instagram?: string;
    tiktok?: string;
    youtube?: string;
    soundcloud?: string;
    spotify?: string;
    twitter?: string;
    web?: string;
  };
  equipment?: string[];
  score?: number;
  is_featured?: boolean;
  salesCount?: number;
  topPlaylistTitle?: string;
  weeklyGrowth?: number;
  monthlyPlaysGrowth?: number;
  playlistCount?: number;
}
