import { useState } from 'react';
import { Beat } from '../types';
import { X, ShoppingCart, ArrowLeft, Trash2, CheckCircle2, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getSupabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

const toValidUuid = (id: any): string => {
  if (!id) return '00000000-0000-0000-0000-000000000000';
  const strId = String(id).trim();
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (uuidRegex.test(strId)) {
    return strId;
  }
  
  if (/^\d+$/.test(strId)) {
    const padded = strId.padStart(12, '0');
    return `00000000-0000-0000-0000-${padded}`;
  }
  
  let hex = '';
  for (let i = 0; i < strId.length; i++) {
    const code = strId.charCodeAt(i);
    hex += (code % 16).toString(16);
  }
  
  const cleanHex = hex.toLowerCase().replace(/[^0-9a-f]/g, '0').padStart(32, '0').substring(0, 32);
  return `${cleanHex.substring(0, 8)}-${cleanHex.substring(8, 12)}-${cleanHex.substring(12, 16)}-${cleanHex.substring(16, 20)}-${cleanHex.substring(20, 32)}`;
};

const toValidIntId = (id: any): number => {
  if (!id) return 1;
  const strId = String(id).trim();
  const parsed = parseInt(strId, 10);
  if (!isNaN(parsed)) {
    return parsed;
  }
  // If it's a padded UUID format like 00000000-0000-0000-0000-000000000006, extract the integer
  const lastParts = strId.split('-');
  const lastPart = lastParts[lastParts.length - 1];
  const parsedLast = parseInt(lastPart, 10);
  if (!isNaN(parsedLast)) {
    return parsedLast;
  }
  return 1;
};

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: Beat[];
  onRemoveItem: (beatId: string) => void;
  isAuthenticated: boolean;
  onOpenAuth: (mode: 'login' | 'signup') => void;
  onCheckoutSuccess?: () => void;
}

export default function Cart({ isOpen, onClose, cartItems, onRemoveItem, isAuthenticated, onOpenAuth, onCheckoutSuccess }: CartProps) {
  if (!isOpen) return null;

  const [createdOrder, setCreatedOrder] = useState<{ id: string; total: number } | null>(null);
  const [step, setStep] = useState<'checkout_info' | 'confirm_success' | null>(null);

  const total = cartItems.reduce((acc, item) => acc + item.price.basic, 0);

  const { user } = useAuth();
  const handleCheckout = async () => {
    const supabase = getSupabase();
    if (!supabase || !user) return;

    if (cartItems.some(item => !item.producer_id)) {
        console.error("Some items are missing producer_id:", cartItems);
        alert("Erro no carrinho: Alguns itens não têm produtor definido.");
        return;
    }

    console.log("items:", cartItems);

    console.log('CHECKOUT START');
    let orderId: string | null = null;
    let checkoutError: any = null;

    try {
      const isSingleBeat = cartItems.length === 1;
      const firstBeat = cartItems[0];
      
      const orderPayload: any = {
        customer_id: user.id,
        amount: total,
        status: 'pending'
      };

      if (isSingleBeat) {
        orderPayload.beat_title = firstBeat.title;
        orderPayload.beat_id = toValidUuid(firstBeat.id);
      } else {
        orderPayload.beat_title = `${cartItems.length} Beats`;
      }

      // 1. Create the Order
      console.log('[CHECKOUT DEBUG] STEP 1: BEFORE creating order for user:', user.id, orderPayload);
      const { data: orderData, error: orderErr } = await supabase
        .from('orders')
        .insert({
          ...orderPayload,
          customer_id: toValidUuid(user.id)
        })
        .select()
        .single();
      console.log('[CHECKOUT DEBUG] STEP 1 DONE: Order creation response.', { orderData, orderErr });

      if (orderErr) {
        throw new Error('Order creation failed: ' + orderErr.message);
      }
      
      orderId = orderData.id;

      // 2. Loop through each cart item and process sequentially
      const items = cartItems.map(item => {
        return {
          ...item,
          beat_id: toValidIntId(item.id)
        };
      });

      console.log(
        'CHECKOUT BEAT IDS:',
         items.map(i => ({
           beat_id: i.beat_id,
           title: i.title
         }))
       );
 
       for (const item of items) {
         const beatIdToInsert = item.beat_id;
 
         // Insert Order Item
         console.log(`[CHECKOUT DEBUG] STEP 2: BEFORE inserting order item for beat ${item.title} (ID: ${beatIdToInsert})`);
         const { error: itemErr } = await supabase
           .from('order_items')
           .insert({
             order_id: orderId,
             beat_id: beatIdToInsert,
             license_id: 1, // basic license identifier
             producer_id: toValidUuid(item.producer_id),
             price: item.price.basic
           });
        console.log(`[CHECKOUT DEBUG] STEP 2 DONE: Order item inserted for beat ${item.title}. Error if any:`, itemErr);

        if (itemErr) {
          throw new Error('Order item insert failed for beat ' + item.title + ': ' + itemErr.message);
        }


      }
    } catch (err: any) {
      console.error('Checkout transaction error:', err);
      checkoutError = err;
    }

    if (checkoutError || !orderId) {
      alert('Error processing order: ' + (checkoutError?.message || 'Unknown error'));
    } else {
      console.log('Order placed successfully! ID: ' + orderId);
      // Clean cart items locally by calling onRemoveItem for each
      const itemsToClear = [...cartItems];
      itemsToClear.forEach(item => {
        onRemoveItem(item.id);
      });
      // Set the states to show instructions
      setCreatedOrder({ id: orderId, total });
      setStep('checkout_info');
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[150] bg-black overflow-y-auto"
    >
      {/* Subtle Background Glows */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/5 blur-[120px] rounded-full -z-10" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-purple-600/5 blur-[120px] rounded-full -z-10" />

      <div className="max-w-7xl mx-auto px-4 pt-32 pb-20">
        {/* Back Button */}
        <button 
          onClick={onClose} 
          className="flex items-center gap-2 text-gray-500 hover:text-white mb-8 transition-all group"
        >
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-xs font-black uppercase tracking-widest">Continuar a Comprar</span>
        </button>

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-black text-white italic uppercase tracking-tighter">
              Teu <span className="text-blue-500">Carrinho</span>
            </h1>
            <p className="text-gray-400 max-w-xl font-medium">
              Estás a um passo de libertar a tua criatividade com beats profissionais de Angola.
            </p>
          </div>
          <div className="flex items-center gap-4 bg-white/5 border border-white/10 px-6 py-4 rounded-2xl">
            <div className="text-right">
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest block leading-none mb-1">Total de Itens</span>
              <span className="text-2xl font-black text-white leading-none">{cartItems.length}</span>
            </div>
            <div className="w-12 h-12 bg-blue-600/10 rounded-xl flex items-center justify-center">
              <ShoppingCart className="text-blue-500" size={24} />
            </div>
          </div>
        </div>
        
        {createdOrder ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-xl mx-auto bg-white/5 border border-white/10 rounded-[40px] p-8 md:p-12 shadow-2xl space-y-8 relative overflow-hidden text-left"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 blur-[60px] rounded-full -z-10" />
            
            {step === 'confirm_success' ? (
              <div className="text-center space-y-6 py-8">
                <CheckCircle2 size={64} className="text-green-500 mx-auto" />
                <h2 className="text-3xl font-black italic uppercase text-white tracking-tight">Obrigado!</h2>
                <p className="text-gray-400 font-medium">
                  O teu pagamento foi submetido para verificação manual. Os teus ficheiros e licenças serão libertados na tua conta assim que o pagamento for validado.
                </p>
                <button 
                  onClick={() => {
                    setCreatedOrder(null);
                    setStep(null);
                    onClose();
                  }}
                  className="w-full py-5 bg-blue-600 text-white font-black rounded-2xl hover:bg-blue-500 transition-all uppercase tracking-[0.2em] text-xs shadow-xl shadow-blue-600/40"
                >
                  Voltar ao Marketplace
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center gap-4 border-b border-white/5 pb-6">
                  <div className="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center text-green-500 shrink-0">
                    <CheckCircle2 size={24} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black italic uppercase text-white tracking-tight">Encomenda Criada!</h2>
                    <p className="text-xs text-gray-500 uppercase tracking-widest font-black">
                      Pedido ID: <span className="font-mono text-white select-all">{createdOrder.id}</span>
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-gray-400 text-[10px] font-black uppercase tracking-widest block">Valor Total a Pagar</span>
                  <p className="text-3xl font-black text-orange-400 italic leading-none">{createdOrder.total.toLocaleString()} Kz</p>
                </div>

                <div className="bg-white/5 border border-white/10 p-6 rounded-3xl space-y-4">
                  <div className="flex items-center gap-2 border-b border-white/5 pb-2">
                    <span className="text-xs font-black uppercase tracking-widest text-blue-400">Opção 1: Multicaixa Express / ATM</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500 text-[10px] uppercase font-black tracking-widest block mb-1">Entidade</span>
                      <p className="font-mono font-bold text-white">12345</p>
                    </div>
                    <div>
                      <span className="text-gray-500 text-[10px] uppercase font-black tracking-widest block mb-1">Referência</span>
                      <p className="font-mono font-bold text-white select-all">{createdOrder.id.slice(0, 8).toUpperCase()}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/10 p-6 rounded-3xl space-y-4">
                  <div className="flex items-center gap-2 border-b border-white/5 pb-2">
                    <span className="text-xs font-black uppercase tracking-widest text-blue-400">Opção 2: Transferência BFA / IBAN</span>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="text-gray-500 text-[10px] uppercase font-black tracking-widest block mb-1">Nome do Beneficiário</span>
                      <p className="font-bold text-white">Miguel Francisco Alfredo</p>
                    </div>
                    <div>
                      <span className="text-gray-500 text-[10px] uppercase font-black tracking-widest block mb-1">IBAN de Destino</span>
                      <p className="font-mono font-bold text-white text-xs select-all">AO06000600002373370230171</p>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-gray-400 leading-relaxed font-semibold">
                  Após efetuar a transferência ou o pagamento por referência, envia o comprovativo para o nosso suporte para agilizar a liberação.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                  <a 
                    href={`https://wa.me/27697273223?text=Olá, acabei de efetuar o pagamento do pedido ${createdOrder.id} no valor de ${createdOrder.total} Kz.`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="flex items-center justify-center gap-2 py-4 bg-green-600 rounded-2xl font-black uppercase text-xs hover:bg-green-500 text-white transition-all shadow-xl shadow-green-600/10 cursor-pointer"
                  >
                    <MessageCircle size={16} /> Enviar Comprovativo
                  </a>
                  <button 
                    onClick={async () => {
                      const supabase = getSupabase();
                      if (supabase) {
                        await supabase.from('orders').update({ status: 'waiting_confirmation' }).eq('id', createdOrder.id);
                      }
                      setStep('confirm_success');
                    }}
                    className="py-4 bg-blue-600 rounded-2xl font-black uppercase text-xs hover:bg-blue-500 text-white transition-all shadow-xl shadow-blue-600/10 cursor-pointer"
                  >
                    Submeter Pagamento
                  </button>
                </div>

                <button 
                  onClick={() => {
                    setCreatedOrder(null);
                    setStep(null);
                    onClose();
                  }}
                  className="w-full text-center text-gray-400 hover:text-white text-xs font-black uppercase tracking-widest pt-4 block"
                >
                  Continuar no site
                </button>
              </div>
            )}
          </motion.div>
        ) : cartItems.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 border border-white/10 rounded-[40px] p-12 md:p-24 flex flex-col items-center justify-center text-center shadow-2xl"
          >
            <div className="w-32 h-32 bg-white/5 rounded-[32px] flex items-center justify-center mb-8 relative">
              <ShoppingCart size={48} className="text-gray-700" />
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-[10px] font-black text-white">0</div>
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-white mb-4 uppercase tracking-tight italic">
              O teu carrinho está vazio.
            </h2>
            <p className="text-gray-400 max-w-sm mb-12 font-medium">
              Parece que ainda não encontraste o beat perfeito. Explora os nossos destaques e começa a tua jornada.
            </p>
            <button 
              onClick={onClose}
              className="px-10 py-5 rounded-2xl bg-blue-600 text-white font-black uppercase tracking-widest text-xs hover:bg-blue-500 transition-all shadow-2xl shadow-blue-600/20 active:scale-95 transform hover:-translate-y-1"
            >
              Explorar Marketplace
            </button>
          </motion.div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-12 items-start">
            {/* Items List */}
            <div className="lg:col-span-2 space-y-6">
              <AnimatePresence>
                {cartItems.map((item) => (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    key={item.id} 
                    className="group relative bg-[#0B0B0B] border border-white/5 p-6 rounded-[32px] flex flex-col sm:flex-row items-center gap-8 hover:bg-[#121212] transition-all"
                  >
                    <div className="w-40 h-40 rounded-2xl overflow-hidden shrink-0 shadow-2xl">
                      <img 
                        src={item.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=160'} 
                        alt={item.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                      />
                    </div>
                    <div className="flex-1 text-center sm:text-left py-2">
                       <div className="flex items-center justify-center sm:justify-start gap-3 mb-2">
                          <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest bg-blue-500/10 px-2 py-1 rounded">Licença Básica</span>
                          <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest bg-white/5 px-2 py-1 rounded">MP3 + WAV</span>
                       </div>
                       <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-1 italic">{item.title}</h3>
                       <p className="text-gray-400 font-bold tracking-widest uppercase text-xs mb-6">@{item.producer}</p>
                       
                       <button 
                          onClick={() => onRemoveItem(item.id)}
                          className="flex items-center gap-2 text-gray-500 hover:text-red-400 transition-colors text-[10px] font-black uppercase tracking-widest group/trash"
                        >
                          <Trash2 size={14} className="group-hover/trash:shake" />
                          Remover do Carrinho
                       </button>
                    </div>
                    <div className="text-center sm:text-right shrink-0">
                      <div className="text-3xl font-black text-white italic mb-1">{item.price.basic} <span className="text-sm not-italic text-blue-500">Kz</span></div>
                      <div className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Inclui uso Comercial</div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
            
            {/* Summary Card */}
            <div className="lg:sticky lg:top-32 space-y-6">
              <div className="bg-white/5 border border-white/10 p-8 rounded-[40px] backdrop-blur-xl shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 blur-[60px] rounded-full -z-10" />
                
                <h3 className="text-xl font-black text-white uppercase tracking-tight mb-8 flex items-center gap-2 italic">
                  Sumário <span className="text-blue-500">Geral</span>
                </h3>

                <div className="space-y-4 mb-10">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Subtotal</span>
                    <span className="text-white font-black">{total} Kz</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Taxas</span>
                    <span className="text-green-500 font-black">0 Kz</span>
                  </div>
                  <div className="pt-6 border-t border-white/5 flex justify-between items-end">
                    <div>
                      <span className="text-gray-500 font-bold uppercase tracking-widest text-[10px] block mb-1">Valor Final</span>
                      <span className="text-3xl font-black text-white italic leading-none">{total} <span className="text-sm not-italic text-blue-500">Kz</span></span>
                    </div>
                  </div>
                </div>

                {isAuthenticated ? (
                  <button type="button" onClick={handleCheckout} className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl hover:bg-blue-500 transition-all uppercase tracking-[0.2em] text-xs shadow-xl shadow-blue-600/40 transform hover:-translate-y-1 active:scale-95 active:translate-y-0">
                    Prosseguir Pagamento
                  </button>
                ) : (
                  <div className="space-y-4">
                    <div className="p-4 bg-orange-500/10 border border-orange-500/20 rounded-2xl text-center">
                      <p className="text-[10px] font-bold text-orange-400 uppercase tracking-widest leading-relaxed">
                        Precisas de criar uma conta ou entrar para finalizar a compra.
                      </p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <button 
                        onClick={() => onOpenAuth('login')}
                        className="w-full bg-white/10 text-white font-black py-4 rounded-xl hover:bg-white/20 transition-all uppercase tracking-widest text-[10px] border border-white/10"
                      >
                        Entrar
                      </button>
                      <button 
                        onClick={() => onOpenAuth('signup')}
                        className="w-full bg-blue-600 text-white font-black py-4 rounded-xl hover:bg-blue-500 transition-all uppercase tracking-widest text-[10px] shadow-lg shadow-blue-600/20"
                      >
                        Criar Conta
                      </button>
                    </div>
                  </div>
                )}
                
                <p className="text-[10px] text-gray-500 text-center mt-6 leading-relaxed font-medium">
                  Pagamento seguro via <span className="text-blue-400">Multicaixa</span> ou Transferência.
                </p>
              </div>

              {/* Security Benefit */}
              <div className="bg-blue-600/10 border border-blue-500/20 p-6 rounded-3xl flex items-center gap-4">
                <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center shrink-0">
                  <X className="rotate-45 text-white" size={20} />
                </div>
                <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest leading-relaxed">
                  Download instantâneo garantido após confirmação do pagamento.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
