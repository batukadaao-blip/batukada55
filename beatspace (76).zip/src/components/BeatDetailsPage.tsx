import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  Heart, 
  Share2, 
  Calendar, 
  Activity, 
  Music, 
  Sparkles, 
  Check, 
  ShieldCheck, 
  FileText, 
  ShoppingCart, 
  User,
  Info,
  MessageSquare,
  Send,
  ListMusic,
  Flag,
  ShieldAlert,
  Mail,
  Download,
  Trash2,
  CornerDownRight,
  Loader2,
  Pin,
  PinOff,
  Smile,
  TrendingUp,
  Zap,
  Copy
} from 'lucide-react';
import { motion } from 'motion/react';
import { Beat } from '../types';
import BeatCard from './BeatCard';
import VerifiedBadge from './VerifiedBadge';
import { getSupabase, getPublicUrl } from '../lib/supabase';
import { adminStore } from '../lib/adminStore';
import { playService } from '../lib/playService';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { slugify } from '../lib/slugify';
import { recommendationService } from '../lib/recommendationService';

const authorVerificationCache = new Map<string, boolean>();

const CommentAuthorVerification = ({ name, username, isBeatProducer, isBeatProducerVerified }: { name: string; username?: string; isBeatProducer: boolean; isBeatProducerVerified: boolean }) => {
  const [verified, setVerified] = useState(isBeatProducer ? isBeatProducerVerified : false);

  useEffect(() => {
    if (isBeatProducer) {
      setVerified(isBeatProducerVerified);
      return;
    }
    const searchVal = (username || name || '').replace(/^@/, '').trim().toLowerCase();
    if (!searchVal) return;

    if (authorVerificationCache.has(searchVal)) {
      setVerified(authorVerificationCache.get(searchVal)!);
      return;
    }

    const supabase = getSupabase();
    if (!supabase) return;

    const fetchV = async () => {
      try {
        const { data } = await supabase.from('profiles')
          .select('is_verified')
          .or(`username.ilike.${searchVal},artistic_name.ilike.${searchVal},display_name.ilike.${searchVal}`)
          .maybeSingle();
        const isV = !!data?.is_verified;
        authorVerificationCache.set(searchVal, isV);
        setVerified(isV);
      } catch (e) {
        // Safe silent handle
      }
    };
    fetchV();
  }, [name, username, isBeatProducer, isBeatProducerVerified]);

  if (!verified) return null;
  return <VerifiedBadge size="sm" />;
};

interface BeatDetailsPageProps {
  beat: Beat;
  beats: Beat[];
  isPlaying: boolean;
  currentBeat: Beat | null;
  onPlay: (beat: Beat) => void;
  onAddToCart: (beat: Beat) => void;
  onSelectProducer: (producerName: string) => void;
  onSelectBeat: (beat: Beat) => void;
  onBack: () => void;
}

export default function BeatDetailsPage({
  beat,
  beats,
  isPlaying,
  currentBeat,
  onPlay,
  onAddToCart,
  onSelectProducer,
  onSelectBeat,
  onBack
}: BeatDetailsPageProps) {
  console.log('BEAT DETAILS RECEIVED:', beat);
  const { user, profile } = useAuth();
  const { showToast } = useToast();
  const supabase = getSupabase();

  const [selectedLicense, setSelectedLicense] = useState<'basic' | 'premium' | 'exclusive'>('basic');
  const [isFavorited, setIsFavorited] = useState(false);
  const [copied, setCopied] = useState(false);

  const [downloadFollowed, setDownloadFollowed] = useState(false);
  const [downloadCommented, setDownloadCommented] = useState(false);
  const [downloadEmail, setDownloadEmail] = useState('');
  const [downloadEmailVerified, setDownloadEmailVerified] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [downloadRequirementComment, setDownloadRequirementComment] = useState('');

  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportType, setReportType] = useState<'beat' | 'comment'>('beat');
  const [reportTargetId, setReportTargetId] = useState('');
  const [reportTargetName, setReportTargetName] = useState('');
  const [reportReason, setReportReason] = useState<'copyright' | 'spam' | 'inappropriate' | 'scam' | 'stolen_beat' | 'other'>('spam');
  const [reportDetails, setReportDetails] = useState('');

  const [isProducerVerified, setIsProducerVerified] = useState(false);
  const [producerAvatar, setProducerAvatar] = useState((beat as any).producer_avatar || '');

  useEffect(() => {
    setIsProducerVerified(false);
    setProducerAvatar((beat as any).producer_avatar || '');
    if (!supabase || !beat?.producer_id) return;
    
    const fetchProducerInfo = async () => {
      try {
        const { data } = await supabase.from('profiles').select('is_verified, avatar_url').eq('id', beat.producer_id).maybeSingle();
        if (data) {
          setIsProducerVerified(!!data.is_verified);
          if (data.avatar_url) {
            setProducerAvatar(data.avatar_url);
          }
        }
      } catch (err) {
        console.warn('Silent skip verification load:', err);
      }
    };
    fetchProducerInfo();
  }, [supabase, beat?.producer_id, beat?.producer_avatar]);

  const handleOpenReport = (type: 'beat' | 'comment', id: string, name: string) => {
    setReportType(type);
    setReportTargetId(id);
    setReportTargetName(name);
    // Reset reason & details
    setReportReason('spam');
    setReportDetails('');
    setIsReportModalOpen(true);
  };

  const handleSendReport = () => {
    if (!beat) return;
    adminStore.addReport({
      reporter_id: user?.id || 'anon-visitor',
      reporter_name: user?.user_metadata?.full_name || user?.user_metadata?.artistic_name || user?.email?.split('@')[0] || 'Utilizador Anónimo',
      target_id: reportTargetId,
      target_type: reportType,
      target_name: reportType === 'beat' ? `Beat: ${reportTargetName}` : `Comentário: ${reportTargetName}`,
      reason: reportReason,
      details: reportDetails
    });

    setIsReportModalOpen(false);
    setReportDetails('');
    showToast('A tua denúncia foi registada e encaminhada para a equipa de moderação do Batukada.', 'success', 'Denúncia Efetuada');
  };

  const [comments, setComments] = useState<any[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [replyingToId, setReplyingToId] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [newComment, setNewComment] = useState('');
  const [commentsFilter, setCommentsFilter] = useState<'top' | 'latest' | 'producer' | 'timestamp'>('top');
  const [hoveredProfileUsername, setHoveredProfileUsername] = useState<string | null>(null);
  const [activeReactionCommentId, setActiveReactionCommentId] = useState<string | null>(null);

  const formatRelativeTimeAO = (dateString: string) => {
    if (!dateString) return "agora";
    try {
      const date = new Date(dateString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      if (diffMs < 0) return "agora";
      
      const diffSecs = Math.floor(diffMs / 1000);
      if (diffSecs < 60) return "agora";
      
      const diffMins = Math.floor(diffSecs / 60);
      if (diffMins < 60) return `há ${diffMins} min`;
      
      const diffHours = Math.floor(diffMins / 60);
      if (diffHours < 24) return `há ${diffHours} h`;
      
      const diffDays = Math.floor(diffHours / 24);
      if (diffDays < 7) return `há ${diffDays} d`;
      
      return date.toLocaleDateString('pt-AO', { day: 'numeric', month: 'short' });
    } catch (e) {
      return "agora";
    }
  };

  const fetchComments = async () => {
    if (!beat?.id) return;
    setLoadingComments(true);
    try {
      const resp = await fetch(`/api/comments/${beat.id}`);
      const data = await resp.json();
      if (data.success && data.comments) {
        setComments(data.comments);
      }
    } catch (e) {
      console.warn("Error fetching premium comments:", e);
    } finally {
      setLoadingComments(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, [beat?.id]);

  // Live stream sync of new comments
  useEffect(() => {
    const handleNewComment = (e: CustomEvent) => {
      const newC = e.detail;
      if (newC && String(newC.beat_id) === String(beat?.id)) {
        setComments(prev => {
          if (prev.some(c => c.id === newC.id)) return prev;
          return [newC, ...prev];
        });
      }
    };
    window.addEventListener('new_comment_received' as any, handleNewComment);
    return () => {
      window.removeEventListener('new_comment_received' as any, handleNewComment);
    };
  }, [beat?.id]);

  // Comment Likes handling (Like & Unlike live toggle)
  const handleLikeComment = async (commentId: string) => {
    if (!user) {
      showToast('Faz login para curtir comentários.', 'error', 'Necessário Login');
      return;
    }
    setComments(prev => prev.map(c => {
      if (c.id === commentId) {
        const likes = c.likes ? [...c.likes] : [];
        const index = likes.indexOf(user.id);
        if (index > -1) {
          likes.splice(index, 1);
        } else {
          likes.push(user.id);
        }
        return { ...c, likes };
      }
      return c;
    }));

    try {
      const response = await fetch(`/api/comments/${commentId}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: user.id })
      });
      const data = await response.json();
      if (data.success) {
        setComments(prev => prev.map(c => (c.id === commentId ? { ...c, likes: data.likes } : c)));
      }
    } catch (err) {
      console.warn("Error liking comment:", err);
    }
  };

  // Reactions Engine (🔥 + 🎧 + 💯 + 🚀 + 😮)
  const handleReactComment = async (commentId: string, emoji: string) => {
    if (!user) {
      showToast('Faz login para reagir a este comentário.', 'error', 'Necessário Login');
      return;
    }
    setComments(prev => prev.map(c => {
      if (c.id === commentId) {
        const reactions = c.reactions ? { ...c.reactions } : {};
        if (!reactions[emoji]) reactions[emoji] = [];
        const index = reactions[emoji].indexOf(user.id);
        if (index > -1) {
          reactions[emoji].splice(index, 1);
        } else {
          reactions[emoji].push(user.id);
        }
        return { ...c, reactions };
      }
      return c;
    }));
    setActiveReactionCommentId(null);

    try {
      const response = await fetch(`/api/comments/${commentId}/react`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: user.id, emoji })
      });
      const data = await response.json();
      if (data.success) {
        setComments(prev => prev.map(c => {
          if (c.id === commentId) {
            return { ...c, reactions: data.reactions };
          }
          return c;
        }));
      }
    } catch (err) {
      console.warn("Error reacting to comment:", err);
    }
  };

  // Producer Pinned comment control
  const handlePinComment = async (commentId: string) => {
    if (!user) return;
    try {
      const response = await fetch(`/api/comments/${commentId}/pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ producer_id: user.id })
      });
      const data = await response.json();
      if (data.success) {
        const isPinnedNow = data.is_pinned;
        showToast(
          isPinnedNow ? 'Comentário fixado no topo!' : 'Comentário desafixado.',
          'success',
          'Membro de Destaque'
        );
        setComments(prev => prev.map(c => {
          if (c.id === commentId) {
            return { ...c, is_pinned: isPinnedNow };
          }
          if (isPinnedNow && c.beat_id === beat.id && c.id !== commentId) {
            return { ...c, is_pinned: false };
          }
          return c;
        }));
      }
    } catch (err) {
      console.warn("Error pinning comment:", err);
    }
  };

  // Comment Sharing Deep Link
  const handleCopyCommentLink = (commentId: string) => {
    const currentUrl = window.location.href.split('?')[0];
    const shareUrl = `${currentUrl}?commentId=${commentId}`;
    navigator.clipboard.writeText(shareUrl).then(() => {
      showToast('Link do comentário copiado para a área de transferência! 🔥', 'success', 'Partilhar');
    }).catch(err => {
      console.warn("Error copying share link:", err);
    });
  };

  // Interactive @username parse render
  const renderContentWithMentions = (text: string) => {
    if (!text) return null;
    const parts = text.split(/(@[a-zA-Z0-9_\-]+)/g);
    return parts.map((part, index) => {
      if (part.startsWith('@')) {
        const u = part.substring(1).trim();
        return (
          <button
            key={index}
            onClick={(e) => {
              e.stopPropagation();
              onSelectProducer(u);
            }}
            className="text-purple-400 font-extrabold hover:text-purple-300 hover:underline transition-all cursor-pointer inline-block pr-0.5 leading-none"
            type="button"
          >
            {part}
          </button>
        );
      }
      return <span key={index} className="text-neutral-300 font-normal leading-relaxed">{part}</span>;
    });
  };

  // Viral Moments Engine: Group beats comments on 10s intervals
  const getViralMoment = () => {
    const timestampComments = comments.filter(c => c.timestamp_seconds !== null && c.timestamp_seconds !== undefined);
    if (timestampComments.length === 0) return null;

    const intervals: { [key: number]: number } = {};
    timestampComments.forEach(c => {
      const rounded = Math.floor(c.timestamp_seconds / 10) * 10;
      intervals[rounded] = (intervals[rounded] || 0) + 1;
    });

    let maxInterval = -1;
    let maxCount = 0;
    Object.entries(intervals).forEach(([seconds, count]) => {
      if (count > maxCount) {
        maxCount = count;
        maxInterval = Number(seconds);
      }
    });

    if (maxCount < 2) return null; // needs at least 2 comments for a segment to spike as viral

    const mins = Math.floor(maxInterval / 60);
    const secs = maxInterval % 60;
    const formatted = `${mins}:${secs.toString().padStart(2, '0')}`;

    return {
      seconds: maxInterval,
      formatted,
      count: maxCount
    };
  };

  // Comments Filtering & Sorting algorithm
  const getParentComments = () => {
    const parentList = comments.filter(c => !c.parent_id);
    
    if (commentsFilter === 'latest') {
      return [...parentList].sort((a, b) => {
        if (a.is_pinned && !b.is_pinned) return -1;
        if (!a.is_pinned && b.is_pinned) return 1;
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      });
    }

    if (commentsFilter === 'producer') {
      return parentList.filter(c => String(c.user_id) === String(beat?.producer_id));
    }

    if (commentsFilter === 'timestamp') {
      return parentList.filter(c => c.timestamp_seconds !== null && c.timestamp_seconds !== undefined)
        .sort((a, b) => {
          if (a.is_pinned && !b.is_pinned) return -1;
          if (!a.is_pinned && b.is_pinned) return 1;
          return (a.timestamp_seconds || 0) - (b.timestamp_seconds || 0);
        });
    }

    // Default: 'top' Algorithm
    return [...parentList].sort((a, b) => {
      if (a.is_pinned && !b.is_pinned) return -1;
      if (!a.is_pinned && b.is_pinned) return 1;

      const scoreA = (a.likes?.length || 0) * 3 + (comments.filter(r => r.parent_id === a.id).length || 0) * 1.5;
      const scoreB = (b.likes?.length || 0) * 3 + (comments.filter(r => r.parent_id === b.id).length || 0) * 1.5;

      if (scoreB !== scoreA) {
        return scoreB - scoreA;
      }
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });
  };

  if (!beat) {
    return (
      <div className="p-10 text-center text-gray-500 flex flex-col items-center justify-center min-h-[400px]">
        <p className="font-bold text-lg mb-4">Carregando detalhes...</p>
        <button onClick={onBack} className="px-5 py-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all font-black uppercase text-xs tracking-widest leading-none">Voltar</button>
      </div>
    );
  }

  const isKit = beat.type === 'kit' || (beat.category && (beat.category === 'Drum Kit' || beat.category === 'Loop Kit' || beat.category === 'drum-kit' || beat.category === 'loop-kit' || beat.category === 'sample-pack' || beat.category.toLowerCase().includes('kit') || beat.category.toLowerCase().includes('pack')));

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;

    const contentForComment = newComment;
    setNewComment('');

    try {
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          beat_id: beat.id,
          user_id: user.id,
          content: contentForComment
        })
      });
      const data = await response.json();
      if (data.success && data.comment) {
        showToast('Comentário publicado!', 'success', 'Comentário');
        setComments((prev) => [data.comment, ...prev]);
      } else {
        showToast(data.error || 'Erro ao publicar comentário.', 'error');
      }
    } catch (err) {
      console.error('Error posting comment:', err);
      showToast('Erro ao publicar comentário.', 'error');
    }
  };

  const handleAddReply = async (e: React.FormEvent, parentId: string) => {
    e.preventDefault();
    if (!replyContent.trim() || !user) return;

    const contentForReply = replyContent;
    setReplyContent('');
    setReplyingToId(null);

    try {
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          beat_id: beat.id,
          user_id: user.id,
          content: contentForReply,
          parent_id: parentId
        })
      });
      const data = await response.json();
      if (data.success && data.comment) {
        showToast('Resposta enviada!', 'success', 'Resposta');
        setComments((prev) => [...prev, data.comment]);
      } else {
        showToast(data.error || 'Erro ao publicar resposta.', 'error');
      }
    } catch (err) {
      console.error('Error listing reply:', err);
      showToast('Erro ao responder.', 'error');
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!user) return;
    if (!confirm('Desejas apagar este comentário?')) return;

    try {
      const response = await fetch(`/api/comments/${commentId}?userId=${user.id}`, {
        method: 'DELETE'
      });
      const data = await response.json();
      if (data.success) {
        showToast('Comentário removido.', 'success', 'Comentário');
        setComments((prev) => prev.filter(c => c.id !== commentId && c.parent_id !== commentId));
      } else {
        showToast(data.error || 'Não foi possível apagar o comentário.', 'error');
      }
    } catch (err) {
      console.error('Error deleting comment:', err);
      showToast('Erro ao apagar o comentário.', 'error');
    }
  };

  // Filter similar beats using target recommendation engine
  const finalRelatedBeats = recommendationService.getSimilarBeats(beat, beats, 3);
  
  // More From this producer beats
  const moreProducerBeats = recommendationService.getMoreFromThisProducer(beat.producer, beats, beat.id, 4);

  // You may also like list
  const youMayAlsoLikeBeats = recommendationService.getYouMayAlsoLike(beats, beat, 4);

  useEffect(() => {
    if (!supabase) return;

    const checkFavorite = async () => {
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      if (!currentUser) return;

      let queryBeatId = String(beat.id);
      if (/^\d+$/.test(queryBeatId)) {
        const padded = queryBeatId.padStart(12, '0');
        queryBeatId = `00000000-0000-0000-0000-${padded}`;
      }

      const { data, error } = await supabase
        .from('favorites')
        .select('beat_id')
        .eq('user_id', currentUser.id)
        .eq('beat_id', queryBeatId);

      if (!error && data && data.length > 0) {
        setIsFavorited(true);
      }
    };

    checkFavorite();
  }, [supabase, beat.id]);

  useEffect(() => {
    // Listen for changes from outer cards to synchronize
    const handleFavoriteChanged = (e: Event) => {
      const customEvent = e as CustomEvent<{ beatId: string | number; isFavorited: boolean }>;
      if (customEvent.detail && String(customEvent.detail.beatId) === String(beat.id)) {
        setIsFavorited(customEvent.detail.isFavorited);
      }
    };

    window.addEventListener('favoriteStatusChanged', handleFavoriteChanged);
    return () => {
      window.removeEventListener('favoriteStatusChanged', handleFavoriteChanged);
    };
  }, [beat.id]);

  const toggleFavorite = async () => {
    if (!supabase) return;
    const { data: { user: currentUser }, error: userError } = await supabase.auth.getUser();

    if (userError || !currentUser) {
      showToast('Por favor, faça login para favoritar beats.', 'info', 'Aviso');
      return;
    }

    let queryBeatId = String(beat.id);
    if (/^\d+$/.test(queryBeatId)) {
      const padded = queryBeatId.padStart(12, '0');
      queryBeatId = `00000000-0000-0000-0000-${padded}`;
    }

    try {
      if (isFavorited) {
        await supabase
          .from('favorites')
          .delete()
          .eq('user_id', currentUser.id)
          .eq('beat_id', queryBeatId);
        
        setIsFavorited(false);
        showToast('Removido dos favoritos', 'success');
        window.dispatchEvent(new CustomEvent('favoriteStatusChanged', { detail: { beatId: beat.id, isFavorited: false } }));
      } else {
        await supabase
          .from('favorites')
          .insert({ user_id: currentUser.id, beat_id: queryBeatId });

        setIsFavorited(true);
        showToast('Adicionado aos favoritos', 'success');
        window.dispatchEvent(new CustomEvent('favoriteStatusChanged', { detail: { beatId: beat.id, isFavorited: true } }));

        // Emit real-time like notification to the beat's producer
        try {
          if (beat.producer_id && currentUser.id !== beat.producer_id) {
            const senderName = currentUser.user_metadata?.full_name || currentUser.user_metadata?.username || currentUser.email?.split('@')[0] || 'Um artista';
            await supabase.from('notifications').insert([{
              user_id: beat.producer_id,
              type: 'like',
              title: 'Novo Favorito! ❤️',
              message: `${senderName} gostou do teu beat "${beat.title}".`,
              read: false,
              created_at: new Date().toISOString()
            }]);
            console.log('[NOTIFICATION] Favorite notification sent to:', beat.producer_id);
          }
        } catch (notifErr) {
          console.warn('Silent skip favorite notification dispatch:', notifErr);
        }
      }
    } catch (err) {
      console.error('Error toggling details favorite:', err);
    }
  };

  const handleShare = () => {
    const url = `${window.location.origin}/beat/${slugify(beat.title) || beat.id}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    showToast('Link de partilha copiado com sucesso!', 'success', 'Partilhar');
    setTimeout(() => setCopied(false), 3000);
  };

  const handleFollowForDownload = async () => {
    setDownloadFollowed(true);
    showToast('Seguiste o produtor com sucesso!', 'success', 'Follow');
    try {
      if (supabase && beat.producer_id && user?.id !== beat.producer_id) {
        await supabase.from('notifications').insert([{
          user_id: beat.producer_id,
          type: 'follower',
          title: 'Novo seguidor de download grátis! 👤',
          message: `${user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Um parceiro'} seguiu-te para descarregar o beat/kit "${beat.title}"`,
          read: false,
          created_at: new Date().toISOString()
        }]);
      }
    } catch (e) {
      console.warn(e);
    }
  };

  const handleCommentForDownload = async () => {
    if (!downloadRequirementComment.trim() || !user) {
      showToast('Por favor, escreva um comentário de feedback.', 'error', 'Erro');
      return;
    }
    const content = downloadRequirementComment.trim();
    setDownloadRequirementComment('');

    try {
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          beat_id: beat.id,
          user_id: user.id,
          content: content
        })
      });
      const data = await response.json();
      if (data.success && data.comment) {
        setComments((prev) => [data.comment, ...prev]);
        setDownloadCommented(true);
        showToast('Comentário registado com sucesso para download grátis!', 'success', 'Comentário');
      } else {
        showToast(data.error || 'Erro ao registar feedback.', 'error');
      }
    } catch (err) {
      console.error('Error posting requirement comment:', err);
      showToast('Erro ao submeter comentário.', 'error');
    }
  };

  const handleEmailForDownload = () => {
    if (!downloadEmail.trim() || !downloadEmail.includes('@') || !downloadEmail.includes('.')) {
      showToast('Por favor, introduza um e-mail válido.', 'error', 'Erro');
      return;
    }
    setDownloadEmailVerified(true);
    showToast('E-mail registado com sucesso para a newsletter oficial!', 'success', 'Newsletter');
    try {
      const emailsList = JSON.parse(localStorage.getItem('captured_emails') || '[]');
      emailsList.push({ email: downloadEmail, beat_id: beat.id, date: new Date().toISOString() });
      localStorage.setItem('captured_emails', JSON.stringify(emailsList));
    } catch (e) {
      console.warn(e);
    }
  };

  const handleDownloadFree = async () => {
    setIsDownloading(true);
    setDownloadSuccess(false);
    try {
      if (supabase && beat.producer_id && user?.id !== beat.producer_id) {
        await supabase.from('notifications').insert([{
          user_id: beat.producer_id,
          type: 'purchase_confirmed',
          title: 'Descarregamento Grátis Efetuado! ⬇️',
          message: `O teu ficheiro "${beat.title}" foi descarregado gratuitamente por ${user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Um parceiro'}.`,
          read: false,
          created_at: new Date().toISOString()
        }]);
      }
    } catch (e) {
      console.warn('Error sending download notification:', e);
    }

    setTimeout(() => {
      setIsDownloading(false);
      setDownloadSuccess(true);
      showToast('O teu descarregamento iniciou com sucesso!', 'success', 'Download');
      
      const link = document.createElement('a');
      const targetUrl = beat.demo_url || beat.master_url || 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
      link.href = targetUrl;
      const extension = targetUrl.toLowerCase().includes('.zip') ? 'zip' : targetUrl.toLowerCase().includes('.rar') ? 'rar' : 'mp3';
      link.setAttribute('download', `${beat.title || 'beat'}_BATUKADA.${extension}`);
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }, 2000);
  };

  const handleBuyNow = () => {
    if (user?.id === beat.producer_id) {
      showToast('Você não pode comprar o seu próprio beat.', 'error', 'Opção Bloqueada');
      return;
    }

    // Pass custom license detail if CheckoutModal supports it, or open existing checkout flow
    // We update detail with selected license tier
    const beatWithLicenseSettings = {
      ...beat,
      selectedLicense: selectedLicense // Just in case, to pass state downstream
    };

    window.dispatchEvent(new CustomEvent('showCheckout', { detail: beatWithLicenseSettings }));
  };

  const currentActivePlayback = currentBeat?.id === beat.id && isPlaying;

  const licenseTiers = [
    {
      id: 'basic' as const,
      name: 'Licença Básica',
      price: beat.price.basic,
      icon: FileText,
      color: 'border-blue-500/30 text-blue-400 focus:ring-blue-500',
      badgeColor: 'bg-blue-500/10 text-blue-400',
      specs: [
        'Ficheiro MP3 de alta qualidade (320kbps)',
        'Ideal para gravação de demos ou maquetes',
        'Até 5.000 streams em plataformas digitais',
        'Distribuição em canais não lucrativos',
        'Contrato padrão incluído'
      ]
    },
    {
      id: 'premium' as const,
      name: 'Licença Premium',
      price: beat.price.premium,
      icon: ShieldCheck,
      color: 'border-amber-500/30 text-amber-500 focus:ring-amber-500',
      badgeColor: 'bg-amber-500/10 text-amber-500',
      recommended: true,
      specs: [
        'Ficheiro Master WAV + MP3 incluído',
        'Ideal para singles oficiais e lançamentos',
        'Até 50.000 streams em plataformas digitais',
        'Direitos de Rádio limitados',
        'Vídeo musical / Uso em clips incluído'
      ]
    },
    {
      id: 'exclusive' as const,
      name: 'Licença Exclusiva',
      price: beat.price.exclusive,
      icon: Check,
      color: 'border-purple-500/30 text-purple-400 focus:ring-purple-500',
      badgeColor: 'bg-purple-500/10 text-purple-400',
      specs: [
        'Ficheiros de produção separados (Stems em WAV)',
        'Direitos de exploração ILIMITADOS',
        'Propriedade comercial e autoral total',
        'O beat é retirado imediatamente da nossa loja',
        'Contrato vitalício com 100% royalties'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-[#000000] text-slate-100 pb-32 animate-in fade-in duration-500">
      {/* Back Button */}
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-8 group"
      >
        <ArrowLeft size={14} className="group-hover:-translate-x-0.5 transition-transform text-[#5865F2]" />
        <span className="text-xs font-semibold uppercase tracking-wider">Voltar e Explorar</span>
      </button>

      {/* Hero Header Section */}
      <section className="relative overflow-hidden bg-[#0c0c0e]/80 border border-white/10 rounded-lg p-6 md:p-10 mb-10 shadow-2xl">
        <div className="absolute inset-x-0 bottom-0 top-1/2 bg-gradient-to-t from-black/60 to-transparent pointer-events-none z-0" />
        
        <div className="relative z-10 flex flex-col lg:flex-row items-center lg:items-end gap-8 md:gap-10">
          {/* Big high-resolution Artwork */}
          <div className="relative w-64 h-64 md:w-72 md:h-72 rounded-lg overflow-hidden bg-[#121212] shadow-2xl border border-white/10 shrink-0 group">
            <img 
              src={beat.image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400'} 
              alt={beat.title}
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              onError={(e) => {
                e.currentTarget.onerror = null; // Prevent infinite loops
                e.currentTarget.src = 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400';
              }}
            />
            {!isKit && (
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onPlay(beat)}
                  className="w-16 h-16 rounded-full bg-[#5865F2] text-white flex items-center justify-center shadow-lg"
                >
                  {currentActivePlayback ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-1" />}
                </motion.button>
              </div>
            )}
          </div>

          {/* Details Metadata Header */}
          <div className="flex-1 text-center lg:text-left space-y-5">
            <div className="space-y-2">
              <span className="inline-flex py-1 px-2 text-[9px] bg-[#5865F2]/10 border border-[#5865F2]/20 text-[#5865F2] font-semibold tracking-wider uppercase rounded">
                {beat.genre}
              </span>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
                {beat.title}
              </h1>
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 text-xs md:text-sm text-gray-400 mt-2">
                <button 
                  onClick={() => onSelectProducer(beat.producer)}
                  className="flex items-center gap-1.5 text-gray-300 hover:text-white transition-colors py-0.5 font-md"
                >
                  <User size={13} className="text-gray-400" />
                  <span className="font-medium">@{beat.producer}</span>
                  {isProducerVerified && (
                    <VerifiedBadge size="sm" />
                  )}
                </button>
                {!isKit && (
                  <>
                    <span className="text-gray-600">•</span>
                    <span className="font-medium flex items-center gap-1">
                      <Activity size={13} className="text-gray-400" />
                      {beat.bpm} BPM
                    </span>
                  </>
                )}
                {!isKit && beat.key && (
                  <>
                    <span className="text-gray-600">•</span>
                    <span className="font-medium flex items-center gap-1" title="Tom">
                      <Music size={13} className="text-gray-400" />
                      {beat.key}
                    </span>
                  </>
                )}
                {!isKit && beat.scale && (
                  <>
                    <span className="text-gray-600">•</span>
                    <span className="font-medium flex items-center gap-1" title="Escala">
                      <Sparkles size={13} className="text-gray-400" />
                      {beat.scale}
                    </span>
                  </>
                )}
                {!isKit && (
                  <>
                    <span className="text-gray-600">•</span>
                    <span className="font-medium text-emerald-500 flex items-center gap-1" title="Visualizações">
                      <Play size={13} className="text-emerald-500 fill-emerald-500/10 shrink-0" />
                      {Number(playService.getPlayCount(beat.id, beat.plays_count || 0)).toLocaleString()} streams
                    </span>
                  </>
                )}
                {beat.created_at && (
                  <>
                    <span className="text-gray-600">•</span>
                    <span className="font-medium flex items-center gap-1">
                      <Calendar size={13} className="text-gray-400" />
                      {new Date(beat.created_at).toLocaleDateString()}
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* Quick Controls Bar */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-4 border-t border-white/5">
              {!isKit && (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onPlay(beat)}
                  className="w-full sm:w-auto px-6 py-2.5 rounded bg-[#5865F2] hover:bg-[#4752C4] border border-[#5865F2] text-white flex items-center justify-center gap-2 font-semibold text-xs tracking-wider transition-colors shadow-sm"
                >
                  {currentActivePlayback ? (
                    <>
                      <Pause size={14} fill="currentColor" /> Pausar Beat
                    </>
                  ) : (
                    <>
                      <Play size={14} fill="currentColor" className="ml-0.5" /> Ouvir Beat
                    </>
                  )}
                </motion.button>
              )}

              <div className="flex w-full sm:w-auto gap-2">
                <button
                  onClick={toggleFavorite}
                  className={`flex-1 sm:flex-initial px-4 py-2.5 rounded bg-white/5 border ${isFavorited ? 'border-rose-500/20 text-rose-500 bg-rose-500/5' : 'border-white/10 text-gray-300 hover:text-white'} hover:bg-white/10 transition-colors flex items-center justify-center gap-1.5 text-xs font-semibold tracking-wide cursor-pointer`}
                  title="Guardar nos favoritos"
                >
                  <Heart size={14} fill={isFavorited ? 'currentColor' : 'none'} />
                  <span>{isFavorited ? 'Favoritado' : 'Favoritar'}</span>
                </button>

                <button
                  onClick={() => {
                    window.dispatchEvent(new CustomEvent('showAddToPlaylist', { detail: { beat } }));
                  }}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded bg-[#5865F2]/5 border border-[#5865F2]/20 text-gray-200 hover:bg-[#5865F2]/10 hover:text-white transition-colors flex items-center justify-center gap-1.5 text-xs font-semibold tracking-wide cursor-pointer"
                  title="Adicionar à Playlist"
                >
                  <ListMusic size={14} className="text-[#5865F2]" />
                  <span>Playlist</span>
                </button>

                <button
                  onClick={handleShare}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded bg-white/5 border border-white/10 text-gray-300 hover:text-white hover:bg-white/10 transition-colors flex items-center justify-center gap-1.5 text-xs font-semibold tracking-wide cursor-pointer"
                  title="Partilhar Beat"
                >
                  <Share2 size={14} />
                  <span>{copied ? 'Copiado!' : 'Partilhar'}</span>
                </button>

                <button
                  onClick={() => handleOpenReport('beat', String(beat.id), beat.title)}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded bg-red-950/10 border border-red-900/20 text-red-400 hover:text-red-300 hover:bg-red-950/20 transition-colors flex items-center justify-center gap-1.5 text-xs font-semibold tracking-wide cursor-pointer"
                  title="Denunciar Abuso ou Direitos de Autor"
                >
                  <Flag size={14} />
                  <span>Reportar</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Grid: Columns */}
      <div className="grid lg:grid-cols-12 gap-12">
        {/* Left Area (8 cols): Contracts & Purchase Options */}
        <div className="lg:col-span-8 space-y-12">
          
          {/* Contracts block */}
          {beat.is_free_download ? (
            <div className="space-y-6 bg-gradient-to-r from-amber-500/5 to-transparent border border-amber-500/10 p-6 md:p-8 rounded-[2.5rem]">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-amber-500/10 text-amber-500 rounded-2xl">
                  <Download size={22} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white italic tracking-tighter uppercase">
                    1. Requisitos de <span className="text-amber-500">Download Grátis</span>
                  </h3>
                  <p className="text-gray-400 text-xs font-semibold mt-1">Este produtor disponibilizou este ficheiro gratuitamente. Conclua os requisitos para baixar!</p>
                </div>
              </div>

              <div className="space-y-4 mt-6">
                {/* REQUIREMENT 1: FOLLOW */}
                {beat.free_download_requires_follow && (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-white/[0.01] border border-white/5">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-xl mt-0.5 ${downloadFollowed ? 'bg-green-500/10 text-green-400' : 'bg-[#5865F2]/10 text-[#5865F2]'}`}>
                        <User size={18} />
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-white uppercase tracking-wider">Seguir o Produtor @{beat.producer}</h4>
                        <p className="text-xs text-gray-500">Apoie a sua presença digital oficial na Batukada.</p>
                      </div>
                    </div>
                    
                    {downloadFollowed ? (
                      <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-green-500/10 text-green-400 text-xs font-black uppercase tracking-wider scale-95 transition-all">
                        <Check size={14} strokeWidth={3} /> Concluído
                      </span>
                    ) : (
                      <button
                        onClick={handleFollowForDownload}
                        className="px-4 py-2 bg-[#5865F2] hover:bg-[#4752C4] text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shadow-lg active:scale-95 cursor-pointer"
                      >
                        Seguir Produtor
                      </button>
                    )}
                  </div>
                )}

                {/* REQUIREMENT 2: COMMENT */}
                {beat.free_download_requires_comment && (
                  <div className="flex flex-col p-5 rounded-2xl bg-white/[0.01] border border-white/5 space-y-4">
                    <div className="flex items-start gap-3 justify-between w-full">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-xl mt-0.5 ${downloadCommented ? 'bg-green-500/10 text-green-400' : 'bg-orange-500/10 text-orange-400'}`}>
                          <MessageSquare size={18} />
                        </div>
                        <div>
                          <h4 className="font-black text-sm text-white uppercase tracking-wider">Deixar um Feedback ao Produtor</h4>
                          <p className="text-xs text-gray-500">Escreva o que achou da sonoridade ou do ritmo.</p>
                        </div>
                      </div>
                      
                      {downloadCommented && (
                        <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-green-500/10 text-green-400 text-xs font-black uppercase tracking-wider shrink-0">
                          <Check size={14} strokeWidth={3} /> Concluído
                        </span>
                      )}
                    </div>

                    {!downloadCommented && (
                      <div className="flex gap-2 w-full">
                        <input
                          type="text"
                          placeholder="Frequência fantástica! Altamente recomendado..."
                          value={downloadRequirementComment}
                          onChange={(e) => setDownloadRequirementComment(e.target.value)}
                          className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500/80 transition-all"
                        />
                        <button
                          onClick={handleCommentForDownload}
                          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shrink-0 active:scale-95 cursor-pointer"
                        >
                          Enviar
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* REQUIREMENT 3: EMAIL */}
                {beat.free_download_requires_email && (
                  <div className="flex flex-col p-5 rounded-2xl bg-white/[0.01] border border-white/5 space-y-4">
                    <div className="flex items-start gap-3 justify-between w-full">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-xl mt-0.5 ${downloadEmailVerified ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                          <Mail size={18} />
                        </div>
                        <div>
                          <h4 className="font-black text-sm text-white uppercase tracking-wider">Registar Endereço de E-mail</h4>
                          <p className="text-xs text-gray-500">Para se manter atualizado de futuros lançamentos.</p>
                        </div>
                      </div>
                      
                      {downloadEmailVerified && (
                        <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-green-500/10 text-green-400 text-xs font-black uppercase tracking-wider shrink-0">
                          <Check size={14} strokeWidth={3} /> Concluído
                        </span>
                      )}
                    </div>

                    {!downloadEmailVerified && (
                      <div className="flex gap-2 w-full">
                        <input
                          type="email"
                          placeholder="digiteseuemail@email.com"
                          value={downloadEmail}
                          onChange={(e) => setDownloadEmail(e.target.value)}
                          className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500/80 transition-all"
                        />
                        <button
                          onClick={handleEmailForDownload}
                          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shrink-0 active:scale-95 cursor-pointer"
                        >
                          Registar
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Action and Download Status Section */}
              {(() => {
                const hasFollowPending = beat.free_download_requires_follow && !downloadFollowed;
                const hasCommentPending = beat.free_download_requires_comment && !downloadCommented;
                const hasEmailPending = beat.free_download_requires_email && !downloadEmailVerified;
                const isBlocked = hasFollowPending || hasCommentPending || hasEmailPending;

                return (
                  <div className="pt-6 border-t border-white/[0.04]">
                    {downloadSuccess ? (
                      <div className="flex flex-col items-center justify-center text-center p-6 bg-green-500/10 rounded-2xl border border-green-500/20 text-white space-y-2">
                        <Check size={28} className="text-green-400 animate-bounce" />
                        <h4 className="font-black text-sm uppercase tracking-wider text-green-400">Download Iniciado!</h4>
                        <p className="text-xs text-gray-400">O ficheiro em qualidade total está a carregar. Obrigado pelo apoio!</p>
                      </div>
                    ) : (
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-6 p-6 rounded-[2rem] bg-amber-500/10 border border-amber-500/20">
                        <div>
                          <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Ações Requisitadas</span>
                          <h4 className="text-lg font-black text-white italic uppercase tracking-tighter mt-1">
                            {isBlocked ? 'Incompleto' : 'Tudo Desbloqueado!'}
                          </h4>
                          <p className="text-xs text-gray-400 mt-1">
                            {isBlocked ? 'Por favor conclua as tarefas do produtor para baixar de graça.' : 'Carregue no botão para transferir em alta fidelidade.'}
                          </p>
                        </div>
                        
                        <button
                          onClick={handleDownloadFree}
                          disabled={isBlocked || isDownloading}
                          className={`w-full sm:w-auto px-6 py-4 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all text-center ${
                            isBlocked 
                              ? 'bg-white/5 border border-white/10 text-gray-600 cursor-not-allowed' 
                              : 'bg-amber-500 border border-amber-400/25 text-black hover:bg-amber-400 hover:scale-105 active:scale-95 cursor-pointer shadow-lg shadow-amber-500/20'
                          }`}
                        >
                          {isDownloading ? 'A Descarregar...' : 'Download Grátis'}
                        </button>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-white tracking-tight">
                1. Selecionar Licença
              </h3>
              <p className="text-gray-400 text-xs">Escolha a licença certa para o seu nível de projeto. Todas incluem termos transparentes e suporte.</p>
              
              <div className="space-y-3">
                {licenseTiers.map((tier) => {
                  const isSelected = selectedLicense === tier.id;
                  const IconComponent = tier.icon;
                  
                  return (
                    <div
                      key={tier.id}
                      onClick={() => setSelectedLicense(tier.id)}
                      className={`relative p-5 rounded-lg border transition-all cursor-pointer ${
                        isSelected 
                          ? 'bg-[#18181b]/40 border-[#5865F2] shadow-sm' 
                          : 'bg-white/[0.01] border-white/5 hover:border-white/10 hover:bg-white/[0.02]'
                      }`}
                    >
                      {tier.recommended && (
                        <span className="absolute -top-2.5 right-4 px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider bg-[#5865F2] text-white rounded">
                          Mais Popular
                        </span>
                      )}

                      <div className="flex items-start gap-3">
                        {/* Custom radio indicator */}
                        <div className="pt-0.5">
                          <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-[#5865F2] text-[#5865F2]' : 'border-white/20'}`}>
                            {isSelected && <div className="w-2 h-2 rounded-full bg-[#5865F2]" />}
                          </div>
                        </div>

                        <div className="flex-1 space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                            <div className="flex items-center gap-1.5 text-left">
                              <IconComponent size={14} className="text-[#5865F2]" />
                              <h4 className="font-bold text-sm text-white tracking-tight">{tier.name}</h4>
                            </div>
                            <span className="text-sm font-bold text-white font-mono shrink-0">
                              {tier.price.toLocaleString()} Kz
                            </span>
                          </div>

                          {/* Collateral visual options details lists */}
                          <ul className="grid sm:grid-cols-2 gap-1 text-[11px] text-gray-400 text-left">
                            {tier.specs.map((spec, i) => (
                              <li key={i} className="flex items-start gap-1.5">
                                <Check size={11} className="text-emerald-500 mt-0.5 shrink-0" />
                                <span>{spec}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Selected Summary Callout */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-5 rounded-lg bg-[#5865F2]/5 border border-[#5865F2]/20">
                <div className="text-left">
                  <span className="text-[9px] font-bold text-[#5865F2] uppercase tracking-wider">Opção Selecionada</span>
                  <h4 className="text-sm font-bold text-white tracking-tight mt-0.5">
                    {selectedLicense === 'basic' ? 'Licença Básica' : selectedLicense === 'premium' ? 'Licença Premium' : 'Licença Exclusiva'}
                  </h4>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    Suporta {selectedLicense === 'basic' ? 'MP3 básico e até 5.000 streams.' : selectedLicense === 'premium' ? 'Qualidade WAV + MP3 e até 50.000 streams.' : 'Ficheiros Stems separados, streams ilimitados e propriedade total.'}
                  </p>
                </div>

                <div className="flex gap-2 w-full sm:w-auto shrink-0 justify-end">
                  {user?.id !== beat.producer_id ? (
                    <>
                      <button
                        onClick={handleBuyNow}
                        className="flex-1 sm:flex-initial px-4 py-2 rounded bg-[#5865F2] hover:bg-[#4752C4] border border-[#5865F2] text-white font-semibold text-xs tracking-wide transition-colors cursor-pointer"
                      >
                        Comprar Agora
                      </button>
                      <button
                        onClick={() => onAddToCart(beat)}
                        className="flex-1 sm:flex-initial px-4 py-2 rounded bg-white/5 border border-white/10 text-gray-300 hover:text-white font-semibold text-xs tracking-wide hover:bg-white/10 transition-colors cursor-pointer"
                      >
                        Ao Carrinho
                      </button>
                    </>
                  ) : (
                    <div className="flex-1 text-center py-2 text-xs font-semibold text-gray-400 uppercase tracking-widest">
                      Este beat pertence a você
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Details / Beats Specifications fields */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white tracking-tight">
              2. Detalhes Técnicos
            </h3>

            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 items-stretch">
              {!isKit ? (
                <>
                  <div className="p-3 bg-[#18181b]/35 border border-white/5 rounded flex flex-col justify-between text-center min-h-[80px] items-stretch">
                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider leading-none">TEMPO</span>
                    <span className="text-xs font-semibold text-white leading-tight break-words pt-1">{beat.bpm} BPM</span>
                  </div>
                  <div className="p-3 bg-[#18181b]/35 border border-white/5 rounded flex flex-col justify-between text-center min-h-[80px] items-stretch">
                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider leading-none">GÉNERO</span>
                    <span className="text-xs font-semibold text-white leading-tight break-words truncate pt-1" title={beat.genre}>{beat.genre}</span>
                  </div>
                  <div className="p-3 bg-[#18181b]/35 border border-white/5 rounded flex flex-col justify-between text-center min-h-[80px] items-stretch">
                    <span className="text-[8px] font-bold text-[#5865F2] uppercase tracking-wider leading-none">TOM</span>
                    <span className="text-xs font-semibold text-[#5865F2] uppercase leading-tight break-words pt-1">{beat.key || '—'}</span>
                  </div>
                  <div className="p-3 bg-[#18181b]/35 border border-white/5 rounded flex flex-col justify-between text-center min-h-[80px] items-stretch">
                    <span className="text-[8px] font-bold text-[#5865F2] uppercase tracking-wider leading-none">ESCALA</span>
                    <span className="text-xs font-semibold text-[#5865F2] uppercase leading-tight break-words pt-1">{beat.scale || '—'}</span>
                  </div>
                  <div className="p-3 bg-[#18181b]/35 border border-white/5 rounded flex flex-col justify-between text-center min-h-[80px] items-stretch">
                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider leading-none">FORMATO</span>
                    <span className="text-xs font-semibold text-white leading-tight break-words pt-1">MP3 / WAV</span>
                  </div>
                  <div className="p-3 bg-[#18181b]/35 border border-white/5 rounded flex flex-col justify-between text-center min-h-[80px] items-stretch">
                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider leading-none">CATEGORIA</span>
                    <span className="text-xs font-semibold text-white uppercase leading-tight break-words pt-1">COMPLETO</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl flex flex-col justify-between text-center min-h-[96px] items-stretch">
                    <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none">FORMATO</span>
                    <span className="text-sm font-black text-white italic leading-tight break-words">ZIP / RAR</span>
                  </div>
                  <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl flex flex-col justify-between text-center min-h-[96px] items-stretch">
                    <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none">GÉNERO</span>
                    <span className="text-sm font-black text-white italic leading-tight break-words truncate" title={beat.genre}>{beat.genre}</span>
                  </div>
                  <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl flex flex-col justify-between text-center min-h-[96px] items-stretch">
                    <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none">CATEGORIA</span>
                    <span className="text-sm font-black text-amber-500 italic uppercase leading-tight break-words truncate" title={beat.category === 'drum-kit' ? 'Drum Kit' : beat.category === 'loop-kit' ? 'Loop Kit' : beat.category === 'sample-pack' ? 'Sample Pack' : (beat.category || 'Drum Kit')}>
                      {beat.category === 'drum-kit' ? 'Drum Kit' : beat.category === 'loop-kit' ? 'Loop Kit' : beat.category === 'sample-pack' ? 'Sample Pack' : (beat.category || 'Drum Kit')}
                    </span>
                  </div>
                  <div className="p-4 bg-[#000000] border border-white/5 rounded-2xl flex flex-col justify-between text-center min-h-[96px] items-stretch">
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest leading-none">TIPO DE KIT</span>
                    <span className="text-sm font-black text-white italic uppercase leading-tight break-words">Sound Kit</span>
                  </div>
                  <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl flex flex-col justify-between text-center min-h-[96px] items-stretch">
                    <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none">DOWNLOADS</span>
                    <span className="text-sm font-black text-white italic leading-tight break-words uppercase">ILIMITADOS</span>
                  </div>
                  <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl flex flex-col justify-between text-center min-h-[96px] items-stretch">
                    <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none">LICENÇA</span>
                    <span className="text-sm font-black text-white italic uppercase leading-tight break-words">ROYALTY FREE</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Comments and Community Section */}
          <div className="space-y-6 pt-6 bg-white/[0.01] border border-white/5 rounded-[2rem] p-6">
            <h3 className="text-xl font-black text-white italic tracking-tighter uppercase flex items-center gap-2">
              <MessageSquare size={18} className="text-purple-500 animate-pulse" />
              Comunidade e <span className="text-purple-400">Comentários</span>
            </h3>
            <p className="text-gray-400 text-xs">Partilha o teu feedback ou faz uma proposta para @{beat.producer} sobre este beat.</p>

            {/* Social Statistics Block & Hottest Moment / Viral Moments Engine */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#000000] border border-white/5 rounded-2xl p-4 text-xs font-mono">
              <div className="flex flex-col justify-center gap-1.5 border-r border-white/5 pr-2 md:border-r md:border-b-0 pb-2 md:pb-0">
                <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest leading-none">TOTAL DISCUSSÕES</span>
                <span className="text-xs font-black text-white flex items-center gap-1">{comments.length} <MessageSquare size={11} className="text-purple-400" /></span>
              </div>
              <div className="flex flex-col justify-center gap-1.5 border-r border-white/5 pr-2 md:border-r md:border-b-0 pb-2 md:pb-0">
                <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest leading-none">REACÇÕES COMUNITÁRIAS</span>
                <span className="text-xs font-black text-purple-400 flex items-center gap-1">
                  {comments.reduce((acc, c) => acc + (c.likes?.length || 0) + Object.values(c.reactions || {}).reduce((sub: number, v: any) => sub + (v?.length || 0), 0), 0)} 🔥
                </span>
              </div>
              <div className="flex flex-col justify-center gap-1.5">
                <span className="text-[9px] text-gray-500 font-bold uppercase tracking-widest leading-none">MOMENTO MAIS QUENTE</span>
                {getViralMoment() ? (
                  <button
                    onClick={() => {
                      const moment = getViralMoment();
                      if (moment) {
                        const customEvent = new CustomEvent('replacePlayerQueue', {
                          detail: { beats: [beat], playFirst: true }
                        });
                        window.dispatchEvent(customEvent);
                        setTimeout(() => {
                          const audioEl = document.querySelector('audio') as HTMLAudioElement | null;
                          if (audioEl) {
                            audioEl.currentTime = moment.seconds;
                            audioEl.play().catch(console.warn);
                          }
                        }, 150);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 text-left text-[11px] text-amber-500 font-black hover:text-amber-400 hover:underline transition-all cursor-pointer leading-tight self-start"
                  >
                    <Zap size={11} className="text-amber-500 fill-amber-500/10 animate-pulse" />
                    <span>Viral aos {getViralMoment()?.formatted} ({getViralMoment()?.count} coment.)</span>
                  </button>
                ) : (
                  <span className="text-gray-500 text-[9.5px] font-medium italic">Nenhum pico viral</span>
                )}
              </div>
            </div>

            {/* Filter controls */}
            <div className="flex items-center gap-1.5 flex-wrap pb-1">
              <button
                type="button"
                onClick={() => setCommentsFilter('top')}
                className={`px-3 py-1.5 rounded-xl uppercase tracking-wider text-[9px] font-black transition-all cursor-pointer ${
                  commentsFilter === 'top' ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.3)]' : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
              >
                🚀 Top Comments
              </button>
              <button
                type="button"
                onClick={() => setCommentsFilter('latest')}
                className={`px-3 py-1.5 rounded-xl uppercase tracking-wider text-[9px] font-black transition-all cursor-pointer ${
                  commentsFilter === 'latest' ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.3)]' : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
              >
                🕒 Mais Recentes
              </button>
              <button
                type="button"
                onClick={() => setCommentsFilter('producer')}
                className={`px-3 py-1.5 rounded-xl uppercase tracking-wider text-[9px] font-black transition-all cursor-pointer ${
                  commentsFilter === 'producer' ? 'bg-amber-600 text-white shadow-[0_0_12px_rgba(217,119,6,0.3)]' : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
              >
                👑 Do Produtor
              </button>
              <button
                type="button"
                onClick={() => setCommentsFilter('timestamp')}
                className={`px-3 py-1.5 rounded-xl uppercase tracking-wider text-[9px] font-black transition-all cursor-pointer ${
                  commentsFilter === 'timestamp' ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.3)]' : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
              >
                🎵 Com Timestamps
              </button>
            </div>

            {/* Comment form with user avatar prefix */}
            <div className="flex items-start gap-3">
              {user ? (
                <div className="w-8 h-8 rounded-full overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                  {profile?.avatar_url ? (
                    <img 
                      src={profile.avatar_url.startsWith('http') ? profile.avatar_url : getPublicUrl('avatars', profile.avatar_url)} 
                      className="w-full h-full object-cover" 
                      alt="O teu avatar"
                    />
                  ) : (
                    <span className="text-[9.5px] font-extrabold text-[#9898a3] uppercase tracking-tighter">
                      {(profile?.artistic_name || user?.email || 'US').slice(0, 2).toUpperCase()}
                    </span>
                  )}
                </div>
              ) : (
                <div className="w-8 h-8 rounded-full bg-white/[0.01] border border-white/5 flex items-center justify-center shrink-0">
                  <User size={12} className="text-gray-600" />
                </div>
              )}
              
              <form onSubmit={handleAddComment} className="flex-1 relative flex items-center gap-3 bg-[#000000] border border-white/5 rounded-2xl p-1.5 focus-within:border-purple-500/60 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.8)] transition-all">
                <textarea
                  rows={1}
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder={user ? "Escreve um comentário... apoia produtores e usa @username" : "Faz login para comentar..."}
                  disabled={!user}
                  maxLength={500}
                  className="flex-grow bg-transparent border-none text-white text-xs px-3.5 py-2 outline-none placeholder-neutral-600 focus:ring-0 disabled:opacity-55 resize-none overflow-y-auto leading-normal min-h-[32px] max-h-[80px]"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleAddComment(e);
                    }
                  }}
                />
                <button
                  type="submit"
                  disabled={!user || !newComment.trim()}
                  className="p-2.5 bg-purple-600 hover:bg-purple-500 disabled:bg-purple-900/30 text-white rounded-xl transition-all hover:scale-102 active:scale-95 cursor-pointer flex items-center justify-center shrink-0 disabled:opacity-30 disabled:hover:scale-100"
                  title="Publicar Comentário"
                >
                  <Send size={12} />
                </button>
              </form>
            </div>

            {/* Comments and Thread List */}
            <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1 select-none">
              {loadingComments ? (
                <div className="py-12 text-center flex flex-col items-center justify-center gap-2">
                  <Loader2 size={24} className="text-purple-500 animate-spin" />
                  <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Carregando discussões...</span>
                </div>
              ) : getParentComments().length === 0 ? (
                <div className="py-12 text-center bg-white/[0.003] border border-dashed border-white/5 rounded-2xl">
                  <MessageSquare size={20} className="text-purple-500/40 mx-auto mb-3" />
                  <p className="text-xs text-neutral-300 font-extrabold uppercase tracking-wide">Sem comentários nesta categoria.</p>
                  <p className="text-[10px] text-neutral-500 font-medium">Partilha o teu feedback com a comunidade!</p>
                </div>
              ) : (
                getParentComments().map((parent) => {
                  const parentId = parent.id;
                  const parentAvatar = parent.author_avatar || '';
                  const parentName = parent.author_name || parent.author || 'Membro';
                  const parentUsername = parent.author_username || parent.username || 'membro';
                  const isParentVerified = parent.is_verified === true;
                  const isParentOwner = user && String(parent.user_id) === String(user.id);
                  const isBeatOwner = user && String(beat.producer_id) === String(user.id);
                  const isCreator = String(parent.user_id) === String(beat.producer_id);
                  
                  const threadReplies = comments.filter(r => r.parent_id === parentId).sort((a,b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

                  return (
                    <div 
                      key={parentId} 
                      className={`space-y-3 p-4 rounded-2xl transition-all duration-300 relative ${
                        parent.is_pinned 
                          ? 'border border-amber-500/35 bg-[#120E06]/75 shadow-[inset_0_0_12px_rgba(245,158,11,0.08)]' 
                          : isCreator 
                            ? 'border border-purple-500/30 bg-[#0E0B14]/80 shadow-[0_0_20px_rgba(168,85,247,0.06)]' 
                            : 'bg-white/[0.015] border border-white/5 hover:border-white/10'
                      }`}
                    >
                      {/* Pinned Badge */}
                      {parent.is_pinned && (
                        <div className="absolute top-2.5 right-4 flex items-center gap-1 bg-amber-500/15 border border-amber-500/25 px-2 py-0.5 rounded-full text-[8px] font-black text-amber-500 tracking-wider uppercase">
                          <Pin size={8} className="fill-amber-500" />
                          <span>Fixado pelo Produtor</span>
                        </div>
                      )}

                      {/* Creator Badge if not pinned and is creator */}
                      {!parent.is_pinned && isCreator && (
                        <div className="absolute top-2.5 right-4 flex items-center gap-1 bg-purple-500/15 border border-purple-500/25 px-2 py-0.5 rounded-full text-[8px] font-black text-purple-400 tracking-wider uppercase">
                          <Sparkles size={8} className="text-purple-400 fill-purple-400" />
                          <span>Criador</span>
                        </div>
                      )}

                      {/* Main Comment */}
                      <div className="flex items-start gap-3">
                        {/* Hovercard wrapper */}
                        <div className="relative shrink-0">
                          <div 
                            className="w-8 h-8 rounded-full overflow-hidden bg-purple-500/5 border border-purple-500/20 flex items-center justify-center cursor-pointer"
                            onClick={() => onSelectProducer(parentUsername)}
                            onMouseEnter={() => setHoveredProfileUsername(parentUsername)}
                            onMouseLeave={() => setHoveredProfileUsername(null)}
                          >
                            {parentAvatar ? (
                              <img
                                src={parentAvatar.startsWith('http') || parentAvatar.startsWith('/') || parentAvatar.startsWith('data:') ? parentAvatar : getPublicUrl('avatars', parentAvatar)}
                                alt={parentName}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <span className="text-[10px] font-black text-purple-400 uppercase tracking-tighter">
                                {parentName.slice(0, 2).toUpperCase()}
                              </span>
                            )}
                          </div>

                          {/* Float Card */}
                          {hoveredProfileUsername === parentUsername && (
                            <div 
                              className="absolute left-0 top-10 w-64 bg-[#000000]/95 backdrop-blur-xl border border-white/10 rounded-2xl p-4 shadow-[0_15px_40px_rgba(0,0,0,0.85)] flex flex-col gap-3 pointer-events-auto text-left leading-normal z-50 transform origin-top-left transition-all duration-200"
                              onMouseEnter={() => setHoveredProfileUsername(parentUsername)}
                              onMouseLeave={() => setHoveredProfileUsername(null)}
                            >
                              <div className="flex gap-3 items-center">
                                <div className="w-10 h-10 rounded-full overflow-hidden bg-purple-500/5 border border-purple-500/20 flex items-center justify-center shrink-0">
                                  {parentAvatar ? (
                                    <img src={parentAvatar.startsWith('http') || parentAvatar.startsWith('/') || parentAvatar.startsWith('data:') ? parentAvatar : getPublicUrl('avatars', parentAvatar)} className="w-full h-full object-cover" alt={parentName} />
                                  ) : (
                                    <span className="text-[10px] font-black text-purple-400">{parentName.slice(0, 2).toUpperCase()}</span>
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <h4 className="text-xs font-black text-white uppercase tracking-tight flex items-center gap-1">
                                    {parentName}
                                    {isParentVerified && <VerifiedBadge size="sm" />}
                                  </h4>
                                  <p className="text-[10px] text-gray-400 font-mono">@{parentUsername}</p>
                                </div>
                              </div>

                              <div className="grid grid-cols-3 gap-2 border-y border-white/5 py-2.5 my-1 text-center font-mono">
                                <div>
                                  <p className="text-[10.5px] font-black text-white">{(parentUsername.split('').reduce((acc: number, c: string) => acc + c.charCodeAt(0), 0) % 150) * 8 + 32}</p>
                                  <p className="text-[7px] font-black text-gray-500 uppercase leading-none">Seguidores</p>
                                </div>
                                <div>
                                  <p className="text-[10.5px] font-black text-white">{(parentUsername.split('').reduce((acc: number, c: string) => acc + c.charCodeAt(0), 0) % 12) + 2}</p>
                                  <p className="text-[7px] font-black text-gray-500 uppercase leading-none">Beats</p>
                                </div>
                                <div>
                                  <p className="text-[10.5px] font-black text-amber-500 leading-none">
                                    {["Kizomba", "Ghetto Zouk", "Tarraxinha", "Afro House", "Semba", "Kuduro"][(parentUsername.split('').reduce((acc: number, c: string) => acc + c.charCodeAt(0), 0) % 6)]}
                                  </p>
                                  <p className="text-[7px] font-black text-gray-500 uppercase leading-none mt-1">Top Gênero</p>
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() => onSelectProducer(parentUsername)}
                                className="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-[9px] font-black uppercase tracking-widest transition-all text-center cursor-pointer"
                              >
                                Ver Perfil
                              </button>
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0 space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1.5">
                              <button 
                                type="button"
                                onClick={() => onSelectProducer(parentUsername)}
                                className="text-left cursor-pointer"
                              >
                                <span className={`text-[11px] font-black hover:text-amber-500 transition-colors uppercase tracking-tight flex items-center gap-1 ${isCreator ? 'text-purple-400' : 'text-white'}`}>
                                  {parentName}
                                  {isParentVerified && <VerifiedBadge size="sm" />}
                                </span>
                                <span className="text-[9px] text-gray-500 font-mono">@{parentUsername}</span>
                              </button>
                            </div>
                            <div className="flex items-center gap-2 pr-2">
                              <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">{formatRelativeTimeAO(parent.created_at)}</span>
                              
                              {/* Delete option for authorized readers */}
                              {(isParentOwner || isBeatOwner) && (
                                <button
                                  onClick={() => handleDeleteComment(parentId)}
                                  className="text-gray-500 hover:text-red-400 p-1 rounded hover:bg-white/5 transition-colors cursor-pointer"
                                  title="Apagar Comentário"
                                >
                                  <Trash2 size={10} />
                                </button>
                              )}
                              
                              <button
                                onClick={() => handleOpenReport('comment', parentId, parent.content)}
                                className="text-gray-500 hover:text-yellow-500 p-1 rounded hover:bg-white/5 transition-colors cursor-pointer"
                                title="Denunciar"
                              >
                                <Flag size={10} />
                              </button>
                            </div>
                          </div>
                          
                          <div className="flex items-start gap-2 flex-wrap pb-1">
                            {parent.timestamp_seconds !== null && parent.timestamp_seconds !== undefined && (
                              <button
                                onClick={() => {
                                  // Dispatch seek direct to currently playing event
                                  const customEvent = new CustomEvent('replacePlayerQueue', {
                                    detail: {
                                      beats: [beat],
                                      playFirst: true
                                    }
                                  });
                                  window.dispatchEvent(customEvent);
                                  // Wait just 150ms for player to swap, then seek to timestamp
                                  setTimeout(() => {
                                    const audioEl = document.querySelector('audio') as HTMLAudioElement | null;
                                    if (audioEl) {
                                      audioEl.currentTime = parent.timestamp_seconds;
                                      audioEl.play().catch(console.warn);
                                    }
                                  }, 150);
                                }}
                                className="inline-flex items-center gap-1 text-[9px] bg-amber-500/10 hover:bg-amber-500 hover:text-black border border-amber-500/20 px-1.5 py-0.5 rounded-md font-mono font-black text-amber-500 cursor-pointer transition-all active:scale-95 shadow-[0_0_8px_rgba(245,158,11,0.08)] shrink-0"
                                title="Saltar para este momento"
                              >
                                {Math.floor(parent.timestamp_seconds / 60)}:{(parent.timestamp_seconds % 60).toString().padStart(2, '0')}
                              </button>
                            )}
                            <p className="text-xs text-neutral-300 leading-relaxed font-normal">{renderContentWithMentions(parent.content)}</p>
                          </div>

                          {/* Interaction bar (likes, reactions picker, sharing, pinning) */}
                          <div className="flex items-center gap-1.5 flex-wrap pt-2 select-none pointer-events-auto">
                            {/* Like Heart */}
                            <button
                              type="button"
                              onClick={() => handleLikeComment(parentId)}
                              className={`inline-flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg transition-all active:scale-95 cursor-pointer font-bold border ${
                                parent.likes?.includes(user?.id)
                                  ? 'bg-rose-500/10 text-rose-500 border-rose-500/20 shadow-[0_0_10px_rgba(244,63,94,0.15)] animate-bounce-once'
                                  : 'bg-white/5 text-gray-400 border-transparent hover:bg-white/10 hover:text-white'
                              }`}
                            >
                              <Heart size={9} className={parent.likes?.includes(user?.id) ? 'fill-rose-500 stroke-rose-400' : ''} />
                              <span>{parent.likes?.length || 0}</span>
                            </button>

                            {/* Aggregated Emojis Emitters list */}
                            {parent.reactions && Object.entries(parent.reactions).map(([emoji, userList]: any) => {
                              if (!userList || userList.length === 0) return null;
                              const reactedByMe = user?.id && userList.includes(user.id);
                              return (
                                <button
                                  key={emoji}
                                  type="button"
                                  onClick={() => handleReactComment(parentId, emoji)}
                                  className={`inline-flex items-center gap-1.5 text-[9px] px-2 py-1 rounded-lg transition-all active:scale-95 cursor-pointer font-extrabold border ${
                                    reactedByMe
                                      ? 'bg-purple-500/10 text-purple-400 border-purple-500/20 shadow-sm'
                                      : 'bg-white/5 text-gray-400 border-transparent hover:bg-white/10'
                                  }`}
                                >
                                  <span>{emoji}</span>
                                  <span>{userList.length}</span>
                                </button>
                              );
                            })}

                            {/* Quick Emoji Picker Drawer Trigger */}
                            <div className="relative">
                              <button
                                type="button"
                                onClick={() => setActiveReactionCommentId(activeReactionCommentId === parentId ? null : parentId)}
                                className="p-1 px-1.5 text-gray-500 hover:text-white hover:bg-white/10 hover:border-white/10 border border-transparent rounded-lg transition-all cursor-pointer"
                                title="Reações rápidas"
                              >
                                <Smile size={10.5} />
                              </button>

                              {activeReactionCommentId === parentId && (
                                <div className="absolute left-0 bottom-8 z-50 bg-[#000000] border border-white/10 p-1.5 rounded-xl shadow-2xl flex items-center gap-2 animate-in slide-in-from-bottom-2 duration-150">
                                  {['🔥', '🎧', '💯', '🚀', '😮'].map(emoji => (
                                    <button
                                      key={emoji}
                                      type="button"
                                      onClick={() => handleReactComment(parentId, emoji)}
                                      className="p-1.5 hover:bg-white/10 rounded-lg active:scale-90 text-[12px] transition-all cursor-pointer"
                                    >
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Producer Pin action button */}
                            {isBeatOwner && (
                              <button
                                type="button"
                                onClick={() => handlePinComment(parentId)}
                                className={`p-1 px-1.5 rounded-lg border transition-all cursor-pointer ${
                                  parent.is_pinned
                                    ? 'bg-amber-505/10 text-amber-500 border-amber-500/20'
                                    : 'text-gray-500 hover:text-amber-500 border-transparent hover:border-amber-500/20 hover:bg-white/5'
                                }`}
                                title={parent.is_pinned ? "Desafixar do topo" : "Fixar no topo"}
                              >
                                <Pin size={10.5} className={parent.is_pinned ? 'fill-amber-500 text-amber-500' : ''} />
                              </button>
                            )}

                            {/* Share button */}
                            <button
                              type="button"
                              onClick={() => handleCopyCommentLink(parentId)}
                              className="p-1 px-1.5 text-gray-500 hover:text-purple-400 hover:bg-white/5 border border-transparent hover:border-white/5 rounded-lg transition-all cursor-pointer"
                              title="Copiar link do comentário"
                            >
                              <Copy size={10} />
                            </button>

                            {/* Reply toggle */}
                            {user && (
                              <button
                                type="button"
                                onClick={() => {
                                  setReplyingToId(replyingToId === parentId ? null : parentId);
                                  setReplyContent('');
                                }}
                                className="text-[8px] text-purple-400 hover:text-purple-300 font-extrabold uppercase tracking-widest cursor-pointer leading-none px-2 py-1 rounded bg-purple-500/10 hover:bg-purple-500/20 transition-all ml-1.5"
                              >
                                {replyingToId === parentId ? 'Cancelar' : 'Responder'}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Reply Form */}
                      {replyingToId === parentId && (
                        <div className="pl-8 pt-1 animate-in slide-in-from-top-1 duration-200">
                          <form onSubmit={(e) => handleAddReply(e, parentId)} className="flex items-center gap-2 bg-[#050508] border border-purple-500/20 rounded-xl p-1 focus-within:border-purple-500/50 transition-colors shadow-inner">
                            <input
                              type="text"
                              value={replyContent}
                              onChange={(e) => setReplyContent(e.target.value)}
                              placeholder={`Responde a @${parentUsername}... e menciona outros membros com @`}
                              maxLength={400}
                              className="flex-grow bg-transparent border-none text-[11px] text-white px-2 py-1.5 outline-none placeholder-gray-600 focus:ring-0"
                            />
                            <button
                              type="submit"
                              disabled={!replyContent.trim()}
                              className="p-2 bg-purple-600 hover:bg-purple-500 disabled:bg-purple-900/40 text-white rounded-lg transition-all text-xs cursor-pointer flex items-center justify-center shrink-0 disabled:opacity-30"
                            >
                              <Send size={10} />
                            </button>
                          </form>
                        </div>
                      )}

                      {/* Nested replies threads */}
                      {threadReplies.length > 0 && (
                        <div className="pl-6 space-y-2 border-l border-white/5 mt-2">
                          {threadReplies.map((reply) => {
                            const replyId = reply.id;
                            const replyAvatar = reply.author_avatar || '';
                            const replyName = reply.author_name || reply.author || 'Membro';
                            const replyUsername = reply.author_username || reply.username || 'membro';
                            const isReplyVerified = reply.is_verified === true;
                            const isReplyOwner = user && String(reply.user_id) === String(user.id);
                            const isReplyCreator = String(reply.user_id) === String(beat.producer_id);

                            return (
                              <div 
                                key={replyId} 
                                className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition-all ${
                                  isReplyCreator 
                                    ? 'border-purple-500/25 bg-[#0D0A13]/60 shadow-[0_0_12px_rgba(168,85,247,0.04)] text-left' 
                                    : 'bg-white/[0.005] border-white/[0.02]'
                                }`}
                              >
                                <CornerDownRight size={10} className="text-gray-600 shrink-0 mt-2" />
                                
                                <div className="relative shrink-0">
                                  <div 
                                    className="w-6 h-6 rounded-full overflow-hidden bg-purple-500/5 border border-purple-500/20 flex items-center justify-center cursor-pointer"
                                    onClick={() => onSelectProducer(replyUsername)}
                                    onMouseEnter={() => setHoveredProfileUsername(replyUsername)}
                                    onMouseLeave={() => setHoveredProfileUsername(null)}
                                  >
                                    {replyAvatar ? (
                                      <img
                                        src={replyAvatar.startsWith('http') || replyAvatar.startsWith('/') || replyAvatar.startsWith('data:') ? replyAvatar : getPublicUrl('avatars', replyAvatar)}
                                        alt={replyName}
                                        className="w-full h-full object-cover"
                                        referrerPolicy="no-referrer"
                                      />
                                    ) : (
                                      <span className="text-[8px] font-semibold text-purple-400 uppercase tracking-tighter">
                                        {replyName.slice(0, 2).toUpperCase()}
                                      </span>
                                    )}
                                  </div>

                                  {/* Reply Mini Hovercard wrapper */}
                                  {hoveredProfileUsername === replyUsername && (
                                    <div 
                                      className="absolute left-0 top-8 w-64 bg-[#000000]/95 backdrop-blur-xl border border-white/10 rounded-2xl p-4 shadow-[0_15px_40px_rgba(0,0,0,0.85)] flex flex-col gap-3 pointer-events-auto text-left leading-normal z-50 transform origin-top-left transition-all duration-200"
                                      onMouseEnter={() => setHoveredProfileUsername(replyUsername)}
                                      onMouseLeave={() => setHoveredProfileUsername(null)}
                                    >
                                      <div className="flex gap-3 items-center">
                                        <div className="w-10 h-10 rounded-full overflow-hidden bg-purple-500/5 border border-purple-500/20 flex items-center justify-center shrink-0">
                                          {replyAvatar ? (
                                            <img src={replyAvatar.startsWith('http') || replyAvatar.startsWith('/') || replyAvatar.startsWith('data:') ? replyAvatar : getPublicUrl('avatars', replyAvatar)} className="w-full h-full object-cover" alt={replyName} />
                                          ) : (
                                            <span className="text-[10px] font-black text-purple-400">{replyName.slice(0, 2).toUpperCase()}</span>
                                          )}
                                        </div>
                                        <div className="min-w-0">
                                          <h4 className="text-xs font-black text-white uppercase tracking-tight flex items-center gap-1">
                                            {replyName}
                                            {isReplyVerified && <VerifiedBadge size="sm" />}
                                          </h4>
                                          <p className="text-[10px] text-gray-400 font-mono">@{replyUsername}</p>
                                        </div>
                                      </div>

                                      <div className="grid grid-cols-3 gap-2 border-y border-white/5 py-2.5 my-1 text-center font-mono">
                                        <div>
                                          <p className="text-[10.5px] font-black text-white">{(replyUsername.split('').reduce((acc: number, c: string) => acc + c.charCodeAt(0), 0) % 150) * 8 + 32}</p>
                                          <p className="text-[7px] font-black text-gray-500 uppercase leading-none">Seguidores</p>
                                        </div>
                                        <div>
                                          <p className="text-[10.5px] font-black text-white">{(replyUsername.split('').reduce((acc: number, c: string) => acc + c.charCodeAt(0), 0) % 12) + 2}</p>
                                          <p className="text-[7px] font-black text-gray-500 uppercase leading-none">Beats</p>
                                        </div>
                                        <div>
                                          <p className="text-[10.5px] font-black text-amber-500 leading-none">
                                            {["Kizomba", "Ghetto Zouk", "Tarraxinha", "Afro House", "Semba", "Kuduro"][(replyUsername.split('').reduce((acc: number, c: string) => acc + c.charCodeAt(0), 0) % 6)]}
                                          </p>
                                          <p className="text-[7px] font-black text-gray-500 uppercase leading-none mt-1">Top Gênero</p>
                                        </div>
                                      </div>

                                      <button
                                        type="button"
                                        onClick={() => onSelectProducer(replyUsername)}
                                        className="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-[9px] font-black uppercase tracking-widest transition-all text-center cursor-pointer"
                                      >
                                        Ver Perfil
                                      </button>
                                    </div>
                                  )}
                                </div>

                                <div className="flex-1 min-w-0 font-normal">
                                  <div className="flex items-center justify-between gap-2 leading-none mb-1">
                                    <button 
                                      type="button"
                                      onClick={() => onSelectProducer(replyUsername)}
                                      className="text-left cursor-pointer"
                                    >
                                      <span className={`text-[10px] font-extrabold hover:text-amber-500 transition-colors uppercase tracking-tight flex items-center gap-0.5 ${isReplyCreator ? 'text-purple-400' : 'text-[#f1f1f5]'}`}>
                                        {replyName}
                                        {isReplyVerified && <VerifiedBadge size="sm" />}
                                        {isReplyCreator && <span className="ml-1 px-1 bg-purple-500/25 border border-purple-500/40 text-[7px] font-black text-purple-400 rounded uppercase">Produtor</span>}
                                      </span>
                                    </button>
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-[7.5px] font-medium text-gray-500 uppercase tracking-widest">{formatRelativeTimeAO(reply.created_at)}</span>
                                      
                                      {/* Delete check */}
                                      {(isReplyOwner || isBeatOwner) && (
                                        <button
                                          onClick={() => handleDeleteComment(replyId)}
                                          className="text-gray-500 hover:text-red-400 p-0.5 rounded hover:bg-white/5 transition-colors cursor-pointer"
                                          title="Deletar Resposta"
                                        >
                                          <Trash2 size={8} />
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex items-start gap-2 flex-wrap pb-0.5">
                                    {reply.timestamp_seconds !== null && reply.timestamp_seconds !== undefined && (
                                      <button
                                        onClick={() => {
                                          const customEvent = new CustomEvent('replacePlayerQueue', {
                                            detail: {
                                              beats: [beat],
                                              playFirst: true
                                            }
                                          });
                                          window.dispatchEvent(customEvent);
                                          setTimeout(() => {
                                            const audioEl = document.querySelector('audio') as HTMLAudioElement | null;
                                            if (audioEl) {
                                              audioEl.currentTime = reply.timestamp_seconds;
                                              audioEl.play().catch(console.warn);
                                            }
                                          }, 150);
                                        }}
                                        className="inline-flex items-center gap-1 text-[8.5px] bg-amber-500/10 hover:bg-amber-500 hover:text-black border border-amber-500/20 px-1 py-0.2 rounded font-mono font-black text-amber-500 cursor-pointer transition-all active:scale-95 shadow-sm shrink-0"
                                        title="Saltar para este momento"
                                      >
                                        {Math.floor(reply.timestamp_seconds / 60)}:{(reply.timestamp_seconds % 60).toString().padStart(2, '0')}
                                      </button>
                                    )}
                                    <p className="text-xs text-neutral-400 font-medium leading-relaxed">{renderContentWithMentions(reply.content)}</p>
                                  </div>

                                  {/* Sub replies interactive reactions list */}
                                  <div className="flex items-center gap-1.5 pt-1">
                                    <button
                                      type="button"
                                      onClick={() => handleLikeComment(replyId)}
                                      className={`inline-flex items-center gap-1 text-[8.5px] px-1.5 py-0.5 rounded transition-all cursor-pointer font-bold ${
                                        reply.likes?.includes(user?.id) 
                                          ? 'bg-rose-500/15 text-rose-500' 
                                          : 'text-gray-500 hover:text-white'
                                      }`}
                                    >
                                      <Heart size={8} className={reply.likes?.includes(user?.id) ? 'fill-rose-500 stroke-rose-400' : ''} />
                                      <span>{reply.likes?.length || 0}</span>
                                    </button>

                                    {reply.reactions && Object.entries(reply.reactions).map(([emoji, userList]: any) => {
                                      if (!userList || userList.length === 0) return null;
                                      const reactedByMe = user?.id && userList.includes(user.id);
                                      return (
                                        <button
                                          key={emoji}
                                          type="button"
                                          onClick={() => handleReactComment(replyId, emoji)}
                                          className={`inline-flex items-center gap-1 text-[8px] px-1.5 py-0.5 rounded font-extrabold ${
                                            reactedByMe ? 'bg-purple-500/15 text-purple-400' : 'text-gray-500 hover:text-purple-400'
                                          }`}
                                        >
                                          <span>{emoji} {userList.length}</span>
                                        </button>
                                      );
                                    })}

                                    <div className="relative">
                                      <button
                                        type="button"
                                        onClick={() => setActiveReactionCommentId(activeReactionCommentId === replyId ? null : replyId)}
                                        className="p-0.5 text-gray-500 hover:text-white rounded"
                                      >
                                        <Smile size={9.5} />
                                      </button>
                                      {activeReactionCommentId === replyId && (
                                        <div className="absolute left-0 bottom-6 bg-[#000000] border border-white/10 p-1 rounded-lg shadow-2xl flex items-center gap-1.5 z-50 animate-in slide-in-from-bottom-2 duration-150">
                                          {['🔥', '🎧', '💯', '🚀', '😮'].map(emoji => (
                                            <button
                                              key={emoji}
                                              type="button"
                                              onClick={() => handleReactComment(replyId, emoji)}
                                              className="p-1 hover:bg-white/10 rounded text-[10px]"
                                            >
                                              {emoji}
                                            </button>
                                          ))}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right Area (4 cols): Producer Info & Related Beats */}
        <div className="lg:col-span-4 space-y-12">
          {/* Producer Profile Mini Card Details */}
          <div className="p-6 bg-white/[0.02] border border-white/5 rounded-[2.5rem] space-y-6">
            <h4 className="text-xs font-black text-gray-500 uppercase tracking-widest italic">Produtor</h4>
            
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full overflow-hidden bg-white/[0.03] border border-white/10 flex items-center justify-center shrink-0">
                {producerAvatar && 
                 !producerAvatar.includes('photo-1516280440614-37939bbacd81') && 
                 !producerAvatar.includes('placeholder') && 
                 !producerAvatar.includes('default') ? (
                  <img 
                    src={producerAvatar.startsWith('http') ? producerAvatar : getPublicUrl('avatars', producerAvatar)} 
                    className="w-full h-full object-cover" 
                    alt={beat.producer} 
                  />
                ) : (
                  <span className="text-sm font-black text-gray-300 uppercase tracking-tighter">
                    {beat.producer ? beat.producer.slice(0, 2).toUpperCase() : 'BT'}
                  </span>
                )}
              </div>
              <div className="min-w-0 flex-grow">
                <h5 className="font-extrabold text-white text-lg truncate leading-tight flex items-center gap-1.5">
                  <span>{beat.producer}</span>
                  {isProducerVerified && (
                    <VerifiedBadge size="md" />
                  )}
                </h5>
                <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Luanda, Angola</span>
              </div>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              Explore o perfil completo de @{beat.producer} para descobrir o seu portfólio completo de produções originais na BATUKADA.
            </p>

            <button
              onClick={() => onSelectProducer(beat.producer)}
              className="w-full py-4 text-center rounded-2xl bg-white/5 border border-white/10 font-black text-[10px] uppercase tracking-widest text-white hover:bg-white hover:text-black transition-colors"
            >
              Ver Perfil Completo
            </button>
          </div>

          {/* Related Beats lists */}
          <div className="space-y-6">
            <h4 className="text-xs font-black text-gray-500 uppercase tracking-widest italic flex items-center gap-2">
              <Music size={14} className="text-indigo-500" /> Sons Semelhantes Inteligentes
            </h4>

            <div className="grid grid-cols-1 gap-4">
              {finalRelatedBeats.length === 0 ? (
                <div className="p-6 text-center border border-dashed border-white/5 rounded-2xl text-xs text-gray-500">
                  Nenhum som semelhante encontrado.
                </div>
              ) : (
                finalRelatedBeats.map((relatedBeat) => (
                  <div 
                    key={relatedBeat.id}
                    onClick={() => {
                      recommendationService.trackClick(relatedBeat.id, 'similar_beats', user?.id);
                    }}
                  >
                    <BeatCard
                      beat={relatedBeat}
                      isPlaying={currentBeat?.id === relatedBeat.id && isPlaying}
                      onPlay={onPlay}
                      onAddToCart={onAddToCart}
                      onSelectProducer={onSelectProducer}
                      onSelectBeat={onSelectBeat}
                    />
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* DISCOVERY ADD-ON SECTIONS - HIGH END DESIGNS */}
      <div className="mt-16 border-t border-white/5 pt-12 space-y-16">
        {/* SECTION 1: More from the producer */}
        <div className="space-y-6 text-left">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-2">
            <div>
              <span className="text-[10px] uppercase font-black tracking-widest text-[#5865F2]">Catálogo de Criações</span>
              <h3 className="text-xl md:text-2xl font-black italic uppercase text-white tracking-tight mt-1 flex items-center gap-2">
                <Sparkles size={18} className="text-amber-500" /> Mais de {beat.producer}
              </h3>
            </div>
            <button
              onClick={() => onSelectProducer(beat.producer)}
              className="text-xs font-bold text-[#5865F2] hover:text-white transition-colors cursor-pointer text-left"
            >
              Explorar todo o portfólio de {beat.producer} →
            </button>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {moreProducerBeats.length === 0 ? (
              <div className="col-span-full p-8 text-center border border-dashed border-white/5 rounded-3xl text-xs text-gray-500">
                Apenas este beat disponível de {beat.producer} atualmente.
              </div>
            ) : (
              moreProducerBeats.map((b) => (
                <div 
                  key={b.id}
                  onClick={() => {
                    recommendationService.trackClick(b.id, 'more_from_producer', user?.id);
                  }}
                  className="hover:scale-[1.01] transition-transform duration-350"
                >
                  <BeatCard
                    beat={b}
                    isPlaying={currentBeat?.id === b.id && isPlaying}
                    onPlay={onPlay}
                    onAddToCart={onAddToCart}
                    onSelectProducer={onSelectProducer}
                    onSelectBeat={onSelectBeat}
                  />
                </div>
              ))
            )}
          </div>
        </div>

        {/* SECTION 2: You may also like */}
        <div className="space-y-6 text-left">
          <div>
            <span className="text-[10px] uppercase font-black tracking-widest text-[#5865F2]">Feito Para Ti</span>
            <h3 className="text-xl md:text-2xl font-black italic uppercase text-white tracking-tight mt-1 flex items-center gap-2">
              <TrendingUp size={18} className="text-[#5865F2]" /> Também Poderás Gostar
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {youMayAlsoLikeBeats.slice(0, 4).map((b) => (
              <div 
                key={b.id}
                onClick={() => {
                  recommendationService.trackClick(b.id, 'you_may_also_like', user?.id);
                }}
                className="hover:scale-[1.01] transition-transform duration-350"
              >
                <BeatCard
                  beat={b}
                  isPlaying={currentBeat?.id === b.id && isPlaying}
                  onPlay={onPlay}
                  onAddToCart={onAddToCart}
                  onSelectProducer={onSelectProducer}
                  onSelectBeat={onSelectBeat}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Reusable Report Modal */}
      {isReportModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-gray-950 border border-white/10 rounded-[2rem] w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-6 border-b border-white/5 bg-gradient-to-r from-red-600/10 to-transparent">
              <div className="flex items-center gap-2.5">
                <Flag className="text-red-500 shrink-0" size={20} />
                <h3 className="text-lg font-black italic uppercase tracking-tighter text-white">
                  Enviar Denúncia
                </h3>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Contribui para uma comunidade transparente e profissional na BATUKADA.
              </p>
            </div>

            <div className="p-6 space-y-4">
              <div className="bg-white/[0.02] border border-white/5 rounded-xl p-3 text-xs text-gray-400">
                <span className="font-bold text-white block uppercase tracking-wider text-[9px] mb-1">Alvo da Denúncia:</span>
                <p className="font-mono leading-tight">{reportType === 'beat' ? `Música: "${beat.title}"` : `Comentário: "${reportTargetName.slice(0, 60)}${reportTargetName.length > 60 ? '...' : ''}"`}</p>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase text-gray-500 tracking-widest">Motivo</label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value as any)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-xs text-white uppercase font-black tracking-widest outline-none focus:border-red-500/50 cursor-pointer"
                >
                  <option value="copyright">Violação de Direitos de Autor / Copyright</option>
                  <option value="stolen_beat">Beat de Origem Roubada ou Copiada</option>
                  <option value="spam">Spam / Publicidade Abusiva</option>
                  <option value="inappropriate">Assédio / Ofensa / Difamação</option>
                  <option value="scam">Fraude / Phishing / Engano comercial</option>
                  <option value="other">Outro Motivo</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase text-gray-500 tracking-widest">Detalhes e Justificação</label>
                <textarea
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="Por favor, introduz argumentos detalhados (links, registos de propriedade, marcas de tempo, etc.)."
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-xs text-white placeholder:text-gray-600 outline-none focus:border-red-500/50 h-24 resize-none font-medium leading-relaxed"
                />
              </div>
            </div>

            <div className="p-6 bg-white/[0.01] border-t border-white/5 flex gap-2 justify-end">
              <button
                onClick={() => { setIsReportModalOpen(false); setReportDetails(''); }}
                className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-[#E6E6E6] hover:bg-white/5 rounded-lg border border-white/10"
              >
                Cancelar
              </button>
              <button
                onClick={handleSendReport}
                disabled={!reportDetails.trim()}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 disabled:opacity-50 disabled:hover:bg-red-600 text-white font-bold uppercase tracking-widest text-[10px] rounded-lg shadow-md shadow-red-900/20 max-w-fit active:scale-95 transition-all text-center flex items-center justify-center cursor-pointer"
              >
                Enviar Denúncia
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
