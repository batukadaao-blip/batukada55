
import React, { useState, useEffect } from 'react';
import { BarChart, Edit2, Trash2, Music, UploadCloud, Sparkles } from 'lucide-react';
import { getSupabase, getPublicUrl } from '@/src/lib/supabase';
import AdicionarBeatModal from './AdicionarBeatModal';
import { useToast } from '@/src/context/ToastContext';
import { useAuth } from '@/src/context/AuthContext';
import { playService } from '@/src/lib/playService';

export default function MeusBeats({ onSelectEstatisticas, onAddBeat }: { onSelectEstatisticas: (beatId: string) => void, onAddBeat?: () => void }) {
  console.log('PARENT COMPONENT RENDER');
  const { user } = useAuth();
  const [beats, setBeats] = useState<any[]>([]);
  const [editingBeat, setEditingBeat] = useState<any>(null);
  const [isDeleting, setIsDeleting] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { showToast } = useToast();

  async function fetchBeats() {
      console.log('fetchBeats: fetching from Supabase...');
      setIsLoading(true);
      const supabase = getSupabase();
      if (!supabase || !user) {
          setIsLoading(false);
          setBeats([]);
          return;
      }
      
      const { data, error } = await supabase.from('beats').select('id, title, producer_id, producer_name, artist_name, genre, tags, price_basic, price_premium, price_exclusive, cover_url, plays_count, bpm, key, scale, demo_url, master_url, description, type, category, status, created_at, updated_at').eq('producer_id', user.id);
      
      console.log('AUTH USER:', user);
      console.log('RAW BEATS:', data);
      
      if (error) {
          console.error('fetchBeats: error', error);
      } else {
          const safeData = data || [];
          const mappedBeats = safeData.map(b => {
              const audioUrl = b.demo_url ? getPublicUrl('beats', b.demo_url) : '';
              console.log('BEAT ID:', b.id, 'MASTER PATH:', b.master_url, 'PUBLIC AUDIO URL:', audioUrl);
              
              let extractedKey = b.key;
              let extractedScale = b.scale;
              if (b.tags && Array.isArray(b.tags)) {
                const kt = b.tags.find((t: string) => t.startsWith('_key:'));
                if (kt) extractedKey = kt.split(':')[1];
                const st = b.tags.find((t: string) => t.startsWith('_scale:'));
                if (st) extractedScale = st.split(':')[1];
              }
              const cleanTags = b.tags ? b.tags.filter((t: string) => !t.startsWith('_key:') && !t.startsWith('_scale:')) : [];

              return {
                  ...b,
                  id: b.id,
                  title: b.title,
                  producer_id: b.producer_id,
                  producer: b.producer_name || b.artist_name || 'Produtor',
                  producer_name: b.producer_name || b.artist_name || 'Produtor',
                  genre: b.genre,
                  tags: cleanTags,
                  price_basic: b.price_basic || 0,
                  price_premium: b.price_premium || 0,
                  price_exclusive: b.price_exclusive || 0,
                  price: {
                      basic: b.price_basic || 0,
                      premium: b.price_premium || 0,
                      exclusive: b.price_exclusive || 0
                  },
                  cover_url: b.cover_url,
                  image: b.cover_url ? getPublicUrl('beats', b.cover_url) : '',
                  plays_count: playService.getPlayCount(b.id, b.plays_count || 0),
                  audioUrl: audioUrl,
                  audio_url: audioUrl,
                  bpm: b.bpm || 0,
                  key: extractedKey || 'C',
                  scale: extractedScale || 'Maior'
              };
          });

          console.log('CURRENT USER ID:', user.id);
          console.log('PRODUCER BEATS RESULT:', mappedBeats);
          setBeats(mappedBeats);
      }
      setIsLoading(false);
  }

  useEffect(() => {
    fetchBeats();
  }, [user]);

  const deleteBeat = async (beatId: string) => {
    console.log('DELETE FUNCTION STARTED');
    console.log('DELETE BEAT ID:', beatId);
    
    console.log('BEFORE CONFIRM');
    // TEMP TEST
    console.log('CONFIRM BYPASSED');
    console.log('AFTER CONFIRM');
    
    setIsDeleting(beatId);
    
    // Required local beat selection for logging
    const beat = beats.find(b => b.id === beatId) || {};
    const beatProducerId = beat.producer_id || beat.producer;
    
    console.log('DELETE CLICKED:', beatId);
    console.log('AUTH USER:', user);
    console.log('BEAT PRODUCER ID:', beatProducerId);
    console.log('BEAT ID:', beatId);
    
    const supabase = getSupabase();
    if (!supabase) {
      console.error('Supabase instance is not available!');
      setIsDeleting(null);
      return;
    }

    try {
      // 1. Core Simple Supabase Delete Query (WITHOUT .select() to bypass any complex RLS-on-select post-actions)
      console.log('RUNNING DELETE QUERY NOW');
      const { error: deleteError } = await supabase
        .from('beats')
        .delete()
        .eq('id', beatId);

      console.log('DELETE QUERY FINISHED');
      console.log('DELETE ERROR:', deleteError);

      if (deleteError) {
        throw deleteError;
      }

      // 2. Clear files from Storage if found
      console.log('[Storage Cleanup] Attempting storage file cleanup...');
      const filesToDelete = [
        beat.cover_url,
        beat.master_url,
        beat.demo_url,
        beat.stems_url
      ].filter(Boolean);

      if (filesToDelete.length > 0) {
        console.log('Deleting storage files for beat:', filesToDelete);
        const { error: storageError } = await supabase.storage.from('beats').remove(filesToDelete);
        if (storageError) {
          console.warn('Alguns ficheiros podem não ter sido eliminados do storage:', storageError);
        }
      }

      // 3. Update UI state (always filter out from local state to ensure responsive feedback instantly)
      setBeats(prev => prev.filter(b => b.id !== beatId));
      showToast('Beat eliminado com sucesso.', 'success', 'Beat Removido');
      
    } catch (error: any) {
      console.error('Erro ao eliminar beat:', error);
      showToast('Não foi possível eliminar o beat. ' + (error.message || 'Tenta novamente.'), 'error', 'Erro');
    } finally {
      setIsDeleting(null);
    }
  };

  return (
    <div className="p-6 md:py-8 md:pr-10 md:pl-4 space-y-10 animate-in fade-in duration-700">
      {/* Header Area */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-white/5">
        <div>
          <h1 className="text-3xl md:text-4xl font-black text-white uppercase tracking-tighter">Meus Beats</h1>
          <p className="text-gray-500 text-sm font-bold uppercase tracking-widest mt-1">Gerencie os seus ritmos e publicações no marketplace</p>
        </div>
        <button 
          onClick={onAddBeat}
          className="bg-blue-600 hover:bg-blue-500 text-white h-14 px-8 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-blue-600/20 active:scale-95 text-xs border border-blue-500/20"
        >
          {onAddBeat && <span className="text-lg font-light">+</span>} Adicionar Beat
        </button>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div key={n} className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 animate-pulse space-y-4">
              <div className="w-full aspect-video bg-white/5 rounded-2xl" />
              <div className="h-5 bg-white/5 rounded w-2/3" />
              <div className="h-4 bg-white/5 rounded w-1/3 mb-6" />
              <div className="flex gap-2 pt-2">
                <div className="flex-1 h-12 bg-white/5 rounded-xl" />
                <div className="w-12 h-12 bg-white/5 rounded-xl" />
                <div className="w-12 h-12 bg-white/5 rounded-xl" />
              </div>
            </div>
          ))}
        </div>
      ) : beats.length === 0 ? (
        <div className="relative overflow-hidden flex flex-col items-center justify-center py-20 px-6 bg-gradient-to-b from-[#0B0B12] to-[#050508] border border-white/[0.04] rounded-[2.5rem] text-center shadow-2xl group max-w-3xl mx-auto">
          {/* Subtle Decorative Ambient Background Glows */}
          <div className="absolute top-1/2 -left-1/4 -translate-y-1/2 w-72 h-72 bg-blue-500/[0.03] rounded-full blur-[80px] pointer-events-none" />
          <div className="absolute top-1/2 -right-1/4 -translate-y-1/2 w-72 h-72 bg-amber-500/[0.03] rounded-full blur-[80px] pointer-events-none" />

          {/* Icon Badge Stack */}
          <div className="relative mb-6">
            <div className="w-20 h-20 rounded-[2rem] bg-white/[0.02] border border-white/5 flex items-center justify-center text-blue-500 shadow-xl group-hover:scale-105 transition-transform duration-500">
              <UploadCloud size={32} className="stroke-[1.5]" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-lg bg-amber-500 flex items-center justify-center text-black border-2 border-[#050508]">
              <Sparkles size={12} fill="currentColor" />
            </div>
          </div>

          <span className="text-[10px] font-black uppercase tracking-[0.25em] text-blue-500 mb-2">Inicia o teu catálogo de sucesso</span>
          <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter mb-3">
            O teu estúdio está pronto para receber instrumentais!
          </h3>
          <p className="text-gray-400 font-semibold mb-8 text-xs max-w-md leading-relaxed">
            Publica os teus ritmos, define os preços das tuas licenças e partilha a tua arte com milhares de cantores e produtores à procura da tua sonoridade.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-lg mb-10 text-left">
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.04] space-y-1">
              <span className="text-[9px] font-black text-blue-400 uppercase tracking-wider block">Passo 1</span>
              <h4 className="text-xs font-black text-white uppercase tracking-tight">Sobe o Áudio Demo</h4>
              <p className="text-[10px] text-gray-500 font-medium leading-relaxed">Com marca de voz de rádio para protecção total contra roubos de batidas.</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.04] space-y-1">
              <span className="text-[9px] font-black text-amber-500 uppercase tracking-wider block">Passo 2</span>
              <h4 className="text-xs font-black text-white uppercase tracking-tight">Define Licenças</h4>
              <p className="text-[10px] text-gray-500 font-medium leading-relaxed">Define valores claros para downloads básicos, WAV premium ou compras exclusivas.</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.04] space-y-1">
              <span className="text-[9px] font-black text-emerald-400 uppercase tracking-wider block">Passo 3</span>
              <h4 className="text-xs font-black text-white uppercase tracking-tight">Vende com Confiança</h4>
              <p className="text-[10px] text-gray-500 font-medium leading-relaxed">Infraestrutura segura para pagamentos online integrados, com entrega imediata.</p>
            </div>
          </div>

          {onAddBeat && (
            <button 
              onClick={onAddBeat} 
              className="group relative flex items-center justify-center gap-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[11px] transition duration-300 transform hover:scale-[1.02] active:scale-95 shadow-xl shadow-blue-500/10 border border-blue-400/20 cursor-pointer"
            >
              <UploadCloud size={16} strokeWidth={2.5} className="group-hover:translate-y-[-2px] transition-transform" />
              Publicar Primeiro Beat (Upload First Beat)
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {beats.map(beat => (
            <div key={beat.id} className="group bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 hover:border-blue-500/30 rounded-3xl overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(37,99,235,0.05)]">
              <div className="relative aspect-video w-full overflow-hidden bg-white/5">
                <img 
                  src={(beat.cover_url?.includes('http') ? beat.cover_url : (beat.cover_url ? getPublicUrl('beats', beat.cover_url) : beat.image)) || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400'} 
                  alt={beat.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400';
                  }}
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1.5 rounded-full bg-blue-600/95 text-white text-[9px] font-black uppercase tracking-widest leading-none border border-blue-500/20 shadow-md">
                    {beat.bpm} BPM
                  </span>
                </div>
                {beat.key && (
                  <div className="absolute top-4 right-4">
                    <span className="px-3 py-1.5 rounded-full bg-black/80 text-orange-500 text-[9px] font-black uppercase tracking-widest leading-none border border-orange-500/20 shadow-md">
                      {beat.key} {beat.scale}
                    </span>
                  </div>
                )}
              </div>
              
              <div className="p-6">
                <div className="mb-6">
                  <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest block mb-1">
                    {beat.genre}
                  </span>
                  <h3 className="font-black text-xl text-white uppercase tracking-tight truncate">
                    {beat.title}
                  </h3>
                </div>
                
                <div className="flex gap-2">
                  <button 
                    onClick={() => onSelectEstatisticas(beat.id)}
                    className="flex-1 flex items-center justify-center gap-2 text-xs font-black uppercase tracking-wider bg-white/5 border border-white/5 text-gray-300 hover:text-white hover:bg-white/10 transition-all py-3.5 rounded-xl active:scale-95"
                  >
                    <BarChart size={14} /> Estatísticas
                  </button>
                  <button 
                    onClick={() => setEditingBeat(beat)}
                    className="p-3.5 bg-blue-600/10 border border-blue-500/10 text-blue-400 rounded-xl hover:bg-blue-600 hover:text-white transition-all active:scale-95"
                    title="Editar Beat"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => {
                      console.log('DELETE BUTTON CLICKED');
                      deleteBeat(beat.id);
                    }}
                    disabled={isDeleting === beat.id}
                    className="p-3.5 bg-rose-600/10 border border-rose-500/10 text-rose-400 rounded-xl hover:bg-rose-600 hover:text-white transition-all disabled:opacity-50 active:scale-95"
                    title="Eliminar Beat"
                  >
                    <Trash2 size={16} className={isDeleting === beat.id ? "animate-pulse" : ""} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {editingBeat && (
        <AdicionarBeatModal 
          isOpen={!!editingBeat} 
          onClose={() => setEditingBeat(null)} 
          onSuccess={() => { fetchBeats(); setEditingBeat(null); }} 
          mode="edit"
          beatId={editingBeat.id}
          initialData={editingBeat}
        />
      )}
    </div>
  );
}
