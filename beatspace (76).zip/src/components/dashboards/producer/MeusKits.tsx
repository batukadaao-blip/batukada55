
import React, { useState, useEffect } from 'react';
import { Plus, Package, Download, Trash2, Edit2, Eye, Search, Filter, Layers, DollarSign, TrendingUp, Music, BarChart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import AdicionarKitModal from './AdicionarKitModal';
import { getSupabase, getPublicUrl } from '@/src/lib/supabase';
import { useAuth } from '@/src/context/AuthContext';
import { useToast } from '@/src/context/ToastContext';

export default function MeusKits() {
  console.log("[MEUS KITS COMPONENT RENDERED]");
  const { user } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [kits, setKits] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDeleting, setIsDeleting] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const { showToast } = useToast();

  const loadKits = async () => {
    // 1. Optimistic load from localStorage
    let localKits: any[] = [];
    const stored = localStorage.getItem('beatangola_kits');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        localKits = parsed.filter((kit: any) => kit.id !== '1' && kit.title !== 'LUANDA LATE NIGHTS');
        setKits(localKits);
      } catch (e) {
        console.warn('Error parsing beatangola_kits from localStorage:', e);
      }
    }

    // 2. Fetch/sync from database as single source of truth
    const supabase = getSupabase();
    if (!supabase || !user) return;

    try {
      const { data, error } = await supabase
        .from('beats')
        .select('*')
        .eq('producer_id', user.id);

      if (error) {
        console.error('[MEUS KITS] Database fetch error:', error);
        return;
      }

      const databaseKits = (data || [])
        .filter((b: any) => 
          b.category === 'Drum Kit' || 
          b.category === 'Loop Kit' || 
          b.category === 'drum-kit' || 
          b.category === 'loop-kit' || 
          b.category === 'sample-pack' || 
          b.category?.toLowerCase().includes('kit') ||
          b.category?.toLowerCase().includes('pack')
        )
        .map((b: any) => ({
          id: b.id,
          title: b.title,
          description: b.description || '',
          category: b.category === 'drum-kit' ? 'Drum Kit' : b.category === 'loop-kit' ? 'Loop Kit' : b.category === 'sample-pack' ? 'Sample Pack' : (b.category || 'Drum Kit'),
          genre: b.genre || 'All Style',
          price: b.price_basic || 0,
          tags: Array.isArray(b.tags) ? b.tags.join(', ') : (b.tags || ''),
          cover: b.cover_url || '',
          file: b.demo_url || '',
          status: b.status || 'published',
          date: b.created_at ? new Date(b.created_at).toLocaleDateString('pt-AO') : new Date().toLocaleDateString('pt-AO'),
          sales: 0,
          earnings: 0,
          is_free_download: b.price_basic === 0 || b.is_free_download
        }));

      // --- AUTO-HEALING & MIGRATION FOR OLDER MISSED LOCALSTORAGE IDs ---
      let localStorageUpdated = false;
      
      const healedLocalKits = localKits.map((localKit: any) => {
        // Find matching database kit based on multiple properties to prevent mismatched ID issues securely
        const matchingDbKit = databaseKits.find((dbKit: any) => {
          if (String(localKit.id) === String(dbKit.id)) {
            return true;
          }
          
          // ID mismatch - check for exact equivalence via highly safe factors
          const nameMatches = localKit.title?.trim().toUpperCase() === dbKit.title?.trim().toUpperCase();
          if (!nameMatches) return false;

          const localCoverPath = localKit.cover ? getStoragePath(localKit.cover, 'beats') : null;
          const dbCoverPath = dbKit.cover ? getStoragePath(dbKit.cover, 'beats') : null;
          const coverMatches = localCoverPath && dbCoverPath && localCoverPath === dbCoverPath;

          const localFilePath = localKit.file ? getStoragePath(localKit.file, 'beats-private') : null;
          const dbFilePath = dbKit.file ? getStoragePath(dbKit.file, 'beats-private') : null;
          const fileMatches = localFilePath && dbFilePath && localFilePath === dbFilePath;

          const categoryMatches = String(localKit.category || '').toLowerCase() === String(dbKit.category || '').toLowerCase();
          const priceMatches = Math.abs((Number(localKit.price) || 0) - (Number(dbKit.price) || 0)) < 0.01;

          // Equivalence is met if the uppercase title matches alongside file path, cover path, or category + price
          return coverMatches || fileMatches || (categoryMatches && priceMatches);
        });

        if (matchingDbKit && String(localKit.id) !== String(matchingDbKit.id)) {
          console.warn("[KIT ID MISMATCH FIXED]", {
            title: matchingDbKit.title,
            mismatchedLocalId: localKit.id,
            realDatabaseId: matchingDbKit.id
          });
          localStorageUpdated = true;
          return {
            ...localKit,
            id: matchingDbKit.id // Safe migration update to the real SQLite/Postgres DB UUID
          };
        }
        return localKit;
      });

      if (localStorageUpdated) {
        try {
          localStorage.setItem('beatangola_kits', JSON.stringify(healedLocalKits));
          console.log('[MEUS KITS] localStorage "beatangola_kits" updated with healed UUIDs.');
          localKits = healedLocalKits;
        } catch (storageSaveErr) {
          console.error('[MEUS KITS] Failed to write healed kits back to localStorage:', storageSaveErr);
        }
      }
      // -----------------------------------------------------------------

      // Merge by ID prioritizing database source of truth
      const mergedMap = new Map();
      localKits.forEach(k => mergedMap.set(String(k.id), k));
      databaseKits.forEach(k => mergedMap.set(String(k.id), k));

      const merged = Array.from(mergedMap.values());
      console.log("[KITS SOURCE] Loaded merged kits list:", merged);
      setKits(merged);
    } catch (err) {
      console.error('[MEUS KITS] Exception syncing with database:', err);
    }
  };

  const getStoragePath = (urlOrPath: string, bucketName: string): string | null => {
    if (!urlOrPath) return null;
    
    // If it's a full URL
    if (urlOrPath.startsWith('http')) {
      // 1. Check if it contains the bucketName in query Param "path="
      if (urlOrPath.includes('path=')) {
        const parts = urlOrPath.split('path=');
        if (parts.length > 1) {
          const decoded = decodeURIComponent(parts[1].split('&')[0]);
          if (decoded.startsWith(`${bucketName}/`)) {
            return decoded.substring(bucketName.length + 1);
          }
          return decoded;
        }
      }
      
      // 2. Otherwise search for /bucketName/ in URL
      const searchStr = `/${bucketName}/`;
      const index = urlOrPath.indexOf(searchStr);
      if (index !== -1) {
        return decodeURIComponent(urlOrPath.substring(index + searchStr.length));
      }
    }
    
    // If it starts with bucketName/ (e.g. "beats-private/some/path")
    if (urlOrPath.startsWith(`${bucketName}/`)) {
      return urlOrPath.substring(bucketName.length + 1);
    }
    
    // If it starts with another bucket name, it's not for this bucket
    if (urlOrPath.includes('/')) {
      const parts = urlOrPath.split('/');
      if (parts[0] !== bucketName && ['beats', 'beats-private', 'avatars'].includes(parts[0])) {
        return null;
      }
    }
    
    return urlOrPath;
  };

  const handleDeleteKit = async (kitId: string | number) => {
    console.log('[DELETE KIT] kitId:', kitId);
    setIsDeleting(String(kitId));
    
    const supabase = getSupabase();
    if (!supabase) {
      setIsDeleting(null);
      showToast('Erro interno: Supabase não está configurado.', 'error', 'Erro');
      return;
    }

    const isNumericStr = typeof kitId === 'number' || (typeof kitId === 'string' && kitId.trim() !== '' && !isNaN(Number(kitId)));
    const parsedId = isNumericStr ? Number(kitId) : kitId;
    console.log('[DELETE KIT] parsedId based on column expectation:', parsedId);

    try {
      // 1. Diagnose User and Session 
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      console.log('[AUTH USER ID]', currentUser?.id);

      let beatBeforeDelete: any = null;
      let fetchBeforeError: any = null;
      let isUuidTypeMismatch = false;

      // Safe DB pre-fetch wrapped to isolate column type mismatches
      try {
        const { data, error } = await supabase
          .from('beats')
          .select('id, producer_id, title')
          .eq('id', parsedId)
          .maybeSingle();
        
        beatBeforeDelete = data;
        fetchBeforeError = error;

        if (fetchBeforeError) {
          if (fetchBeforeError.code === '22P02' || fetchBeforeError.message?.includes('invalid input syntax for type integer')) {
            console.warn('[DELETE KIT] Legacy UUID used against integer-based DB beats.id. Proceeding with local state cleanup only.');
            isUuidTypeMismatch = true;
          } else {
            console.error('[BEAT DATA FETCH ERROR]', fetchBeforeError);
          }
        }
      } catch (err: any) {
        console.warn('[DELETE KIT] Database Exception catching pre-fetch:', err);
        if (err.code === '22P02' || err.message?.includes('invalid input syntax for type integer')) {
          isUuidTypeMismatch = true;
        }
      }

      console.log('[BEAT DATA]', beatBeforeDelete);

      if (currentUser && beatBeforeDelete) {
        console.log('[COMPARE AUTH VS PRODUCER]', {
          auth_uid: currentUser.id,
          producer_id: beatBeforeDelete.producer_id,
          is_match: currentUser.id === beatBeforeDelete.producer_id
        });
      }

      // Find the kit currently in state to get file/cover references
      const kitToDelete = kits.find(k => String(k.id) === String(kitId));
      
      if (kitToDelete) {
        console.log('[DELETE KIT] Found kit details to clean up files:', kitToDelete);
        
        // Delete Cover image from 'beats' bucket if applicable
        if (kitToDelete.cover) {
          const coverPath = getStoragePath(kitToDelete.cover, 'beats');
          if (coverPath && !coverPath.startsWith('http')) {
            console.log('[DELETE KIT] Attempting to remove cover from "beats" storage path:', coverPath);
            try {
              const { error: coverStorageError } = await supabase.storage
                .from('beats')
                .remove([coverPath]);
              if (coverStorageError) {
                console.warn('[DELETE KIT] Non-blocking storage deletion error for cover:', coverStorageError);
              } else {
                console.log('[DELETE KIT] Cover deleted from storage successfully.');
              }
            } catch (storageErr) {
              console.warn('[DELETE KIT] Exception deleting cover from storage:', storageErr);
            }
          }
        }

        // Delete ZIP pack file from 'beats-private' bucket if applicable
        if (kitToDelete.file) {
          const filePath = getStoragePath(kitToDelete.file, 'beats-private');
          if (filePath && !filePath.startsWith('http')) {
            console.log('[DELETE KIT] Attempting to remove ZIP package from "beats-private" storage path:', filePath);
            try {
              const { error: fileStorageError } = await supabase.storage
                .from('beats-private')
                .remove([filePath]);
              if (fileStorageError) {
                console.warn('[DELETE KIT] Non-blocking storage deletion error for ZIP package:', fileStorageError);
              } else {
                console.log('[DELETE KIT] ZIP package deleted from storage successfully.');
              }
            } catch (storageErr) {
              console.warn('[DELETE KIT] Exception deleting ZIP package from storage:', storageErr);
            }
          }
        }
      }

      let deleteData: any = null;
      let deleteError: any = null;

      // 2. Delete database row securely on the "beats" table if UUID mismatch isn't already active
      if (!isUuidTypeMismatch) {
        console.log('[DELETE KIT] Sending DELETE query to "beats" table for ID:', parsedId);
        try {
          const { data, error } = await supabase
            .from('beats')
            .delete()
            .eq('id', parsedId)
            .select();
          
          deleteData = data;
          deleteError = error;

          if (deleteError) {
            if (deleteError.code === '22P02' || deleteError.message?.includes('invalid input syntax for type integer')) {
              console.warn('[DELETE KIT] Legacy UUID used against integer during delete call. Continuing with local removal.');
              isUuidTypeMismatch = true;
              deleteError = null; // Bypass error for graceful recovery
            } else {
              throw deleteError;
            }
          }
        } catch (err: any) {
          if (err.code === '22P02' || err.message?.includes('invalid input syntax for type integer')) {
            isUuidTypeMismatch = true;
          } else {
            throw err;
          }
        }
      }

      console.log('[DELETE RESULT]', deleteData);
      console.log('[DELETE ERROR]', deleteError);
      
      const finalDeletedCount = deleteData?.length || 0;
      console.log('[ROWS DELETED]', finalDeletedCount);

      if (deleteError) {
        throw deleteError;
      }

      // 3. Remove from local React state (UI updates automatically)
      setKits(prev => prev.filter(k => String(k.id) !== String(kitId)));

      // 4. Delete from localStorage 'beatangola_kits' to prevent sync issues on reload
      try {
        const stored = localStorage.getItem('beatangola_kits');
        if (stored) {
          const parsed = JSON.parse(stored);
          const filtered = parsed.filter((k: any) => String(k.id) !== String(kitId));
          localStorage.setItem('beatangola_kits', JSON.stringify(filtered));
          console.log('[DELETE KIT] Successfully deleted kit from "beatangola_kits" localStorage');
        }
      } catch (storageSaveErr) {
        console.error('[DELETE KIT] Error updating localStorage:', storageSaveErr);
      }

      // 5. Dispatch force refresh event for App.tsx to reload beats from DB bypass-cache
      try {
        window.dispatchEvent(new CustomEvent('beatangola_force_refresh_beats'));
        console.log('[DELETE KIT] Dispatched beatangola_force_refresh_beats custom event.');
      } catch (evtErr) {
        console.warn('[DELETE KIT] Error dispatching custom refresh event:', evtErr);
      }

      showToast('Kit de som removido com sucesso.', 'success', 'Kit Removido');
    } catch (error: any) {
      console.error('[DELETE KIT ERROR]', error);
      showToast('Erro ao remover o kit. ' + (error.message || 'Tente novamente.'), 'error', 'Erro');
    } finally {
      setIsDeleting(null);
    }
  };

  const deleteKit = handleDeleteKit;

  useEffect(() => {
    loadKits();
  }, [user]);

  const totalEarnings = kits.reduce((acc, kit) => acc + (kit.price * (kit.sales || 0)), 0);
  const totalSales = kits.reduce((acc, kit) => acc + (kit.sales || 0), 0);

  const filteredKits = kits.filter(kit => 
    kit.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    kit.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 md:py-8 md:pr-10 md:pl-4 space-y-10 animate-in fade-in duration-700">
      {/* Header Area */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-white/5">
        <div>
          <h1 className="text-3xl md:text-4xl font-black text-white uppercase tracking-tighter">Meus Sound Kits</h1>
          <p className="text-gray-500 text-sm font-bold uppercase tracking-widest mt-1">Gerencie os seus drum kits e pacotes de samples</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-blue-600 hover:bg-blue-500 text-white h-14 px-8 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-blue-600/20 active:scale-95 text-xs border border-blue-500/20"
        >
          <span className="text-lg font-light">+</span> Novo Kit
        </button>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Total Kits', value: kits.length, icon: Layers, color: 'text-blue-500', bg: 'bg-blue-500/10' },
          { label: 'Vendas Totais', value: totalSales, icon: TrendingUp, color: 'text-blue-400', bg: 'bg-blue-500/5' },
          { label: 'Receita Kits', value: `${totalEarnings.toLocaleString()} Kz`, icon: DollarSign, color: 'text-indigo-400', bg: 'bg-indigo-500/5' }
        ].map((stat, i) => (
          <div key={i} className="bg-white/[0.01] hover:bg-white/[0.02] border border-white/5 p-6 rounded-3xl flex items-center gap-6 transition-all">
            <div className={`p-4 rounded-2xl ${stat.bg} ${stat.color}`}>
              <stat.icon size={22} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{stat.label}</p>
              <p className="text-2xl font-black text-white mt-0.5">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600" size={16} />
          <input 
            type="text"
            placeholder="PESQUISAR KITS..."
            className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-4 pl-12 text-xs font-black text-white uppercase tracking-widest outline-none focus:border-blue-500/50 transition-all placeholder:text-gray-600"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
        <button className="bg-white/[0.02] border border-white/5 text-gray-400 px-6 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 hover:text-white transition-all active:scale-95">
          <Filter size={14} className="text-gray-500" />
          Filtrar
        </button>
      </div>

      {/* Kits Card Grid */}
      {filteredKits.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 bg-white/[0.01] border border-white/5 rounded-[2.5rem] p-8 text-center">
          <div className="w-16 h-16 bg-white/[0.02] border border-white/5 rounded-2xl flex items-center justify-center text-gray-500 mb-4">
            <Package size={28} />
          </div>
          <div className="space-y-1 mb-6">
            <p className="text-sm font-black uppercase tracking-wider text-white">Nenhum kit publicado ainda</p>
            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider">Seus kits de som aparecerão nesta seção</p>
          </div>
          <button
            onClick={() => setIsModalOpen(true)}
            type="button"
            className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-black uppercase tracking-widest px-6 py-3.5 rounded-2xl transition-all active:scale-95"
          >
            Publicar Primeiro Kit
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredKits.map((kit) => (
            <div key={kit.id} className="group bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 hover:border-amber-500/30 rounded-3xl overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(245,158,11,0.05)]">
              <div className="relative aspect-video w-full overflow-hidden bg-white/5">
                <img 
                  src={kit.cover && (kit.cover.startsWith('http') || kit.cover.startsWith('data:')) 
                    ? kit.cover 
                    : (kit.cover ? getPublicUrl('beats', kit.cover) : 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400')} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                  alt={kit.title} 
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=400';
                  }}
                />
                
                {/* Price Tag Badge */}
                <div className="absolute top-4 left-4">
                  {kit.is_free_download || kit.price === 0 ? (
                    <span className="px-3 py-1.5 rounded-full bg-blue-600/90 text-white text-[9px] font-bold uppercase tracking-widest leading-none border border-blue-500/20 shadow-md">
                      Grátis
                    </span>
                  ) : (
                    <span className="px-3 py-1.5 rounded-full bg-blue-600/95 text-white text-[9px] font-black uppercase tracking-widest leading-none border border-blue-500/20 shadow-md">
                      {kit.price.toLocaleString()} Kz
                    </span>
                  )}
                </div>

                {/* Category Badge */}
                <div className="absolute top-4 right-4">
                  <span className="px-3 py-1.5 rounded-full bg-black/80 text-amber-500 text-[9px] font-black uppercase tracking-widest leading-none border border-amber-500/20 shadow-md">
                    {kit.category}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <div className="mb-6">
                  <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest block mb-1">
                    {kit.genre}
                  </span>
                  <h3 className="font-black text-xl text-white uppercase tracking-tight truncate">
                    {kit.title}
                  </h3>
                </div>
                
                <div className="flex gap-2 h-12 items-center">
                  {confirmDeleteId === String(kit.id) ? (
                    <div className="flex gap-2 items-center w-full animate-in fade-in zoom-in-95 duration-200">
                      <div className="text-[10px] sm:text-xs font-black text-rose-400 uppercase tracking-wider flex-grow pr-1">
                        Certeza?
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          console.log("[DELETE CANCEL CLICKED]", kit.id);
                          setConfirmDeleteId(null);
                        }}
                        className="px-3.5 py-2.5 bg-white/5 hover:bg-white/10 text-gray-300 font-bold uppercase tracking-wider text-[9px] rounded-xl active:scale-95 transition-all outline-none"
                      >
                        Não
                      </button>
                      <button
                        type="button"
                        style={{
                          pointerEvents: 'auto',
                          position: 'relative',
                          zIndex: 999999
                        }}
                        onMouseDown={() => console.log("[DELETE CONFIRM MOUSE DOWN]", kit.id)}
                        onClick={() => {
                          console.log("[DELETE CONFIRM BUTTON CLICKED]", kit.id);
                          setConfirmDeleteId(null);
                          deleteKit(kit.id);
                        }}
                        disabled={isDeleting === String(kit.id)}
                        className="px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-black uppercase tracking-widest text-[9px] rounded-xl active:scale-95 transition-all border border-rose-500/20 shadow-lg shadow-rose-600/10 outline-none"
                      >
                        Sim
                      </button>
                    </div>
                  ) : (
                    <>
                      <button 
                        type="button"
                        onClick={() => {
                          showToast(`Estatísticas do kit de som: ${kit.sales || 0} Downloads/Vendas.`, 'info', kit.title);
                        }}
                        className="flex-1 flex items-center justify-center gap-2 text-xs font-black uppercase tracking-wider bg-white/5 border border-white/5 text-gray-300 hover:text-white hover:bg-white/10 transition-all py-3.5 rounded-xl active:scale-95"
                      >
                        <BarChart size={14} /> Estatísticas
                      </button>
                      <button 
                        type="button"
                        onClick={() => {
                          showToast('A edição do kit de som estará disponível em breve.', 'info', 'Editar Kit');
                        }}
                        className="p-3 bg-amber-600/10 border border-amber-500/10 text-amber-400 rounded-xl hover:bg-amber-600 hover:text-white transition-all active:scale-95"
                        title="Editar Kit"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        type="button"
                        style={{
                          pointerEvents: 'auto',
                          position: 'relative',
                          zIndex: 999999
                        }}
                        onMouseDown={() => console.log("[DELETE TRIGGER MOUSE DOWN]", kit.id)}
                        onClick={() => {
                          console.log("[DELETE TRIGGER CLICKED]", kit.id);
                          setConfirmDeleteId(String(kit.id));
                        }}
                        disabled={isDeleting === String(kit.id)}
                        className="p-3 bg-rose-600/10 border border-rose-500/10 text-rose-400 rounded-xl hover:bg-rose-600 hover:text-white transition-all disabled:opacity-50 active:scale-95"
                        title="Eliminar Kit"
                      >
                        <Trash2 size={16} className={isDeleting === String(kit.id) ? "animate-pulse" : ""} />
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <AdicionarKitModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        onSuccess={loadKits}
      />
    </div>
  );
}
